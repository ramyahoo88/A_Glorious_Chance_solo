// Compare ordinary play across release builds, without exercising save recovery.
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const { policy } = require('./campaigns');
const make = repo => require(path.resolve(repo,'tools/bundle_engine.js'))();
const updated = make(process.argv[2]);
const previous = make(process.argv[3]);
const firstSeed = Number(process.argv[4] || 520000);
const count = Number(process.argv[5] || 128);
const vitals = { firstSeed, count, games: 0, prompts: 0, match: 0, ties: 0, earlyEnds: 0, decisiveBlockades: 0, minScore: Infinity, maxScore: -Infinity };
function normalized(value) {
  return JSON.parse(JSON.stringify(value).replace(/= ∞:1/g,'= 99:1'));
}
function comparable(s) {
  const { app, build, ...play } = s;
  return normalized(play);
}
for (let i=0;i<count;i++) for (const side of ['US','BR']) for (const style of ['fleet','coast']) {
  const seed=firstSeed+i;
  const opts = { cuttingOut: i%2===0, oa1Upgrades: i%3===0 };
  const a = updated.newGame(side,seed,opts), b = previous.newGame(side,seed,opts);
  updated.run(a); previous.run(b);
  let n=0;
  while (!a.over && n<1500) {
    const details = `${seed}/${side}/${style}, prompt ${n}`;
    assert(a.prompt && b.prompt,details);
    assert.deepEqual(normalized(a.prompt),normalized(b.prompt),details);
    const answer = policy(a,a.prompt,style);
    assert(!updated.validateAnswer(a,a.prompt,answer),details);
    assert(!previous.validateAnswer(b,b.prompt,answer),details);
    updated.act(a, answer); previous.act(b,answer); n++;
  }
  assert(a.over && b.over,`Game did not end for ${seed}/${side}/${style}`);
  assert.deepEqual(comparable(a),comparable(b),`Final boards differ for ${seed}/${side}/${style}`);
  const score = a.vpLog.reduce((total,row)=>total+(row.side==='US'?row.n:-row.n),0);
  assert.equal(a.result.score,score);
  vitals.games++; vitals.match++; vitals.prompts+=n;
  if (a.result.level==='Draw') vitals.ties++;
  if (a.turn<7) vitals.earlyEnds++;
  if (a.result.forced) vitals.decisiveBlockades++;
  vitals.minScore=Math.min(vitals.minScore,score);
  vitals.maxScore=Math.max(vitals.maxScore,score);
}
const record=JSON.stringify(vitals,null,2)+'\n';
fs.writeFileSync(path.join(__dirname,'compare-play-results.json'),record);
console.log(record.trim());
