# A Glorious Chance Solo v0.2.8 re-audit evidence

Reviewed release `ffd7317bf3c41b45d8ad8443073d1e5c47d17c34`, main `67f161f18d689cd6da71a7833484bd48d44b1f1b`, and Pages `ef31610277f09af73e9b6fec91246457b044ecdf`. The four shipped copies and the separate rebuild contain 308,978 bytes. SHA-256 is `386ef169acf1f508e1fe4eca3fff028f55d6ca86089170c1bd51601268ee9793`. Rule citations, source lines and proposed fixes are in `audit.md`. The author's response is available in GitHub under `audits/2026-11-18-v0.2.7/`.

## Import the witnesses

Open https://ramyahoo88.github.io/A_Glorious_Chance_solo/ and use **Load game** or **Load**. Pick the file or paste the full JSON. Use test games for the comparisons. If the public deployment has advanced, use `dist/index.html` from the pinned commit above.

| File | Result on v0.2.8 |
|---|---|
| `fixtures/V026_saved_after_wrong_Wolfe_repair.json` | The Wolfe warning appears at the pending withdrawal and survives reload. The board is kept. |
| `positions-found/D01_wrong_Wolfe_exported_by_v027.json` | Same altered Wolfe board, saved once more by v0.2.7. It opens without a warning and scores +32 at Tally. |
| `fixtures/F01_fresh_pending_withdrawal.json` | Clean control. Wolfe is still British and pending at withdrawal. The same decisions reach 0. |
| `positions-found/D01_wrong_Asp_exported_by_v027.json` | Old wrongly-rescued Asp, saved once more by v0.2.7. He still belongs to the U.S. and no warning appears. The original `fixtures/V026_saved_after_wrong_Asp_repair.json` does warn. |
| `positions-found/D02_wrong_Wolfe_already_scored_in_v026.json` | Opens at June II Tally, +32. No warning despite the recorded capture before the Strike Check. |
| `positions-found/D02_wrong_Kingston_after_reset_in_v027.json` | Opens at July II ship upgrades, score −7 and British supply −1. The earlier attack is still in the log and the banner is absent. |
| `fixtures/V027_saved_after_E02_old_after_Kingston_Tally.json` | The previous cut of the same Kingston turn. Opens at Tally and warns. |
| `positions-found/D03_legal_deployment_after_correct_v027_repair.json` | Incorrect warning at the July I **AI Deployment** prompt even though B20 legally used the one-Troops row. The force already carries the available marker. |
| `positions-found/D03_legal_deployment_after_confirmation.json` | Same legal deployment, saved after Continue in v0.2.7. No false banner on load. |
| `fixtures/V026_saved_after_wrong_B35_repair.json` | The genuine stale picker still warns in v0.2.8. |
| `positions-found/Chrome_v028_export_with_notice.json` | Open the original B35 warning, then download. The banner is stored in this real Chrome export. |

For Wolfe at **Withdrawal result against you**, choose **Ignore – fight on**, Continue twice, Attack, select Sir Sidney Smith and Confirm, Continue, Attack, then Continue twice to the June II Tally. The clean board scores 0. The altered board from D01 scores +32. To generate the later scored D02 file, follow those steps in v0.2.6 from the already-altered fixture, then Save at Tally.

For D01, create the intermediate export by opening each v0.2.6 damaged fixture in v0.2.7 and choosing Save before any decisions. Both intermediate exports have `build` 0.2.7 and no `migrated` field. The older autosave at the same point reproduces the silence as well under the shipped DOM harness.

For the July II D02 file, open `fixtures/E02_old_after_Kingston_Tally.json` in v0.2.7 and observe the initial warning. Press Continue twice and Save. The following turn's opening carries the score and supply loss.

For D03, load `positions-found/D03_pre_repair_B20_with_spare_marker.json` in v0.2.7. One marker moves into the F7 queue before B20 is consulted. Continue to **AI Deployment**. The single legal marker embarks. Save at this confirmation and again after one Continue. The first file falsely warns in v0.2.8. The second file is the adjacent control. The starting fixture is a focused case derived from the B35 position by replacing B35 with B20 and selecting automatic Force Packages, then performing the old withdrawal action.

## Reproduce the release and audit

Run from the extracted directory using Git, Python 3.12 or later, and Node. `verify_public.py` compares the current HTTP response and reports any subsequent public deployment.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git project
git -C project checkout --detach ffd7317bf3c41b45d8ad8443073d1e5c47d17c34
git -C project worktree add --detach "$PWD/v027" 497721c
git -C project worktree add --detach "$PWD/v026" b7eb835
git -C project worktree add --detach "$PWD/v024" f15cdd3
python compare_release.py project
python verify_public.py project
npm --prefix project test

node next_rules.js project --require-rules
node recheck_engine.js project
node boundary_checks.js project
node edges.js project
node followup_rules.js project --require-rules
node new_boundaries.js project
node map_checks.js project
node paper_checks.js project
node export_data.js project
python verify_land_aid.py
```

The Target Card comparison also uses the published VASSAL v1.0 module images, Pillow and NumPy. Run `python verify_component_grids.py /path/to/extracted/images` after the data export. Publisher PDFs, components and the project's rulings are identified in `source-manifest.json`.

```sh
npm install --prefix audit-node jsdom@26.1.0
export NODE_PATH="$PWD/audit-node/node_modules"
node recheck_dom.js project
node legacy_dom.js project
node verify_legacy_rake.js project --require-rules
node check_recovery.js project v024 v026 v027
node check_recovery.js project v024 v026 v027 --require-safety
```

The last command is expected to exit 1 on v0.2.8. It reports the two D01 inputs, two D02 inputs, and the D03 false warning. The command before it records the original tests that pass and the new observations. For the legacy Undo check, `fixtures/V024_autosave_with_pre_F7_undo.json` is staged as the same-origin autosave. The shipped v0.2.8 UI resumes it, then Undo and Save produce `positions-found/V028_export_after_legacy_Undo.json` with one due at F7 and build 0.2.8.

```sh
node scan_saves.js project project fresh 191000 512
node scan_saves.js project v027 previous7 191000 512
node scan_saves.js project v026 previous6 191000 512
node scan_saves.js project v024 legacy 191000 512
node scan_saves.js project v024 legacy 300000 3072
node find_natural_deployment.js project v024 v027 300000 3072
node compare_play.js project v026 520000 128
node campaign_controls.js project US 190843 coast
node campaign_controls.js project BR 191073 fleet
```

The saves in the general sweeps are taken directly from uninterrupted games. The historical Pursuit runs choose the expected prize at the original boundary and check later snapshots. The separate natural deployment search looked for the focused D03 repair pattern in ordinary v0.2.4 play and its continuations after the correct v0.2.7 repair. There was no natural D03 witness on those policies and seeds. The 512-play comparison normalizes the intended odds wording and version metadata.

`public-browser-results.json` records the live page imports, banner controls, responsive check, odds, and both full games. `controls-190843.json` and `controls-191073.json` give the exact control sequence. The normal browser tests are desktop Chrome. The 337-pixel case used page zoom, with desktop hardware, and had no horizontal overflow in the tested banner and Load states. The archive includes both actual final downloads under `positions-found/`.
