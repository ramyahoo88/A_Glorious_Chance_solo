# A Glorious Chance Solo
## v0.2.8 release and save recovery re-audit
18 November 2026 · Release commit ffd7317

**Pass for new campaigns. Hold sign-off on full legacy recovery.** The original damaged files trigger the persistent banner, both banner buttons work, and legacy Undo stamps the export. Three additional release boundaries still need work. One can falsely ask you to replay a valid deployment.

| Priority | Finding | Confirmed player effect |
|---|---|---|
| High · D01 | A v0.2.7 autosave or export can hide recognizable v0.2.6 damage. | Wolfe's incorrect capture survives and adds 32 U.S. VP. The improperly rescued Asp still costs Britain its 4-VP capture. Both open silently. |
| High · D02 | Older damage can go undetected after the relevant Encounter or turn ends. | June II already includes Wolfe's 32 VP. At the next turn, the bad Kingston attack still leaves score −7 and British supply −1. Neither save warns. |
| Medium · D03 | A legal Army Support force can trigger a false recovery banner when it embarks. | B20 correctly uses the one-Troops row after F7 repair. Loading the placement confirmation mistakenly demands an earlier save. |

### Release verification
The release branch was at ffd7317bf3c41b45d8ad8443073d1e5c47d17c34. Main was 67f161f18d689cd6da71a7833484bd48d44b1f1b with the author's response documents. Pages was ef31610277f09af73e9b6fec91246457b044ecdf. The separate rebuild, shipped HTML on both refs, Pages branch and anonymous public response matched byte for byte at **308,978 bytes**. Refresh in Chrome showed v0.2.8. [Release commit](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/ffd7317bf3c41b45d8ad8443073d1e5c47d17c34) · [Public companion](https://ramyahoo88.github.io/A_Glorious_Chance_solo/)

`386ef169acf1f508e1fe4eca3fff028f55d6ca86089170c1bd51601268ee9793`

I read the author's response in GitHub alongside the prior audit. The evidence ZIP includes importable descendants, original controls, Chrome results and a runnable check for all three findings. The rulings for this review are in project notes 68 and 72–73. [Author's response](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/67f161f18d689cd6da71a7833484bd48d44b1f1b/audits/2026-11-18-v0.2.7/AGC_v0.2.8_response_to_v0.2.7_reaudit.md) · [Project rulings](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/ffd7317bf3c41b45d8ad8443073d1e5c47d17c34/RULES_NOTES.md#L95)

<!-- page -->
## D01 · Opening in v0.2.7 can hide a prior repair error
**A campaign resumed during the upgrade sequence can still score the wrong prize without guidance.** LC5.3 settles a ship at the end of its own Encounter. Card A05 starts a new Encounter. Project note 68 settles earlier surrenders at the Pursuit boundary, and note 73 requires a recovery notice when a recognizable earlier repair cannot be reversed safely. [British Living Rules](https://www.legionwargames.com/docs/AGC_Living_Rulebook_British_Solo_as_of_7aug2024.pdf) · [Project note 73](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/ffd7317bf3c41b45d8ad8443073d1e5c47d17c34/RULES_NOTES.md#L111)

### Repeat through Save and Load
Open `fixtures/V026_saved_after_wrong_Wolfe_repair.json` in the pinned v0.2.7 HTML, then Save immediately. This writes `build` 0.2.7 and leaves no `migrated` field. No gameplay choices are needed. The included `positions-found/D01_wrong_Wolfe_exported_by_v027.json` came from those exact handlers. Use the file picker in v0.2.8 to compare it with the original v0.2.6 export.

| British seed 191347 · June II, Niagara | v0.2.8 load result |
|---|---|
| Original v0.2.6 export after the bad repair | Wolfe is American, and the red banner identifies the premature capture. |
| Same board exported once in v0.2.7 | Wolfe is still American. The red banner is absent. The owner, pending withdrawal, dice and capture credit are otherwise identical. |

At **Withdrawal result against you**, click **Ignore – fight on**, Continue twice, Attack, select Sir Sidney Smith and Confirm, Continue, Attack, then Continue twice. The silently loaded v0.2.7 export reaches **+32**, including 32 U.S. VP for Wolfe. In the clean v0.2.8 control, his surrender is still pending at this prompt and the same route reaches **0**. This is an existing save error carried forward.

The same route with `positions-found/D01_wrong_Asp_exported_by_v027.json` leaves Asp rescued for the U.S. and shows no warning. The original unwrapped v0.2.6 export warns. Both underlying v0.2.4 Asp saves, opened directly before the faulty repair, produce exactly one British capture under note 68.

### Smallest fix
Run detection without changing ownership or dice for v0.2.7 saves that still show the exact historical contradiction, including those without `migrated`. The current early return skips that entire state. Keep successful repairs and current campaign saves on their usual paths. `src/engine_combat.js:578` · `src/engine_combat.js:579` · `src/engine_combat.js:648` · `src/ui.js:130`

<!-- page -->
## D02 · Finishing the disputed action can hide the evidence from recovery
**An older campaign can retain an invalid scored outcome with no warning even though its saved log still records what happened.** Note 73 calls for identifying recognizable damage without rolling back the board. LC5.3 determines the ship's fate, and F1 books it at Tally. LC5 and F7 hold withdrawn unlaunched Troops out of the available count until reset.

| Load this file in v0.2.8 | What the saved game and log show |
|---|---|
| `positions-found/D02_wrong_Wolfe_already_scored_in_v026.json` | Opens at **Tally – June II**, score +32. The same-turn log records Wolfe captured before his 2 + 1 Strike Check, then credits the capture. There is no recovery notice. |
| `positions-found/D02_wrong_Kingston_after_reset_in_v027.json` | Opens at **A2 British Ship Upgrades**, July II, score −7 and British supply −1. The July I log still contains the early return, Kingston landing and the two-space supply loss. There is no recovery notice. |

For the first file, open the known bad Wolfe save in v0.2.6. Follow the exact D01 combat route, then Save at Tally. The earlier pending cut has the v0.2.8 banner. After the Encounter ends, `encounter` is null, so the next save skips the ship detection even with the contradiction still in the log.

For the Kingston file, open `fixtures/E02_old_after_Kingston_Tally.json` in v0.2.7. It warns on first load. Press Continue twice (through Reset) and Save in July II. The pre-reset v0.2.7 export, `fixtures/V027_saved_after_E02_old_after_Kingston_Tally.json`, does warn in v0.2.8. The post-reset export still has the identical scored loss but opens silently. Both later files were generated by the previous shipped UI and read through Chrome's current file picker.

### Smallest fix
Keep the positive identification rules when the observable history supports them. For Wolfe, compare the saved capture and later Strike Check order for that ship in the same Encounter's log, including after Tally. For Troops, check earlier log turns for the known unresolved legacy withdrawal and deployment before certifying a v0.2.7 export. Preserve any resulting score and ship ownership and retain the banner. The current detector restricts evidence to the active turn, and ship detection also requires an active Encounter. `src/engine_combat.js:585` · `src/engine_combat.js:658` · `src/engine_combat.js:683` · `src/engine_encounter.js:253` · `src/engine_tally.js:11`

<!-- page -->
## D03 · The warned B20 deployment uses a legal row
**A player can be told to discard a valid continuation and replay the same turn.** Under 11.1.2 and the errata, cross-reference the available Troops count at the time you consult the Target Card. At Naval Balance ≤−70, B20 uses **Force Package 7 with one Troops** and is blank with two. A marker that legally embarks is removed from Available. F7 returns the separate unlaunched marker. [Publisher errata](https://www.legionwargames.com/docs/AGC_errata_and_clarifications_rev_13Apr2024.pdf)

### Repeat the adjacent one-marker control
This is a focused position, British seed 185301, July I, Naval Balance −72. The setup uses the original B35 boundary board with B20 as the next Target Card and the normal automatic package selection. Load `positions-found/D03_pre_repair_B20_with_spare_marker.json` in v0.2.7. The game has one legitimate available marker and one that v0.2.4 returned too early. v0.2.7 puts the early marker in the F7 queue and keeps one Available. Continue to **AI Deployment**. B20 uses row 1 and the placed force carries one marker. The board now correctly shows zero Available and one due at F7.

Save there. The included `positions-found/D03_legal_deployment_after_correct_v027_repair.json` is that exact v0.2.7 export. Load it in v0.2.8. Chrome displays the same force and counts, but its red banner attributes the position to a faulty v0.2.6 repair and asks for an earlier save. This route ran the repair in v0.2.7. One **Continue** in v0.2.7 acknowledges the placement and ends the deployment procedure. Its next export, `positions-found/D03_legal_deployment_after_confirmation.json`, opens in v0.2.8 without the false notice. The original, genuinely damaged B35 picker still warns.

### Smallest fix
Distinguish a pending lookup from a force that has embarked. In the active placement confirmation, reconstruct the pre-embarkation count by including markers already carried by that force when comparing its row. That preserves the stale-picker case and the proven real late-repair case. The current check compares the cached pre-embarkation row with the post-embarkation box count. `src/engine_combat.js:687` · `src/engine_combat.js:688` · `src/engine_deploy.js:165` · `src/engine_deploy.js:273` · `src/engine_deploy.js:295`

A supplemental search through 12,288 older scripted games located 12 eligible correct repairs with a marker to spare. Their deterministic continuations produced no natural witness. The focused B20 fixture shows the failure immediately, without assuming its frequency in play.

<!-- page -->
## Retest results and release verdict
All three original damaged exports showed the right banner and preserved the saved data. The banner also returned on the original v0.2.7 B35 and Tally exports. Save, file-picker import, paste, reload, Undo and further play preserved it. Closing Load left it visible. Loading the earlier B35 position cleared it and restored the no-attack Tally. **Keep playing this position** dismissed it without moving the board and stayed dismissed after reload. Both buttons worked at 1,348 and 337 CSS px in desktop Chrome through normal page zoom. The legacy Undo/export using the older autosave in jsdom queued one at F7 and wrote build 0.2.8.

I played both campaigns through scoring in Chrome. U.S. seed 190843 finished in 142 prompts with U.S. 16, British 48, score −32. British seed 191073 finished in 148 prompts with U.S. 57, British 31, score +26. The final downloads and autosave reviews matched exactly. The new Growler surrender restored exactly mid-combat. At Sacket's, 9 vs 0 showed ∞:1 both in the preview and the applied 3:1+ round. Mobile hardware and standalone browser launch remain unverified here.

| Independent sample | Checks | Failures in this sample |
|---|---|---|
| Clean v0.2.6, v0.2.7 and v0.2.8 campaigns, 2,048 per build | 128,127 save validation checks | 0 |
| v0.2.4 campaigns, original and new seed sets, 14,336 games | 8,354 checked prompts and 11,529 Pursuit prize comparisons | 0 |
| Both sides and strategies, 512 paired uninterrupted v0.2.6 and v0.2.8 campaigns | 72,844 prompts and all final boards and ledgers, with version and ∞ text normalized | 0 |

All **232 repository assertions** and **200 smoke campaigns** passed. Prior fixture checks covered exhausted supplies, ties, simultaneous effects, blockade endings, interruption, Intelligence, Rake and damaged-save refusal. These sweeps used plain play or sampled clean saves. The replayed historic upgrade paths above exercise states they do not produce.

### Rules used
British Living Rules (7 August 2024), U.S. Living Rules (13 April 2024 PDF), Living Playbook (6 August 2024), April 2024 errata, Launch and Reset rules, A05 and the printed B20 and B35 layouts. The checks covered all 2,912 deployment cells across 104 cards, 648 Hit Distribution cases across 18 columns, 70 Lake Combat and 60 Convoy Scatter outcomes, and all 538 printed Land Battle outcomes across 15 columns. [Publisher support](https://www.legionwargames.com/legion_AGC_GS.html)

**Unresolved rulings.** The printed Aid VII leaves 62–63 at 0 Long Gun and three Troops unassigned. The app uses Attacker Success. Package 8 first-Force selection and Tactic return timing beyond the demonstrated Rake case remain project interpretations.

**Pass for fresh games. Hold full legacy recovery sign-off.** First preserve the detection of known bad old positions through v0.2.7 and after scoring. Correct the embarkation check before recommending that players replay a lawful turn.
