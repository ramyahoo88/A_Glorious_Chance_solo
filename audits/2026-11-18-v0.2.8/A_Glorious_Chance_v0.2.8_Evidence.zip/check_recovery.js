// Load actual release HTML through its DOM handlers, preserving original save provenance.
const {fs,path,assert,repo,out,launch,st,button,loadText,start}=require('./page_helpers');
const old24=fs.readFileSync(path.resolve(process.argv[3],'dist/index.html'),'utf8');
const old26=fs.readFileSync(path.resolve(process.argv[4],'dist/index.html'),'utf8');
const old27=fs.readFileSync(path.resolve(process.argv[5],'dist/index.html'),'utf8');
const current=JSON.parse(fs.readFileSync(path.join(repo,'package.json'),'utf8')).version;
const fixture=name=>fs.readFileSync(path.join(out,'fixtures',name+'.json'),'utf8');
const result={original:{},buttons:{},undo:{},next:{}};
const proc=t=>t.doc.querySelector('#proc');
const next=t=>button(t,'Continue',proc(t));
const banner=t=>proc(t).querySelector('.banner.recovery')?.textContent||'';
const error=t=>proc(t).querySelector('.err')?.textContent||'';
const storage=t=>t.w.localStorage.getItem('agc_solo_companion_v1');
const score=s=>s.vp.US-s.vp.BR;
const close=t=>{assert.deepEqual(t.errors,[]);t.dom.window.close();};
function exportUI(t, name) {
  button(t,'Save');
  const modal=t.doc.querySelector('#modal');
  const text=modal.querySelector('textarea').value;
  button(t,'Close',modal);
  if(name)fs.writeFileSync(path.join(out,'positions-found',name+'.json'),text);
  return text;
}
const comparable=s=>{
  const c=structuredClone(s);
  for(const field of ['build','recovery','migrated'])delete c[field];
  if(c.encounter&&c.encounter.flagIn&&!Object.keys(c.encounter.flagIn).length)delete c.encounter.flagIn;
  return c;
};
async function importUI(save, html) {
  const host=await launch(null,html);
  start(host,'BR',581917);
  loadText(host,save);
  return host;
}
async function resumeUI(bytes) {
  const host=await launch(bytes);
  button(host,'Continue it');
  return host;
}
function choose(t, prefix) {
  const label=Array.from(proc(t).querySelectorAll('.sel-list label')).find(row=>row.textContent.startsWith(prefix));
  assert(label,'Missing selector '+prefix);
  label.querySelector('input').click();
}
function tallyWolfe(t) {
  button(t,'Ignore – fight on',proc(t)); next(t); next(t); button(t,'Attack',proc(t));
  choose(t,'Sir Sidney Smith'); button(t,'Confirm',proc(t));
  next(t); button(t,'Attack',proc(t)); next(t); next(t);
  assert.equal(st(t).prompt.title,'Tally – June II');
}
function overview(t) {
  const s=st(t);
  const ship=id=>({owner:s.ships[id].owner,encounter:s.encounter?.ships[id]??null,box:s.ships[id].box,credit:s.lossesThisTurn.filter(l=>l.id===id)});
  return {app:s.app,build:s.build||null,migrated:s.migrated||null,turn:s.turn,phase:s.phase,title:s.prompt?.title,score:score(s),britishSupply:s.supply.BR,
    banner:banner(t),warnings:s.recovery||[],message:error(t),wolfe:ship('wolfe'),asp:ship('asp'),available:s.aiTroops.box.filter(m=>m.revealed&&m.troops).length,
    queued:s.troopsReturning.US,aiDeploy:s.calls.filter(f=>f.proc==='aiDeploy').map(f=>({step:f.pc,index:f.L.cell?.row,package:f.L.cell?.v,force:f.L.force,ships:f.L.ships})),
    losses:s.vpLog.filter(entry=>/Wolfe|Asp/.test(entry.why)),rng:s.rng};
}
async function originalCases() {
  for(const [file,notice] of [
    ['V026_saved_after_wrong_Wolfe_repair','Wolfe struck in the current Encounter'],
    ['V026_saved_after_wrong_Asp_repair','Asp struck before the Pursuit'],
    ['V026_saved_after_wrong_B35_repair','already chosen a deployment row'],
    ['V027_saved_after_E01_old_B35_at_package_picker','before the withdrawal'],
    ['V027_saved_after_E02_old_after_Kingston_Tally','that this Tally has scored'],
    ['V027_saved_after_L01_old_already_sailed','before the withdrawal'],
  ]){
    const raw=fixture(file), host=await importUI(raw);
    const before=overview(host);
    assert(before.banner.includes(notice),file);
    assert.deepEqual(comparable(st(host)),comparable(JSON.parse(raw).state),file);
    const resumed=await resumeUI(storage(host)), exported=await importUI(exportUI(host));
    assert.deepEqual(st(host),st(resumed));assert.equal(banner(resumed),banner(host));
    assert.deepEqual(st(host),st(exported));assert.equal(banner(exported),banner(host));
    result.original[file]={notice:before.warnings,unchangedBoard:true,autosave:true,export:true};
    [host,resumed,exported].forEach(close);
  }
  const good=await importUI(fixture('F02_just_after_Asp_pursuit'));
  assert.equal(st(good).ships.asp.owner,'BR');assert.equal(banner(good),'');
  result.original.cleanAsp={owner:'BR',banner:false};close(good);
  const cleanWolfe=await importUI(fixture('F01_fresh_pending_withdrawal'));
  assert.equal(st(cleanWolfe).ships.wolfe.owner,'BR');assert.equal(st(cleanWolfe).encounter.ships.wolfe,'struck');assert.equal(banner(cleanWolfe),'');
  tallyWolfe(cleanWolfe);assert.equal(score(st(cleanWolfe)),0);
  result.original.cleanWolfe={owner:st(cleanWolfe).ships.wolfe.owner,tally:score(st(cleanWolfe)),banner:false};close(cleanWolfe);
}
async function noticeButtonsAndUndo() {
  const host=await importUI(fixture('E01_old_B35_at_package_picker'));
  const warning=banner(host), before=st(host);
  button(host,'Load an earlier save',proc(host));
  assert.match(host.doc.querySelector('#modal h2').textContent,/Load game/);
  button(host,'Close',host.doc.querySelector('#modal'));
  assert.equal(banner(host),warning);
  button(host,'Confirm',proc(host)); // decline empty package; continue forward one legal choice
  assert.equal(banner(host),warning);
  button(host,'↶ Undo');assert.equal(banner(host),warning);assert.deepEqual(st(host),before);
  button(host,'Keep playing this position',proc(host));
  const acknowledged=st(host);
  assert.equal(banner(host),'');assert.deepEqual(comparable(acknowledged),comparable(before));
  const resumed=await resumeUI(storage(host));assert.equal(banner(resumed),'');
  loadText(host,fixture('E01_manual_package_control')); assert.equal(banner(host),'');
  result.buttons={opensLoad:true,cancelKeepsNotice:true,advanceKeepsNotice:true,undoKeepsNotice:true,acknowledgeKeepsBoard:true,acknowledgeSurvivesReload:true,earlierPositionClearsNotice:true};
  [host,resumed].forEach(close);
  const undone=await resumeUI(fixture('V024_autosave_with_pre_F7_undo'));
  button(undone,'↶ Undo');
  const e=JSON.parse(exportUI(undone,'V028_export_after_legacy_Undo')).state;
  assert.equal(e.build,current);assert.equal(e.troopsReturning.US,1);
  result.undo={build:e.build,queued:e.troopsReturning.US,notice:error(undone)};
  close(undone);
}
async function carryThroughV027() {
  for(const ship of ['Wolfe','Asp']) {
    const previous=await importUI(fixture(`V026_saved_after_wrong_${ship}_repair`),old27);
    const name=`D01_wrong_${ship}_exported_by_v027`;
    const exported=exportUI(previous,name);
    assert.equal(st(previous).build,'0.2.7');assert.equal(st(previous).migrated,undefined);
    const candidate=await importUI(exported);
    const autosave=await resumeUI(storage(previous));
    assert.deepEqual(st(candidate),st(autosave));assert.equal(banner(autosave),banner(candidate));
    const atImport=overview(candidate);
    result.next[name]={before:overview(previous),atImport,autosave:overview(autosave)};
    if(ship==='Wolfe') {tallyWolfe(candidate);assert.equal(score(st(candidate)),32);result.next[name].tally=overview(candidate);}
    [previous,candidate,autosave].forEach(close);
  }
  const damaged=await importUI(fixture('V026_saved_after_wrong_Wolfe_repair'),old26);
  tallyWolfe(damaged);
  const late=await importUI(exportUI(damaged,'D02_wrong_Wolfe_already_scored_in_v026'));
  assert.equal(score(st(late)),32);assert.equal(st(late).encounter,null);
  result.next.D02_wrong_Wolfe_already_scored_in_v026={sameBoard:true,atImport:overview(late)};
  assert.deepEqual(comparable(st(damaged)),comparable(st(late)));[damaged,late].forEach(close);
  const earlier=await importUI(fixture('E02_old_after_Kingston_Tally'),old27);
  assert.match(error(earlier),/before the withdrawal/);
  const observedWarning=error(earlier);
  next(earlier);next(earlier);
  assert.equal(st(earlier).turn,3);assert.equal(score(st(earlier)),-7);
  const lateKingston=await importUI(exportUI(earlier,'D02_wrong_Kingston_after_reset_in_v027'));
  result.next.D02_wrong_Kingston_after_reset_in_v027={originalWarning:observedWarning,atImport:overview(lateKingston)};
  [earlier,lateKingston].forEach(close);
}
async function realDeploymentAfterCorrectRepair() {
  // Same board as E01, but B20 has a positive one-Troops cell at this balance.
  const setup=JSON.parse(fixture('E01_manual_package_control'));
  setup.state.targetRow[1].id='B20';
  setup.state.options.manualPackages=false;
  const old=await importUI(JSON.stringify(setup),old24);
  next(old);
  assert.equal(overview(old).available,2);assert.equal(overview(old).queued,0);
  const fixed=await importUI(exportUI(old,'D03_pre_repair_B20_with_spare_marker'),old27);
  assert.equal(overview(fixed).available,1);assert.equal(overview(fixed).queued,1);
  assert.match(error(fixed),/return at F7/);
  const before=overview(fixed);
  for(let i=0;i<8 && st(fixed).prompt.title!=='AI Deployment';i++) next(fixed);
  assert.match(st(fixed).prompt.text,/Troops 1 row.*Force Package #7/);
  assert.match(st(fixed).prompt.text,/Carrying 1 Troops/);
  const applied=overview(fixed);assert.equal(applied.available,0);
  const r=await importUI(exportUI(fixed,'D03_legal_deployment_after_correct_v027_repair'));
  result.next.D03_legal_deployment_after_correct_v027_repair={before,applied,atImport:overview(r)};
  assert.deepEqual(comparable(st(fixed)),comparable(st(r)));
  next(fixed); // Acknowledging the already-deployed force removes the aiDeploy frame.
  const after=await importUI(exportUI(fixed,'D03_legal_deployment_after_confirmation'));
  result.next.D03_legal_deployment_after_confirmation={atImport:overview(after)};
  [old,fixed,r,after].forEach(close);
}
(async()=>{
  fs.mkdirSync(path.join(out,'positions-found'),{recursive:true});
  await originalCases();await noticeButtonsAndUndo();await carryThroughV027();await realDeploymentAfterCorrectRepair();
  fs.writeFileSync(path.join(out,'recovery-results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({original:Object.keys(result.original),buttons:result.buttons,undo:result.undo,
    next:Object.fromEntries(Object.entries(result.next).map(([name,r])=>[name,{title:r.atImport.title,score:r.atImport.score,banner:r.atImport.warnings,tally:r.tally?.score}]))},null,2));
  if(process.argv.includes('--require-safety')) {
    const bad=[];
    for(const name of ['D01_wrong_Wolfe_exported_by_v027','D01_wrong_Asp_exported_by_v027','D02_wrong_Wolfe_already_scored_in_v026','D02_wrong_Kingston_after_reset_in_v027']){
      if(!result.next[name].atImport.banner)bad.push(`${name}: recovery guidance is missing`);
    }
    if(result.next.D03_legal_deployment_after_correct_v027_repair.atImport.banner) bad.push('D03: an already placed and legitimate deployment should not get a recovery warning');
    assert.deepEqual(bad,[]);
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
