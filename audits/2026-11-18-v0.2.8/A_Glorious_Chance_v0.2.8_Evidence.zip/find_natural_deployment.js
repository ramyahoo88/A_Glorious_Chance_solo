// Find a then-correctly repaired legacy game that pays for a legal follow-on deployment.
const fs=require('node:fs'), path=require('node:path'), assert=require('node:assert/strict');
const {policy}=require('./campaigns');
const [current, old, previous, firstArg, countArg]=process.argv.slice(2);
const make=repo=>require(path.resolve(repo,'tools/bundle_engine.js'))();
const historical=make(old), prior=make(previous);
const clone=s=>JSON.parse(JSON.stringify(s));
function validator(repo){
  const {x}=require('./load')(path.resolve(repo));
  x(fs.readFileSync(path.resolve(repo,'src/ui.js'),'utf8'));
  return x('(s)=>({state:checkSaveState(s),notice:(UI.loadNotes||[]).slice()})');
}
const migrate=validator(previous), open=validator(current);
const available=s=>s.aiTroops.box.filter(m=>m.revealed&&m.troops).length;
const first=Number(firstArg||300000), count=Number(countArg||3072);
const found={first,count,started:0,eligibleRepairs:0,witness:null};
outer:for(let i=0;i<count;i++)for(const human of ['BR','US'])for(const style of ['fleet','coast']){
  const seed=first+i, options={cuttingOut:i%2===0,oa1Upgrades:i%3===0};
  const raw=historical.newGame(human,seed,options);historical.run(raw);found.started++;
  for(let j=0;raw.prompt&&!raw.over&&j<1000;j++) {
    const logLength=raw.log.length, answer=policy(raw,raw.prompt,style);
    historical.act(raw,answer);
    const abort=raw.log.slice(logLength).find(row=>/Coastal mission aborted – \d+ Troops marker\(s\) remain available/.test(row.text));
    if(!abort||available(raw)<2)continue;
    const {state:fixed,notice}=migrate(clone(raw));
    if(!notice.some(line=>line.includes('return at F7'))||!available(fixed))continue;
    found.eligibleRepairs++;
    const turn=fixed.turn, route=[], starting=clone(fixed);
    for(let k=0;fixed.turn===turn&&!fixed.over&&k<120;k++){
      const frame=fixed.calls.find(f=>f.proc==='aiDeploy'&&f.L?.cell?.row>available(fixed)&&f.L.force&&fixed.forces[f.L.force]?.troops);
      if(frame){
        const loaded=open(clone(fixed)).state;
        if((loaded.recovery||[]).some(line=>line.includes('changed by version 0.2.6'))){
          assert(!fixed.recovery&&fixed.build==='0.2.7');
          const evidence=path.join(__dirname,'positions-found');fs.mkdirSync(evidence,{recursive:true});
          const write=(name,state)=>fs.writeFileSync(path.join(evidence,`${name}.json`),JSON.stringify({state,undo:[]}));
          write('D03_natural_v024_before_repair',raw);write('D03_natural_v027_correct_repair',starting);write('D03_natural_v027_after_legal_deployment',fixed);
          const saved=clone(fixed), deployment=fixed.forces[frame.L.force];
          prior.act(fixed,policy(fixed,fixed.prompt,style));write('D03_natural_v027_after_confirmation',fixed);
          found.witness={seed,human,style,options,originalPrompt:j+1,turn,abort,startingAvailable:available(starting),startingQueued:starting.troopsReturning[starting.ai],deployment,
            deploymentPrompt:saved.prompt.title,shown:saved.prompt.text,availableAfterEmbarking:available(saved),actualNotice:loaded.recovery,afterConfirmation:(open(clone(fixed)).state.recovery||[]),route};
          break outer;
        }
      }
      const a=policy(fixed,fixed.prompt,style);route.push([fixed.prompt.title,a]);prior.act(fixed,a);
    }
  }
}
const text=JSON.stringify(found,null,2)+'\n';
fs.writeFileSync(path.join(__dirname,'natural-deployment-results.json'),text);console.log(text.trim());
