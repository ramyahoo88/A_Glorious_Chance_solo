const {fs,path,assert,repo,out,launch,ev,st,button,start,step,loadText}=require('./page_helpers');
const {execFileSync}=require('child_process');
const source=path.join(out,'original-saves'),newDir=path.join(out,'new-saves');
const cases={},games=[],fileChecks=[],issues={};
function observation(t){const s=st(t);return {title:s.prompt?.title||'End',rendered:t.doc.querySelector('#proc').textContent.slice(0,1400),side:s.human,supply:s.supply.US,availableAI:s.aiTroops.box.filter(m=>m.troops&&m.revealed).length,pending:s.troopsReturning};}
async function fromFile(t,file){
  button(t,'Load');const inp=t.doc.querySelector('#modal input[type=file]'),f=new t.w.File([fs.readFileSync(file)],path.basename(file),{type:'application/json'});
  Object.defineProperty(inp,'files',{value:[f]});const end=new Promise((resolve,reject)=>{
    const w=t.w,deadline=setTimeout(()=>reject(new Error("FileReader timeout: "+file)),3000),observer=new w.MutationObserver(()=>{
      if(!t.doc.querySelector('#modal').classList.contains('open') || t.doc.querySelector('#modal .err')?.textContent){clearTimeout(deadline);observer.disconnect();resolve();}
    });observer.observe(t.doc.body,{childList:true,subtree:true,characterData:true,attributes:true});});
  inp.dispatchEvent(new t.w.Event('change',{bubbles:true}));await end;
}
async function testOriginal(file){
 const id=file.slice(0,-5),t=await launch();start(t,'BR',185400);const original=st(t);
 const pos=JSON.parse(fs.readFileSync(path.join(source,file))).state;
 await fromFile(t,path.join(source,file));assert.equal(st(t).seed,pos.seed,id+' import');assert.equal(st(t).prompt.title,pos.prompt.title);
 const before=st(t),record=[],snap=()=>record.push(observation(t)),advance=()=>{step(t);snap();};
 advance();const after=st(t);button(t,'↶ Undo');assert.deepStrictEqual(st(t),before,id+' Undo');step(t);assert.deepStrictEqual(st(t),after,id+' replay');
 const rendered=()=>t.doc.querySelector('#proc').textContent;
 if(['N01','C01_blank'].includes(id)){assert(rendered().includes('Convoy Destroyed'));advance();assert(st(t).prompt.title.startsWith('Tally'));assert.equal(st(t).supply.US,1);}
 if(['N02','C02_false_alarm'].includes(id)){advance();assert.equal(st(t).ships.madison.owner,id==='N02'?'US':'BR');advance();assert.equal(st(t).vpLog.filter(v=>v.side==='BR'&&v.why.includes('captur')).reduce((n,v)=>n+v.n,0),id==='N02'?0:32);}
 if(id==='N03'){assert.equal(st(t).ships.melville.steps,2);assert.equal(st(t).cd.BR,before.cd.BR+2);}
 if(id.startsWith('N04_')){advance();if(id==='N04_dis'){assert(rendered().includes('Event Card #9'));assert.equal(st(t).encounter.ships.moira,'in');assert.equal(st(t).ships.moira.steps,1);}else{assert(rendered().includes('Weather Gage recheck'));assert(!st(t).log.some(l=>l.text.includes('new Encounter begins')));}}
 if(id==='N05')assert(rendered().includes('A1/D3W'));
 if(id==='N06_withdraw')advance();
 if(id.startsWith('N06_')){assert.equal(st(t).ships.rg.steps,2);assert.equal(st(t).ships.rg.box,'transit');}
 if(id==='N07_N08'){
   const r=await launch(t.w.localStorage.getItem('agc_solo_companion_v1'));button(r,'Continue it');assert.deepStrictEqual(st(r),st(t));r.dom.window.close();
   const candidate=st(t).prompt.options.find(o=>o.id==='random').label;assert.equal(candidate,'Random ship: Royal George (A)');button(t,candidate);snap();
   assert(st(t).log.some(l=>l.text.includes('Rake: all hits on Royal George')));assert.equal(st(t).deck.tacA.filter(c=>c==='A_rake').length,1);assert(!st(t).tacPlayed.includes('A_rake'));
 }
 if(id==='N09'){assert(rendered().includes('4.5 vs 8'));advance();assert(rendered().includes('4.5 vs 8'));while(!st(t).log.some(l=>l.text.startsWith('Gunnery Round 1:')))advance();assert(st(t).log.find(l=>l.text.startsWith('Gunnery Round 1:')).text.includes('U.S. 4.5 vs British 8'));}
 if(id==='N10'){button(t,'+ Add Force');assert(![...t.doc.querySelector('.asg-force select').options].some(o=>o.value==='CuttingOut'));assert(!st(t).cuttingOutUsed.BR);}
 if(id.startsWith('N11_')){assert(rendered().includes('rides out'));assert.equal(st(t).troopsReturning.BR,1);while(!st(t).prompt.title.startsWith('Reset'))advance();assert.equal(id==='N11_human'?st(t).troops.BR.available:observation(t).availableAI,1);}
 if(id.startsWith('natural_')){
   const data=JSON.parse(fs.readFileSync(path.join(out,'old-stock-examples.json')));
   const side=id==='natural_gale_BR_183050'?'US':Object.values(data).find(v=>v.name===id).change.side;
   assert.equal(st(t).troopsReturning[side],(before.troopsReturning[side]||0)+1,id);
   if(id==='natural_gale_BR_183050'){assert(!st(t).forces.F21);for(const ship of ['rg','moira','oneida','madison','pike'])assert.equal(st(t).ships[ship].box,'transit');}
 }
 assert.deepStrictEqual(t.errors,[]);cases[id]={fileReader:true,undoAndReplay:true,observations:record};t.dom.window.close();
}
async function freshCampaign(side,seed){
 const t=await launch();start(t,side,seed);const trace=[];
 while(!st(t).over&&trace.length<1000){const s=st(t);trace.push({turn:s.turn,phase:s.phase,...step(t)});}
 const s=st(t);assert(s.over);assert.deepStrictEqual(t.errors,[]);assert.equal(s.result.score,s.vpLog.reduce((v,row)=>v+(row.side==='US'?row.n:-row.n),0));
 const counts=trace.reduce((a,e)=>(a[e.kind]=(a[e.kind]||0)+1,a),{});games.push({side,seed,turn:s.turn,score:s.result,counts,errors:t.errors,ledgerVerified:true,trace,vp:s.vp,vpLog:s.vpLog});t.dom.window.close();
}
async function newCases(){
 for(const file of ['W01_B20','W01_natural','W02_Pursuit_struck','C02_ordinary_withdrawal']){
  const t=await launch();start(t,'US',185428);await fromFile(t,path.join(newDir,file+'.json'));assert.equal(st(t).seed,JSON.parse(fs.readFileSync(path.join(newDir,file+'.json'))).state.seed);
  const observations=[];const go=()=>{step(t);observations.push(observation(t));};
  go();if(file.startsWith('W01')){assert.equal(observations[0].availableAI,1);assert.equal(st(t).troopsReturning[st(t).ai],0);
   if(file==='W01_B20'){for(let i=0;i<16&&!st(t).log.some(l=>l.text.includes('Troops launched in Kingston'));i++)go();assert(st(t).log.some(l=>l.text.includes('Troops launched in Kingston')));
     for(let i=0;i<30&&!st(t).prompt.title.startsWith('Tally');i++)go();
     assert(st(t).prompt.title.startsWith('Tally'));assert.equal(st(t).supply.BR,-1);assert.equal(st(t).vp.US-st(t).vp.BR,-7);
   }
  }else {go();if(file.startsWith('W02')){assert.equal(st(t).encounter.ships.beres,'struck');assert(observations.at(-1).rendered.includes('Event Card #9'));}else{assert.equal(st(t).ships.beres.owner,'US');assert(observations.at(-1).rendered.includes('CAPTURED'));}}
  issues[file]={observations,errors:t.errors};assert.deepStrictEqual(t.errors,[]);t.dom.window.close();
 }

 for(const order of ['pass','attack']){
  const t=await launch();start(t,'BR',185428);await fromFile(t,path.join(newDir,'W02_Pursuit_struck.json'));
  let calls=0;const pathTaken=[];
  for(let n=0;n<25&&st(t).ships.beres.box==='lake';n++){
   const game=st(t),p=game.prompt;
   if(p.kind==='choice' && p.title.startsWith('Command Decision') && p.options.some(o=>o.id==='pass')){
    const selected=calls++===0?'pass':order,op=p.options.find(o=>o.id===selected);pathTaken.push([p.title,selected]);
    button(t,op.label,t.doc.querySelector('#proc'));
   } else {pathTaken.push([p.title,'default']);step(t);}
  }
  const game=st(t);assert.equal(game.ships.beres.owner,order==='pass'?'BR':'US',order);
  issues['W02_new_command_'+order]={owner:game.ships.beres.owner,pathTaken,logs:game.log.filter(l=>/Beresford.*(?:rescued|CAPTURED|Struck Colors)/i.test(l.text)).map(l=>l.text)};
  t.dom.window.close();
 }
 // Produce the legacy save by clicking the authentic v0.2.3 release, then exporting through its Save dialog.
 const oldHtml=execFileSync('git',['-C',repo,'show','ff616f1:dist/index.html'],{encoding:'utf8',maxBuffer:2e6});
 const old=await launch(null,oldHtml);start(old,'US',185423);await fromFile(old,path.join(source,'N07_N08.json'));step(old);
 const oldLabel=st(old).prompt.options.find(o=>o.id==='random').label;assert.equal(oldLabel,'A random ship');
 button(old,'Save');button(old,'Copy save text',old.doc.querySelector('#modal'));const save=old.doc.querySelector('#modal textarea').value;
 const legacy=path.join(newDir,'W03_legacy_Rake.json');fs.writeFileSync(legacy,save);old.dom.window.close();
 const now=await launch();start(now,'BR',185424);await fromFile(now,legacy);const shown=st(now).prompt.options.find(o=>o.id==='random').label;
 const record={from:'0.2.3',pendingChoice:shown,options:st(now).prompt.options.map(o=>o.label),fileReader:true};
 button(now,shown);record.applied=st(now).log.find(l=>l.text.startsWith('Rake:')).text;assert.equal(record.applied,'Rake: all hits on Royal George (A).');
 button(now,'↶ Undo');assert.equal(st(now).prompt.options.find(o=>o.id==='random').label,shown);record.undoRestoresLabel=true;record.namedCandidate=shown.includes('Royal George');issues.W03=record;now.dom.window.close();
 for(const name of ['R01_original_v022','R02_original_v022']){
   const t=await launch();start(t,'US',185427);step(t);const s=st(t),before=t.w.localStorage.getItem('agc_solo_companion_v1'),undo=JSON.stringify(ev(t,'UNDO'));
   await fromFile(t,path.join(out,'inputs',name+'.json'));
   if(name.startsWith('R01')){assert.deepStrictEqual(st(t),s);assert.equal(t.w.localStorage.getItem('agc_solo_companion_v1'),before);assert.equal(JSON.stringify(ev(t,'UNDO')),undo);}
   else{assert.notEqual(st(t).seed,s.seed);step(t);assert.deepStrictEqual(st(t).intelligence.US,{card:29,until:3});}
   fileChecks.push({name,passed:true});assert.deepStrictEqual(t.errors,[]);t.dom.window.close();
 }
}
(async()=>{
 for(const file of fs.readdirSync(source).filter(n=>n.endsWith('.json')).sort()) {await testOriginal(file);console.log('Verified '+file);}
 await newCases();await freshCampaign('US',185401);await freshCampaign('BR',185402);
 fs.writeFileSync(path.join(out,'v024-dom-results.json'),JSON.stringify({cases,issues,games,fileChecks},null,2));
 console.log(JSON.stringify({saves:Object.keys(cases).length,issues:Object.keys(issues),games:games.map(g=>[g.side,g.seed,g.score,g.counts])},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
