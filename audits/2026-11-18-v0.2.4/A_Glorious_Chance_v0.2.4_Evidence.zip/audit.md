# A Glorious Chance Solo
## Independent release and rules audit
18 November 2026 · Version 0.2.4 · Release commit f15cdd3

**Verdict. Hold v0.2.4 for rules-faithful play.** All eleven v0.2.3 findings pass their original examples, and both documentation corrections are in place. Two additional cases can change a campaign. A third affects players resuming an older save at one specific choice.

| Priority | Reproduced in the shipped HTML |
|---|---|
| W01 · High | An AI Army Support force withdraws. Its Troops marker immediately becomes available, letting another force embark it and attack Kingston in the same turn. The focused position ended the turn at −7 VP instead of 0. |
| W02 · High | Pursuit starts a new Encounter with Lord Beresford’s earlier surrender still undecided. Changing the second Encounter’s final command from Pass to Attack changes the ship from a British rescue to an American capture. |
| W03 · Low | A save exported by v0.2.3 while Rake awaits a target still hides the random ship’s name in v0.2.4. Fresh decisions correctly name Royal George before the choice. |

**Release identity.** The reviewed release branch is f15cdd39fa3fe93c86e999dee868178703ad2abc. The public-site README update moved main to 80534c1. Only README.md differs between those commits. GitHub Pages serves the root index.html from gh-pages commit fa93310. [Release commit](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/f15cdd39fa3fe93c86e999dee868178703ad2abc) · [Public-site README](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/80534c10b304de2c950d62cf38b9cb481fedca32/README.md) · [Deployment commit](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/fa93310d02e88b4c43712ca71f67853d540ea1ca)

**Build and deployment.** I ran the pinned builder in a separate temporary directory and compared the output with the shipped HTML using cmp. I also read the anonymous HTTP response from GitHub Pages and compared its bytes against the release, main, gh-pages and another clean rebuild. All five copies were identical at 295,018 bytes. Their SHA-256 follows.

`65709398b2964946de21c346c96a2f92aca8decc53e944314196618b67fcca93`

**Reproduce a finding.** Open the pinned dist/index.html, start either campaign, select Load and choose the named JSON from the evidence ZIP. The save fixes the next dice and card draws. Undo returns to the previous state.

**Public play.** The public URL opened directly in desktop Chrome. I played both campaigns from setup through final scoring, checked the rendered score ledgers and reproduced W01–W03 on the live site. Page 7 gives the results and the save/recovery checks. [Open the public companion](https://ramyahoo88.github.io/A_Glorious_Chance_solo/)

<!-- page -->
## W01 · A withdrawn Troops marker can attack again
**Player impact.** A single American Troops marker embarks on Madison at Niagara, withdraws, then embarks on another force and launches at Kingston in the same turn. This adds a Harbor Encounter and a land battle. It changes both players’ scores and reduces British Convoy Supply.

**Expected behavior.** The withdrawal procedure aborts the coastal mission and prevents its Troops from launching that turn. F7 returns unlaunched embarked markers to the Available box. Both solo rulebooks place that return in F7, and project rules notes 23 and 58 specify the same timing. A waiting marker is neither Available nor aboard a ship. At Naval Balance −15 to +15, Target B20 is blank with zero Troops and shows Package 7 with one. Source material includes the original card face, Aid V #7, British and U.S. LC5 withdrawal (p.33) and F7 (p.20).

**Focused position.** Load `new-saves/W01_B20.json`. July I, British player, seed 185301, saved RNG state 1. Wolfe attacks Madison. One American marker is aboard Madison, two remain on the supply track and none is Available. B20 is still in the Target row.

| Player action | Observed result |
|---|---|
| Click Continue once. | British d10 6 becomes 7, D1W. Madison passes Disengagement on 2 and withdraws. Board → Tracks shows one AI Troops available. The F7 queue is zero. Expected zero Available and one queued. |
| Click Continue three more times. | B20 selects the one-Troops row and deploys Force Package 7 to Kingston carrying the returned marker. The zero-Troops row would produce no deployment. |
| Continue six more times to Tally. | The U.S. launches the marker. Roll 45 with 17 Long Gun and one Troops yields Attacker Success. British supply goes from 1 to −1. Britain captures Fair American for 8 VP and the U.S. scores 1 for Lake Control. Signed score −7. |

**Control and ordinary play.** Moving that marker into the F7 queue immediately after withdrawal in the same position produces no Kingston battle, British supply 1, score 0 and exactly one returned marker at F7. In a separate 512-campaign run I observed 19 early returns across 18 games, including both AI sides. No same-turn re-embark appeared in those 512 games. The B20 example demonstrates that consequence in a focused position. For a natural position, load `new-saves/W01_natural.json` and click Continue once. U.S. campaign, seed 186010, fleet policy, September I, decision 115. British Available rises from zero to one during the withdrawal.

**Smallest fix.** In abortCoastalMission, add unlaunched markers for either side to troopsReturning, clear the force’s count and let the existing F7 routine return them once. `src/engine_combat.js:741`, `src/engine_encounter.js:462`, `src/engine_tally.js:148`.

<!-- page -->
## W02 · Pursuit carries a surrender into the next Encounter
**Player impact.** The player can change the ownership of an already-surrendered ship by changing a command in the next Encounter. The ship’s availability and eventual capture VP depend on that later choice.

**Rule.** A05 Pursuit cancels an eligible withdrawal and begins a new Encounter with the same forces. LC5.3 adjudicates Struck Colors ships when their Encounter ends. Read the British Living Rules p.36 left column, the U.S. Living Rules pp.35–36, the printed A05 face and the Playbook p.16 example. Project rule note 62 also excludes struck ships from the new Encounter.

**Reproduce.** Load `new-saves/W02_Pursuit_struck.json`. U.S. player, seed 182304, saved RNG state 15. In North Lake, Oneida attacks Moira. Lord Beresford already has Struck Colors. Click Continue twice. D1W follows d10 2. Moira passes Disengagement and Pursuit starts. Event 9 establishes American Weather Gage in the new Encounter. Beresford is still recorded in the lake with the old Struck Colors state.

**Try both endings from that save.** Continue past Event 9, choose Pass in the Patrol Segment, confirm no Reaction ships and continue to the second Command Decision. Change only that decision.

| Second Command Decision | Fate of the ship that struck earlier |
|---|---|
| Pass | The app rolls d6 4 and rescues Beresford for Britain. |
| Attack, accept the offered lineup and continue through Gunnery | The app awards Beresford to the United States. |

**Expected result.** Resolve the original surrender before Event 9. A choice made after Event 9 must give the same owner from the same starting position. The ordinary-withdrawal control, `new-saves/C02_ordinary_withdrawal.json`, clears the surrender and records a U.S. capture before returning control.

**Unresolved ruling within W02.** LC5.3 assigns automatic and rolled fates to several ways an Encounter can end. It does not expressly classify a withdrawal cancelled by A05. The timing defect can be reproduced under either reading. Whether this example calls for automatic capture or a die roll needs a designer or project ruling.

**Smallest fix.** Reuse the Struck Colors portion of resolveEncounterEnd at the Pursuit boundary, settle each pending ship once using the agreed ruling, then draw the new Weather Gage. Preserve Disengagement recovery and the cleanup of effects that last one Encounter. `src/engine_encounter.js:142`, `src/engine_encounter.js:475`, `src/engine_combat.js:418`.

<!-- page -->
## W03 · An imported Rake decision hides the random ship
**Player impact.** A player who saved while choosing a Rake target in v0.2.3 has to choose the random option blind. A06 allows the player to see that ship and then choose among lead, rear and random.

**Reproduce.** Load `new-saves/W03_legacy_Rake.json`. I generated it through the authentic v0.2.3 Save control while its Rake choice was on screen. U.S. player, seed 182307. The visible options in v0.2.4 identify Wolfe as lead, Earl of Moira as rear and the third option as “A random ship.” Choose that option. The log names Royal George (A). Undo brings back the anonymous option.

**Expected result and control.** Royal George should be named before selection and the same candidate retained after Undo or reload. Import `original-saves/N07_N08.json` and click Continue to enter the same decision in v0.2.4. The third button names Royal George immediately, survives reload, puts the hits on that ship and returns the used Rake card to its deck exactly once. Sources are A06, Playbook p.19 and project rule note 66.

**Smallest fix.** During import or autosave recovery, recognize a pending combat/grRake frame with no stored candidate. Use the saved RNG to pick once and update both the frame and the random option’s label before showing it. Apply that normalization to restored legacy Undo snapshots when they are first displayed. `src/ui.js:59`, `src/ui.js:115`, `src/ui.js:49`, `src/engine_combat.js:312`, `src/engine_combat.js:325`.

### Prior save and Intelligence repairs
**R01.** The damaged original was refused by the file-input handler and by pasted text. The current game, autosave and Undo history remained identical. Separate invalid procedure, ship-step and supply examples were also refused. Undo after a valid import returned to the former game with its own prior Undo history.

**R02.** The original same-turn fixture correctly retained Intelligence. On the eligible next turn, Events 29 and 31 survived nonqualifying Encounters, expired unused at reset, or were consumed by the first qualifying Encounter. I retested the Pursuit boundary and a legacy save without a stored flagship-participation flag.

**General save compatibility.** I opened the original v0.2.0, v0.2.1, v0.2.2 and v0.2.3 pages, advanced a campaign eight decisions in each, exported the save, and imported it into v0.2.4. All four retained their prompt, ships, scores and RNG state, advanced, and could be undone. W03 concerns a pending target choice in one older build.

<!-- page -->
## Previous findings and campaign play
**All eleven previous findings passed their original tests.** I replayed the 18 retained saves through the file-input handler. Each imported successfully and reproduced the same state and RNG after Undo and replay of the first action. All 28 independent rules comparisons passed.

| Earlier finding | Verified v0.2.4 result |
|---|---|
| N01 · Convoy escort | An unmet B02 package and a blank cell both route the unescorted convoy to Scatter. Wolfe’s 22 guns and d10 6 destroy it. The valid two-ship escort still deploys. |
| N02 and N10 · Cutting-Out | A confirmed sighting with no enemy deployment aborts the mission. The paired false alarm still permits Madison’s 32-VP capture. A7 omits an empty port and accepts a port with a Deployable or Make Ready target. |
| N03 and N06 · Ships | A lone hull keeps its strength on shipyard roll 8 while taking the two-point construction delay. Two eligible hulls are damaged. Withdrawal and F7 return Royal George to her printed two-step Reduced face. |
| N04 and N05 · Combat | Moira’s passed Disengagement check admits her to Pursuit at Reduced strength. Her failed check keeps the current sequence. A schooner whose tow has left takes the printed −1, producing A1/D3W. |
| N07, N08 and N09 · Player information | New Rake decisions name and retain their random target. The used card returns once. With Missed Signal, Command Decision, lineup and applied Gunnery all show 4.5 vs 8. |
| N11 · Unlaunched Troops | Original Gale and capture saves retain their markers for F7. Focused last-ship sinkings also return one marker for each campaign. The matched 256 campaigns went from 40 losses in 39 games on v0.2.3 to zero losses on v0.2.4. W01 concerns the timing of an ordinary withdrawal. |
| D01 and D02 · Documentation | README gives the 1–18 ship Hit Distribution coverage. Rule note 57 explains the seeded Package 8 tie and the possibility of an unfilled second force. Both agree with the implementation. |

**Representative play through scoring.** The page-control policy used Army Support at Niagara when it could carry Troops, Patrol otherwise, and a Raid with a Secondary ship when available. U.S. seed 185401 reached September II with 40 U.S. and 22 British VP, a +18 U.S. Marginal Victory. The eight turn contributions were 0, 0, +1, +2, +12, −4, +1 and +6. The page required 25 choices, selections, lineups or assignments and 82 information confirmations. British seed 185402 finished 18–21, score −3, Draw, with 35 such decisions and 90 confirmations. Two additional full page-control campaigns exercised active reload, save, Undo and completed-game review. The ZIP includes the fresh campaigns’ prompt traces and scoring ledgers.

<!-- page -->
## Rules coverage, open questions and release decision
**Sources.** British Solo Living Rules dated 7 August 2024, U.S. Solo Living Rules dated 13 April 2024, Living Playbook dated 6 August 2024, errata revision dated 13 April 2024, VASSAL v1.0 card and map faces, and both 2023 player-aid photographs. I used the full printed page layouts at the material timings and reread both photographs upright, including footnotes and outcome boxes. The earlier comprehensive audit covered both complete books and decks. The input manifest records the exact files. [Publisher support](https://www.legionwargames.com/legion_AGC_GS.html) · [Pinned project rulings](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/f15cdd39fa3fe93c86e999dee868178703ad2abc/RULES_NOTES.md)

| Material | Independent checks |
|---|---|
| Both Target decks | All 104 cards, all four Troops rows and all seven balance columns. The artwork comparison found zero mismatches in 2,912 cells. |
| Player Aids V and VI | All 11 force packages tested with full and empty pools, including #8’s split and troop capacity. All 648 single-hit lookups across 18 columns agreed. |
| Photographed Aid VII | All 15 Long Gun/Troops columns and all 36 dice pairs per column. All 538 printed outcomes agreed. For zero guns and three Troops, the photograph omits 62 and 63. The app assigns Attacker Success. |
| Maps and campaign edges | All 70 Lake Combat and 60 Convoy Scatter cells, gun-band endpoints and both maps’ Naval Balance bands agreed. Exact score thresholds, ties, simultaneous Fall Offensive, dual-blockade victory and the adjacent continuation passed. |

**Tests and limits.** All 180 repository assertions passed (65 unit, 14 scenario, 101 regression), as did 200 repository smoke campaigns and the earlier 22 engine, 23 boundary and 29 extended edge comparisons. The two stock-count runs completed 256 matched and 192 fresh campaigns. Another 512 fresh campaigns specifically monitored withdrawal timing for W01. Both sides and both fleet and coastal policies were exercised. The ordinary runs reached scheduled endings; a focused position exercised the early ending. The policies were designed to exercise rules paths. No balance estimate is inferred.

**Direct UI coverage.** Four full campaigns and the retained save checks ran on the shipped HTML using jsdom 26.1.0 and its actual click handlers. I then replayed two of those campaigns in desktop Chrome on the public site, operated the native file chooser, downloaded saves and checked resumed play. Android touch, home-screen installation, an offline launch of that shortcut and physical-table lookup time remain untested.

**Rulings and optional usability.** The agreed baseline uses the combat mat’s Long Gun for the default U.S. attack precondition and the errata’s two-space defender supply loss after a successful Homeport attack. Alongside W02’s ruling, keep open Aid VII’s two unassigned rolls, whether Package 8 should choose a first force that preserves a viable second one, and the return timing of other used or negated Tactics. An optional Board → Tracks change would show how many Troops are due back at F7 alongside those available now. It would use an existing count and require no new player action. `src/ui.js:521`.

**Release verdict. Hold for W01 and W02.** Fix the early Troops return first, then settle outstanding surrenders at the Pursuit boundary. Include W03’s older-save repair in the same patch. A candidate should leave B20 dormant in the supplied position and give Beresford the same owner under both later commands, while retaining the 28 passing prior comparisons.

<!-- page -->
## Public GitHub Pages and desktop Chrome
**Release check.** The public URL returned HTTP 200 without signing in. Its title identified v0.2.4. A separate clean rebuild, the release, the current main copy, the gh-pages branch and the HTTP response all contained the exact bytes identified on page 1. Run `python public-site/verify_public.py project` from the evidence archive against a Git clone with the three pinned commits. [Public companion](https://ramyahoo88.github.io/A_Glorious_Chance_solo/)

### Two complete campaigns on the live site
I entered each seed through Setup and used the visible controls for all eight turns. Every prompt title and turn matched the earlier scripted campaign. I summed the signed rows in the Game Over table independently of the displayed total.

| Campaign and seed | Normal-play prompts | Scoring ledger |
|---|---|---|
| U.S. · 185401 | 107, including 82 information confirmations | 26 rows. U.S. 40, Britain 22. Score +18, U.S. Marginal Victory. |
| British · 185402 | 125, including 90 information confirmations | 19 rows. U.S. 18, Britain 21. Score −3, Draw. |

**Recovery.** In June I, Undo and replay restored the same prompt. Reload and Continue it recovered the entire exported game state. In July II, I loaded an earlier downloaded JSON through the native file chooser, verified the imported position, then used Undo twice. The first Undo restored the July campaign. The second reached its previous decision. Replaying it reproduced the same state and dice. The damaged R01 file was refused and the current game stayed intact. A finished British game also survived file import, reload and Review it.

**Fresh rules checks on the public page.** B20 reused the withdrawn marker and produced the −7 Kingston tally. The ordinary September save independently showed British AI availability rise from zero to one before F7. Under Pursuit, the next command changed Beresford’s owner. Without Pursuit, the original Encounter settled his capture. The older Rake save concealed Royal George before selection. The matching fresh choice named him, survived reload and applied the hits to him. With Missed Signal, both previews and the applied Gunnery round showed 4.5 vs 8. The chosen Surprise Tactic then shifted the combat column as printed.

**Evidence.** The public-site folder contains the visible prompt and ledger transcripts, both importable final saves, the replay actions, the public file comparison and the rule reproductions. The public URL and desktop recovery pass. Android home-screen use and offline relaunch remain open device checks.

**Release verdict. Hold for W01 and W02.** Return unlaunched Troops at F7 and settle each surrender before Pursuit draws the next Encounter. W03 is a lower-priority migration repair for games saved at the older Rake prompt.
