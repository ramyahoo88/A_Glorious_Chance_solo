const {fs,path,assert,out,launch,st,button,start,loadText}=require('./page_helpers');
(async()=>{
  const t=await launch();start(t,'BR',185431);
  loadText(t,fs.readFileSync(path.join(out,'new-saves','W03_legacy_Rake.json'),'utf8'));
  const prompt=st(t).prompt;
  assert(prompt.options.some(o=>o.id==='random'),'The legacy Rake choice must load');
  const label=prompt.options.find(o=>o.id==='random').label;
  button(t,label,t.doc.querySelector('#proc'));
  const applied=st(t).log.find(l=>l.text.startsWith('Rake:')).text;
  button(t,'↶ Undo');
  const undoLabel=st(t).prompt.options.find(o=>o.id==='random').label;
  const expectedName='Royal George (A)',pass=label.includes(expectedName)&&undoLabel===label&&applied.includes(expectedName);
  console.log(JSON.stringify({expectedName,label,undoLabel,applied,pass},null,2));
  t.dom.window.close();
  if(process.argv.includes('--require-rules')&&!pass)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
