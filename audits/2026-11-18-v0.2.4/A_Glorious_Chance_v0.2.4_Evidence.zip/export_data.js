const fs=require('fs'),path=require('path');const repo=path.resolve(process.argv[2]||path.join(__dirname,'../../agc'));
const{x}=require('./load')(repo);
fs.writeFileSync(path.join(__dirname,'app-data.json'),x('JSON.stringify({targets:TARGET_CARDS,events:EVENTS,ships:SHIP_DEFS,landBattle:LB_TABLE},null,2)'));
console.log('Exported reviewed application data for picture comparison.');
