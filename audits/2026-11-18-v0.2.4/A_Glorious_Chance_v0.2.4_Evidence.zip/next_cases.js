// Independent expectations from the printed rules, player aids, cards and worked examples.
const say=(s,re)=>s.log.filter(l=>re.test(l.text)).map(l=>l.text);
const tally=s=>playUntil(s,q=>q.prompt?.title.startsWith('Tally'));
const reset=s=>playUntil(s,q=>q.prompt?.title.startsWith('Reset'));
for(const [id,card,pool] of [['N01','B2',['oneida']],['C01_blank','B15',['oneida']],['C01_escorted','B2',['lady','growler']]]){
 const s=convoyBoard(card,pool);if(id!=='C01_escorted')keep(id,s);act(s,'ok');
 const c=s.convoys.US[2];const msg=s.prompt.text;
 if(id==='C01_escorted'){test(id,['growler','lady'],Object.values(s.forces).find(f=>f.side==='US').ships.slice().sort(),msg);continue;}
 tally(s);test(id,['D',1],[c.result,s.supply.US],{encounter:msg,tally:s.prompt.text});
}
for(const spy of [true,false]){
 const s=convoyBoard('B40',['madison'],'CuttingOut',spy);s.rng=2;
 const id=spy?'N02':'C02_false_alarm';keep(id,s);act(s,'ok');
 const marker={encounter:s.pe[0].status,force:s.forces.F1.ended};
 playUntil(s,q=>q.prompt?.title.includes('Cutting-Out mission'));const msg=s.prompt.text;tally(s);
 const n=s.vpLog.filter(v=>v.side==='BR'&&v.why.includes('Madison captured')).reduce((a,v)=>a+v.n,0);
 test(id,spy?['US',0]:['BR',32],[s.ships.madison.owner,n],{marker,coastal:msg,tally:s.prompt.text});
}
for(const [id,ids,side,rng,expected] of [['N03',['melville'],'BR',4,[2]],['C03_pair',['pike','sylph'],'US',4,[2,2]],['C03_none',[],'BR',4,[]]]){
 const s=yardBoard(ids,side,rng);if(id==='N03')keep(id,s);act(s,'ok');test(id,expected,ids.map(i=>s.ships[i].steps),s.prompt.text);
}
for(const mode of ['dis','failed']){
 const s=pursuitBoard(mode);const id='N04_'+mode;keep(id,s);act(s,'ok');const round=s.prompt.text;act(s,'ok');
 const started=say(s,/pursuit/i).some(t=>/new Encounter/i.test(t));
 if(mode==='dis')test(id,true,started&&s.encounter?.ships.moira==='in'&&!s.prompt.text.includes('no ships left'),{round,next:s.prompt.text,status:s.encounter?.ships.moira});
 else test(id,false,started,{round,next:s.prompt?.text,status:s.encounter?.ships.moira});
}
for(const [id,active,forget] of [['N05',false,false],['C05_release',false,true],['C05_active',true,false]]){
 const s=towBoard(active);if(forget)s.combat.tows={};if(id==='N05')keep(id,s);
 act(s,'attack');const line=say(s,/^Gunnery Round 2:/)[0];test(id,active?'active tow':'A1/D3W',active?(line.includes('untowed Laker')?'untowed':'active tow'):line.match(/→ ([^ .]+)\./g).at(-1).slice(2,-1),line);
}
for(const [id,action,steps] of [['N06_withdraw','withdraw',1],['N06_reset','reset',1],['C06_face','withdraw',2]]){
 const s=action==='withdraw'?retreatBoard(steps):resetBoard(steps);if(id.startsWith('N'))keep(id,s);
 act(s,'ok');if(action==='withdraw')act(s,'withdraw');
 test(id,['transit',2],[s.ships.rg.box,s.ships.rg.steps],{result:s.prompt?.text,printedReduced:def(s.ships.rg).red[4]});
}
{
 const s=rakeBoard();keep('N07_N08',s);act(s,'ok');const printedOptions=s.prompt.options.map(o=>o.label);
 const sample=JSON.parse(JSON.stringify(s));const candidate=pick(sample,s.combat.col.BR);
 test('N07',true,printedOptions.some((v,i)=>i===2 && v.includes('Royal George')),{candidate,printedOptions});
 act(s,'random');test('C07_target','Rake: all hits on Royal George (A).',say(s,/^Rake:/)[0]);
 test('N08',true,s.deck.tacA.includes('A_rake'),{onPlayedPile:s.tacPlayed.includes('A_rake'),gunnery:s.prompt.text});
}
for(const missed of [true,false]){
 const s=missedBoard(missed);if(missed)keep('N09',s);act(s,'ok');const preview=s.prompt.text.split('\n').find(a=>a.startsWith('Odds if you attack'));act(s,'attack');
 const p=s.prompt,first=missed?p.candidates.filter(i=>i!=='madison'):p.candidates;
 const str=sideStrength(s,first,'US',false);test(missed?'N09':'C09_clear',true,preview.includes('ships: '+str+' vs 8'),{preview,participatingShips:first,nextStrength:str});
}
for(const box of [null,'makeReady','deployable']){
 const s=emptyPortBoard(box);if(!box)keep('N10',s);act(s,'ok');
 const p=s.prompt,a={flagship:p.flagship,forces:[{mission:'CuttingOut',zone:'SAC',ships:['wolfe'],troops:0}]};
 const accepted=validateAnswer(s,p,a)===null; if(accepted)act(s,a);
 test(box?'C10_'+box:'N10',!!box,!!accepted,{opportunitySpent:s.cuttingOutUsed.BR,eligibleBox:box});
}
for(const human of ['US','BR']){
 const s=galeBoard(human);const id='N11_'+(human==='BR'?'human':'AI');keep(id,s);act(s,'ok');const msg=s.prompt.text;reset(s);
 const avail=human==='BR'?s.troops.BR.available:s.aiTroops.box.filter(t=>t.troops).length;
 test(id,1,avail,{gale:msg,afterReset:s.prompt.text,losses:s.lossesThisTurn,ships:[s.ships.wolfe.box,s.ships.oneida.box],unreleased:human==='BR'?s.troops.BR.track.length:s.aiTroops.track.filter(t=>t.troops).length});
}
{
 const s=galeBoard('BR');waitAt(s,'tally','reset');act(s,'ok');test('C11_unlaunched',1,s.troops.BR.available,'Unlaunched marker still on a Force at F7.');
}
// Aid VII: last printed legal roll for each result row. The two omitted rolls are kept explicit.
const limits=[
 [[14,23,43,65,66,0],[13,23,41,64,66,0],[12,21,34,61,65,66]],
 [[11,16,34,62,66,0],[0,14,31,61,66,0],[0,13,26,56,64,66]],
 [[11,13,31,55,66,0],[0,12,26,54,66,0],[0,11,24,53,63,66]],
 [[11,12,24,52,66,0],[0,11,22,51,66,0],[0,11,21,46,62,66]],
 [[0,11,16,44,66,0],[0,11,15,35,66,0],[0,11,14,33,61,66]]];
{
 const mis=[],missing=[],names=['DM','DS','DR','AS','AM','AF'];let specified=0;
 for(const [band,g] of [0,1,7,16,25].entries())for(let t=1;t<=3;t++)for(let a=1;a<=6;a++)for(let b=1;b<=6;b++){
  const n=a*10+b,actual=lbLookup(g,t,0,n).result;
  if(!g&&t===3&&[62,63].includes(n)){missing.push({g,t,n,actual});continue;}
  specified++;const expected=names[limits[band][t-1].findIndex(end=>end>=n)];
  if(expected!==actual)mis.push({g,t,n,expected,actual});
 }
 test('AidVII_specified',[538,[]],[specified,mis],{printedGaps:missing});
}
