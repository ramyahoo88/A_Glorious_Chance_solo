# A Glorious Chance Solo v0.2.4 audit evidence

Reviewed release commit f15cdd39fa3fe93c86e999dee868178703ad2abc. The PDF’s text is also included as audit.md. File and source line references apply to this pinned commit.

## Reproduce in the shipped app

1. Open dist/index.html, choose either campaign and start it.
2. Select **Load** and choose the JSON file. Alternatively, paste the JSON into the text area and select **Load pasted text**.
3. Follow the instructions below. Files include the complete RNG state. The current game remains reachable through Undo immediately after import.

| Save in new-saves/ | What to try |
|---|---|
| W01_B20.json | Click Continue four times to see B20 deploy a second American force carrying the Troops that withdrew from Niagara. Six more Continues reach Tally at −7 and British supply −1. The corrected control scores 0 with supply 1. |
| W01_natural.json | Genuine U.S. campaign, seed 186010, fleet policy. Continue once in September I. See the British marker in Board → Tracks during the withdrawal. |
| W02_Pursuit_struck.json | Continue through Event 9, Pass the first command, confirm zero Reactions, then Pass the next command. Beresford is rescued. Reload and change the second Pass to Attack, accept the lineup and continue. Beresford is captured. |
| C02_ordinary_withdrawal.json | Two Continues settle the surrender at the end of the original Encounter. |
| W03_legacy_Rake.json | Exported at the Rake decision by the authentic v0.2.3 page. Compare the third button before and after selecting it, then try Undo. The matching new-decision control is original-saves/N07_N08.json. |

The 18 original-saves/ files are unchanged inputs from the v0.2.3 audit. Three were captured during full campaigns. The remaining originals are narrow positions and controls. The two original v0.2.2 re-audit inputs are in inputs/. Four legacy/ samples were exported through the actual Save dialog in their respective older releases. The examples marked W01_B20, W02 and W03 originate from focused setups. Only W01_natural is offered as an ordinary-play example of the new findings.

## Independent checks

Run from an extracted copy of this archive. Pass the path to a Git checkout with its release history. The engine/build checks need Node and Git. The isolated build verifier also needs Python 3.12 or later and cmp. jsdom 26.1.0 was used for the player-control checks. Node 24.22.3 and Python 3.12.14 were used here. The scripts write their results beside themselves.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git project
git -C project checkout --detach f15cdd39fa3fe93c86e999dee868178703ad2abc
python compare_release.py project
node next_rules.js project --require-rules
node recheck_engine.js project
node boundary_checks.js project
node edges.js project
node map_checks.js project
node paper_checks.js project
node followup_rules.js project --require-rules
```

The last command exits 1 on v0.2.4. Five comparisons document W01 and W02. Four adjacent controls pass. Omit --require-rules to record results with a zero exit. Both W02 futures must settle the old surrender before the new Encounter’s decisions. The test allows either ownership ruling.

```sh
npm install --prefix audit-node jsdom@26.1.0
export NODE_PATH="$PWD/audit-node/node_modules"
node v024_dom.js project
node recheck_dom.js project
node legacy_dom.js project
node verify_legacy_rake.js project --require-rules
```

v024_dom.js is a pinned observation replay. Its assertions reproduce the v0.2.4 failures as well as the passes. verify_legacy_rake.js is a rules check and deliberately exits 1 for the anonymous legacy choice on this release. It reads the frozen original v0.2.3 save in new-saves/. File-input tests supplied a browser File to the shipped FileReader handler and exercised the import callback. These were DOM-level controls and do not measure native file-picker behavior or visual layout.

```sh
node campaigns.js project 183000 64
node campaigns.js project 185000 48
node timing_campaigns.js project 128
node project/tests/unit.js
node project/tests/scenario.js
node project/tests/regression.js
node project/tests/sim.js 100
```

The repository smoke command runs 100 games per side and makes random player decisions, so its result mix can vary. Each base seed in campaigns.js and timing_campaigns.js runs four configurations, both campaigns and both fleet and coastal play policies. Timing runs begin at seed 186000. Defaults vary OA2 and OA1 by seed. The 512-game timing run recorded 19 early returns in 18 games. The focused B20 reproduction supplies the actual same-turn re-embark. For a purely historical comparison, read v023-stock-baseline.json alongside campaign-results.json.

The Target-card optical check needs the supplied VASSAL v1.0 module’s extracted images, Pillow and NumPy. Researchers with their own copy can run the following.

```sh
node export_data.js project
python verify_component_grids.py /path/to/vmod/images
```

## Evidence index

- literal-build-results.json, release-status.json and remote-refs.txt identify the hash, separate build, current main and release branch. The private Artifact returned a sign-in page. Its matching hash was supplied by the owner.
- followup-results.json and W03-results.json contain the rule-versus-app comparisons. v024-dom-results.json contains file-import and Undo/replay results, both W02 outcomes, and the two fresh page-control campaign traces.
- timing-campaign-results.json contains all 19 observed early returns. campaign-results.json and campaign-fresh-results.json record full-campaign outcomes, prompts, signed score reconciliation and marker conservation.
- next-results.json, engine-results.json, boundary-results.json and edges-results.json cover old findings and boundary controls. map-results.json, paper-results.json and component-grid-results.json include the printed aids and card-table checks.
- dom-results.json and legacy-results.json cover earlier save, preview and recovery checks. The repository suite and smoke-run outputs are under logs/.
- source-manifest.json records the exact rules, errata, player-aid photographs and component source hashes. The game and publisher’s original artworks are available separately from their respective sources.

**Release verdict.** Hold for W01 and W02. Add the pending-choice migration for W03 in the same patch. Re-run the previous regression cases and the independent rules checks above.

## Public GitHub Pages follow-up

The public-site/ directory documents a second clean rebuild, the anonymous HTTP response, two full campaigns played through desktop Chrome, real downloads and file imports, and both branches of the unresolved Pursuit case. Start with public-site/README.md. The older release-status.json and remote-refs.txt document the original check before GitHub Pages went live. public-site/release.json gives the public deployment's verified commit.
