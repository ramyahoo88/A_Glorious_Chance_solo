// Loaded into the same Node VM as the unmodified engine. All fixture state is plain save data.
function fresh(side='US',seed=182311) {
  const s=newGame(side,seed);
  s.turn=2;s.phase='lake';s.calls=[];s.prompt=null;
  s.lossesThisTurn=[];s.troopsReturning={US:0,BR:0};
  return s;
}
function waitAt(s,proc,pc,A={},L={},title='Continue from audit position') {
  s.calls=[{proc,pc,A,L}]; s.prompt=info(title,'Press Continue to resolve the next printed step.');
}
function stageCombat(s,zone,us,br,att='US'){
  const u=newForce(s,'US',zone,'Patrol',us);
  const b=newForce(s,'BR',zone,'Patrol',br);
  s.encounter={zone,kind:'normal',segment:'patrol',ships:{},side:{},struckBy:{},withdrawn:{BR:false,US:false},
    humanForce:(s.human==='US'?u:b).id,aiForce:(s.ai==='US'?u:b).id,wg:att,wgCard:8,firstAttack:false};
  [...us,...br].forEach(id=>encAdd(s,id));
  s.zones[zone].event=8; s.deck.event=[9,...s.deck.event.filter(n=>n!==8&&n!==9)];
  s.combat={att,def:OTHER[att],seq:att==='US'?'A':'B',pos:0,segment:'patrol',col:{US:us.slice(),BR:br.slice()},tows:{},tac:{att:null,def:null},gr:0,roundAttackers:[],newSeq:false};
}
function setCombatCaller(s) {
  s.calls.unshift({proc:'encounter',pc:'afterCombat',A:{},L:{}});
}
function playUntil(s,stop,limit=35) {
  for(let i=0;i<limit;i++){
    if(stop(s))return;
    const p=s.prompt;
    if(!p)throw Error('Position ended before the requested decision.');
    let a='ok';
    if(p.kind==='choice')a=(p.options.find(o=>o.primary)||p.options[0]).id;
    else if(p.kind==='select')a=p.initial||[];
    else if(p.kind==='lineup')a={attackers:p.candidates,tows:p.defaultTows||{}};
    else if(p.kind!=='info')throw Error('Unexpected prompt '+p.kind+' '+p.title);
    act(s,a);
  }
  throw Error('Position exceeded its decision limit');
}
function convoyBoard(card='B2',pool=['oneida'],mission='Patrol',spy=true){
  const s=fresh('BR',182301);
  s.options.cuttingOut=true;
  const fr=newForce(s,'BR','SAC',mission,['wolfe']);
  if(mission==='CuttingOut')s.cuttingOutUsed.BR=true;
  for(const sh of sideShips(s,'US')) {
    if(sh.box==='deployable'&&!pool.includes(sh.id))sh.box='ordinary';
  }
  s.nb=0;s.nbBand=3;s.aiTroops.box=[];s.convoys.US[2]={real:true,revealed:false,delay:false,deployed:false,result:null};
  s.convoys.US[3]={real:false,revealed:false,delay:false,deployed:false,result:null};
  s.targetRow=[{id:card,revealed:false,enc:false,removed:false}];
  s.pe=[{num:1,idx:0,zone:'SAC',forceId:fr.id,status:'possible'}];
  const first=spy?8:22;s.deck.event=[first,...s.deck.event.filter(id=>id!==first)];
  waitAt(s,'turn','B2',{},{});s.rng=1;
  return s;
}
function yardBoard(ships,side='BR',rollState=4){
  const s=fresh(side==='BR'?'US':'BR',182303);
  for(const sh of sideShips(s,side)) if(sh.box==='construction'&&!ships.includes(sh.id))sh.box='makeReady';
  s.coastal.battles=[{side:OTHER[side],target:'HOME',zone:homeZone(side),result:'AM'}];s.phase='tally';
  waitAt(s,'tally','start');s.rng=rollState;
  return s;
}
function pursuitBoard(mode='dis'){
  const s=fresh('US',182304);stageCombat(s,'NOR',['oneida'],['moira']);
  s.combat.tac.att={id:'A_pursuit',used:false,negated:false};
  s.deck.tacA=s.deck.tacA.filter(id=>id!=='A_pursuit');s.tacPlayed=['A_pursuit'];
  waitAt(s,'combat','grRoll',{},{st:'GR1'},'Resolve Pursuit in Gunnery Round 1');setCombatCaller(s);
  s.rng=mode==='dis'?15:12; // Raw CRT 2 in both positions.
  return s;
}
function towBoard(active=false){
  const s=fresh('US',182305);stageCombat(s,'NOR',['madison','tompkins'],['moira']);
  s.combat.col.US=active?['madison','tompkins']:['tompkins'];
  if(!active){s.encounter.ships.madison='dis';s.ships.madison.steps=2;}
  s.combat.pos=2;s.combat.gr=1;s.combat.tows={madison:'tompkins'};
  waitAt(s,'combat','grDecide',{},{st:'GR2'});
  s.prompt=choice('Gunnery Round 2 – attack or pass?','The United States retains the Weather Gage.',[{id:'attack',label:'Attack',primary:true},{id:'pass',label:'Pass'}]);
  setCombatCaller(s);s.rng=45;
  return s;
}
function retreatBoard(steps=1){
  const s=fresh('BR',182306);stageCombat(s,'NOR',['oneida'],['rg','moira'],'US');
  s.ships.rg.steps=steps;s.encounter.ships.rg='dis';s.combat.col.BR=['moira'];
  // Royal George Disengaged earlier in this Encounter. The only current defender is Moira.
  waitAt(s,'combat','grRoll',{},{st:'GR1'},'Resolve withdrawal with a previously Disengaged ship');
  setCombatCaller(s);s.rng=15;return s;
}
function resetBoard(steps=1){
  const s=fresh('BR',182306);newForce(s,'BR','NOR','Patrol',['rg']);s.ships.rg.steps=steps;
  s.phase='tally';waitAt(s,'tally','reset',{},{});return s;
}
function rakeBoard(){
  const s=fresh('US',182307);stageCombat(s,'NOR',['madison','oneida'],['wolfe','rg','moira']);
  s.combat.tac.att={id:'A_rake',negated:false,used:false};s.deck.tacA=s.deck.tacA.filter(id=>id!=='A_rake');s.tacPlayed=['A_rake'];
  s.rng=42;waitAt(s,'combat','grRoll',{},{st:'GR1'},'Resolve Attacker Rake');setCombatCaller(s);return s;
}
function emptyPortBoard(eligibleBox=null){
  const s=fresh('BR',182309);s.phase='prep';s.options.cuttingOut=true;
  for(const sh of sideShips(s,'US'))if(sh.box==='deployable'||sh.box==='makeReady')sh.box='ordinary';
  if(eligibleBox)s.ships.oneida.box=eligibleBox;
  waitAt(s,'turn','A7');return s;
}
function missedBoard(missed=true){
  const s=fresh('US',182310);stageCombat(s,'NOR',['madison','oneida'],['wolfe']);s.combat=null;
  if(missed){s.zones.NOR.flags.missedSignal='madison';s.zones.NOR.event=13;s.encounter.wgCard=13;}
  waitAt(s,'encounter','command');return s;
}
function galeBoard(human='BR',event=30) {
  const s=fresh(human,182311);const b=newForce(s,'BR','NIA','ArmySupport',['wolfe'],{troops:1});
  const u=newForce(s,'US','NIA','Patrol',['oneida']);
  if(human==='BR'){s.troops.BR.available=0;s.troops.BR.track=[7,8];}
  else {s.aiTroops.track=[{space:7,troops:true},{space:8,troops:true}];s.aiTroops.box=[];}
  s.deck.event=[event,...s.deck.event.filter(n=>n!==event)];s.rng=4;
  waitAt(s,'encounter','start',{zone:'NIA',kind:'normal',humanForces:[human==='BR'?b.id:u.id],aiForces:[human==='BR'?u.id:b.id]});
  s.calls.unshift({proc:'turn',pc:'E',A:{},L:{}});return s;
}
