# Public v0.2.4 deployment and desktop Chrome

Checked on 18 November 2026. The public site is https://ramyahoo88.github.io/A_Glorious_Chance_solo/.

## Release identity and reproducible comparison

The release commit was f15cdd39fa3fe93c86e999dee868178703ad2abc. Main was 80534c10b304de2c950d62cf38b9cb481fedca32, and gh-pages was fa93310d02e88b4c43712ca71f67853d540ea1ca. Only README.md changed from the release commit to main. All five HTML copies in rebuilt-live.log were compared in memory byte for byte. The baseline had 295,018 bytes and SHA-256 65709398b2964946de21c346c96a2f92aca8decc53e944314196618b67fcca93.

With Python 3.12+, Git, Node and network access, run the following from the root of this evidence archive. Supply an ordinary clone containing all three commits. The script builds into a fresh temporary directory and compares against an anonymous identity-encoded HTTP response. The URL follows the current deployment and may legitimately change after this audit.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git project
python public-site/verify_public.py project
```

## Repeat the live cases

For a clean full campaign, select the named side, enter the seed, leave Setup options at their defaults and press Tab to commit the seed. Select Start campaign. The files choices-185401.json and choices-185402.json list the exact controls in play order. Their prompt titles and turns were checked against the public page at each step. campaigns.json records what was visible, including final score rows and independent signed sums. Action counts exclude setup, extra recovery probes and board mirroring. They include the normal prompt-confirming clicks. The final saves are genuine browser downloads. Open either through Load, then reload and select Review it to inspect the final ledger.

| Campaign | Seed | Prompts | Visible ledger | Verdict |
|---|---:|---:|---|---|
| U.S. | 185401 | 107 | 26 entries, 40 U.S. and 22 British | +18, U.S. Marginal Victory |
| British | 185402 | 125 | 19 entries, 18 U.S. and 21 British | −3, Draw |

browser-evidence.json contains the live UI observations. The original regression inputs are in ../new-saves/, ../original-saves/ and ../inputs/. See ../README.md and pages 2–4 of the audit for each initial board state, dice, rule, source line and smallest fix.

- W01 used the native file picker. Four Continues in W01_B20.json display the second force carrying the withdrawn marker. At the tenth Continue, Tally shows −7. The companion W01_natural.json also shows early availability in September I.
- W02 used the Load dialog's pasted-text control. Continue twice, then read the following Command Decision. Lord Beresford is still listed as Struck Colors. Pass the first command and send zero Reaction ships. On the second command, Pass rescues him. Undo to that command and Attack to have him captured. C02_ordinary_withdrawal.json settles the ship in the original Encounter.
- W03 used the Load dialog with a genuine pending v0.2.3 Rake decision. The third button names no ship. It hits Royal George. Undo restores the anonymous button. In N07_N08.json one step before the choice, Royal George is named, and remains named after reload.
- N09 uses N09.json. Continue, select Attack, read the lineup, choose Attack with these ships and play Surprise. The Command Decision, lineup and applied Gunnery round all use 4.5 vs 8. The chosen Tactic shifts the column once.
- The file picker refused the earlier broken procedure fixture inputs/R01_original_v022.json. The original in-progress export stayed identical. In another game an actual downloaded JSON restored the exact earlier position. Undo restored the separate July game with its old history. Reload/Continue it restored an active game and reload/Review it restored a finished game.

The browser recorded 80 repeated extension-origin messages in the last 80 console entries. That bounded sample is not a complete application error log. All 232 expected full-campaign prompts and both scoring tables were observed. The checks used desktop Chrome. Android touch, home-screen installation, cold offline shortcut launch and physical-table lookup time were outside these observations.

## Release decision

Correct the withdrawal return at F7 and the Encounter boundary on Pursuit first. Migrate previously pending legacy Rake choices as a smaller correction. The public file matches the audited release.
