"""Compare a public release with a clean rebuild and its Git commits. Python 3.12+, Git, Node."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile
from urllib.request import Request, urlopen

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("repo", type=Path, help="Git clone containing the three audited commits")
args = parser.parse_args()
repo = args.repo.resolve()
pin = "f15cdd39fa3fe93c86e999dee868178703ad2abc"
main = "80534c10b304de2c950d62cf38b9cb481fedca32"
pages = "fa93310d02e88b4c43712ca71f67853d540ea1ca"
url = "https://ramyahoo88.github.io/A_Glorious_Chance_solo/"

def git(*args):
    return subprocess.check_output(["git", "-C", str(repo), *args])

sources = {
    "release": git("show", pin + ":dist/index.html"),
    "main": git("show", main + ":dist/index.html"),
    "gh-pages": git("show", pages + ":index.html"),
}
with tempfile.TemporaryDirectory(prefix="agc-public-audit-") as folder:
    archive = git("archive", pin, "src", "tools", "package.json")
    with tarfile.open(fileobj=io.BytesIO(archive)) as files:
        files.extractall(folder, filter="data")
    subprocess.run(["node", "tools/build.js"], cwd=folder, check=True)
    sources["separateRebuild"] = (Path(folder) / "dist" / "index.html").read_bytes()

request = Request(url, headers={"Accept-Encoding": "identity", "Cache-Control": "no-cache"})
with urlopen(request, timeout=30) as response:
    status = response.status
    media = response.headers.get("Content-Type")
    final_url = response.geturl()
    sources["publicHTTP"] = response.read()
baseline = sources["release"]
records = {
    name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
           "byteIdenticalToRelease": data == baseline}
    for name, data in sources.items()
}
print(json.dumps({"url": final_url, "httpStatus": status, "contentType": media, "files": records}, indent=2))
if not all(row["byteIdenticalToRelease"] for row in records.values()):
    raise SystemExit("A copy differs. A later deployment may legitimately supersede this release.")
