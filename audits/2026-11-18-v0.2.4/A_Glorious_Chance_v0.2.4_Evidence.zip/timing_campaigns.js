// Record naturally played campaign positions in which withdrawn AI Troops become available early.
const fs = require('fs'), path = require('path'), assert = require('assert');
const repo = path.resolve(process.argv[2]), E = require(path.join(repo, 'tools/bundle_engine.js'))();
const {policy} = require('./campaigns');
const folder = path.join(__dirname, 'new-saves'); fs.mkdirSync(folder, {recursive:true});
const count = Number(process.argv[3] || 128), start = 186000;
const findings = [], reembarks = []; let games = 0, naturalSaved = false, reuseSaved = false;
for(let i=0; i<count; i++) for (const human of ['US','BR']) for(const style of ['fleet','coast']) {
  const seed=start+i, s=E.newGame(human,seed,{cuttingOut:i%2===0,oa1Upgrades:i%4===0});
  E.run(s); let entry=null, entrySnapshot=null;
  for(let n=0;!s.over && n<1500;n++){
    const current=s.turn, prompt=s.prompt, answer=policy(s,prompt,style), logLen=s.log.length;
    assert(!E.validateAnswer(s,prompt,answer));
    const box=s.aiTroops.box.filter(m=>m.revealed&&m.troops).length;
    const eligible=Object.values(s.forces).some(f=>f.side===s.ai&&f.troops);
    const before=eligible && (!naturalSaved || !reuseSaved && !box) ? JSON.stringify({state:s,undo:[]}) : null;
    E.act(s,answer);
    const delta=s.log.slice(logLen), label=s.ai==='BR'?'British':'U.S.';
    const abort=delta.find(l=>l.text.startsWith(label+' Coastal mission aborted'));
    if(abort){
      const after=s.aiTroops.box.filter(m=>m.revealed&&m.troops).length;
      const record={seed,human,style,turn:current,step:n+1,title:prompt.title,answer,side:s.ai,beforeBox:box,afterBox:after,pending:s.troopsReturning[s.ai],log:abort.text};
      findings.push(record);
      if(before && !naturalSaved && box===0 && after>0 && !record.pending){
        naturalSaved=true;fs.writeFileSync(path.join(folder,'W01_natural.json'),before);record.file='W01_natural.json';
      }
      if(!box && after>0){entry=record;entrySnapshot=before;}
    }
    if(entry && entry.turn===current && s.turn===current && s.phase!=='tally'){
      const redeployed=delta.find(l=>l.text.includes('AI Deploys to ') && l.text.includes('Carrying '));
      if(redeployed){
        const result={...entry,nextStep:n+1,redeployment:redeployed.text};reembarks.push(result);
        if(!reuseSaved && entrySnapshot){reuseSaved=true;fs.writeFileSync(path.join(folder,'W01_natural_reembark.json'),entrySnapshot);result.file='W01_natural_reembark.json';}
        entry=null;entrySnapshot=null;
      }
    }
    if(current!==s.turn || s.phase==='tally'){entry=null;entrySnapshot=null;}
  }
  assert(s.over);games++;
}
const document={start,count,games,withdrawals:findings.length,reembarks:reembarks.length,findings,examples:reembarks};
fs.writeFileSync(path.join(__dirname,'timing-campaign-results.json'),JSON.stringify(document,null,2));
console.log(JSON.stringify({games,withdrawals:findings.length,reembarks:reembarks.length,examples:[findings.find(r=>r.file),reembarks.find(r=>r.file)]},null,2));
