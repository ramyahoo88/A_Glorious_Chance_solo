const fs=require('fs'),path=require('path'),assert=require('assert');const {x,ctx}=require('./load')(path.resolve(process.argv[2]));
x(fs.readFileSync(path.join(__dirname,'positions.js'),'utf8'));
const out=[];ctx.confirm=(name,want,got)=>{const copy=JSON.parse(JSON.stringify(got));const expected=JSON.parse(JSON.stringify(want));assert.deepStrictEqual(copy,expected,name);out.push({name,expected,observed:copy});};
x(`
for(const [a,b,award,points] of [[10,10,'both',[0,0]],[10,9,'US',[5,0]],[9,10,'BR',[0,5]]]){
 const s=fresh();s.supply={US:a,BR:b};for(const sd of ['US','BR'])s.convoys[sd][2]={real:true,delay:false,result:null,revealed:true};waitAt(s,'tally','start');act(s,'ok');
 const bonus=sd=>s.vpLog.filter(v=>v.side===sd&&v.why==='Fall Offensive Supplied first').reduce((n,v)=>n+v.n,0);
 confirm('Simultaneous F5 / '+a+' and '+b,[award,points],[s.fallOffensive,[bonus('US'),bonus('BR')]]);
}
for(const [n,want] of [[-33,'British Decisive Victory'],[-32,'British Victory'],[-22,'British Victory'],[-21,'British Marginal Victory'],[-11,'British Marginal Victory'],[-10,'Draw'],[0,'Draw'],[10,'Draw'],[11,'U.S. Marginal Victory'],[21,'U.S. Marginal Victory'],[22,'U.S. Victory'],[32,'U.S. Victory'],[33,'U.S. Decisive Victory']]){
 const s=fresh();if(n>=0)addVP(s,'US',n,'setup');else addVP(s,'BR',-n,'setup');endGame(s);confirm('3.3.2 score '+n,[n,want],[s.result.score,s.result.level]);
}
for(const canBreak of [false,true]){
 const s=fresh();s.turn=3;s.troops.US.available=0;
 for(const sh of sideShips(s,'BR'))if(!['wolfe',...(canBreak?['rg']:[])].includes(sh.id))sh.box='sunk';
 s.ships.sss.owner='US';s.ships.sss.box='deployable';s.ships.sylph.box='deployable';s.ships.pike.box='deployable';
 newForce(s,'US','KIN','Patrol',['madison','oneida','tompkins','fairam']);newForce(s,'US','YOR','Patrol',['pike','sylph','conquest','sss']);
 for(const z of ['KIN','YOR']){s.zones[z].blockade='US';s.zones[z].control='US';}waitAt(s,'tally','start');act(s,'ok');act(s,'ok');
 confirm('14.2 dual blockade, defenders '+(canBreak?'8 vs 7':'4 vs 7'),canBreak?[false,null]:[true,'U.S. Decisive Victory (Dual Blockade)'],[s.over,s.result?.level||null]);
}
for(let n=1;n<=11;n++){
 const s=fresh('BR');s.rng=7;s.aiTroops.box=[{troops:true,revealed:true}];for(const i of ['sylph','pike'])s.ships[i].box='deployable';
 const pool=sideShips(s,'US').filter(sh=>sh.box==='deployable');const r=forcePackageSelect(s,n,pool);let ok=r.ok;
 if(ok){const sh=r.ships.map(i=>s.ships[i]);const sum=(ids,get)=>ids.reduce((a,v)=>a+get(v),0);const eq=(a,b)=>a.slice().sort().join(',')===b.slice().sort().join(',');
  if(n===1)ok=eq(r.ships,pool.filter(isMain).map(z=>z.id));
  if(n>=2&&n<=6){const need=[28,22,16,18,20][n-2];const main=pool.filter(isMain);const mainLG=main.reduce((a,v)=>a+lg(v),0);const included=mainLG>=need?main:pool.filter(z=>!isMain(z));const required=mainLG>=need?need:need-mainLG;let sum=0,k=0;for(const v of included.map(lg).sort((a,b)=>b-a)){if(sum>=required)break;sum+=v;k++;}ok=sh.length===(mainLG>=need?k:k+main.length)&&sh.reduce((v,z)=>v+lg(z),0)>=need&&(mainLG>=need?sh.every(isMain):main.every(z=>r.ships.includes(z.id)));}
  if(n===7)ok=eq(r.ships,pool.filter(z=>isMain(z)||lg(z)>0||ca(z)>0).map(z=>z.id));
  if(n===8)ok=sh.every(isMain)&&sum(sh,ca)>=8&&sum(r.ships2.map(i=>s.ships[i]),lg)>=22&&r.ships2.every(i=>!r.ships.includes(i));
  if(n===9)ok=eq(r.ships,['lady','asp']);
  if(n===10)ok=sh.length===2&&sh.every(z=>!isMain(z))&&new Set(r.ships).size===2;
  if(n===11)ok=sh.every(z=>!isMain(z))&&sum(sh,z=>z.steps)>=5&&sum(sh.slice(0,-1),z=>z.steps)<5;
 }confirm('Aid V package '+n+' full pool',true,ok);
}
`);fs.writeFileSync(path.join(__dirname,'edges-results.json'),JSON.stringify(out,null,2));console.log(out.length+' expected outcomes verified.');
