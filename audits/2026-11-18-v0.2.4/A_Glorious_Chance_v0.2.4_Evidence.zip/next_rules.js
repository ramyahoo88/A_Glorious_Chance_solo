// node next_rules.js /path/to/checkout [--require-rules]
// Normal mode records rule comparisons. Strict mode exits 1 for any rules mismatch.
const path=require('path'),fs=require('fs');
const repo=path.resolve(process.argv[2]);const {x,ctx}=require('./load')(repo);
const destination=__dirname,saves=path.join(destination,'saves');
fs.mkdirSync(saves,{recursive:true});
ctx.keep=(id,s)=>fs.writeFileSync(path.join(saves,id+'.json'),JSON.stringify({state:s,undo:[]},null,2));
const checks=[];
ctx.test=(id,expected,observed,detail)=>checks.push(JSON.parse(JSON.stringify({id,expected,observed,pass:JSON.stringify(expected)===JSON.stringify(observed),detail})));
x(fs.readFileSync(path.join(__dirname,'positions.js'),'utf8'));
x(fs.readFileSync(path.join(__dirname,'next_cases.js'),'utf8'));
fs.writeFileSync(path.join(destination,'next-results.json'),JSON.stringify(checks,null,2));
console.log(JSON.stringify({comparisons:checks.length,agree:checks.filter(t=>t.pass).length,disagree:checks.filter(t=>!t.pass).map(t=>t.id)},null,2));
if(process.argv.includes('--require-rules') && checks.some(t=>!t.pass))process.exitCode=1;
