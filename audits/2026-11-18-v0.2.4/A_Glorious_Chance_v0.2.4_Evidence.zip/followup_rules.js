// Focused rules comparisons. Use --require-rules to fail when any independent expectation disagrees.
const fs=require('fs'), path=require('path'), assert=require('assert');
const {x,ctx}=require('./load')(path.resolve(process.argv[2]));
const dst=path.join(__dirname,'new-saves');fs.mkdirSync(dst,{recursive:true});
const checks=[];
ctx.keep=(id,s)=>fs.writeFileSync(path.join(dst,id+'.json'),JSON.stringify({state:s,undo:[]},null,2));
ctx.check=(id,expected,actual,details)=>checks.push(JSON.parse(JSON.stringify({id,expected,actual,pass:JSON.stringify(expected)===JSON.stringify(actual),details})));
x(fs.readFileSync(path.join(__dirname,'positions.js'),'utf8'));
x(`
function beresfordSettled(s) {
  const pending=s.encounter && s.encounter.ships.beres==='struck';
  return !pending && (s.ships.beres.owner==='US' || s.ships.beres.box==='transit' ||
    s.log.some(row=>/Beresford.*rescued/i.test(row.text)));
}
function markerPosition() {
  const s=fresh('BR',185301);
  stageCombat(s,'NIA',['madison'],['wolfe'],'BR');
  const fr=s.forces[s.encounter.aiForce];fr.mission='ArmySupport';fr.troops=1;
  s.aiTroops.box=[];s.aiTroops.track=[{space:7,troops:true},{space:8,troops:true}];
  s.nb=0;s.nbBand=3;
  s.targetRow=[{id:'B16',enc:true,removed:false,revealed:true},{id:'B20',enc:false,removed:false,revealed:false}];
  waitAt(s,'combat','grRoll',{},{st:'GR1'},'Resolve the Niagara withdrawal');
  setCombatCaller(s);s.calls.unshift({proc:'turn',pc:'B2done',A:{},L:{pe:1}});
  s.pe=[{num:1,idx:0,zone:'NIA',forceId:s.encounter.humanForce,status:'encounter'}];
  s.encounter.peNum=1;s.rng=1;return s;
}
{
  const s=markerPosition();keep('W01_B20',s);act(s,'ok');
  check('W01_available_before_F7',[0,1],[aiTroopsInBox(s),s.troopsReturning.US],s.prompt.text);
  playUntil(s,q=>q.prompt?.title.startsWith('Tally')||q.log.some(l=>l.text.includes('Troops launched in Kingston')));
  check('W01_Kingston_reembark',false,s.log.some(l=>l.text.includes('Troops launched in Kingston')),s.log.filter(l=>l.text.includes('Target Card B20')||l.text.includes('Troops launched')).map(l=>l.text));
  playUntil(s,q=>q.prompt?.title.startsWith('Tally'));
  check('W01_Kingston_correct_tally',[1,0],[s.supply.BR,gameScore(s)],{tally:s.prompt.text,battles:s.coastal.battles});
}
{
  const s=markerPosition();act(s,'ok');
  // Counterfactual: put the withdrawn marker where rule F7 and notes 23/58 require.
  s.aiTroops.box=[];s.troopsReturning.US=1;
  playUntil(s,q=>q.prompt?.title.startsWith('Reset'));
  check('C01_F7_one_return',[false,1,0],[s.log.some(l=>l.text.includes('Troops launched in Kingston')),aiTroopsInBox(s),s.troopsReturning.US],s.prompt.text);
}
for (const pursue of [true,false]) {
  const s=pursuitBoard('dis');if(!pursue){s.combat.tac.att=null;s.tacPlayed=[];s.deck.tacA.push('A_pursuit');}
  addShipToForce(s,'beres',s.encounter.aiForce);encAdd(s,'beres','struck');
  s.ships.beres.steps=0;s.encounter.struckBy.beres='US';
  keep(pursue?'W02_Pursuit_struck':'C02_ordinary_withdrawal',s);
  act(s,'ok');const round=s.prompt.text;act(s,'ok');
  check(pursue?'W02_old_strike_resolved':'C02_strike_resolved',true,beresfordSettled(s),
    {round,next:s.prompt.text,pending:s.encounter?.ships?.beres||null,owner:s.ships.beres.owner,box:s.ships.beres.box,losses:s.lossesThisTurn});
}
{
  const s=pursuitBoard('dis');addShipToForce(s,'beres',s.encounter.aiForce);
  encAdd(s,'beres','struck');s.ships.beres.steps=0;s.encounter.struckBy.beres='US';
  act(s,'ok');act(s,'ok');
  const settled=beresfordSettled(s);
  if(!settled){act(s,'ok');act(s,'pass');act(s,[]);act(s,'ok');}
  const outcomes=[];
  for(const order of ['pass','attack']) {
    const branch=JSON.parse(JSON.stringify(s));
    if(!settled){act(branch,order);playUntil(branch,beresfordSettled);}
    outcomes.push({order,owner:branch.ships.beres.owner,logs:branch.log.map(l=>l.text).filter(txt=>/Beresford.*(?:rescued|CAPTURED|Struck Colors)/i.test(txt))});
  }
  check('W02_new_command_cannot_change_old_prize',true,outcomes[0].owner===outcomes[1].owner,outcomes);
}

for(const human of ['US','BR']){
  const s=galeBoard(human);
  sinkShip(s,'wolfe','US','last ship of Army Support force');
  const pending=s.troopsReturning.BR;
  waitAt(s,'tally','reset');act(s,'ok');
  const available=human==='BR'?s.troops.BR.available:aiTroopsInBox(s);
  check('C03_last_ship_sunk_'+human,[1,1],[pending,available],s.prompt.text);
}

`);
fs.writeFileSync(path.join(__dirname,'followup-results.json'),JSON.stringify(checks,null,2));
console.log(JSON.stringify(checks.map(({id,expected,actual,pass})=>({id,expected,actual,pass})),null,2));
assert(checks.length===9);if(process.argv.includes('--require-rules')&&checks.some(c=>!c.pass))process.exitCode=1;
