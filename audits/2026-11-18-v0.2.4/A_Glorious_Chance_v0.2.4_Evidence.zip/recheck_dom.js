// Runs the unmodified shipped inline script and its actual DOM click handlers
// in jsdom. This is NOT a real-browser or visual-layout test.
const fs=require('fs'),path=require('path'),assert=require('assert');
const {JSDOM,VirtualConsole}=require(process.env.AGC_JSDOM_PATH||'jsdom');
const repo=path.resolve(process.argv[2]||path.join(__dirname,'../../../agc-v0.2.3'));
const html=fs.readFileSync(path.join(repo,'dist/index.html'),'utf8');
const out=__dirname,results={};
async function launch(saved) {
  const errors=[];const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
  const dom=new JSDOM(html,{url:'https://offline-audit.invalid/',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){if(saved)w.localStorage.setItem('agc_solo_companion_v1',saved)}});
  await new Promise(r=>dom.window.addEventListener('load',r));
  return {dom,w:dom.window,doc:dom.window.document,errors};
}
const ev=(t,c)=>t.w.eval(c), st=t=>JSON.parse(ev(t,'JSON.stringify(G_STATE)'));
function button(t,label,root=t.doc){const a=[...root.querySelectorAll('button')].find(e=>e.textContent===label);assert(a,'Missing button '+label);assert(!a.disabled,'Disabled '+label);a.click();}
function change(t,element,value){assert(element);element.value=value;element.dispatchEvent(new t.w.Event('change',{bubbles:true}));}
function loadText(t,text){button(t,'Load');change(t,t.doc.querySelector('#modal textarea'),text);button(t,'Load pasted text',t.doc.querySelector('#modal'));}
function start(t,side,seed){if(side==='BR')button(t,'British Solo CampaignYou are Cdre. Yeo; the A.I. runs the American squadron.');change(t,t.doc.querySelector('input[type=number]'),String(seed));button(t,'Start campaign');}
function pickShips(t,ids){
  ids.forEach(id=>{const name=ev(t,`def(G_STATE.ships[${JSON.stringify(id)}]).name+(def(G_STATE.ships[${JSON.stringify(id)}]).ver?' '+def(G_STATE.ships[${JSON.stringify(id)}]).ver:'')`);const chip=[...t.doc.querySelectorAll('.asg-force')[t.doc.querySelectorAll('.asg-force').length-1].querySelectorAll('.asg-ship')].find(e=>e.textContent.replace(' (Isolated)','')===name);assert(chip,'Missing ship '+name);chip.click();});
}
function step(t){
  const s=st(t),p=s.prompt;assert(p,'No prompt');const root=t.doc.querySelector('#proc');
  if(p.kind==='info')button(t,'Continue',root);
  else if(p.kind==='choice'){const e=p.tactic?root.querySelector('.optcard'):root.querySelector('.opts button.primary')||root.querySelector('.opts button');assert(e);e.click();}
  else if(p.kind==='select'){
    let b=root.querySelector('button.primary');
    if(b.disabled){for(const item of p.items){const name=item.label;const lab=[...root.querySelectorAll('label')].find(e=>e.textContent===name);if(lab)lab.querySelector('input').click();b=root.querySelector('button.primary');if(!b.disabled)break;}}
    assert(!b.disabled,'No legal selection');b.click();
  } else if(p.kind==='lineup')button(t,'Attack with these ships',root);
  else if(p.kind==='assign'){
    if(p.ships.length){
      const mainNames=['pike','sylph','madison','oneida','tompkins','fairam','conquest','wolfe','rg','sss','moira','beres','melville'];
      let main=p.ships.filter(id=>mainNames.includes(id));if(!main.length)main=p.ships.slice(0,1);
      button(t,'+ Add Force',root);pickShips(t,main);
      const capacity=ev(t,`troopCapacity(G_STATE,${JSON.stringify(main)})`);
      if(p.troops&&capacity&&p.missions.ArmySupport){change(t,t.doc.querySelector('.asg-force select'), 'ArmySupport');change(t,t.doc.querySelectorAll('.asg-force select')[1],'NIA');change(t,t.doc.querySelector('.asg-force input[type=number]'),String(Math.min(p.troops,capacity)));}
      else change(t,t.doc.querySelectorAll('.asg-force select')[1],s.turn%2?'NOR':'SAC');
      const sec=p.ships.filter(id=>!main.includes(id));
      if(sec.length){button(t,'+ Add Force',root);change(t,[...t.doc.querySelectorAll('.asg-force')].at(-1).querySelector('select'),'Raid');pickShips(t,sec.slice(0,1));}
    }
    button(t,'Confirm assignments',root);
  } else throw Error(p.kind);
  assert.equal(ev(t,'UI.err'),'');return {kind:p.kind,title:p.title};
}
(async()=>{
  for(const [side,seed]of [['US',181118],['BR',181119]]){
    const t=await launch();start(t,side,seed);const initial=st(t);step(t);const after=st(t);button(t,'↶ Undo');assert.deepStrictEqual(st(t),initial);step(t);assert.deepStrictEqual(st(t),after);
    const re=await launch(t.w.localStorage.getItem('agc_solo_companion_v1'));button(re,'Continue it');assert.deepStrictEqual(st(re),after);re.dom.window.close();
    button(t,'Save');button(t,'Copy save text',t.doc.querySelector('#modal'));const text=t.doc.querySelector('#modal textarea').value;button(t,'Close',t.doc.querySelector('#modal'));step(t);loadText(t,text);assert.deepStrictEqual(st(t),after);
    const trace=[];for(let i=0;i<1200&&!st(t).over;i++)trace.push(step(t));assert(st(t).over);
    const final=st(t),done=await launch(t.w.localStorage.getItem('agc_solo_companion_v1'));button(done,'Review it');assert.equal(st(done).over,true);
    results[side]={seed,prompts:trace.length,score:final.result,errors:t.errors,undoReplay:true,validLoad:true,activeReload:true,completedReview:true};
    fs.writeFileSync(path.join(out,`${side}_final.json`),JSON.stringify({state:final,undo:[]},null,2));done.dom.window.close();t.dom.window.close();
  }
  // Original damaged payload is refused, plus nearby structurally valid but broken saves.
  for(const variant of ['minimal','unknown_pc','excess_steps','excess_supply']){
    const t=await launch();start(t,'US',181123);step(t);const old=st(t),oldSave=t.w.localStorage.getItem('agc_solo_companion_v1'),oldUndo=ev(t,'UNDO.length');
    const bad=JSON.parse(JSON.stringify(old));let payload;
    if(variant==='minimal')payload='{"ships":{},"calls":[]}';
    else {if(variant==='unknown_pc')bad.calls.at(-1).pc='__audit_missing_handler__';if(variant==='excess_steps')bad.ships.madison.steps=999;if(variant==='excess_supply')bad.supply.US=13;payload=JSON.stringify({state:bad,undo:[]});}
    if(variant==='unknown_pc')fs.writeFileSync(path.join(out,'R01_invalid_procedure.json'),payload);
    loadText(t,payload);
    const parsed=JSON.parse(payload);const target=parsed.state||parsed;const accepted=JSON.stringify(st(t))===JSON.stringify(target),preserved=t.w.localStorage.getItem('agc_solo_companion_v1')===oldSave;
    const msg=t.doc.querySelector('#modal')?.textContent||'';
    results['save_'+variant]={accepted,previousAutosavePreserved:preserved,previousStatePreserved:JSON.stringify(st(t))===JSON.stringify(old),undoBefore:oldUndo,undoAfter:ev(t,'UNDO.length'),message:msg};
    if(variant==='unknown_pc'&&accepted){try{step(t)}catch(e){results['save_'+variant].nextActionFailure=ev(t,'UI.err')||e.message;}}
    t.dom.window.close();
  }
  // A valid but unintended import can be undone, restoring the previous game's own history.
  const u=await launch();start(u,'US',181126);const gameA0=st(u);step(u);const gameA1=st(u),historyA=ev(u,'UNDO.slice()');
  const other=await launch();start(other,'BR',181127);const gameB=st(other);other.dom.window.close();loadText(u,JSON.stringify({state:gameB,undo:[]}));assert.deepStrictEqual(st(u),gameB);button(u,'↶ Undo');assert.deepStrictEqual(st(u),gameA1);assert.deepStrictEqual(ev(u,'UNDO.slice()'),historyA);button(u,'↶ Undo');assert.deepStrictEqual(st(u),gameA0);results.loadUndo={previousGameRestored:true,priorUndoHistoryRestored:true};u.dom.window.close();
  // Verify that the exact supplied R01 payload is refused and old saves are still accepted.
  const q=await launch();start(q,'US',181128);step(q);const beforeQ=st(q),undoQ=JSON.stringify(ev(q,'UNDO.slice()')),saveQ=q.w.localStorage.getItem('agc_solo_companion_v1');loadText(q,fs.readFileSync(path.join(__dirname,'inputs/R01_original_v022.json'),'utf8'));results.originalR01={undoHistoryPreserved:undoQ===JSON.stringify(ev(q,'UNDO.slice()')),statePreserved:JSON.stringify(st(q))===JSON.stringify(beforeQ),autosavePreserved:q.w.localStorage.getItem('agc_solo_companion_v1')===saveQ};q.dom.window.close();
  // F08 through the assignment controls.
  const f=await launch();start(f,'BR',181121);while(st(f).prompt.kind!=='assign')step(f);const fix=st(f);fix.troops.BR.available=2;fix.prompt.troops=2;fix.prompt.missions.ArmySupport=['NIA','SAC'];loadText(f,JSON.stringify(fix));
  button(f,'+ Add Force');pickShips(f,['wolfe']);change(f,f.doc.querySelector('.asg-force select'),'ArmySupport');change(f,f.doc.querySelectorAll('.asg-force select')[1],'NIA');change(f,f.doc.querySelector('.asg-force input[type=number]'),'1.5');
  results.F08={confirmDisabled:[...f.doc.querySelectorAll('button')].find(e=>e.textContent==='Confirm assignments').disabled,troopsRemain:st(f).troops.BR.available};f.dom.window.close();
  for(const missed of [false,true]){
    const t=await launch();ev(t,`G_STATE=newGame('US',181122);var s=G_STATE;s.prompt=null;s.calls=[];s.lossesThisTurn=[];s.troopsReturning={US:0,BR:0};s.ships.wolfe.ver='A';newForce(s,'US','NOR','Patrol',['madison','oneida']);newForce(s,'BR','NOR','Patrol',['wolfe']);s.encounter={zone:'NOR',kind:'normal',segment:'patrol',ships:{},side:{},struckBy:{},wg:'US',wgCard:2,withdrawn:{US:false,BR:false}};['madison','oneida','wolfe'].forEach(id=>encAdd(s,id));s.zones.NOR.event=${missed?13:0};s.zones.NOR.flags=${missed?"{missedSignal:'madison'}":"{}"};s.deck.tacA=['A_rof','A_firstshot','A_surprise','A_outmaneuver'];s.deck.tacD=['D_rof','D_firstshot','D_openrange','D_escape','D_repel'];s.calls=[{proc:'combat',pc:'start',A:{attacker:'US',segment:'patrol'},L:{}}];run(s);UI.local=null;render();`);
    const preview=[...t.doc.querySelectorAll('.muted')].map(e=>e.textContent).find(t=>t.startsWith('First-Round Gunnery strength'));
    step(t);while(st(t).prompt&&!st(t).log.some(x=>x.text.startsWith('Gunnery Round 1:')))step(t);
    const actual=st(t).log.find(x=>x.text.startsWith('Gunnery Round 1:')).text;
    assert(preview.includes(missed?'4.5 vs 8':'14.5 vs 8'));assert(actual.includes(missed?'U.S. 4.5 vs British 8':'U.S. 14.5 vs British 8'));
    results[missed?'F10':'previewControl']={preview,actual};t.dom.window.close();
  }
  // Old-version active Encounter is loaded through the actual importer.
  for(const legacy of [false,true]){
    const t=await launch();start(t,'US',181124);const fixture=ev(t,`(()=>{var s=newGame('US',1);s.app=${legacy?"'0.2.1'":"'0.2.3'"};s.turn=2;newForce(s,'US','NOR','Patrol',['oneida']);newForce(s,'BR','NOR','Patrol',['wolfe']);s.turn=1;grantIntelligence(s,'US',29,[]);s.turn=2;s.encounter={zone:'NOR',kind:'normal',segment:'patrol',ships:{},side:{},struckBy:{},wg:'US',wgCard:2,withdrawn:{US:false,BR:false}};['oneida','wolfe'].forEach(id=>encAdd(s,id));${legacy?'delete s.encounter.flagIn;':''}s.calls=[{proc:'encounter',pc:'end',A:{},L:{}}];s.prompt=info('Audit: finish this Encounter','The enemy Flagship is present.');return JSON.stringify({state:s,undo:[]});})()`);
    if(legacy)fs.writeFileSync(path.join(out,'R02_legacy_intelligence.json'),fixture);
    loadText(t,fixture);button(t,'Continue',t.doc.querySelector('#proc'));
    results[legacy?'R02_legacy':'IntelligenceControl']={afterEncounter:st(t).intelligence.US};t.dom.window.close();
  }
  const z=await launch();start(z,'US',181125);ev(z,`Storage.prototype.setItem=function(){throw new Error('simulated storage refusal')}`);step(z);results.autosaveWarning={shown:z.doc.querySelector('#hdr').textContent.includes('Not autosaved')};z.dom.window.close();
  fs.writeFileSync(path.join(out,'dom-results.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
