const fs=require('fs'),path=require('path'),assert=require('assert');
const repo=path.resolve(process.argv[2]);const{x}=require('./load')(repo);const checks=[];
const init=(human='US')=>x(`var s=newGame('${human}',1);s.turn=2;s.calls=[];s.prompt=null;s.lossesThisTurn=[];s.troopsReturning={US:0,BR:0};`);
function eq(id,observed,expected){const pass=JSON.stringify(observed)===JSON.stringify(expected);checks.push({id,expected,observed,pass});}
function enc(ids){x(`s.encounter={zone:'NOR',kind:'normal',segment:'patrol',ships:{},side:{},withdrawn:{US:false,BR:false},struckBy:{},wg:'BR',wgCard:2};${JSON.stringify(ids)}.forEach(id=>encAdd(s,id));`);}
// Original F01 through the actual F7 reset, with blocked/destroyed nearby controls.
init();x(`s.turn=0;s.convoys.US={0:{real:true,revealed:true,result:'S'},1:{real:false,revealed:true}};convoySupply(s,'US',()=>{});s.calls=[{proc:'tally',pc:'reset',A:{},L:{}}];run(s);s.turn=1;convoySupply(s,'US',()=>{});`);eq('F01 scatter recovers',x('s.supply.US'),3);
init();x(`s.turn=0;s.zones.SAC.blockade='BR';s.convoys.US={0:{real:true,revealed:true,result:'S'},1:{real:false,revealed:true}};convoySupply(s,'US',()=>{});s.calls=[{proc:'tally',pc:'reset',A:{},L:{}}];run(s);s.turn=1;convoySupply(s,'US',()=>{});`);eq('F01 blockade holds delayed convoy',x('s.supply.US'),1);
init('BR');x(`newForce(s,'BR','NOR','Patrol',['wolfe','rg']);newForce(s,'US','NOR','Patrol',['oneida']);s.ships.wolfe.steps=2;`);enc(['wolfe','rg','oneida']);
x(`s.combat={att:'BR',def:'US',seq:'B',pos:1,segment:'patrol',col:{BR:['wolfe','rg'],US:['oneida']},tows:{},tac:{att:null,def:null},gr:1,newSeq:false,roundAttackers:['rg']};var f={L:{st:'GR2',txt:'Audit',res:{aHits:1,dHits:0}}};var old66=d66;d66=()=>({red:1,blue:1,v:11});PROCS.combat.grApply(s,f);d66=old66;`);
eq('F02 actual return-fire target excludes Reduced Wolfe',x('[s.ships.wolfe.steps,s.ships.rg.steps]'),[2,2]);
// Independently read run lengths from the rendered printed 13–18 columns.
const ranges={13:[1,3,3,3,3,3,3,3,3,3,3,3,2],14:[2,3,3,3,3,3,3,3,3,3,3,2,1,1],15:[2,2,2,2,2,2,4,4,4,2,2,2,2,2,2],16:[2,2,2,2,2,2,2,4,4,2,2,2,2,2,2,2],17:[2,2,2,2,2,2,2,3,3,2,2,2,2,2,2,2,2],18:Array(18).fill(2)};
for(const[n,rs]of Object.entries(ranges)){const want=rs.flatMap((k,i)=>Array(k).fill(i+1));eq(`F03 all 36 rolls in column ${n}`,x(`Array.from({length:36},(_,i)=>hitPosition(${n},Math.floor(i/6)+1,i%6+1))`),want);}
init();x(`s.turn=1;grantIntelligence(s,'US',29,[]);s.turn=2;`);enc(['wolfe','oneida']);x('resolveEncounterEnd(s)');eq('F04 normal encounter consumes Intelligence',x('s.intelligence.US'),null);
init();x(`s.turn=1;grantIntelligence(s,'US',29,[]);s.turn=2;`);enc(['rg','oneida']);x('resolveEncounterEnd(s)');eq('F04 nonqualifying encounter retains Intelligence',x('!!s.intelligence.US'),true);
init();x(`s.turn=1;grantIntelligence(s,'US',29,[]);s.turn=2;newForce(s,'US','NOR','Patrol',['oneida']);newForce(s,'BR','NOR','Patrol',['wolfe']);`);enc(['wolfe','oneida']);x(`s.encounter.wg='US';var beforePursuit=intelligenceApplies(s,'US');var pursue=PROCS.encounter.afterCombat(s,{ret:{outcome:'pursuit'}});`);
eq('R02a Pursuit begins a new encounter with Intelligence consumed',x(`({next:pursue.goto,intelligenceActive:intelligenceApplies(s,'US')})`),{next:'event',intelligenceActive:false});
init();x(`s.turn=1;grantIntelligence(s,'US',29,[]);s.turn=2;`);enc(['wolfe','oneida']);x(`delete s.encounter.flagIn;resolveEncounterEnd(s);`);eq('R02b legacy encounter without flagIn consumes Intelligence',x('s.intelligence.US'),null);
init('BR');x(`newForce(s,'US','NOR','Patrol',['oneida']);newForce(s,'BR','NOR','Patrol',['wolfe']);s.zones.NOR.event=8;s.turn=1;grantIntelligence(s,'BR',29,[]);s.turn=2;s.flagship.US='oneida';`);enc(['oneida','wolfe']);eq('F05 actual Homeport reaction DRM',x(`humanReactionCandidates(s).find(c=>c.key==='home').drm`),3);
init('BR');x(`s.ships.wolfe.steps=2;`);enc(['wolfe','rg','oneida']);x(`s.encounter.ships.wolfe='dis';s.combat={att:'BR',def:'US',col:{BR:['wolfe','rg'],US:['oneida']}};`);eq('F07 flag transfer after Disengagement',x('flagTransferOptions(s,"BR")'),['rg']);
init('BR');x(`s.troops.BR.available=2;var p=buildAssignPrompt(s);`);eq('F08 fractional markers rejected',x(`!!validateAssignment(s,p,{flagship:p.flagship,forces:[{mission:'ArmySupport',zone:'NIA',ships:['wolfe'],troops:1.5}]})`),true);
init();enc(['oneida','wolfe']);x(`s.ships.oneida.steps=1;s.encounter.ships.oneida='dis';s.combat={att:'BR',def:'US',col:{BR:['wolfe'],US:['oneida']},tac:{att:null,def:null}};var f={L:{wQueue:['US'],failedDis:{US:[],BR:[]},hit:{US:['oneida']},lines:[]}};var w=PROCS.combat.withdraw(s,f);`);eq('F09 all-Disengaged human Force gets W choice',x('w.prompt.title'),'Withdrawal result against you');
// Verify the new timing from an actual grant rather than manually fabricating its lifetime.
init();x(`s.turn=1;grantIntelligence(s,'US',29,[]);`);enc(['wolfe','oneida']);
eq('R02 same-turn Intelligence inactive',x(`intelligenceApplies(s,'US')`),false);
x('resolveEncounterEnd(s)');eq('R02 same-turn Encounter preserves next-turn card',x('s.intelligence.US.until'),2);
x('s.turn=2;');enc(['wolfe','oneida']);eq('R02 next-turn Intelligence active',x(`intelligenceApplies(s,'US')`),true);
x('resolveEncounterEnd(s)');eq('R02 next-turn qualifying Encounter consumes card',x('s.intelligence.US'),null);
init();x(`s.turn=1;grantIntelligence(s,'US',29,[]);s.turn=2;s.calls=[{proc:'tally',pc:'reset',A:{},L:{}}];run(s);`);eq('R02 unused Intelligence expires at next-turn F7',x('s.intelligence.US'),null);
fs.writeFileSync(path.join(__dirname,'engine-results.json'),JSON.stringify(checks,null,2));console.log(JSON.stringify(checks.map(c=>({id:c.id,pass:c.pass,...(!c.pass?{expected:c.expected,observed:c.observed}:{})})),null,2));
