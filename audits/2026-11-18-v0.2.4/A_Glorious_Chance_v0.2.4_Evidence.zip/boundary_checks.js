// Independent nearby controls and boundary cases. Run: node boundary_checks.js /path/to/repo
const fs=require('fs'),path=require('path'),assert=require('assert');
const repo=path.resolve(process.argv[2]||path.join(__dirname,'../../agc'));
const{x}=require('./load')(repo);const passed=[];
function check(name,got,want){assert.deepStrictEqual(JSON.parse(JSON.stringify(got)),want,name);passed.push(name);}
x(`var s=newGame('BR',181123);s.calls=[];s.prompt=null;`);
for(let p=1;p<=11;p++)check(`Force Package ${p}: empty pool deploys nothing`,x(`forcePackageSelect(s,${p},[]).ok`),false);
check('Package 9 without Lady: zero-CA secondaries with lowest LG',x(`forcePackageSelect(s,9,['asp','growler','hamilton'].map(id=>s.ships[id])).ships.sort()`),['asp','growler']);
check('Package 7 excludes unarmed Secondary ships',x(`forcePackageSelect(s,7,['asp','lady','growler','conquest'].map(id=>s.ships[id])).ships.sort()`),['conquest','growler']);
check('Package 11 insufficient Secondary steps',x(`forcePackageSelect(s,11,['lady','growler'].map(id=>s.ships[id])).ok`),false);
check('Gale is redrawn outside its legal event step',x(`s.deck.event=[30,8];drawEvent(s,'audit control',false).id`),8);
x(`s.deck.event=[];s.intelligence.BR={card:29,until:1};var d=drawEvent(s,'exhaustion control',true).id;`);
check('Exhausted Event deck excludes held Intelligence',x(`[d,...s.deck.event].includes(29)`),false);
check('Exhausted deck has 37 cards before draw',x('s.deck.event.length'),36);
// Verify every valid die result in every Land Battle column resolves; source gap 62-63 is separately ruled.
x(`var lbCounts={};for(var g of [0,1,7,16,25])for(var t=1;t<=3;t++)for(var a=1;a<=6;a++)for(var b=1;b<=6;b++){var z=lbLookup(g,t,0,10*a+b);if(!z.result)throw Error('unresolved Land Battle');lbCounts[g+':'+t]=(lbCounts[g+':'+t]||0)+1;}`);
check('All 15 Land Battle columns resolve all 36 valid dice',x('Object.values(lbCounts)'),Array(15).fill(36));
check('More Defenders shifts LG band twice, keeps troop count',x('lbLookup(25,2,-2,31).colLabel'),'7 to 15 Long Gun / 2 Troops');
check('More Defenders stops at lowest LG band',x('lbLookup(1,3,-2,31).colLabel'),'0 Long Gun / 3 Troops');
check('Integer 1 Troops is legal in the F08 setup',x(`s.troops.BR.available=2;var p=buildAssignPrompt(s);validateAnswer(s,p,{flagship:p.flagship,forces:[{mission:'ArmySupport',zone:'NIA',ships:['wolfe'],troops:1}]})`),null);
check('Integer 2 Troops is legal in the F08 setup',x(`validateAnswer(s,p,{flagship:p.flagship,forces:[{mission:'ArmySupport',zone:'NIA',ships:['wolfe'],troops:2}]})`),null);
// Independently calculated British attack strength: (Wolfe A LG2 + Royal George A LG1)/2 + Car8 + Def6 = 15.5.
x(`s.ships.wolfe.ver='A';s.ships.rg.ver='A';`);
check('British attack retains the half point',x(`sideStrength(s,['wolfe','rg'],'BR',false)`),15.5);
const data={passed:passed.length,checks:passed};fs.writeFileSync(path.join(__dirname,'boundary-results.json'),JSON.stringify(data,null,2));console.log(JSON.stringify(data,null,2));
