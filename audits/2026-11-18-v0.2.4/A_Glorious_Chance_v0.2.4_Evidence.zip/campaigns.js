// Deterministic policies use ships, missions and choices visible to the human.
// Diagnostics inspect state and ledger only AFTER actions; hidden decks never guide play.
const fs=require('fs'),path=require('path'),assert=require('assert');const repo=path.resolve(process.argv[2]);
const E=require(path.join(repo,'tools/bundle_engine.js'))();
function policy(s,p,style){
 if(p.kind==='info')return 'ok';
 if(p.kind==='choice'){
  const opts=p.options.filter(o=>!o.disabled);
  const prefs=style==='coast'?['A_rake','A_pursuit','D_escape','bypass','withdraw']:['A_pursuit','A_rake','D_rof','confront','attack','withdraw'];
  const pick=prefs.map(id=>opts.find(o=>o.id===id)).find(Boolean)||opts.find(o=>o.primary)||opts[0];return pick.id;
 }
 if(p.kind==='select'){
  if(/eaction/i.test(p.title)){const a=p.items.map(i=>i.id).slice(0,p.max);if(!E.validateAnswer(s,p,a))return a;}
  if(/pgrade/.test(p.title)&&p.max&&p.items.length){const a=[p.items[0].id];if(!E.validateAnswer(s,p,a))return a;}
  const a=(p.initial||[]).slice();for(const it of [...p.items].reverse()){if(!E.validateAnswer(s,p,a))break;if(!a.includes(it.id))a.push(it.id);}
  return a;
 }
 if(p.kind==='lineup')return {attackers:p.candidates,tows:p.defaultTows||{}};
 if(p.kind==='assign'){
   const ids=p.ships.slice(),enemy=s.human==='BR'?'SAC':'KIN',home=s.human==='BR'?'KIN':'SAC',f=[];
   function take(m,z,ships,t=0){if(!ships.length)return;f.push({mission:m,zone:z,ships,troops:t});for(const id of ships)ids.splice(ids.indexOf(id),1);}
   if(style==='coast'){
    const raidZones=p.missions.Raid||[];for(const z of raidZones){const id=ids.find(i=>!E.def(s.ships[i]).main)||ids.at(-1);if(id&&ids.length>2)take('Raid',z,[id]);}
    if(p.troops>0&&p.missions.ArmySupport){const squad=[];for(const id of ids){squad.push(id);if(E.troopCapacity(s,squad)>=p.troops)break;}const t=Math.min(p.troops,E.troopCapacity(s,squad));if(t)take('ArmySupport',s.turn%2?'NIA':enemy,squad,t);}
    const target=Object.values(s.ships).some(sh=>sh.owner!==s.human&&sh.port==='home'&&['makeReady','deployable'].includes(sh.box));
    if(p.missions.CuttingOut&&ids.length&&target)take('CuttingOut',enemy,[ids[0]]);
    if(ids.length>1)take('Patrol',enemy,ids.slice(0,-1));
   }else{
    if(p.missions.Escort&&ids.length>3)take('Escort',p.missions.Escort[0],[ids.at(-1)]);
    if(p.troops&&p.missions.ArmySupport&&ids.length>2){
     const ships=ids.slice(0,2),t=Math.min(p.troops,E.troopCapacity(s,ships));if(t)take('ArmySupport','NIA',ships,t);
    }
    if(ids.length)take('Patrol',s.turn%3===0?home:enemy,ids.slice(0,Math.max(1,ids.length-1)));
   }
   return {forces:f,flagship:p.flagship};
 }
 throw Error('Unknown prompt '+p.kind);
}
function sumStock(s,side,launched){
 const stored=side===s.human?s.troops[side].track.length+s.troops[side].available:s.aiTroops.track.filter(m=>m.troops).length+s.aiTroops.box.filter(m=>m.troops).length;
 return stored+(s.troopsReturning?.[side]||0)+Object.values(s.forces).filter(f=>f.side===side).reduce((n,f)=>n+(f.troops||0),0)+launched[side];
}
function expectedVictory(s,score){
 if(s.result.forced)return (s.result.forced==='US'?'U.S.':'British')+' Decisive Victory (Dual Blockade)';
 if(Math.abs(score)<=10)return 'Draw';const tier=Math.abs(score)>=33?' Decisive':Math.abs(score)>=22?'':' Marginal';return (score>0?'U.S.':'British')+tier+' Victory';
}
function runCampaigns(){
const startSeed=Number(process.argv[3]||183000), seedCount=Number(process.argv[4]||64);
const resultName=startSeed===183000?'campaign-results.json':'campaign-fresh-results.json';
const res=[],samples={},folder=path.join(__dirname,'saves');
fs.mkdirSync(folder,{recursive:true});
for(let i=0;i<seedCount;i++)for(const side of ['US','BR'])for(const style of ['fleet','coast']){
 const seed=startSeed+i, s=E.newGame(side,seed,{cuttingOut:i%2===0,oa1Upgrades:i%4===0});
 E.run(s);
 const launched={US:0,BR:0},baseline={US:sumStock(s,'US',launched),BR:sumStock(s,'BR',launched)};
 const diffs=[],kinds={};let n=0,original=null;
 while(!s.over && n<1500){
  const p=s.prompt;assert(p);const a=policy(s,p,style);assert(!E.validateAnswer(s,p,a),JSON.stringify({side,seed,style,p:p.title,a}));
  kinds[p.kind]=(kinds[p.kind]||0)+1;
  const was=s.log.length;const before={US:sumStock(s,'US',launched),BR:sumStock(s,'BR',launched)};
  if(!samples[side])original=JSON.stringify({state:s,undo:[]});
  if(seed===183050&&side==='BR'&&style==='fleet'&&n===93)fs.writeFileSync(path.join(folder,'natural_gale_BR_183050.json'),JSON.stringify({state:s,undo:[]},null,2));
  E.act(s,a);n++;const additions=s.log.slice(was);
  for(const e of additions){const m=/^(U\.S\.|British) Troops launched in .+: (\d+)\./.exec(e.text);if(m)launched[m[1]==='U.S.'?'US':'BR']+=+m[2];}
  for(const sd of ['US','BR']){
   const stock=sumStock(s,sd,launched);if(stock===before[sd])continue;
   const change={turn:s.turn,step:n,side:sd,before:before[sd],after:stock,prompt:p.title,next:s.prompt?.title,newLog:additions.map(e=>e.text)};
   diffs.push(change);
   if(!samples[side]&&stock<before[sd]){const name='natural_'+side+'_'+seed+'_'+style;fs.writeFileSync(path.join(folder,name+'.json'),original);samples[side]={name,seed,human:side,style,answer:a,change};}
  }
 }
 assert(s.over);const ledger=s.vpLog.reduce((n,v)=>n+(v.side==='US'?v.n:-v.n),0);assert.equal(ledger,s.result.score);assert.equal(s.result.level,expectedVictory(s,ledger));
 res.push({seed,human:side,style,prompts:n,kinds,finalTurn:s.turn,score:ledger,forced:s.result.forced||null,level:s.result.level,baseline,stockChanges:diffs});
}
const summary={games:res.length,early:res.filter(s=>s.finalTurn<8).length,minPrompts:Math.min(...res.map(r=>r.prompts)),maxPrompts:Math.max(...res.map(r=>r.prompts)),scoreRange:[Math.min(...res.map(r=>r.score)),Math.max(...res.map(r=>r.score))],gamesWithStockChanges:res.filter(r=>r.stockChanges.length).length,samples};
fs.writeFileSync(path.join(__dirname,resultName),JSON.stringify({summary,games:res},null,2));console.log(JSON.stringify(summary,null,2));

}
if (require.main === module) runCampaigns();
module.exports = {policy};
