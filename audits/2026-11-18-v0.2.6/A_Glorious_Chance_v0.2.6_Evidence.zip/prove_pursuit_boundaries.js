// Reconstruct the witness positions from Setup in the unmodified released engines.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {policy}=require('./campaigns');
const {x}=require('./load')(path.resolve(process.argv[2]));
x(fs.readFileSync(path.join(path.resolve(process.argv[2]),'src/ui.js'),'utf8'));
const migrate=x('(s)=>({state:checkSaveState(s),notes:UI.loadNotes.slice()})');
const make=repo=>require(path.join(path.resolve(repo),'tools/bundle_engine.js'))();
const now=make(process.argv[2]), old=make(process.argv[3]), folder=path.join(__dirname,'positions-found');
fs.mkdirSync(folder,{recursive:true});
const clone=x=>JSON.parse(JSON.stringify(x));
const write=(n,s)=>fs.writeFileSync(path.join(folder,n+'.json'),JSON.stringify({state:s,undo:[]}));
function open(E,{side,first=191000,seed,style},decisions) {
  const n=seed-first,s=E.newGame(side,seed,{cuttingOut:n%2===0,oa1Upgrades:n%3===0});
  E.run(s);
  for(let i=0;i<decisions;i++){
    const a=policy(s,s.prompt,style);
    assert(!E.validateAnswer(s,s.prompt,a));
    E.act(s,a);
  }
  return s;
}
function casualty(s,id) {
  return {owner:s.ships[id].owner,box:s.ships[id].box,encounter:s.encounter?.ships[id],captures:s.lossesThisTurn.filter(l=>l.id===id&&l.how==='captured').length};
}
function apply(E,s,style) {
  const p=s.prompt,answer=policy(s,p,style);assert(!E.validateAnswer(s,p,answer));E.act(s,answer);return [p.title,answer];
}
function tally(E,s,style,id) {
  const actions=[];
  while(s.prompt&&!s.prompt.title.startsWith('Tally')&&actions.length<90)actions.push(apply(E,s,style));
  assert(s.prompt?.title.startsWith('Tally'));
  const name=E.def(s.ships[id]).name;
  return {score:E.gameScore(s),vp:s.vp,prize:casualty(s,id),ledger:s.vpLog.filter(v=>v.why.includes(name)),
    fateLog:s.log.filter(l=>l.turn===s.turn&&l.text.startsWith(name)&&/rescued|CAPTURED|Struck Colors/.test(l.text)).map(l=>l.text),actions};
}
const fresh={side:'BR',seed:191073,style:'fleet'};
const f0=open(now,fresh,115);
const f1=clone(f0),action=apply(now,f1,fresh.style);
assert.equal(f1.prompt.title,'Transfer the flag?');
assert.equal(f1.app,'0.2.6');
assert(f1.prompt.text.includes('Growler Strike Check'));
assert.equal(f1.encounter.ships.growler,'struck');
const upgraded=migrate(clone(f1));
const normalPlay=tally(now,clone(f1),fresh.style,'growler');
const reloadedPlay=tally(now,clone(upgraded.state),fresh.style,'growler');
write('F01_fresh_before_Growler_strikes',f0);
write('F01_fresh_pending_flag_transfer',f1);
const major={side:'BR',seed:191347,style:'fleet'};
const w0=open(now,major,40), w1=clone(w0);
const toWithdrawal=apply(now,w1,major.style);
assert.equal(w1.prompt.title,'Withdrawal result against you');
assert(w1.prompt.text.includes('Wolfe (B) Strike Check')&&w1.encounter.ships.wolfe==='struck');
const wLoaded=migrate(clone(w1));
const stay=s=>{const c=clone(s);now.act(c,'stay');return tally(now,c,major.style,'wolfe');};
const stayNormal=stay(w1), stayReload=stay(wLoaded.state);
write('F01_fresh_before_Wolfe_strikes',w0);
write('F01_fresh_pending_withdrawal',w1);
const l={side:'BR',seed:191074,style:'fleet'};
const prior=open(old,l,112), justAfter=clone(prior), startPursuit=apply(old,justAfter,l.style), later=open(old,l,120);
assert(prior.prompt.text.includes('Asp Strike Check 7'));
assert(later.prompt.text.includes('Lord Melville Strike Check 5+4'));
assert.equal(later.encounter.ships.asp,'struck');
assert.equal(later.encounter.ships.julia,'struck');
const earlyRepair=migrate(clone(justAfter));
const lateRepair=migrate(clone(later));
assert.equal(casualty(earlyRepair.state,'asp').owner,'BR');
assert.equal(casualty(lateRepair.state,'julia').encounter,'struck');
write('F02_before_Asp_pursuit',prior);
write('F02_just_after_Asp_pursuit',justAfter);
write('F02_after_Melville_sinks',later);
const report={
  fresh:{setup:fresh,action,promptBefore:f0.prompt.title,atSave:f1.prompt.title,text:f1.prompt.text,
    before:casualty(f1,'growler'),after:casualty(upgraded.state,'growler'),notice:upgraded.notes,
    normalPlay,reloadedPlay,
    priorPursuit:f1.log.filter(l=>l.turn===f1.turn&&l.text.includes('Pursuit!'))},
  scoredFresh:{setup:major,turn:w1.turn,zone:w1.encounter.zone,toWithdrawal,atSave:w1.prompt.title,round:w1.prompt.text,
    pending:casualty(w1,'wolfe'),upgraded:casualty(wLoaded.state,'wolfe'),notice:wLoaded.notes,withoutReload:stayNormal,afterReload:stayReload},
  late:{setup:l,startPursuit,originalRound:prior.prompt.text,atBoundary:justAfter.prompt.title,lateRound:later.prompt.text,earlyNotice:earlyRepair.notes,
    earlyPrize:casualty(earlyRepair.state,'asp'),lateNotice:lateRepair.notes,latePrize:casualty(lateRepair.state,'asp'),
    laterJulia:casualty(lateRepair.state,'julia'),lateTally:tally(now,lateRepair.state,l.style,'asp')}
};
fs.writeFileSync(path.join(__dirname,'pursuit-proof-results.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({fresh:{action,before:report.fresh.before,after:report.fresh.after,normalTally:normalPlay.score,reloadTally:reloadedPlay.score,normalCredit:normalPlay.ledger,reloadCredit:reloadedPlay.ledger,notice:report.fresh.notice},scoredFresh:report.scoredFresh,late:{startPursuit,early:report.late.earlyPrize,late:report.late.latePrize,notice:report.late.lateNotice}},null,2));
if(process.argv.includes('--require-fixes')){
  assert.deepEqual(report.fresh.after,report.fresh.before,'Fresh Growler must remain pending.');
  assert.deepEqual(report.late.latePrize,report.late.earlyPrize,'Asp must have the same owner at either save point.');
}
