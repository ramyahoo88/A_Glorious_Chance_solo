// Simulate ordinary seeded campaigns and exercise the released save validator at selected live prompts.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { isDeepStrictEqual } = require('node:util');
const repo = path.resolve(process.argv[2]);
const source = path.resolve(process.argv[3]);
const E = require(path.join(source, 'tools/bundle_engine.js'))();
const { policy } = require('./campaigns');
function validator(dir){
  const { x } = require('./load')(dir);
  x(fs.readFileSync(path.join(dir, 'src/ui.js'), 'utf8'));
  return x('(st) => { const result = checkSaveState(st); return { result, notes: (UI.loadNotes || []).slice() }; }');
}
const loadSave = validator(repo);
const isLegacy = source !== repo;
const baseline = !isLegacy && process.argv[6] ? validator(path.resolve(process.argv[6])) : null;
const first = Number(process.argv[4] || 191000);
const count = Number(process.argv[5] || 512);
const report = { first, count, app: isLegacy ? '0.2.4' : '0.2.6', games: 0, decisions: 0, loads: 0, pursuitWindows: 0, struckPrompts: 0, changed: 0, existingNormalization: 0, mismatches: 0, errorCount: 0, examples: [] };
const folder = path.join(__dirname, 'positions-found');
fs.mkdirSync(folder, { recursive: true });
const clone = value => JSON.parse(JSON.stringify(value));
const currentStruck = s => Object.keys(s.encounter?.ships || {}).filter(id => s.encounter.ships[id] === 'struck');
const proof = (id, raw, record) => {
  if (report.examples.length >= 32) return;
  const k = report.examples.length + 1;
  const filename = (isLegacy ? 'legacy' : 'fresh') + '-' + k + '-' + id + '.json';
  fs.writeFileSync(path.join(folder, filename), JSON.stringify({ state: raw, undo: [] }));
  report.examples.push({ ...record, file: filename });
};
for (let i = 0; i < count; i++) for (const human of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const seed = first + i;
  const s = E.newGame(human, seed, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 3 === 0 });
  E.run(s);
  let pursuit = null;
  for (let num = 0; s.prompt && !s.over && num < 1500; num++) {
    const old = currentStruck(s);
    const forced = pursuit && s.turn === pursuit.turn && old.length && (!isLegacy || s.encounter === pursuit.encounter);
    const context = { seed, human, style, turn: s.turn, zone: s.encounter?.zone, index: num, prompt: s.prompt.title };
    report.decisions++;
    if (forced) report.struckPrompts++;
    if ((!isLegacy && num % 7 === 0) || forced) {
      report.loads++;
      const raw = clone(s);
      let retry;
      try { retry = loadSave(clone(raw)); } catch (error) {
        report.errorCount++;
        proof('error', raw, { ...context, error: error.message });
      }
      if (retry && !isDeepStrictEqual(raw, clone(retry.result))) {
        const earlier = baseline && !retry.notes.length && isDeepStrictEqual(clone(baseline(clone(raw)).result), clone(retry.result));
        if(earlier) report.existingNormalization++;
        else {
          report.changed++;
          if (!isLegacy) proof('unexpected-change', raw, { ...context, notes: retry.notes, owners: old.map(id => [id, raw.ships[id].owner, retry.result.ships[id].owner]), rng: [raw.rng, retry.result.rng], log: raw.log.slice(-6) });
        }
      }
      if (retry && isLegacy && forced) {
        for (const id of old) {
          if (!pursuit.fates[id]) continue;
          const expected = pursuit.fates[id], actual = [retry.result.ships[id].owner, retry.result.encounter.ships[id]];
          if (!isDeepStrictEqual(expected, actual)) {
            report.mismatches++;
            proof('changed-fate', raw, { ...context, id, expected, actual, repair: retry.notes, atBoundary: pursuit.step, log: raw.log.slice(-12) });
          }
        }
      }
    }
    const p = s.prompt, a = policy(s, p, style), previousLog = s.log.length, zone = s.encounter?.zone;
    assert(!E.validateAnswer(s, p, a), JSON.stringify(context));
    E.act(s, a);
    const change = s.log.slice(previousLog);
    if (change.some(l => /^Pursuit! The withdrawal is cancelled and a new Encounter begins/.test(l.text))) {
      report.pursuitWindows++;
      const fates = {};
      if (isLegacy && currentStruck(s).length) {
        const upgraded = loadSave(clone(s)).result;
        currentStruck(s).forEach(id => { fates[id] = [upgraded.ships[id].owner, upgraded.encounter.ships[id]]; });
      }
      pursuit = { turn: s.turn, zone, fates, step: num + 1, encounter: s.encounter };
    }
    if (s.turn !== pursuit?.turn || isLegacy && !s.encounter) pursuit = null;
  }
  assert(s.over);report.games++;
}
const name = isLegacy ? 'legacy-scan' : 'fresh-scan';
fs.writeFileSync(path.join(__dirname, name + '.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ ...report, examples: report.examples.map(({log,...ex})=>ex).slice(0,5) }, null, 2));
