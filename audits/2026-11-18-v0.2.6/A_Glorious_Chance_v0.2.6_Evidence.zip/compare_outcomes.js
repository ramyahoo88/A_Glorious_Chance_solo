const fs=require('fs'),path=require('path');
const dir=__dirname,repo=path.resolve(process.argv[2]);
const E=require(path.join(repo,'tools/bundle_engine.js'))();
const {policy}=require(path.join(dir,'campaigns'));
const {x}=require(path.join(dir,'load'))(repo);
x(fs.readFileSync(path.join(repo,'src/ui.js'),'utf8'));
const load=x('s => checkSaveState(s)');
const cases=JSON.parse(fs.readFileSync(path.join(dir,'fresh-scan.json'))).examples;
const clone=s=>JSON.parse(JSON.stringify(s));
for(const info of cases){
 if(!info.owners?.some(([,a,b])=>a!==b))continue;
 const raw=JSON.parse(fs.readFileSync(path.join(dir,'positions-found',info.file))).state;
 const ids=info.owners.filter(([,a,b])=>a!==b).map(([id])=>id);
 for(const br of (raw.prompt.options||[]).filter(p=>!p.disabled).map(p=>p.id)){
  const visit=s=>{
   const turns=s.turn;
   E.act(s,br);
   for(let i=0;s.turn===turns&&s.prompt&&!s.prompt.title.startsWith('Tally')&&i<100;i++)E.act(s,policy(s,s.prompt,info.style));
   return {score:E.gameScore(s),owners:ids.map(id=>s.ships[id].owner),capture:ids.map(id=>s.lossesThisTurn.filter(x=>x.id===id&&x.how==='captured').length),ended:s.prompt?.title};
  };
  const before=visit(clone(raw)),after=visit(load(clone(raw)));
  if(before.score!==after.score||JSON.stringify(before.owners)!==JSON.stringify(after.owners))console.log(JSON.stringify({seed:info.seed,turn:info.turn,side:info.human,plan:info.style,step:info.index,file:info.file,prompt:raw.prompt.title,br,ids,before,after}));
 }
}
