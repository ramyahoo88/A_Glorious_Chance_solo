// Play the earlier shipped HTML, using its Save and autosave. Reopen using the released v0.2.6 page.
const {fs,path,assert,out,launch,st,button,start,loadText,html}=require('./page_helpers');
const oldHTML=fs.readFileSync(path.join(path.resolve(process.argv[3]),'dist/index.html'),'utf8');
const src=n=>path.join(out,'new-saves',n+'.json');
const read=n=>fs.readFileSync(src(n),'utf8');
const result={};
const fixture=path.join(out,'positions-found');
fs.mkdirSync(fixture,{recursive:true});
const proc=t=>t.doc.querySelector('#proc');
const note=t=>proc(t).querySelector('.err')?.textContent||'';
const next=t=>button(t,'Continue',proc(t));
function save(t,name){
  button(t,'Save');const data=t.doc.querySelector('#modal textarea').value;
  button(t,'Close',t.doc.querySelector('#modal'));
  if(name)fs.writeFileSync(path.join(fixture,name+'.json'),data);
  return data;
}
const autosave=t=>t.w.localStorage.getItem('agc_solo_companion_v1');
const oldRun=async bytes=>{const t=await launch(undefined,oldHTML);start(t,JSON.parse(bytes).state.human,58001);loadText(t,bytes);return t;};
const run=async(data,via)=>{
  const t=await launch(via==='autosave'?data:undefined);
  if(via==='autosave')button(t,'Continue it');
  else {
    start(t,'US',8502);
    if(via==='paste')loadText(t,data);
    else {
      button(t,'Load');const field=t.doc.querySelector('input[type=file]');
      const file=new t.w.File([data],'audit.json',{type:'application/json'});
      Object.defineProperty(field,'files',{value:[file]});
      const done=new Promise((resolve,reject)=>{
        const timeout=setTimeout(()=>reject(new Error('FileReader timeout')),3500);
        const obs=new t.w.MutationObserver(()=>{
          if(!t.doc.querySelector('#modal').classList.contains('open')){
            clearTimeout(timeout);obs.disconnect();resolve();
          }
        });
        obs.observe(t.doc.querySelector('#modal'),{attributes:true});
      });
      field.dispatchEvent(new t.w.Event('change',{bubbles:true}));
      await done;
    }
  }
  return t;
};
const clean=t=>{assert.deepStrictEqual(t.errors,[]);t.dom.window.close();};
const avail=s=>s.aiTroops.box.filter(m=>m.revealed&&m.troops).length;
const troopResult=t=>{const s=st(t);return {available:avail(s),queue:s.troopsReturning[s.ai],lines:note(t),title:s.prompt.title};};
const prizeResult=t=>{const s=st(t);return {owner:s.ships.beres.owner,state:s.encounter.ships.beres,scoreEntries:s.lossesThisTurn.filter(x=>x.id==='beres').length,lines:note(t),title:s.prompt.title};};
async function routes(n,name,readout,validate) {
  const file=read(name), old=await oldRun(file);
  assert.equal(st(old).app,'0.2.4');
  const oldAuto=autosave(old);
  const entries={};
  for(const via of ['file','paste','autosave']){
    const t=await run(via==='autosave'?oldAuto:file,via);
    entries[via]=readout(t);
    validate(entries[via]);assert(entries[via].lines.includes('Older save upgraded'));
    const exported=save(t);
    const r=await run(exported,'paste');
    const again=readout(r);
    assert.deepStrictEqual(again,{...entries[via],lines:''});
    assert.deepStrictEqual(st(t),st(r));
    clean(r);clean(t);
  }
  next(old);
  const host=await run(autosave(old),'autosave');
  button(host,'↶ Undo');
  entries.undo=readout(host);
  validate(entries.undo);assert(entries.undo.lines.includes('Older save upgraded'));
  clean(host);clean(old);result[n]=entries;
}
async function cutoff() {
  const t=await oldRun(read('L01_after_v024_withdrawal'));
  for(let i=0;i<3;i++)next(t);
  assert(st(t).prompt.text.includes('Carrying 1 Troops'));
  const sailed=save(t,'L01_old_already_sailed');
  const after=await run(sailed,'file');
  assert(note(after).includes('load a save from before the withdrawal'));
  const old=JSON.parse(sailed).state, kept=st(after);
  const attempted=kept.migrated;delete kept.migrated;
  assert.deepStrictEqual(kept,old);
  result.sailed={hint:note(after),sameBoard:true,attempted};
  while(!st(t).prompt.title.startsWith('Tally'))next(t);
  const tally=save(t,'E02_old_after_Kingston_Tally');
  const atTally=await run(tally,'file');
  result.L01_tally={title:st(atTally).prompt.title,note:note(atTally),score:st(atTally).vp.US-st(atTally).vp.BR,britishSupply:st(atTally).supply.BR,seenOnSailing:result.sailed.hint};
  assert.equal(result.L01_tally.score,-7);assert.equal(result.L01_tally.britishSupply,-1);
  const post=await run(read('L01_after_v024_withdrawal'),'paste');
  while(!st(post).prompt.title.startsWith('Tally'))next(post);
  const tallyFixed=st(post);
  result.fixedTally=[tallyFixed.vp.US-tallyFixed.vp.BR,tallyFixed.supply.BR,tallyFixed.troopsReturning.US];
  assert.deepStrictEqual(result.fixedTally,[0,1,1]);
  for(const w of [t,after,atTally,post])clean(w);
}
async function pendingPackage() {
  const original=JSON.parse(fs.readFileSync(path.join(out,'baseline-saves','W01_B20.json'),'utf8'));
  const s=original.state;
  s.options.manualPackages=true;
  s.aiTroops.track.pop();
  s.aiTroops.box=[{ troops:true, revealed:true }];
  s.nb=-72;s.nbBand=0;
  s.targetRow[1].id='B35';
  const pre=JSON.stringify(original);
  fs.writeFileSync(path.join(fixture,'E01_manual_package_control.json'),pre);
  const before=await oldRun(pre);
  for(let i=0;i<4;i++)next(before);
  assert.equal(st(before).prompt.title,'AI Force Package #7');
  assert(st(before).prompt.text.includes('Troops 2 row'));
  const stuck=save(before,'E01_old_B35_at_package_picker');
  const loaded=await run(stuck,'file');
  const noteAtLoad=note(loaded), shown=st(loaded).prompt.text;
  assert.equal(avail(st(loaded)),1);assert.equal(st(loaded).troopsReturning.US,1);
  const eligible=st(loaded).prompt.items.filter(it=>!/^(Asp|Lady of the Lake) /.test(it.label));
  for(const choice of eligible){
    const box=[...proc(loaded).querySelectorAll('.sel-list label')].find(l=>l.textContent===choice.label).querySelector('input');
    box.click();
  }
  button(loaded,'Confirm',proc(loaded));
  const applied=st(loaded), card='Target Card B35:';
  const route=await run(pre,'paste');
  for(let i=0;i<4;i++)next(route);
  const fixed=st(route), text=s=>s.log.filter(l=>l.text.includes(card)).map(l=>l.text);
  result.manual={seed:s.seed,noteAtLoad,shown,selected:eligible.map(it=>it.id),loaded:applied.prompt.title,legacyDeploy:text(applied),controlled:text(fixed),
    forcesAfterLoad:Object.values(applied.forces).filter(f=>f.side==='US'&&f.zone==='KIN').map(f=>({mission:f.mission,ships:f.ships,troops:f.troops})),
    forcesFromBefore:Object.values(fixed.forces).filter(f=>f.side==='US'&&f.zone==='KIN').length};
  assert(result.manual.controlled.some(t=>t.includes('Troops 1 row')&&t.includes('blank')));
  assert.equal(result.manual.forcesFromBefore,0);
  for(const t of [before,loaded,route])clean(t);
}
(async()=>{
  await routes('L01','L01_after_v024_withdrawal',troopResult,v=>assert.deepStrictEqual([v.available,v.queue],[0,1]));
  await routes('L02','L02_after_v024_pursuit',prizeResult,v=>assert.deepStrictEqual([v.owner,v.state,v.scoreEntries],['US','done',1]));
  await cutoff();await pendingPackage();
  fs.writeFileSync(path.join(out,'load-path-results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({paths:Object.keys(result.L01),baseTally:result.fixedTally,warning:result.sailed,atTally:result.L01_tally,manual:{actual:result.manual.forcesAfterLoad,expected:result.manual.forcesFromBefore}},null,2));
  if(process.argv.includes('--require-boundaries')){
    const issues=[];
    if(result.manual.forcesAfterLoad.length!==result.manual.forcesFromBefore)issues.push('A pending Target Card kept its old row.');
    if(!result.L01_tally.note.includes('before the withdrawal'))issues.push('The reused Troops warning was missing at Tally.');
    assert.deepStrictEqual(issues,[]);
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
