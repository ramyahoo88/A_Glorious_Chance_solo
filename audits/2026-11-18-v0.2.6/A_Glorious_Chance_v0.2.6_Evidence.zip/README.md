# A Glorious Chance Solo v0.2.6 re-audit evidence

The reviewed GitHub release and code are b7eb835e11b55372367af4701cd324b12f0cb8a3. The reviewed public Pages HTML is c592ad47b52de348da4569ac6c61f441ec364067. Both and the separate rebuild contain 300,650 bytes and SHA-256 4ca717bd1893d095378e1a6aab9756005adcb1f937ea2f379842b668a1b07bb5. See audit.md for the report text and code references. The public URL serves the current deployment, so use the pinned dist/index.html when the page has advanced.

## Load the witness positions

In the public app at https://ramyahoo88.github.io/A_Glorious_Chance_solo/, use **Load game** from Setup or **Load** during play. Pick the JSON file or paste its full text. Move or test counters only on a test game. A running game has Undo after import.

| File | What to try |
|---|---|
| positions-found/F01_fresh_before_Wolfe_strikes.json | Real v0.2.6 game, British seed 191347, June II at Niagara. Click Continue once to enter Withdrawal result against you. At that point either reload and Continue it, or choose Ignore – fight on and Undo. Wolfe is incorrectly captured by the U.S. Replaying from the same initial file and continuing without recovery leaves Wolfe pending. |
| positions-found/F01_fresh_pending_withdrawal.json | The fresh save from one click later, already at the withdrawal choice. Importing it prematurely awards Wolfe to the U.S. |
| positions-found/F01_fresh_before_Growler_strikes.json | A second v0.2.6 fresh position, seed 191073, British, September I. Continue once to Transfer the flag? and reload. Growler is captured prematurely. |
| positions-found/F02_just_after_Asp_pursuit.json | Genuine v0.2.4 British campaign, seed 191074. On load after the first Encounter, Asp is captured for Britain. |
| positions-found/F02_after_Melville_sinks.json | Same turn and Pursuit. The repair now rolls 5 and rescues Asp for the U.S. Julia's later surrender stays pending. |
| positions-found/E01_old_B35_at_package_picker.json | A focused B35 case. Load and see 1 Available and 1 due back at F7 while the picker uses the 2-Troops row. Select all, deselect Asp and Lady of the Lake, then Confirm. One marker lands at Kingston. Continue to Tally, with score −7 and British supply −1. |
| positions-found/E01_manual_package_control.json | The matching B35 board before withdrawal. Four Continues in v0.2.6 correctly read the blank row and bypass the deployment. |
| positions-found/L01_old_already_sailed.json | The original B20 voyage has already deployed. It shows the earlier-save warning and keeps the in-game position. |
| positions-found/E02_old_after_Kingston_Tally.json | Later save from that same old campaign. It opens at Tally with no warning and retains score −7 and British supply −1. |
| new-saves/L01_after_v024_withdrawal.json | The original L01 reproduction queues the marker, sends no second force and reaches score 0 and British supply 1. |
| new-saves/L02_after_v024_pursuit.json | The original Beresford reproduction repairs on load. Pass the Patrol segment, confirm zero Reactions and change the next Command Decision. Either branch preserves exactly one U.S. capture. |

For Wolfe, after the withdrawal prompt choose **Ignore – fight on**. Continue past Gunnery and Weather Gage. Choose Attack, select Sir Sidney Smith for the Reaction Check, confirm, continue, then Attack again. Continue from Encounter ended and through the Land Battle. The uninterrupted score is 0 and Wolfe stays British on 1d6 4. The reloaded score is +32. This comparison uses the exact same decisions.

## Repeat the audit

Run from the extracted archive. Python 3.12+, Git and Node are used for build and engine checks. The live HTML comparison needs network access. The DOM tests use jsdom 26.1.0.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git project
git -C project checkout --detach b7eb835e11b55372367af4701cd324b12f0cb8a3
git -C project worktree add --detach "$PWD/v025" aa6de34
git -C project worktree add --detach "$PWD/v024" f15cdd3
python compare_release.py project
python verify_public.py project
npm --prefix project test

node next_rules.js project --require-rules
node recheck_engine.js project
node boundary_checks.js project
node edges.js project
node followup_rules.js project --require-rules
node new_boundaries.js project
node map_checks.js project
node paper_checks.js project
node export_data.js project
python verify_land_aid.py
```

For the Target-card matrices, also use separately obtained VASSAL v1.0 module images, Pillow and NumPy. Run `python verify_component_grids.py /path/to/extracted/images` after the data export.

```sh
npm install --prefix audit-node jsdom@26.1.0
export NODE_PATH="$PWD/audit-node/node_modules"
node recheck_dom.js project
node legacy_dom.js project
node verify_legacy_rake.js project --require-rules
node check_load_paths.js project v024
node prove_pursuit_boundaries.js project v024
node check_load_paths.js project v024 --require-boundaries
node prove_pursuit_boundaries.js project v024 --require-fixes
```

The final two commands deliberately exit 1 on the reviewed release. The positive comparisons use the original v0.2.4 Save exports, the original older autosave, and its actual stored Undo history. In the two failing Pursuit comparisons, normal seeded play generates the new and old witness boards. The B35 package and Tally warning tests use focused reconstructions.

```sh
node scan_migrations.js project project 191000 512 v025
node scan_migrations.js project v024 191000 512
node compare_outcomes.js project
node campaign_controls.js project BR 191073 fleet
```

The fresh scan plays both human sides and two policies for each seed. It tests every seventh decision and checks every prompt with a pending surrender after a Pursuit that turn. The earlier validator distinguishes existing flag bookkeeping from changes caused by the new recovery. The old scan compares late Pursuit prizes with recovery at their original boundary. The two scans record 42,709 fresh loads with 20 migrations that should not occur and 12 wrong old prize comparisons across 1,224 checked old prompts. These scripted observations are reproducible, and are not estimates of the rate in games played by people.

The Chrome campaign used the controls recorded in controls-191073.json. Enter that British seed with default settings, and press Tab to commit the field. The signed browser ledger and exact tested prompt sequence are in public-browser-results.json. The genuine finished download is positions-found/Chrome-final-191073.json.

The archive contains tested state, traces and derived rule comparisons. It does not include publisher artwork or the source rule PDFs. Their identifiers and hashes are in source-manifest.json.

**Verdict.** Hold save and Undo sign-off. Fix the fresh-save capture and the late legacy prize first.
