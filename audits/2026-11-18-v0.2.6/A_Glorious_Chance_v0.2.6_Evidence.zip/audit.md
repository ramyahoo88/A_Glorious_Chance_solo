# A Glorious Chance Solo
## v0.2.6 release and save re-audit
18 November 2026 · Release commit b7eb835

**Hold release sign-off. A mid-combat reload or Undo can change the result of a new v0.2.6 game.** The original L01 and L02 saves repair correctly. The same migration also runs on fresh saves and can award a ship before the printed Capture or Rescue procedure.

| Priority | Finding | Reproduced result |
|---|---|---|
| Blocker · F01 | A new surrender can be mistaken for an old Pursuit surrender. | In fresh seed 191347, reload or Undo changes Wolfe from a pending British surrender to a U.S. capture. Identical later play changes the June II score from 0 to +32. |
| High · F02 | A later Encounter's casualties can change the repair of an earlier surrender. | In old seed 191074, the first save after Pursuit awards Asp to Britain. A save after Lord Melville sinks rolls and rescues Asp for the U.S. |
| High · F03 | Repairing the Troops count leaves a pending manual package on the old row. | B35 still sends an Army Support force to Kingston. The replay from before withdrawal uses the corrected row and skips that deployment. |
| Low · F04 | The recovery warning disappears at Tally. | A late old save imports a turn already scored at −7 with British supply −1. The earlier deployment save shows the recovery warning. |

### Verified release
At review, main and release/v0.2.6 both pointed to b7eb835e11b55372367af4701cd324b12f0cb8a3. The Pages branch was c592ad47b52de348da4569ac6c61f441ec364067. The public page opened without sign-in and read v0.2.6 after a normal reload. The separate build, GitHub release HTML, Pages branch and anonymous public HTTP response all matched at **300,650 bytes**. [Reviewed commit](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/b7eb835e11b55372367af4701cd324b12f0cb8a3) · [Public companion](https://ramyahoo88.github.io/A_Glorious_Chance_solo/)

`4ca717bd1893d095378e1a6aab9756005adcb1f937ea2f379842b668a1b07bb5`

The evidence bundle includes source links, importable before and after positions, browser observations, runnable comparisons, both simulated release cohorts and the byte check.

<!-- page -->
## F01 · Reload or Undo can award a fresh surrender
**A new campaign can lose a flagship and give the opponent 32 VP merely by recovering a save.** Struck Colors suspends the ship until the end of its own Encounter, when LC5.3 determines Capture or Rescue. A05 and project notes 68 and 71 only settle surrenders from the Encounter that ended at Pursuit.

### Repeat in desktop Chrome
Load `positions-found/F01_fresh_before_Wolfe_strikes.json`. It came from a fresh v0.2.6 British campaign at seed 191347, June II, Niagara. An earlier Pursuit has already started the present Encounter. The save opens at **Tactics**. Click **Continue** once.

The new combat yields D2W, with both hits on Wolfe (B). His Strike Check is 2 + 1, so he still has British ownership and is awaiting settlement at **Withdrawal result against you**. Choose one of these routes.

| Route from the withdrawal prompt | Immediate result | Same decisions through the June II Tally |
|---|---|---|
| Continue without recovery. | British ownership, Struck Colors, no capture entry. | On 1d6 4, Wolfe returns to Britain. The signed score is 0, with 4 cumulative VP per side. |
| Reload and click **Continue it**. | A notice calls this an older surrender and awards Wolfe to the U.S. before the choice. | The ledger awards 32 U.S. VP for Wolfe. The signed score is +32. |
| Click **Ignore – fight on** and immediately press **Undo**. | The previous prompt returns with Wolfe already captured by the U.S. | The same early capture is recorded. |

To reach the two tallies, choose **Ignore – fight on**. Continue through Gunnery and Weather Gage, choose **Attack**, select Sir Sidney Smith for the Reaction Check, confirm and continue. Choose **Attack** at the next Command Decision, then continue through Encounter ended and the Land Battle result. The evidence records the rendered prompts and both scoring rows.

The save data actually says v0.2.6. A second fresh witness at seed 191073 captures Growler on loading **Transfer the flag?**. Its branch eventually captures Growler during continuous play too. In 42,709 validation checks across 2,048 fresh scripted campaigns, 20 positions were altered by the new repair. Nineteen were at the withdrawal choice and one at flag transfer. The earlier save validator made its existing normalization in another 1,190 positions. These counts describe the sampled saves.

### Smallest fix
Limit the repair to proven prior-Encounter surrenders and distinguish snapshots written by the corrected procedure. The active combat frame already has the new Strike Check in its pending lines. The code currently classifies it as old because it has yet to write those lines to the log. Use the pending lines in the recovery test and require affirmative evidence of the original surrender before changing the board. Cover Undo as well as imports. `src/engine_combat.js:373` · `src/engine_combat.js:404` · `src/engine_combat.js:598` · `src/ui.js:49` · `src/ui.js:116`

<!-- page -->
## F02 · A later casualty can reverse an old Pursuit prize
**The same earlier surrender can recover to two different owners depending on the save point.** Under project note 68, the pursued U.S. defender counts as withdrawn when the old Encounter ends. The pursuing British side is still present at that boundary. Asp therefore becomes a British capture. The loss of a British ship in the next Encounter has no bearing on that prize. [Project ruling and migration intent](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/b7eb835e11b55372367af4701cd324b12f0cb8a3/RULES_NOTES.md#L95)

### Repeat with two saves from the same old campaign
Both positions came from uninterrupted v0.2.4 play at seed 191074, British campaign, August II, Kingston breakout. Lord Melville attacked the U.S. blockading force. In the first Engagement, Gunnery roll 4 at 2.5:1 gave A1/D3W and Asp's Strike Check was 7. Lord Melville and eligible U.S. ships continued under Pursuit.

| Load this file in v0.2.6 | Result on load |
|---|---|
| `positions-found/F02_just_after_Asp_pursuit.json` | The migration awards Asp to Britain and records one capture for F1 scoring. |
| `positions-found/F02_after_Melville_sinks.json` | Lord Melville has sunk during the later Engagement on a Strike Check of 5 + 4. Migration rolls 5 to rescue Asp for the U.S. The original capture entry is absent. |

The later snapshot also contains Julia's pending U.S. surrender from the new combat. The repair leaves Julia pending in this example. The Asp error removes a 4-VP British capture from this turn's eventual ledger. The original Beresford save still passes because it is saved at the first Event, before another combat alters the balance of ships.

In the paired old-engine sweep, the same policies played 2,048 seeded v0.2.4 campaigns. I checked 1,224 later prompts associated with a Pursuit and pending struck ship. Twelve prize comparisons in ten games disagreed with the settlement immediately after the original boundary. The submitted saves and trace include the exact same old dice and choices.

### Smallest fix
Resolve using the sides' status at the Pursuit boundary. Where only the pursued side could have withdrawn, the original defender's struck ships are captured without a roll. A later save should preserve that decision. If the historic state cannot establish both sides' status, warn and request a pre-Pursuit save. The current migration passes the correct pursued side into the shared procedure but also lets it infer the other side's fate from ships present now. `src/engine_combat.js:606` · `src/engine_combat.js:611` · `src/engine_encounter.js:490` · `src/engine_encounter.js:493`

<!-- page -->
## F03 · A manual deployment keeps the wrong Troops row
**A repaired marker can still produce an illegal Kingston attack.** The printed B35 table at Naval Balance ≤−70 has a blank with one Troops marker and uses Force Package 7 with two. Rule 11.1.2 and the errata use the number of currently Available Troops. LC5 and F7 hold the withdrawn marker out of that pool until reset.

Load `positions-found/E01_old_B35_at_package_picker.json`, the focused British campaign at seed 185301, July I. The old engine has sent Madison to In Transit and opened the manual picker before placing the second force. There is one legitimate marker in Available and one would-be early return.

1. The notice correctly puts one marker into the F7 queue and the Board shows one Available.
2. The picker still shows the **two-Troops row** and **Force Package #7**. Select all, deselect Asp and Lady of the Lake, then **Confirm**.
3. Eleven ships sail with the remaining marker. Continue to Tally. Land Battle roll 45 at 17 Long Gun is Attacker Success. The score is −7 and British supply is −1.

In `positions-found/E01_manual_package_control.json`, four Continues from before withdrawal read B35 at one Troops marker and deploy nothing. The Tally is 0 and British supply is 1. I checked both tracks in Chrome and read the B35 card face.

Recompute the saved AI deployment after the Troops count changes. Re-enter its card lookup before restoring the manual assignment controls. If the saved prompt cannot be rebuilt safely, show the earlier-save warning. The count changes in the migration. The picker and place steps still use the row and mission cached when the old save was made. `src/engine_combat.js:590` · `src/engine_deploy.js:159` · `src/engine_deploy.js:214` · `src/engine_deploy.js:264`

### F04 · Late old saves lose their recovery warning
Load `positions-found/L01_old_already_sailed.json` to see the requested recovery message. It asks for the save before withdrawal and keeps the ships, markers, and dice as saved. Load `positions-found/E02_old_after_Kingston_Tally.json`, generated by continuing that same v0.2.4 game. The original invalid supply loss and −7 score have already been scored. The game opens silently before F7.

Extend the detection and message into Tally when the log proves reuse. Keep settled scoring as saved and point to the earlier position for replay. The current phase gate skips Tally. This is a recovery notice defect. `src/engine_combat.js:578` · `src/engine_combat.js:585` · `src/engine_tally.js:5`

<!-- page -->
## What passed and what the release needs
The prior audit's exact L01 and L02 positions passed through file input, pasted text, autosave and Undo in the shipped HTML under jsdom. Desktop Chrome separately confirmed file, paste, reload, Undo and the visible repairs on the public site. L01 queued the single marker, skipped B20, and reached 0 with British supply 1. Reload preserved the repaired state. L02 recorded one capture of Beresford before the later commands, and either command preserved it. The older Rake case continued to pass.

I played a complete British campaign in desktop Chrome at seed 191073. The fleet policy used Patrol, available Army Support, and convoy escorts. All 148 prompts matched the scripted choices, including 109 information confirmations. The 26 signed final ledger rows give U.S. 57, Britain 31, and **+26 U.S. Victory**. Download and finished-game reload recovered the exact state. The separate branch at the withdrawal prompt in seed 191347 compared the failure with uninterrupted play. Landscape desktop Chrome covered the live checks. Hardware mobile playback and offline shortcut launch remain unverified here.

All **206 fixed repository assertions** and **200 smoke campaigns** passed. The audit reran the 28 previous finding comparisons, the 22 save and engine checks, 23 boundary checks, 29 extended checks, and 11 additional Pursuit and F7 controls. The 2,048 fresh campaigns used a matched set of 512 seeds, both sides and fleet and coastal policies. I validated every seventh decision and all sampled prompts with a pending surrender following Pursuit that turn. The legacy cohort replayed the same seeds under the v0.2.4 engine. These are deterministic regression tests.

### Published rule and aid checks
The reviewed rules are the British Living Rules (7 August 2024), U.S. Living Rules (13 April 2024), Living Playbook (6 August 2024), and errata (13 April 2024). I used the printed page layouts at F7 and LC5.3, the A05 and A06 faces, the Target cards, maps and photographed Aids V and VII. I treated Pursuit's settlement under note 68 as the project's ruling. [Publisher support](https://www.legionwargames.com/legion_AGC_GS.html) · [Errata](https://www.legionwargames.com/docs/AGC_errata_and_clarifications_rev_13Apr2024.pdf)

| Checked material | Result |
|---|---|
| Both Target decks | 104 cards and all 2,912 deployment cells agreed, including the B35 adjacent control. |
| Force Packages, Hit Distribution and maps | The 11 Force Packages, all 648 Hit Distribution cases across 18 columns, 70 Lake Combat cells and 60 Convoy Scatter cells passed. |
| Land Battle Aid VII | All 538 printed outcomes matched across 15 columns. |

**Unresolved ruling.** Land Battle Aid VII leaves rolls 62 and 63 open at zero Long Gun and three Troops. The app treats both as Attacker Success. The materials reviewed did not settle those two entries.

**Hold v0.2.6 for save, reload and Undo.** Fix the false capture in newly saved games first, then make the old Pursuit outcome independent of later casualties. Recompute a pending Target Card after moving the marker and carry the old-save warning through Tally. The original migration passes and the public build is reproducible.
