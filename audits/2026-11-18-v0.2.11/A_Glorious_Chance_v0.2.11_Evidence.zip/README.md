# A Glorious Chance v0.2.11 audit evidence

The reviewed v0.2.9 checkout is 1c0edd236297b31db6a10ba34e8617bdde096734. The gameplay fixes in v0.2.10 were published at db76199d8e845616d44fda05014380503f253b8e. The final v0.2.11 application is 696f1d2a272973696c59e3ba7b82dc83479003b0. Its Pages deployment is 2176fdcf871831951e2b03da4c3abb5f292e2b2b. All four are in ramyahoo88/A_Glorious_Chance_solo. Open dist/index.html and use **Load → Choose file** for a referenced position. Generated results, transcripts and autosave wrappers are identified separately from importable game saves in the reports below.

| Directory | Contents |
| --- | --- |
| release | Separate-path rebuild script, checksums for all three shipped versions, final HTTP comparison and complete test logs. |
| printed | Source manifest, independent paper transcriptions and original-art classification checks, including every Target deployment cell and every Land Battle column. Obtain the publisher sources listed in the manifest to repeat the image comparison. |
| deploy | Aid V package oracle and replays, original B35 position and its legal second-stage save, September-I and A5 controls. Read README.md. |
| combat | Lake combat rules, baseline and fixed replays, seven staged positions and three natural positions under campaign. Read REPORT.md. |
| coastal | Harbor, coastline and victory timing. Nine importable positions and resulting board states. Read README.md. |
| persistence | Fresh-save rejection, interruption, Undo and manual corrections. Read README.md for tests through the page. |
| phone | Five confirmed UI defects, touch lookups and nearby controls. Read FINDINGS.md. |
| campaign | Per-game results for both releases, policies, independent tally oracle, all eight turns of a representative campaign and natural replay positions. Commands and seeds are in findings.md. |
| table | Matched grouped/individual game states and prompt counts for 160 game pairs. Read README.md. |
| browser | Two complete public Chromium campaigns, exact UI action transcripts, midgame checks, final-state comparisons and screenshots. The chrome subdirectory contains actual public-page exports. |

From the corrected checkout, run `npm test`. For the UI suite install jsdom 26.1.0 in a test-only directory, point NODE_PATH at its node_modules, and run `npm run test:ui`. Running `python release/compare_release.py /path/to/checkout` from this evidence directory rebuilds the pinned checkout's sources in a separate temporary directory and runs cmp. Run it on a clean checkout of any of the three application commits. The independent data and campaign scripts take a checkout path. The publisher's complete rulebooks and VASSAL module are available from its game support page. The manifest records the edition, exact files and hashes used here.

The root SHA256SUMS lists the archived files other than the checksum file itself. From the unpacked root, `sha256sum -c SHA256SUMS` verifies them.
