## Visual coverage inventory

Symbols: C = club; H = heart; D = diamond; A = downward arrow; S = square; T = star; O = circle. “—” means absent. Spyglass is present on cards 1–20 and absent on 21–38. Initial Weather Gage is A on 1–19, B on 20–29 and 31–38, and absent on Gale 30.

| Card | Lake event and affected side | Invalidating symbols | Coastal event |
|---|---|---|---|
| 1 | Minor Damage, British | C H T | None |
| 2 | Construction Delay, U.S. | — | None |
| 3 | Construction Delay, British | — | None |
| 4 | Construction Delay, British | — | None |
| 5 | Convoy Delay, British | — | None |
| 6 | Missed Signal, British | H D | None |
| 7 | Sickness, U.S. | C D S O | None |
| 8 | Fair Wind, human | — | None |
| 9 | Extra Men, U.S. | — | None |
| 10 | Extra Men, British | — | None |
| 11 | Separated Ships, U.S.; clockwise, displaced force becomes Patrol | H D | None |
| 12 | Sickness, British | C D O | None |
| 13 | Missed Signal, U.S. | H D | None |
| 14 | Separated Ships, British; counterclockwise, displaced force becomes Patrol | H D | None |
| 15 | Adverse Wind, human | — | None |
| 16 | Haze | C H A S T | None |
| 17 | Haze | C H A S T | None |
| 18 | Adverse Wind, human | — | None |
| 19 | Rainy Squalls | C H D A S T | None |
| 20 | Rainy Squalls | C H D A S T | Local Militia |
| 21 | Rainy Squalls | C H D A S T | Supplies Burned |
| 22 | Adverse Wind, human | — | Supplies Moved |
| 23 | Haze | C H A S T | Heated Shot |
| 24 | Adverse Wind, human | — | Heated Shot |
| 25 | Fair Wind, human | — | Explosion |
| 26 | Sickness, U.S. | C D S O | Requisition |
| 27 | Separated Ships, U.S.; clockwise, both forces become Patrol | H D | Requisition |
| 28 | Sickness, British | C D O | Requisition |
| 29 | Missed Signal, U.S. | H D | Intelligence |
| 30 | Gale; Lake Action Phase only | — | Not a coastal event; redraw |
| 31 | Fair Wind, A.I. | — | Intelligence |
| 32 | Fair Wind, A.I. | — | Sudden Storm |
| 33 | Minor Damage, U.S. | C H T | Sudden Storm |
| 34 | Separated Ships, British; counterclockwise, displaced force becomes Patrol | H D | Sudden Storm |
| 35 | Missed Signal, British | H D | Sudden Storm |
| 36 | Convoy Delay, U.S. | — | More Defenders |
| 37 | Commanding Breeze, British attack | — | More Defenders |
| 38 | Commanding Breeze, British attack | — | More Defenders |

Source-layout anomaly: the VASSAL image named `_0029_Event 20.jpg` prints “21” at the bottom, as does the following Supplies Burned card. Its Rainy Squalls/Local Militia content and spyglass distinguish it. The module's named slot and this app consistently identify it as event 20; this is not reported as an application defect.

