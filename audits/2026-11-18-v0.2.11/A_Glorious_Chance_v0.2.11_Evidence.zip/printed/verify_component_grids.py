"""Compare every Target Card deployment cell with independently classified source pixels.
Templates below are visually identified cells, not values read from the implementation.
Requires Pillow and numpy. Run from the delivered audit directory with source images.
"""
from pathlib import Path
import json,re,numpy as np
from PIL import Image,ImageDraw
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('vmod_image_dir',type=Path)
args=parser.parse_args()
out=Path(__file__).resolve().parent
pics=args.vmod_image_dir
app=json.load(open(out/'app-data.json'))['targets']
paths={}
for p in pics.glob('*Target-*.jpg'):
 m=re.search(r'Target-([AB])\s*(\d+)',p.name)
 if m: paths[m[1]+str(int(m[2]))]=p
cols=[(142,237),(238,332),(333,427),(428,522),(523,617),(618,712),(713,810)]
rows=[(318,364),(370,416),(421,468),(473,519)]
images={k:Image.open(p).convert('L') for k,p in paths.items()}
def crop(k,r,c):
 im=images[k];x0,x1=cols[c];y0,y1=rows[r]
 return im.crop((x0+6,y0+6,x1-6,y1-6))
def sig(im):
 a=np.array(im)<100;ys,xs=np.where(a)
 if not len(ys):return np.zeros((28,28)),0,0
 m=a[ys.min():ys.max()+1,xs.min():xs.max()+1];h,w=m.shape
 return np.array(Image.fromarray((m*255).astype('uint8')).resize((28,28)))/255,w,h
# - / I / 2 / 3 / 4 / 5 / 6 / 7 / 8 / 9 / IO / II in the printed font.
ident={0:('B1',0,0),1:('B9',0,6),2:('B9',0,5),3:('B9',0,4),4:('B9',0,3),5:('B9',0,2),6:('B9',0,1),7:('B9',0,0),8:('B20',1,4),9:('B1',1,1),10:('B1',1,4),11:('B1',1,3)}
templates={n:sig(crop(*loc)) for n,loc in ident.items()}
canvas=Image.new('RGB',(6*170,2*90),'white');d=ImageDraw.Draw(canvas)
for idx,(n,loc) in enumerate(ident.items()):
 x=idx%6*170;y=idx//6*90;d.text((x,y),f'{n}: {loc}',fill='black');canvas.paste(crop(*loc).resize((150,60)),(x,y+20))
canvas.save(out/'grid_templates.png')
results=[];mismatch=[];weak=[]
for key,p in sorted(paths.items()):
 grid=[]
 for r in range(4):
  row=[]
  for c in range(7):
   im=crop(key,r,c);v,w,h=sig(im)
   if key.startswith('A'):
    # A's elongated ship icon fills more than 17% of the cell; blanks are empty.
    ink=(np.array(im)<100).mean();value=int(ink>.17);quality=round(float(ink),3)
   else:
    ranked=sorted((float(np.abs(v-v2).mean()+abs(w-w2)*.02+abs(h-h2)*.01),n) for n,(v2,w2,h2) in templates.items())
    quality,value=ranked[0]
    if not h: value=0;quality=0
    if quality>.13: weak.append([key,r,c,value,quality])
   row.append(value)
   expected=int(app[key]['grid'][r][c])
   if value!=expected:mismatch.append([key,r,c,value,expected,quality])
  grid.append(row)
 results.append({'id':key,'pictureGrid':grid})
res={'cards':len(results),'cells':len(results)*28,'mismatches':mismatch,'weakClassifications':weak,'grids':results}
json.dump(res,open(out/'component-grid-results.json','w'),indent=2)
print(json.dumps({'cards':len(results),'cells':len(results)*28,'mismatches':mismatch,'weakClassifications':len(weak)},indent=2))
can=Image.new('RGB',(8*140,((len(weak)+7)//8)*75),'white');d=ImageDraw.Draw(can)
for i,(k,r,c,v,q) in enumerate(weak):
 x=i%8*140;y=i//8*75;d.text((x,y),f'{k} r{r} c{c} => {v}',fill='black');can.paste(crop(k,r,c).resize((132,50)),(x,y+20))
can.save(out/'weak_grid_cells.png')
