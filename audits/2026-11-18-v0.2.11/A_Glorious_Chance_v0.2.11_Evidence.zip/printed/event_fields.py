"""Compare the rendered 38-face inventory to the app's data export. Columns are independent."""
from pathlib import Path
import json
root=Path(__file__).parent
inventory=root/'event-face-inventory.md'
events=json.loads((root/'app-data.json').read_text())['events']
keys={'Minor Damage':'minorDamage','Construction Delay':'constructionDelay','Convoy Delay':'convoyDelay','Missed Signal':'missedSignal','Sickness':'sickness','Extra Men':'extraMen','Separated Ships':'separated','Haze':'haze','Rainy Squalls':'rainySqualls','Gale':'gale','Adverse Wind':'adverseWind','Commanding Breeze':'commandingBreeze'}
coastal={'None':'none','Local Militia':'localMilitia','Supplies Burned':'suppliesBurned','Supplies Moved':'suppliesMoved','Heated Shot':'heatedShot','Explosion':'explosion','Requisition':'requisition','Intelligence':'intelligence','Not a coastal event':'gale','Sudden Storm':'suddenStorm','More Defenders':'moreDefenders'}
symbols={'C':'club','H':'heart','D':'diamond','A':'arrow','S':'square','T':'star','O':'circle'}
n=0
for line in inventory.read_text().splitlines():
 if not line.startswith('| '):continue
 cells=[c.strip() for c in line.strip('|').split('|')]
 if not cells[0].isdigit():continue
 id=int(cells[0]);lake,icons,action=cells[1:]
 name=lake.split(',')[0].split(';')[0]
 k=keys.get(name)
 if name=='Fair Wind': k='fairWindAI' if 'A.I.' in lake else 'fairWindHuman'
 if 'both forces' in lake:k='separatedBoth'
 side='US' if ', U.S.' in lake else 'BR' if ', British' in lake and name!='Commanding Breeze' else None
 want=[id<=20,'A' if id<=19 else 'B' if id!=30 else None,sorted(symbols[c] for c in icons.split() if c in symbols),k,side,coastal[action.split(';')[0]]]
 actual=events[str(id)]
 have=[bool(actual['spy']),actual['wg'],sorted(actual['sym']),actual['lake'],actual['lakeSide'],actual['coastal']]
 assert want==have,(id,want,have)
 n+=1
assert n==38
print(f'{n} Event faces x 6 fields match the rendered inventory.')
