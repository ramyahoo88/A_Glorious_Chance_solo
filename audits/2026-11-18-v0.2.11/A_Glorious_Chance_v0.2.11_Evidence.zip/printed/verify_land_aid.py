"""Compare the released Land Battle Table with the photographed 2023 Aid VII."""
import json
from pathlib import Path

folder = Path(__file__).resolve().parent
# Columns are read left to right. Within each band, the three columns are Troops 1, 2, 3.
# Rows are Defender Major, Defender Success, Draw, Attacker Success, Attacker Major, Feat.
printed_rows = [
    "11-14 11-13 11-12 11 - - 11 - - 11 - - - - -",
    "15-23 14-23 13-21 12-16 11-14 11-13 12-13 11-12 11 12 11 11 11 11 11",
    "24-43 24-41 22-34 21-34 15-31 14-26 14-31 13-26 12-24 13-24 12-22 12-21 12-16 12-15 12-14",
    "44-65 42-64 35-61 35-62 32-61 31-56 32-55 27-54 25-53 25-52 23-51 22-46 21-44 16-35 15-33",
    "66 65-66 64-65 63-66 62-66 61-64 56-66 55-66 54-63 53-66 52-66 51-62 45-66 36-66 34-61",
    "- - 66 - - 65-66 - - 64-66 - - 63-66 - - 62-66",
]
details = ["Defender Major Success", "Defender Success", "Draw", "Attacker Success", "Attacker Major Success", "Attacker Feat of Arms"]
bands = ["0", "1 to 6", "7 to 15", "16 to 24", "25+"]
printed = [r.split() for r in printed_rows]
assert all(len(row) == 15 for row in printed)
app = json.loads((folder / 'app-data.json').read_text())["landBattle"]

def parse_interval(token):
    if token == "-":
        return None
    values = tuple(int(part) for part in token.split("-"))
    return values[0], values[-1]

def matches(rows, roll):
    hit = [details[i] for i, pair in enumerate(rows) if pair and pair[0] <= roll <= pair[1]]
    assert len(hit) <= 1, (roll,hit)
    return hit[0] if hit else None

report = {"columns": 0, "diceCases": 0, "printedMatches": 0, "unassignedInPhoto": [], "mismatches": []}
for band in range(5):
    for troops in range(1, 4):
        report["columns"] += 1
        actual = app[band][troops - 1]
        photo = [parse_interval(row[band*3 + troops-1]) for row in printed]
        for red in range(1, 7):
            for blue in range(1, 7):
                die = red * 10 + blue
                report["diceCases"] += 1
                expected, observed = matches(photo, die), matches(actual, die)
                case = {"longGun": bands[band], "troops": troops, "roll": die, "app": observed}
                if expected is None:
                    report["unassignedInPhoto"].append(case)
                elif expected != observed:
                    report["mismatches"].append({**case, "photo": expected})
                else:
                    report["printedMatches"] += 1
assert report["printedMatches"] == 538, report
assert [(r["longGun"], r["troops"], r["roll"], r["app"]) for r in report["unassignedInPhoto"]] == [
    ("0", 3, 62, "Attacker Success"), ("0", 3, 63, "Attacker Success")
]
assert not report["mismatches"]
(folder / 'land-aid-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
