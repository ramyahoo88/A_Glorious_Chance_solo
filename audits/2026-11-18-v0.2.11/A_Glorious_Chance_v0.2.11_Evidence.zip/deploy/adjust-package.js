// Load the genuine B35 position, then try to remove the only eligible first stack through Adjust.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{JSDOM,VirtualConsole}=require('jsdom');
async function check(file){
 const errors=[],dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',url:'https://audit.invalid/',virtualConsole:new VirtualConsole().on('jsdomError',e=>errors.push(e.message))});
 const w=dom.window,d=w.document;await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const button=t=>[...d.querySelectorAll('button')].find(b=>b.textContent.trim()===t);
 const click=t=>{const b=button(t);assert(b&&!b.disabled,'Enabled '+t);b.click();};
 const change=(select,val)=>{select.value=val;select.dispatchEvent(new w.Event('change',{bubbles:true}));};
 const selectByOption=opt=>[...d.querySelectorAll('#modal select')].find(n=>[...n.options].some(o=>o.value===opt));
 click('Load a saved game');d.querySelector('#modal textarea').value=fs.readFileSync(path.join(__dirname,'Package8_BR_871004.json'),'utf8');click('Load pasted text');
 click('Adjust');
 change(selectByOption('pike'),'pike');change(selectByOption('outOfPlay'),'outOfPlay');click('Apply');
 const message=d.querySelector('#modal .err')?.textContent||'';
 click('Close');click('Save');
 const s=JSON.parse(d.querySelector('#modal textarea').value).state;click('Close');
 const result={title:d.title,pike:s.ships.pike.box,message,listed:s.prompt.items?.some(o=>o.id==='pike'),errors};
 if(button('Use suggested ships')){click('Use suggested ships');result.confirm=!button('Confirm').disabled;
  if(result.confirm){click('Confirm');result.next=d.querySelector('#proc h2')?.textContent;
   if(button('Use suggested ships')){click('Use suggested ships');result.patrolConfirm=!button('Confirm').disabled;}}
 }else{
  const l=[...d.querySelectorAll('#proc .sel-list label')].find(n=>n.textContent.startsWith('General Pike'));
  if(l){l.querySelector('input').click();if(!button('Confirm').disabled){click('Confirm');click('Save');const v=JSON.parse(d.querySelector('#modal textarea').value).state;result.applied=v.ships.pike.box;}}
 }
 dom.window.close();return result;
}
check(process.argv[2]).then(v=>{console.log(JSON.stringify(v,null,2));if(process.argv.includes('--require-fixed')){assert.equal(v.pike,'deployable');assert(v.message);assert.equal(v.patrolConfirm,true);assert.equal(v.errors.length,0);}}).catch(e=>{console.error(e);process.exitCode=1;});
