// Exercise shipped HTML buttons and inspect only the exported save. Requires jsdom.
const {JSDOM,VirtualConsole}=require('jsdom'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const results=[],errors=[];
async function run(tag,file,width,unit){
 const dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',url:'https://audit.invalid/',virtualConsole:new VirtualConsole().on('jsdomError',e=>errors.push(e.message)),
   beforeParse(w){Object.defineProperty(w,'innerWidth',{configurable:true,value:width});}});
 const w=dom.window,d=w.document;await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const button=label=>[...d.querySelectorAll('button')].find(b=>b.textContent.trim()===label);
 const click=label=>{const b=button(label);assert(b&&!b.disabled,'enabled button '+label);b.click();};
 function load(f){click('Load a saved game');d.querySelector('#modal textarea').value=fs.readFileSync(path.join(__dirname,f),'utf8');click('Load pasted text');}
 function save(){click('Save');const value=JSON.parse(d.querySelector('#modal textarea').value).state;click('Close');return value;}
 const fleet=s=>Object.values(s.forces).filter(f=>f.cardId==='B35').map(f=>({mission:f.mission,ships:f.ships,troops:f.troops}));
 const row={tag,width,unit};
 if(unit==='package'){
  load('Package8_BR_871004.json');
  row.emptyAllowed=!button('Confirm').disabled;
  d.querySelector('#proc .sel-list').querySelectorAll('label').forEach(l=>{if(l.textContent.startsWith('General Pike'))l.querySelector('input').click();});
  row.oneAllowed=!button('Confirm').disabled;
  if(tag==='baseline'){
   assert(row.emptyAllowed&&row.oneAllowed);click('Confirm');row.applied=fleet(save());assert.equal(row.applied.length,1);
  }else{
   assert(!row.emptyAllowed&&!row.oneAllowed);click('Use suggested ships');assert.equal(d.querySelectorAll('.sel-list input:checked').length,13);click('Confirm');
   assert(button('Confirm').disabled);row.emptyPatrolAllowed=false;
   const pre=save();click('Use suggested ships');assert.equal(d.querySelectorAll('.sel-list input:checked').length,12);click('Confirm');
   const after=save();row.applied=fleet(after);assert.deepEqual(row.applied.map(f=>f.ships.length),[1,12]);
   click('↶ Undo');assert.deepEqual(save(),pre);click('Use suggested ships');click('Confirm');assert.deepEqual(save(),after);row.undoReplayExact=true;
  }
 }else if(unit==='humanPurchase'){
  load('A5_human_two_CA_US_871101.json');click('Confirm');
  const labels=[...d.querySelectorAll('#proc .sel-list label')];
  labels.find(l=>l.textContent.startsWith('Hamilton')).querySelector('input').click();
  row.oneCAAllowed=!button('Confirm').disabled;
  assert.equal(row.oneCAAllowed,tag==='baseline');
  if(tag==='baseline'){click('Confirm');const s=save();row.box=s.ships.hamilton.box;row.delay=s.cd.US;}
  else {const other=[...d.querySelectorAll('#proc .sel-list label')].find(l=>l.textContent.startsWith('Fair American'));other.querySelector('input').click();click('Confirm');const s=save();row.twoCAPurchase=[s.ships.hamilton.box,s.ships.fairam.box,s.cd.US];assert.deepEqual(row.twoCAPurchase,['ordinary','ordinary',0]);}
 }else if(unit==='purchase'){
  load('A5_one_CA_BR_871101.json');click('Confirm');const s=save();row.box=s.ships.hamilton.box;row.delay=s.cd.US;
  assert.equal(row.box,tag==='baseline'?'ordinary':'deployable');assert.equal(row.delay,1);
 }else{
  load('SeptemberI_requisition_'+unit+'.json');click('Continue');const s=save();row.over=s.over;row.next=s.prompt?.title||null;row.score=s.result?.score;
  assert.equal(row.over,tag==='candidate'&&unit==='reduced');
 }
 results.push(row);dom.window.close();
}
(async()=>{for(const [tag,file] of [['baseline',process.argv[2]],['candidate',process.argv[3]]])for(const width of [390,1280])for(const unit of ['package','purchase','humanPurchase','reduced','full'])await run(tag,file,width,unit);
 assert.deepEqual(errors,[]);console.log(JSON.stringify({environment:'jsdom. Widths are nominal. No layout or hardware assertions.',runs:results,errors},null,2));})().catch(e=>{console.error(e);process.exitCode=1;});
