// Run against either source tree. Writes fixtures only when --write is supplied.
// node reproduce.js /path/to/checkout [--write]
// The natural Package 8 first-stage save in this directory was reached with the
// 48-action trace shipped in tests/fixtures/v0210-deploy-path.json.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]), write=process.argv.includes('--write');
const order=JSON.parse(fs.readFileSync(path.join(root,'tools/files.json'))).engine;
const ctx=vm.createContext({console,localStorage:{getItem(){return null;},setItem(){}}});
vm.runInContext(order.map(f=>fs.readFileSync(path.join(root,'src',f),'utf8')).join('\n;\n')+'\n;installResume();\n'+fs.readFileSync(path.join(root,'src/ui.js'),'utf8'),ctx);
const E=vm.runInContext('({checkSaveState,newGame,run,act,validateAnswer,topFrame,aiTroopsInBox,lg,ca,def})',ctx);
const clone=x=>JSON.parse(JSON.stringify(x));
const read=name=>E.checkSaveState(JSON.parse(fs.readFileSync(path.join(__dirname,name))).state);
function save(name,s){
 E.checkSaveState(clone(s));
 if(write)fs.writeFileSync(path.join(__dirname,name),JSON.stringify({state:s,undo:[]})+'\n');
}
const result={release:JSON.parse(fs.readFileSync(path.join(root,'package.json'))).version};
const natural=read('Package8_BR_871004.json');
const patrol=['oneida','madison','tompkins','fairam','conquest','growler','hamilton','julia','ontario','pert','raven','scourge'];
const union=['pike',...patrol];
function confirm(s,selection){
 const error=E.validateAnswer(s,s.prompt,selection);
 if(!error)E.act(s,selection);
 return {selection,error,after:s.prompt?.title,forces:Object.values(s.forces).filter(f=>f.cardId==='B35').map(f=>({ships:f.ships,mission:f.mission,zone:f.zone,troops:f.troops}))};
}
result.incomplete=confirm(clone(natural),['pike']);
result.skipped=confirm(clone(natural),[]);
const second=clone(natural); assert.equal(E.validateAnswer(second,second.prompt,union),null);E.act(second,union);
save('Package8_second_BR_871004.json',second);
result.badSplit=confirm(clone(second),['pike']);
result.emptyPatrol=confirm(clone(second),[]);
result.correctSplit=confirm(clone(second),patrol);
assert.equal(result.correctSplit.forces.length,2);
result.suddenDeath=[];
result.construction=[];
for(const ids of [['hamilton'],['hamilton','fairam']]){
 const q=E.newGame('BR',871101);q.turn=2;q.cd.US=2;q.flagship.US='lady';
 Object.values(q.ships).filter(sh=>sh.owner==='US').forEach(sh=>{sh.box=sh.id==='lady'||ids.includes(sh.id)?'deployable':'outOfPlay';});
 q.calls=[{proc:'turn',pc:'A4',A:{},L:{}}];q.prompt=null;E.run(q);
 if(ids.length===1)save('A5_one_CA_BR_871101.json',q);
 E.act(q,[]);
 result.construction.push({ids,delayAfter:q.cd.US,ships:ids.map(id=>[id,q.ships[id].box]),log:q.log.filter(l=>l.text.includes('must buy down Construction Delay')).map(l=>l.text)});
}
const human=E.newGame('US',871101);human.turn=2;human.cd.US=2;
Object.values(human.ships).filter(sh=>sh.owner==='US').forEach(sh=>{sh.box=['hamilton','fairam'].includes(sh.id)?'deployable':'outOfPlay';});
human.calls=[{proc:'turn',pc:'A4',A:{},L:{}}];human.prompt=null;E.run(human);
save('A5_human_two_CA_US_871101.json',human);E.act(human,[]);
const badPurchase=E.validateAnswer(human,human.prompt,['hamilton']);
if(!badPurchase)E.act(human,['hamilton']);
result.humanPurchase={error:badPurchase,delay:human.cd.US,hamilton:human.ships.hamilton.box};
for(const steps of [2,3]){
 const s=E.newGame('BR',871100);
 s.turn=6;s.phase='tally';s.stepLabel='F Tally and Reset';
 Object.values(s.ships).filter(sh=>sh.owner==='US').forEach(sh=>{sh.box='sunk';sh.steps=0;});
 const sh=s.ships.madison;sh.box='requisitioned';sh.steps=steps;sh.flags.reqUntil=7;
 s.prompt=null;s.calls=[{proc:'turn',pc:'next',A:{},L:{}},{proc:'tally',pc:'reset',A:{},L:{}}];E.run(s);
 assert.equal(s.prompt.title,'Reset – end of September I');
 save('SeptemberI_requisition_'+(steps===2?'reduced':'full')+'.json',s);
 E.act(s,'ok');
 const next=s.prompt?.title; 
 // A2up pauses before A3 for the British human; inspect the final destination.
 if(!s.over&&s.prompt?.title.startsWith('A2 British Ship Upgrades'))E.act(s,[]);
 result.suddenDeath.push({steps,over:s.over,followingReset:next||null,afterA3:sh.box,result:s.result});
}
console.log(JSON.stringify(result,null,2));
