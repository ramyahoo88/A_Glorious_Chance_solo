# Deployment, setup and end-of-turn audit

The baseline is v0.2.9 at `1c0edd236297b31db6a10ba34e8617bdde096734`. Findings D01–D03 were reproduced against its checked-in HTML and the candidate build. The position files use the normal Load dialog. The labels *natural* and *constructed* describe how each position was obtained.

## D01 · Medium · The manual picker accepted illegal A.I. forces

**Player impact.** A player using manual American Force Packages could skip a mandatory deployment, fight a smaller force, or put the wrong ships into battle. The default automatic bot chose legal forces in the checks below.

**Rule.** British Solo §5.3.1, p.21 right column, and the photographed 2023 Player Aid V, both printed columns and footnote. Player judgment resolves eligible ship choices. Package 8 needs a first Force of Main ships with at least 8 Close Action carrying Troops on Army Support, and a separate Patrol of at least 22 Long Gun in the same zone. The Main-first, fewest-ships rule applies to each selection. A d6 selects Army Support on odd or Patrol on even. The British p.12 diagram uses the Naval Balance column and the row for Troops in the box plus Troops already embarked. The setup below uses the actual B35 face.

**Exact reproduction.** Load `Package8_BR_871004.json`. This is a natural British campaign after 48 ordinary answers, August I, first Encounter, Kingston, B35, Naval Balance +62, one revealed U.S. Troop. Verify that the printed one-Troop row and rightmost column show 8. On the initial screen confirm only General Pike. For a second independent reproduction load `Package8_second_BR_871004.json` and confirm either no Patrol ships or just General Pike. The intermediate save contains the legal 13-ship combined selection.

**Expected and observed.** Pike is the only single Main ship with at least 8 Close Action. Pike carries the one Troop. The Patrol contains Oneida, Madison, Gov. Tompkins, Fair American, Conquest, Growler, Hamilton, Julia, Ontario, Pert, Raven and Scourge for exactly 22 Long Gun. The preserved die is 1, placing the Army Support Force in the Encounter. On v0.2.9, Pike sailed alone in the first reproduction. In the second, an empty Patrol turned all 13 ships into a single Army Support Force. Selecting Pike for Patrol sent her 10 Long Gun into that Force and gave Army Support the other 12. The initial screen also allowed suppressing the entire deployment or padding the selection with surplus hulls.

**Implemented fix.** Apply Aid V legality at confirmation in both prompts, including class, minimum count, legal ties and Package 9 priorities. The new **Use suggested ships** button proposes the combined force or its Patrol without spending a die. The second prompt shows each hull's Long Gun and Close Action. The v0.2.9 source accepts the unchecked selections in `src/engine_deploy.js:218`, `:224` and `:233`. The patch validates in `src/engine_deploy.js:91`, `:319` and `:330`. The fallback for a position already open on one of these prompts is in `src/engine_core.js:63`.

**Adjust while the picker is open.** In the same first-stage save, open Adjust, select General Pike, set her box to Out of Play, press Apply and Close. On v0.2.9 Pike remained listed. Ticking her and pressing Confirm returned the ship to the lake. The shipped correction path accepted this change at `src/ui.js:848` and `:853`. The patch checks whether the decision depends on the ship at `src/ui.js:1058`, preserves the position and draft, and tells the player to finish the decision or use Undo before making the correction. Both legal package stages still work afterward. Reproduce with `adjust-package.js` and compare `adjust-before.json` with `adjust-after.json`.

**Nearby cases.** Selecting the legal Patrol assigned exactly one Troop and retained both Forces. An alternate raw cursor of 1 gives a d6 of 4 and encounters the Patrol instead. The same save survives Undo and replay. If a permitted first selection could leave fewer than 22 Long Gun, accepting no deployment preserves project note 57. Project note 38 also permits a final two-step Secondary to take Package 11 past five steps. No new ruling was made on either point.

## D02 · Medium · A Reduced requisition could create a spurious September II

**Player impact.** The human could play an extra turn, with another assignment, scoring and Convoy Supply cycle after the A.I. fleet was already unable to sail.

**Rule.** Both Solo rulebooks §5.1, p.21, end the game when the A.I. has no ship eligible for September II. Event 26's coastal half keeps the requisitioned ship out for the following turn. The normal A2 return and A3 repair procedure send a Reduced returning ship via In Transit to Repairing. See British p.9 right column, U.S. p.21 right column §6.1, and the v0.2.9 Requisition repair fix.

**Exact reproduction.** Load `SeptemberI_requisition_reduced.json` and press **Continue** at Reset. The constructed British position uses seed 871100 with two-step, Reduced Madison requisitioned until September II. All other American ships are out of action. V0.2.9 opened September II and offered British upgrades. Declining took Madison to Repairing. The patched game ends at the September I reset and scores the position as a draw, 0. Load `SeptemberI_requisition_full.json` to repeat with full-strength, three-step Madison returning on the same turn. Both versions properly continue and make her Deployable. Focused assertions also cover Wolfe in the U.S. campaign and a full ship due back too late.

**Implemented fix.** Require full strength as well as a due return in the §5.1 eligibility test, `src/engine_turn.js:444` in both baseline and patch. The normal return and repair logic at `:52` and `:99` supplies the comparison. This last-survivor situation was exercised with constructed boards.

## D03 · Low · A5 could lay up ships for no Construction Delay reduction

**Player impact.** A.I. or human ships could disappear from the deployable squadron for an entire turn with no effect on the shipyard. An unaffordable human purchase also added a pointless choice.

**Rule.** British p.10 A5, lower left, and §8.1, p.23 right. The equivalent U.S. A5 and §8.1 also charge two Close Action for each point bought. The free reduction is applied first. The A.I. must buy an affordable reduction and prefers Secondary ships. The human may decline.

**Exact reproduction.** Load `A5_one_CA_BR_871101.json` and confirm A4 with no ships laid up. The U.S. has Construction Delay 2, Lady of the Lake as a 0-CA flagship, and Hamilton as its only other Deployable ship at 1 CA. The free reduction leaves delay 1. V0.2.9 logs an A.I. purchase, places Hamilton In Ordinary and leaves delay 1. The patch keeps Hamilton Deployable and delay 1. Nothing in this example can fund two CA, even with a flag transfer. This is a constructed pool.

**Human reproduction.** Load `A5_human_two_CA_US_871101.json`, confirm A4, and select only Hamilton at A5. Hamilton and Fair American each have 1 CA. The baseline allowed Confirm, laid Hamilton up and left delay 1. The patch rejects the one-CA choice. Clearing it declines the purchase. Selecting both ships lays them up and reduces delay to 0. With just one eligible CA across the whole human squadron, the patch skips that purchase prompt entirely.

**Implemented fix.** Limit the A.I. target to the number of whole points affordable and require a real purchase when the human selects ships at A5. Original lines are `src/engine_turn.js:153`, `:162`, `:473` and `:477`. Patched lines are `:153`, `:476` and `:492`. Other checks cover three separate 1-CA ships buying one of two outstanding points, a single indivisible 3-CA ship buying one, no purchase after a sufficient free reduction, and Secondary-first selection. The question about voluntarily shifting the flagship to buy more remains open. A search of 2,000 seeded campaign starts, capped at 200 decisions each, found 44 candidate high-delay control positions and no natural one-CA-only reproduction.

## Direct checks and bounds

| Check | Evidence |
|---|---|
| Baseline and candidate | `observed-before.json`, `observed-after.json` and six importable positions. All go through the app's checked save reader. |
| Regression assertions | `tests/regression_v0210_deploy.js` and the 48 actual player answers in `tests/fixtures/v0210-deploy-path.json`. Baseline passed 113 of 302 assertions. The candidate passed all 302. Counts include multiple legal alternatives and repeated UI proposals. |
| Source-independent setup and bot selection | `setup-and-packages.js` checked 256 new setups, both campaigns, and 5,632 automatic selections across all 11 packages and eight pools with 64 raw cursors. 3,042 selections deployed and 2,590 legitimately failed. All matched the independent oracle. The before and after records are identical. The captured-Wolfe, two-Troop natural case appears separately in the campaign evidence. |
| Original layout | Read both columns of the relevant Living Rules pages and the photographed Aid V including its footnote. Directly transcribed all 56 cells of B35 and A25 from the card faces. Dummies, unrevealed Troops and embarked Troops have separate assertions. The shared printed-component evidence independently compares the full 104-card, 2,912-cell deck with all seven columns on every row. |
| Prior fixes | The 55 deployment and 29 turn regression checks passed, covering upgrade eligibility, literal OA1 recheck and labels, PE assignment and transfer, and a blockaded extra-card draw. |
| Player controls | `controls.js` loads the shipped and rebuilt HTML, presses player-facing controls and reads the resulting export. The 20 jsdom runs exercised both decisions of Package 8, its suggestion, Undo and exact replay, A5 on each side, and the Reduced/full §5.1 pair. The environment used two nominal widths. No visual or hardware claim follows from jsdom. |

Run the checks from a checkout as follows. The evidence scripts also accept a separate baseline checkout. Supply the jsdom dependency through the Node module search path when needed.

```sh
node tests/regression_v0210_deploy.js
node /path/to/deploy/setup-and-packages.js .
node /path/to/deploy/reproduce.js .
node /path/to/deploy/controls.js /path/to/v0.2.9/dist/index.html dist/index.html
```

**Lane verdict.** Ship the three fixes together. The first prevents an invalid Encounter through ordinary controls, the second protects last-turn scoring and the third prevents an uncompensated ship lay-up. Automatic package selection, including the documented Package 8 and 11 interpretations, matched the independent oracle before and after the changes.
