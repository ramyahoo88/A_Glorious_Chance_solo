// node replay-campaigns.js <checkout> <campaign-evidence-directory>
const fs = require('fs'), path = require('path');
const root = path.resolve(process.argv[2]), dir = path.resolve(process.argv[3]);
const E = require(path.join(root,'tools/bundle_engine.js'))();
for (const file of ['baseline-gale-outside-lake.json','baseline-defender-outmaneuver.json','baseline-separated-different-distribution.json']) {
  const s = JSON.parse(fs.readFileSync(path.join(dir,file))).state, count = s.log.length;
  const old = s.encounter ? { shown: s.encounter.wgCard, top: s.deck.event[0] } : { top: s.deck.event[0] };
  E.act(s,'ok');
  const e = s.encounter;
  const draw = {file, seed:s.seed, pre:old, title:s.prompt.title, card:s.prompt.eventCard || null, wg:e && e.wg, drawn:e && e.wgCard, deckHead:s.deck.event[0],
    text:s.prompt.text, log:s.log.slice(count).map(l => l.text)};
  console.log(JSON.stringify(draw,null,2));
}
