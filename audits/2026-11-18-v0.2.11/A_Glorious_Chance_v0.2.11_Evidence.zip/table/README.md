## Victory display, Undo and table pace

### V01 · Medium · Two winners on the final screen

**Player impact.** The Game Score header could name the opposite winner from the final adjudication. **Rule.** Under 14.2 a qualifying Dual Blockade awards decisive victory regardless of score. **Reproduce.** Load `coastal/C02-forced-victory.json` and Continue from the Raid through Tally to Game Over. The constructed position ends on −21. In v0.2.9 the header says British Marginal Victory while the final panel awards the U.S. decisive victory. With full-strength Wolfe returning in `C02-breakout-in-transit.json`, the campaign should continue instead. **Fix.** At `src/ui.js:272` on v0.2.9, use the stored adjudicated level whenever the game is over. Continue showing the signed point total separately. The victory position and the continuing position were both exercised in public Chromium. The normal eight-turn campaigns retain their points-based headings.

### V02 · Low · Ctrl/Cmd-Z stopped working on Game Over

**Player impact and expected behavior.** A keyboard player should be able to undo the last move wherever the enabled Undo button permits it. **Reproduce.** Start with the same forced-victory save, complete the last move, close any dialog, focus the page and press Ctrl-Z or Cmd-Z. On v0.2.9 the game stayed over. Clicking Undo did restore the Tally. **Fix.** The early return at `src/main.js:5` excluded states with no pending prompt. Handle Undo before checking for a prompt. The patched button and shortcut both restore the prior position. An open dialog or text editor retains its native keyboard handling. Runnable regression: `tests/browser/tabletop_v0210.js`.

### Optional pace and board improvements

**Map updates.** Each applied action now offers an expandable list of public counter moves. It names the ship, old and new box or Force, steps and owner; it includes public supply, victory, flag, convoy, Troops, Encounter, control, blockade and card movements. The same Force identifier appears on the board. Face-down cards disclose only the printed back. Unrevealed A.I. Troops and Convoys stay hidden. Read-only lookups, closing the disclosure, Save, reload and Undo do not roll dice.

**Grouped updates.** Setup and Settings offer an opt-in grouped pace. Target Card layout, PE placement and false alarms, ordinary Enemy Operations deployments, Tally, Reset and a single legal Tactic can be acknowledged in the same action. The recap keeps the reports and intermediate board changes in order. Genuine choices, combat results and nonroutine events stay visible as individual prompts. A single Undo restores the preceding click. The separate individual-notices checkbox now names the types of messages that it controls.

**Measured effect.** With the same enabled individual notices, 160 paired games across seeds 891000–891079 produced 21,767 individual prompt submissions versus 13,548 grouped submissions. That is 8,219 fewer, or 51.4 per game (37.8%). Only 120 automatically submitted answers were sole legal Tactics. At all 13,548 player stops the board, log, dice cursor, hidden decks and remaining procedure stack matched after setting aside the display-only recap. The independent study of turning notices *off* is a different comparison: 47.8 fewer Continue prompts per game in its own matched sample. The savings should not be added.

**Board lookup.** A revealed Target Card now records and labels the row and column actually used, including the recalculated OA1 column. Before lookup the display identifies the current board lookup. This supports reviewing a card after the board has changed. The baseline had only a live recalculation in `src/ui.js:507`. The implementation stores the two coordinates in the Target Card slot in `src/engine_deploy.js:271` and displays them in `targetCardView`. It does not expose face-down fronts.

Run `node table/grouped_campaigns.js /path/to/checkout 80` from the evidence directory. The 160 pairs in this study are separate from the primary 1,280-campaign matrix. The measures count submitted prompts. One assignment can require several taps and physical counter moves.
