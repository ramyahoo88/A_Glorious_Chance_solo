const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const dir=__dirname;
const read=name=>JSON.parse(fs.readFileSync(path.join(dir,name+'.json'),'utf8'));
const base=read('baseline'), rc=read('candidate');
const sum=(rows,get)=>rows.reduce((n,r)=>n+get(r),0);
const n=x=>x.toLocaleString('en-US');
const fixed=x=>x.toFixed(1);
const qty=(r,k)=>r.games.filter(g=>g.seen.includes(k)).length;
const key=r=>[r.human,r.seed,r.style].join('/');
function pairs(a,b) {
  const m=new Map(b.games.map(g=>[key(g),g]));
  assert(!a.failures.length&&!b.failures.length);
  assert.equal(a.games.length,b.games.length);
  return a.games.map(row=>{const other=m.get(key(row));assert(other);return [row,other];});
}
const optsBase=read('options-baseline'),optsRC=read('options-candidate');
const optKeys=new Set(optsRC.games.map(g=>JSON.stringify(g.opts)));
assert.equal(optKeys.size,64);assert.equal(pairs(optsBase,optsRC).length,128);
const scorePairs=pairs(base,rc);
const scoreDiff=scorePairs.filter(([a,b])=>a.score!==b.score).length;
const rankDiff=scorePairs.filter(([a,b])=>a.level!==b.level).length;
function pairUI(label){
  const full=read('paused-'+label), fast=read('fast-'+label), p=pairs(full,fast);
  const diff=p.filter(([a,b])=>a.outcome!==b.outcome);
  assert.equal(diff.length,0,'Pause setting changed end state: '+label+' '+diff.map(row=>key(row[0])).join(', '));
  const clicks=r=>r.checks.prompts, info=r=>sum(r.games,g=>g.kinds.info||0), manual=r=>sum(r.games,g=>g.changedShipRows);
  return {pairs:p.length,full:clicks(full),fast:clicks(fast),fullInfo:info(full),fastInfo:info(fast),
    fullOther:clicks(full)-info(full),fastOther:clicks(fast)-info(fast),exact:p.length-diff.length,
    fullRows:manual(full),fastRows:manual(fast),perGameRemoved:(clicks(full)-clicks(fast))/p.length};
}
const pairedB=pairUI('baseline'),pairedC=pairUI('candidate');
let lines=[];
const l=(s='')=>lines.push(s);
const table=(rows)=>{for(const [i,row] of rows.entries()){l('| '+row.join(' | ')+' |');if(i===0)l('| '+row.map(()=> '---').join(' | ')+' |');}l();};
l('# Fresh campaign audit');l();
l('Reviewed engine sources for v0.2.9 and v0.2.10. The sweep invokes the same public engine actions as the shipped page. Browser, device, publishing and document-render checks are recorded separately in the main report.');l();
l('## Comparable fresh campaigns');l();
l('Seeds 710000–710127 each ran once with each of two human sides and five deterministic policies. Each policy used only the visible prompts, component values and public board. These paired trajectories measure coverage under those policies. They cannot establish population-level incidence or win balance.');l();
table([
 ['Check','v0.2.9','v0.2.10'],
 ['Completed campaigns',n(base.games.length),n(rc.games.length)],
 ['Failed campaign assertions',n(base.failures.length),n(rc.failures.length)],
 ['Legal prompt actions',n(base.checks.prompts),n(rc.checks.prompts)],
 ['Independent A6 balance and band',n(base.observed['A6 signed balance and band']),n(rc.observed['A6 signed balance and band'])],
 ['Independent Tally score deltas',n(base.observed['Tally independent VP components']),n(rc.observed['Tally independent VP components'])],
 ['Literal human all-ship Round 1 previews matched the applied strengths',n(base.checks.textOddsChecked),n(rc.checks.textOddsChecked)],
 ['Repeated combat previews left state and RNG untouched',n(base.checks.previewPurity),n(rc.checks.previewPurity)],
 ['Saved snapshot restored and next action reproduced exactly',n(base.checks.roundTrips),n(rc.checks.roundTrips)],
 ['Mid-campaign saves followed to byte-identical final state in a second engine instance',n(base.checks.fullSaveContinuations),n(rc.checks.fullSaveContinuations)],
 ['Actions followed on those restored branches',n(base.checks.fullSaveActions),n(rc.checks.fullSaveActions)],
 ['Manual Land Battle results read against all 15 printed columns as applicable',n(base.checks.manualLandBattles),n(rc.checks.manualLandBattles)],
 ['Manual package decisions',n(base.checks.manualPackages),n(rc.checks.manualPackages)],
 ['Manual Package 8 second-stack decisions',n(base.observed['Manual Package 8 second stack']||0),n(rc.observed['Manual Package 8 second stack']||0)],
 ['Final Draws',n(base.summary.draws),n(rc.summary.draws)],
 ['Campaigns ending under §14.2 Dual Blockade',n(qty(base,'Dual Blockade ending')),n(qty(rc,'Dual Blockade ending'))],
]);
l('The same chosen policies and seeds produced different final VP scores in '+n(scoreDiff)+' pairs and a different victory level in '+n(rankDiff)+' pairs. A corrected event or changed eligible choice can alter subsequent draws. These differences alone are not defect counts.');l();
l('The same release intentionally permits different strategies. Positive scores favor the U.S. For the two seats separately, the following counts are human wins, draws, and human losses. The two seats use separate campaign books.');l();
function outcomes(rows,side){
  const draw=rows.filter(g=>g.level==='Draw').length,win=rows.filter(g=>g.level!=='Draw'&&(g.level.startsWith('U.S.')?'US':'BR')===side).length;
  return [win,draw,rows.length-win-draw].join(' / ');
}
function median(vals){const a=[...vals].sort((x,y)=>x-y);return (a[(a.length-1)>>1]+a[a.length>>1])/2;}
table([['Policy', 'U.S. human W/D/L','British human W/D/L','Median U.S. / British human net VP'],
 ...rc.policies.map(style=>{const sides=['US','BR'].map(sd=>rc.games.filter(g=>g.style===style&&g.human===sd));return [style,outcomes(sides[0],'US'),outcomes(sides[1],'BR'),sides.map(a=>median(a.map(g=>g.score))).join(' / ')];})]);
const sameSeed=rc.games.filter(g=>g.seed===710000&&g.human==='US');
l('For an example with identical setup and options, the U.S. coastal policy at seed 710000 scored +'+sameSeed.find(g=>g.style==='coast').score+', a U.S. marginal victory. The dispersed screen scored '+sameSeed.find(g=>g.style==='screen').score+', a British decisive victory. The values in both median columns use the U.S. score perspective.');l();
l('## Coverage and limits');l();
l('- Fleet reserved ships for Reaction, attempted legal tows and selected Pursuit where offered. Coast dispersed Raiders and prioritised Troops. Cautious used the fleet assignment and passed, bypassed or withdrew when possible. Screen split Patrol and Escort Forces in the same waters. Blockade concentrated four full-strength Main Ships at the regular port and then attempted the temporary port.');l('- Seed-indexed options alternated both U.S. A.I. attack preconditions, Cutting-Out, OA1, A.I. confirmations and manual Package/Land Battle modes. Each campaign ran from setup to the game-over result. A manual package tie was selected deterministically, so the manual mode is an eligibility test rather than a statistical sample of physical random draws.');l('- Separate seeds 713000–713063 paired both sides under the coastal policy with all 64 combinations of the six binary settings: Cutting-Out, OA1, manual Packages, manual Land Battles, A.I. confirmations and U.S. A.I. precondition. Both versions completed all 128 fresh runs at those seeds. This sample is separate from the 1,280-game table.');l('- Every action checked matching ship/Force links, ownership and zones, active ship locations, deck uniqueness, ship step bounds, Troops conservation for both sides, valid procedure and supply bounds, VP sums and the printed victory thresholds. Land Battle results came from the photographed aid including the previously agreed unprinted 62 and 63 faces at zero Long Guns and three Troops. The Tally check derives ship losses, Cutting-Out repulses, Lake Control, Niagara victory, untransported human Troops, Raids, Fall Offensive, and newly destroyed ships on the stocks from the board, printed counter values and displayed militia die. It is separate from summing the internal VP ledger.');l('- The final sample recorded '+qty(rc,'US supply at -1')+' U.S. and '+qty(rc,'BR supply at -1')+' British campaigns at Convoy Supply −1, '+qty(rc,'US supply at 12')+' and '+qty(rc,'BR supply at 12')+' at 12, and '+qty(rc,'Simultaneous Fall Offensive')+' simultaneous Fall Offensive results. '+n(rc.observed['No human ship available at A7']||0)+' assignment prompts had no available human ships. '+n(rc.observed['Tied naval balance after June I']||0)+' had a tied balance after the fixed first turn. '+qty(rc,'Breakout')+' campaigns reached a Breakout.');l('- Manual Land Battles naturally exercised '+rc.coverage.landColumns.filter(Boolean).length+' of 15 printed columns. The vector from 0 LG/1 Troop to 25+ LG/3 Troops is '+rc.coverage.landColumns.join(', ')+'. The standalone paper-table audit in the main report checks every cell.');l('- Turn-level point reconstruction takes the resolved Lake Control markers as input. Full-state save equality was tested against a second engine in memory. Actual browser cancellation, Undo, storage, importing the file and restoring after a browser reload are independent checks in the main report. Physical setup and movement times were not timed.');l();
l('## One game and five importable positions');l();
const t=read('candidate-trace');l('The U.S. coastal campaign at seed '+t.seed+' ended '+t.endScore+' ('+t.result.level+'). candidate-trace.json contains every chosen action, the legal A7 forces, the displayed Tally, each VP award and the reconstructed point delta per turn. candidate-midgame.json resumes this campaign after 30 decisions.');l();
table([['Turn','U.S./British supply at Tally','U.S./British Tally VP change','Net score'],
  ...t.turns.map(u=>[u.turn,[u.tally.supply.US,u.tally.supply.BR].join(' / '),[u.tally.independentDelta.US,u.tally.independentDelta.BR].join(' / '),u.tally.score])]);
l('All listed baseline files load from the app’s Load control. The table identifies the exact first action. natural_positions.js checks both versions with the same input; natural-positions.json records the results.');l();
table([['Source, normal position and action','v0.2.9 observed','v0.2.10 and player impact'],
 ['Event #34, EN1.2 • British 710037 screen • baseline-separated-different-distribution.json • Continue at A.I. Deployment','Wolfe and Moira were separate single-ship Forces at Sacket’s. Wolfe displaced to Kingston. src/engine_encounter.js:400 pooled the ships.','Both remain at Sacket’s. The card’s more-than-one-ship test applies to the Force. Where multiple Forces individually qualify, this card supplies no tie-break.'],
 ['Event #30, EN1.2 and §14.3 • British 710014 blockade • baseline-gale-outside-lake.json • Continue at A.I. Deployment','The ensuing Breakout drew Gale, captured Royal George and removed other ships. src/engine_encounter.js:73 allowed Gale despite the phase.','Gale is discarded, Event #5 supplies the real result and Royal George remains British.'],
 ['D06 Defender Outmaneuver, LC Weather Gage check • U.S. 710000 fleet • baseline-defender-outmaneuver.json • Continue after Gunnery Round results','The U.S. gained the Gage and no Event was drawn. src/engine_combat.js:510 skipped the draw.','Event #13 is drawn and the U.S. wins the Weather Gage. Later draws follow the proper deck.'],
 ['Aid V #8 • British 710000 blockade • baseline-manual-package8-second.json • choose an empty second stack or the eligible Patrol in baseline.json','An empty second stack passed validation at src/engine_deploy.js:228.','The empty stack is refused. The legal Army Support stack is captured Wolfe at 8 CA with two Troops. The twelve remaining selected ships produce precisely 22 LG in the Patrol.'],
 ['§14.2 Dual Blockade • U.S. 710031 blockade • baseline-dual-blockade.json • Continue at C Enemy Operations through Tally','U.S. decisive victory in July II at +29.','Same decisive result, overriding the ordinary +29 victory tier. The U.S. maintains four full-strength Main Ships at Kingston and four at York. This position has no qualifying British breakout ships.'],
]);
l('Two further saved endings isolate score and timing. In zero-dual-dual-blockade.json (U.S. 710101), Continue through Tally awards the U.S. a §14.2 decisive victory at exactly zero VP. In last-turn-5-1-early.json (U.S. 710005), Continue from the end-of-September-I reset. The A.I. has no eligible ships for September II, so §5.1 ends the game at +38. These two positions came from the primary matrix.');l();
l('The candidate offered displaced human ships for Reaction in '+n(rc.observed['Separated human ship offered for same-Encounter Reaction']||0)+' prompts and observed '+n(rc.observed['Separated ship rejoined same Encounter']||0)+' successful return events across both sides. In candidate-displaced-returned.json, select Beresford and Royal George at Kingston. Royal George rejoins. Seven multi-Force Event draws had no result inconsistent with an eligible Force.');l();
l('## Pauses and bookkeeping');l();
l('A disjoint set of seeds 712000–712015 ran one matched campaign per policy and human side with A.I. confirmations on and off. Actions at actual decisions follow the same policy. End-state comparison excludes the version stamps, prompt sequence number and confirmation preference. All remaining state, including the RNG, roll history, final VP, decks, forces and full log, must match.');l();
table([['Measure','v0.2.9','v0.2.10'],['Exact paired end states',pairedB.exact+' / '+pairedB.pairs,pairedC.exact+' / '+pairedC.pairs],
 ['Info-only Continue prompts per campaign, confirmations on',fixed(pairedB.fullInfo/pairedB.pairs),fixed(pairedC.fullInfo/pairedC.pairs)],
 ['Info-only Continue prompts per campaign, confirmations off',fixed(pairedB.fastInfo/pairedB.pairs),fixed(pairedC.fastInfo/pairedC.pairs)],
 ['Other decision prompts per campaign, on / off',fixed(pairedB.fullOther/pairedB.pairs)+' / '+fixed(pairedB.fastOther/pairedB.pairs),fixed(pairedC.fullOther/pairedC.pairs)+' / '+fixed(pairedC.fastOther/pairedC.pairs)],
 ['Prompts avoided per campaign',fixed(pairedB.perGameRemoved),fixed(pairedC.perGameRemoved)]]);
l('Counts are prompts, not physical clicks or elapsed minutes. A ship may change several times between prompts. The evidence also records how many individual ship rows changed between successive prompts, and the number of manual package and Land Battle lookups. Pilot and search runs are excluded.');l();
l('## Reproduction');l();l('Use Node and the two repo checkouts as BASE and RC. Invoke commands from this evidence directory.');l();
for(const s of [
'node sweep.js BASE 710000 128 baseline','node sweep.js RC 710000 128 candidate',
'AGC_PAUSES=1 node sweep.js BASE 712000 16 paused-baseline','AGC_PAUSES=0 node sweep.js BASE 712000 16 fast-baseline',
'AGC_PAUSES=1 node sweep.js RC 712000 16 paused-candidate','AGC_PAUSES=0 node sweep.js RC 712000 16 fast-candidate',
'AGC_OPTION_GRID=1 AGC_POLICIES=coast node sweep.js BASE 713000 64 options-baseline','AGC_OPTION_GRID=1 AGC_POLICIES=coast node sweep.js RC 713000 64 options-candidate',
'AGC_SEATS=US AGC_POLICIES=blockade node sweep.js RC 710101 1 zero-dual','AGC_SEATS=US AGC_POLICIES=blockade node sweep.js RC 710005 1 last-turn',
'node natural_positions.js BASE RC','node compare.js'])l('    '+s);
l();l('Concatenated engine SHA-256 follows tools/files.json order. v0.2.9 '+base.sourceHash+'. v0.2.10 '+rc.sourceHash+'. The main report records the separately rebuilt HTML digest.');
fs.writeFileSync(path.join(dir,'findings.md'),lines.join('\n')+'\n');
fs.writeFileSync(path.join(dir,'comparison.json'),JSON.stringify({baseHash:base.sourceHash,candidateHash:rc.sourceHash,scorePairs:scorePairs.length,changedFinalScore:scoreDiff,changedVictoryTier:rankDiff,baselinePausePair:pairedB,candidatePausePair:pairedC,optionConfigurations:optKeys.size,optionGamesEach:optsRC.games.length},null,2)+'\n');
console.log(JSON.stringify({scorePairs:scorePairs.length,scoreDiff,rankDiff,pairedC}));
