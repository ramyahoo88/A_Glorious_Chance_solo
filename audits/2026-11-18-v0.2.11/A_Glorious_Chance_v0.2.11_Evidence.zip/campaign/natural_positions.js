const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const load = require('./load');
const meta = require('./baseline.json').examples;
const read = name => JSON.parse(fs.readFileSync(path.join(__dirname, 'baseline-'+name+'.json'), 'utf8')).state;
const summary = {};
for (const [index, repo] of process.argv.slice(2).entries()) {
  const fixed = index === 1;
  const E = load(path.resolve(repo)).x('({act, validateAnswer, def, curVals})');
  const rows = summary[fixed?'candidate':'baseline']={};
  function play(s, a) {assert.equal(E.validateAnswer(s,s.prompt,a),null);E.act(s,a);}
  {
    const key='separated-different-distribution', s=read(key);
    play(s,meta[key].action);
    assert.equal(s.zones.SAC.event,34);
    assert.equal(s.ships.moira.zone,'SAC');
    assert.equal(s.ships.wolfe.zone,fixed?'SAC':'KIN');
    rows[key]={seed:s.seed,prompt:s.prompt.title,event:s.zones.SAC.event,wolfe:s.ships.wolfe.zone,moira:s.ships.moira.zone};
  }
  {
    const key='gale-outside-lake',s=read(key);
    const before=s.eventsDrawn.length;
    play(s,meta[key].action);
    assert.equal(s.encounter.kind,'breakout');
    assert.equal(s.eventsDrawn.length-before,fixed?2:1);
    assert.equal(s.zones.SAC.event,fixed?5:30);
    assert.equal(s.ships.rg.owner,fixed?'BR':'US');
    rows[key]={seed:s.seed,phase:s.phase,kind:s.encounter.kind,prompt:s.prompt.title,event:s.zones.SAC.event,
      eventCardsSpent:s.eventsDrawn.length-before,royalGeorge:s.ships.rg.owner};
  }
  {
    const key='defender-outmaneuver',s=read(key);
    const count=s.eventsDrawn.length;
    play(s,meta[key].action);
    assert.equal(s.eventsDrawn.length-count,fixed?1:0);
    assert.equal(s.prompt.title,'Weather Gage changes!');
    rows[key]={seed:s.seed,change:s.prompt.title,eventCardsSpent:s.eventsDrawn.length-count,display:s.prompt.text};
  }
  {
    const first='manual-package8-first',second='manual-package8-second',s=read(first);
    play(s,meta[first].action);assert.match(s.prompt.title,/second stack/);
    assert.equal(E.validateAnswer(s,s.prompt,[] )===null,!fixed);
    play(s,meta[second].action);
    const army=s.forces[s.ships.wolfe.forceId],patrol=Object.values(s.forces).find(f=>f.side==='US'&&f.zone==='NIA'&&f.mission==='Patrol');
    assert.deepEqual([...army.ships],['wolfe']);assert.equal(army.mission,'ArmySupport');assert.equal(army.troops,2);
    const ca=army.ships.reduce((n,id)=>n+E.curVals(s.ships[id])[2],0),lg=patrol.ships.reduce((n,id)=>n+E.curVals(s.ships[id])[0],0);
    assert.equal(ca,8);assert.equal(lg,22);
    rows[second]={seed:s.seed,army:army.ships,armyTroops:army.troops,armyCA:ca,patrol:patrol.ships,patrolLG:lg,emptyPatrolAllowed:!fixed};
  }
  {
    const key='dual-blockade',s=read(key);
    play(s,meta[key].action);
    assert.match(s.prompt.title,/Tally/);
    while(!s.over){assert.equal(s.prompt.kind,'info');play(s,'ok');}
    assert.equal(s.result.forced,'US');assert.equal(s.result.score,29);
    rows[key]={seed:s.seed,turn:s.turn+1,result:s.result};
  }
}
assert.equal(Object.keys(summary).length,2,'Usage: node natural_positions.js BASELINE_REPO CANDIDATE_REPO');
fs.writeFileSync(path.join(__dirname,'natural-positions.json'),JSON.stringify(summary,null,2)+'\n');
console.log('Replayed all five natural positions from identical input on both engines.');
