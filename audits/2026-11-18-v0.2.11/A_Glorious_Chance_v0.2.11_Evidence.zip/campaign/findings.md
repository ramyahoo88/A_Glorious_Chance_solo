# Fresh campaign audit

Reviewed engine sources for v0.2.9 and v0.2.10. The sweep invokes the same public engine actions as the shipped page. Browser, device, publishing and document-render checks are recorded separately in the main report.

## Comparable fresh campaigns

Seeds 710000–710127 each ran once with each of two human sides and five deterministic policies. Each policy used only the visible prompts, component values and public board. These paired trajectories measure coverage under those policies. They cannot establish population-level incidence or win balance.

| Check | v0.2.9 | v0.2.10 |
| --- | --- | --- |
| Completed campaigns | 1,280 | 1,280 |
| Failed campaign assertions | 0 | 0 |
| Legal prompt actions | 163,592 | 163,141 |
| Independent A6 balance and band | 10,234 | 10,231 |
| Independent Tally score deltas | 10,234 | 10,231 |
| Literal human all-ship Round 1 previews matched the applied strengths | 2,474 | 2,448 |
| Repeated combat previews left state and RNG untouched | 5,819 | 5,743 |
| Saved snapshot restored and next action reproduced exactly | 5,914 | 5,895 |
| Mid-campaign saves followed to byte-identical final state in a second engine instance | 80 | 80 |
| Actions followed on those restored branches | 8,308 | 8,264 |
| Manual Land Battle results read against all 15 printed columns as applicable | 853 | 859 |
| Manual package decisions | 4,574 | 4,559 |
| Manual Package 8 second-stack decisions | 15 | 11 |
| Final Draws | 232 | 235 |
| Campaigns ending under §14.2 Dual Blockade | 2 | 4 |

The same chosen policies and seeds produced different final VP scores in 165 pairs and a different victory level in 82 pairs. A corrected event or changed eligible choice can alter subsequent draws. These differences alone are not defect counts.

The same release intentionally permits different strategies. Positive scores favor the U.S. For the two seats separately, the following counts are human wins, draws, and human losses. The two seats use separate campaign books.

| Policy | U.S. human W/D/L | British human W/D/L | Median U.S. / British human net VP |
| --- | --- | --- | --- |
| fleet | 11 / 21 / 96 | 8 / 18 / 102 | -35.5 / 36 |
| coast | 57 / 39 / 32 | 21 / 41 / 66 | 6.5 / 12.5 |
| cautious | 4 / 33 / 91 | 1 / 20 / 107 | -34 / 28.5 |
| screen | 1 / 3 / 124 | 5 / 6 / 117 | -56.5 / 48 |
| blockade | 12 / 17 / 99 | 13 / 37 / 78 | -37 / 22 |

For an example with identical setup and options, the U.S. coastal policy at seed 710000 scored +20, a U.S. marginal victory. The dispersed screen scored -34, a British decisive victory. The values in both median columns use the U.S. score perspective.

## Coverage and limits

- Fleet reserved ships for Reaction, attempted legal tows and selected Pursuit where offered. Coast dispersed Raiders and prioritised Troops. Cautious used the fleet assignment and passed, bypassed or withdrew when possible. Screen split Patrol and Escort Forces in the same waters. Blockade concentrated four full-strength Main Ships at the regular port and then attempted the temporary port.
- Seed-indexed options alternated both U.S. A.I. attack preconditions, Cutting-Out, OA1, A.I. confirmations and manual Package/Land Battle modes. Each campaign ran from setup to the game-over result. A manual package tie was selected deterministically, so the manual mode is an eligibility test rather than a statistical sample of physical random draws.
- Separate seeds 713000–713063 paired both sides under the coastal policy with all 64 combinations of the six binary settings: Cutting-Out, OA1, manual Packages, manual Land Battles, A.I. confirmations and U.S. A.I. precondition. Both versions completed all 128 fresh runs at those seeds. This sample is separate from the 1,280-game table.
- Every action checked matching ship/Force links, ownership and zones, active ship locations, deck uniqueness, ship step bounds, Troops conservation for both sides, valid procedure and supply bounds, VP sums and the printed victory thresholds. Land Battle results came from the photographed aid including the previously agreed unprinted 62 and 63 faces at zero Long Guns and three Troops. The Tally check derives ship losses, Cutting-Out repulses, Lake Control, Niagara victory, untransported human Troops, Raids, Fall Offensive, and newly destroyed ships on the stocks from the board, printed counter values and displayed militia die. It is separate from summing the internal VP ledger.
- The final sample recorded 28 U.S. and 57 British campaigns at Convoy Supply −1, 80 and 35 at 12, and 0 simultaneous Fall Offensive results. 138 assignment prompts had no available human ships. 95 had a tied balance after the fixed first turn. 280 campaigns reached a Breakout.
- Manual Land Battles naturally exercised 15 of 15 printed columns. The vector from 0 LG/1 Troop to 25+ LG/3 Troops is 67, 19, 6, 345, 109, 13, 63, 44, 9, 91, 29, 9, 22, 16, 17. The standalone paper-table audit in the main report checks every cell.
- Turn-level point reconstruction takes the resolved Lake Control markers as input. Full-state save equality was tested against a second engine in memory. Actual browser cancellation, Undo, storage, importing the file and restoring after a browser reload are independent checks in the main report. Physical setup and movement times were not timed.

## One game and five importable positions

The U.S. coastal campaign at seed 710000 ended 20 (U.S. Marginal Victory). candidate-trace.json contains every chosen action, the legal A7 forces, the displayed Tally, each VP award and the reconstructed point delta per turn. candidate-midgame.json resumes this campaign after 30 decisions.

| Turn | U.S./British supply at Tally | U.S./British Tally VP change | Net score |
| --- | --- | --- | --- |
| 1 | 5 / -1 | 4 / 2 | 2 |
| 2 | 6 / -1 | 5 / 1 | 6 |
| 3 | 8 / 1 | 4 / 2 | 8 |
| 4 | 9 / 0 | 2 / 6 | 4 |
| 5 | 11 / 0 | 5 / 2 | 7 |
| 6 | 11 / 0 | 4 / 4 | 7 |
| 7 | 12 / -1 | 9 / 0 | 16 |
| 8 | 12 / -1 | 4 / 0 | 20 |

All listed baseline files load from the app’s Load control. The table identifies the exact first action. natural_positions.js checks both versions with the same input; natural-positions.json records the results.

| Source, normal position and action | v0.2.9 observed | v0.2.10 and player impact |
| --- | --- | --- |
| Event #34, EN1.2 • British 710037 screen • baseline-separated-different-distribution.json • Continue at A.I. Deployment | Wolfe and Moira were separate single-ship Forces at Sacket’s. Wolfe displaced to Kingston. src/engine_encounter.js:400 pooled the ships. | Both remain at Sacket’s. The card’s more-than-one-ship test applies to the Force. Where multiple Forces individually qualify, this card supplies no tie-break. |
| Event #30, EN1.2 and §14.3 • British 710014 blockade • baseline-gale-outside-lake.json • Continue at A.I. Deployment | The ensuing Breakout drew Gale, captured Royal George and removed other ships. src/engine_encounter.js:73 allowed Gale despite the phase. | Gale is discarded, Event #5 supplies the real result and Royal George remains British. |
| D06 Defender Outmaneuver, LC Weather Gage check • U.S. 710000 fleet • baseline-defender-outmaneuver.json • Continue after Gunnery Round results | The U.S. gained the Gage and no Event was drawn. src/engine_combat.js:510 skipped the draw. | Event #13 is drawn and the U.S. wins the Weather Gage. Later draws follow the proper deck. |
| Aid V #8 • British 710000 blockade • baseline-manual-package8-second.json • choose an empty second stack or the eligible Patrol in baseline.json | An empty second stack passed validation at src/engine_deploy.js:228. | The empty stack is refused. The legal Army Support stack is captured Wolfe at 8 CA with two Troops. The twelve remaining selected ships produce precisely 22 LG in the Patrol. |
| §14.2 Dual Blockade • U.S. 710031 blockade • baseline-dual-blockade.json • Continue at C Enemy Operations through Tally | U.S. decisive victory in July II at +29. | Same decisive result, overriding the ordinary +29 victory tier. The U.S. maintains four full-strength Main Ships at Kingston and four at York. This position has no qualifying British breakout ships. |

Two further saved endings isolate score and timing. In zero-dual-dual-blockade.json (U.S. 710101), Continue through Tally awards the U.S. a §14.2 decisive victory at exactly zero VP. In last-turn-5-1-early.json (U.S. 710005), Continue from the end-of-September-I reset. The A.I. has no eligible ships for September II, so §5.1 ends the game at +38. These two positions came from the primary matrix.

The candidate offered displaced human ships for Reaction in 39 prompts and observed 44 successful return events across both sides. In candidate-displaced-returned.json, select Beresford and Royal George at Kingston. Royal George rejoins. Seven multi-Force Event draws had no result inconsistent with an eligible Force.

## Pauses and bookkeeping

A disjoint set of seeds 712000–712015 ran one matched campaign per policy and human side with A.I. confirmations on and off. Actions at actual decisions follow the same policy. End-state comparison excludes the version stamps, prompt sequence number and confirmation preference. All remaining state, including the RNG, roll history, final VP, decks, forces and full log, must match.

| Measure | v0.2.9 | v0.2.10 |
| --- | --- | --- |
| Exact paired end states | 160 / 160 | 160 / 160 |
| Info-only Continue prompts per campaign, confirmations on | 94.2 | 94.5 |
| Info-only Continue prompts per campaign, confirmations off | 46.5 | 46.7 |
| Other decision prompts per campaign, on / off | 42.5 / 42.5 | 42.6 / 42.6 |
| Prompts avoided per campaign | 47.7 | 47.8 |

Counts are prompts, not physical clicks or elapsed minutes. A ship may change several times between prompts. The evidence also records how many individual ship rows changed between successive prompts, and the number of manual package and Land Battle lookups. Pilot and search runs are excluded.

## Reproduction

Use Node and the two repo checkouts as BASE and RC. Invoke commands from this evidence directory.

    node sweep.js BASE 710000 128 baseline
    node sweep.js RC 710000 128 candidate
    AGC_PAUSES=1 node sweep.js BASE 712000 16 paused-baseline
    AGC_PAUSES=0 node sweep.js BASE 712000 16 fast-baseline
    AGC_PAUSES=1 node sweep.js RC 712000 16 paused-candidate
    AGC_PAUSES=0 node sweep.js RC 712000 16 fast-candidate
    AGC_OPTION_GRID=1 AGC_POLICIES=coast node sweep.js BASE 713000 64 options-baseline
    AGC_OPTION_GRID=1 AGC_POLICIES=coast node sweep.js RC 713000 64 options-candidate
    AGC_SEATS=US AGC_POLICIES=blockade node sweep.js RC 710101 1 zero-dual
    AGC_SEATS=US AGC_POLICIES=blockade node sweep.js RC 710005 1 last-turn
    node natural_positions.js BASE RC
    node compare.js

Concatenated engine SHA-256 follows tools/files.json order. v0.2.9 b17b58f81f48d80bed3228df3daabd910a5f9f74d71ec2b8eabe73969dbe0e47. v0.2.10 c99735c1343cbbd15bf41fc7105f9066cdc055d11accf99d7e938403f944a855. The main report records the separately rebuilt HTML digest.
