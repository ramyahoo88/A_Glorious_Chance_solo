"""Run the unmodified builder in a separate copy of the committed source, then compare raw bytes."""
from pathlib import Path
import subprocess,tarfile,io,tempfile,hashlib,json,sys
repo=Path(sys.argv[1]).resolve();dest=Path(__file__).resolve().parent
commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
with tempfile.TemporaryDirectory(prefix='agc-audit-rebuild-') as temp:
    root=Path(temp)
    data=subprocess.check_output(['git','-C',str(repo),'archive',commit,'tools','src','package.json'])
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:') as tf:tf.extractall(root,filter='data')
    subprocess.run(['node','tools/build.js'],cwd=root,check=True)
    built=root/'dist/index.html';shipped=repo/'dist/index.html'
    assert shipped.read_bytes()==subprocess.check_output(['git','-C',str(repo),'show',commit+':dist/index.html'])
    subprocess.run(['cmp',str(shipped),str(built)],check=True)
    def describe(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    record={'commit':commit,'shipped':describe(shipped),'separateBuild':describe(built),'cmpExit':0,'node':subprocess.check_output(['node','-v'],text=True).strip()}
(dest/'literal-build-results.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
