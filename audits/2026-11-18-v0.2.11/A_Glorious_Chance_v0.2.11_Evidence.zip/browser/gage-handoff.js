// Exercise the public page's Load, Continue and Undo handlers on the normal U.S. game.
const {fs, path, assert, launch, st, button, loadText} = require('./page_helpers');
(async () => {
  const game = await launch();
  button(game, 'Start campaign');
  const save = fs.readFileSync(path.join(__dirname, '../campaign/baseline-defender-outmaneuver.json'), 'utf8');
  loadText(game, save);
  const result = {};
  const area = game.doc.querySelector('#proc');
  function capture() {
    return {
      prompt: area.querySelector('.ptitle').textContent,
      report: area.querySelector('.ptext')?.textContent,
      formation: area.querySelector('.combat')?.previousElementSibling?.textContent,
      roles: Array.from(area.querySelectorAll('.colm > b'), b => b.textContent)
    };
  }
  const before=st(game);
  result.before = capture();
  button(game, 'Continue', area);
  result.after = capture();
  const after=st(game);
  assert.equal(after.encounter.wgCard,13);
  assert.equal(after.encounter.wg,'US');
  assert.equal(after.combat.att,'BR');
  button(game,'↶ Undo');
  assert.deepEqual(st(game),before);
  button(game,'Continue',area);
  assert.deepEqual(st(game),after);
  button(game,'Continue',area);
  result.next = capture();
  assert.equal(result.next.prompt,'You gain the Weather Gage');
  assert.ok([...area.querySelectorAll('button')].some(b=>b.textContent==='Pass'));
  if(process.argv.includes('--fixed')) {
    assert.match(result.after.formation,/Previous formation \(Sequence B\)/);
    assert.deepEqual(result.after.roles,['American – previous defender','British – previous attacker']);
  }
  assert.deepEqual(game.errors,[]);
  console.log(JSON.stringify(result,null,2));
  game.dom.window.close();
})().catch(e=>{ console.error(e);process.exitCode=1; });
