// node replay.js /path/to/checkout > observations.json
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(process.argv[2]);
const sources = JSON.parse(fs.readFileSync(path.join(root, 'tools/files.json'))).engine;
const context = vm.createContext({console});
const x = code => vm.runInContext(code, context);
x(sources.map(file => fs.readFileSync(path.join(root, 'src', file), 'utf8')).join('\n;\n') + '\ninstallResume();');
const json = expr => JSON.parse(x('JSON.stringify(' + expr + ')'));
const observations = { version: x('APP_VERSION'), fixtures: {}, independentBoundaries: {} };
for (const name of fs.readdirSync(__dirname).filter(n => /^C\d\d-.*\.json$/.test(n))) {
  const input = JSON.parse(fs.readFileSync(path.join(__dirname, name))).state;
  x('var s=' + JSON.stringify(input));
  const frames = [];
  for (let i=0; i<25; i++) {
    frames.push(json(`({title:s.prompt?.title || 'Game Over',step:s.stepLabel,turn:s.turn,
      forces:Object.values(s.forces).filter(f=>f.mission==='ArmySupport').map(f=>({zone:f.zone,cargo:f.troops,launched:f.launched||0})),
      wolfe:[s.ships.wolfe.steps,s.ships.wolfe.box,s.ships.wolfe.port],flagships:s.flagship,score:gameScore(s)})`));
    if (x('s.over || s.turn>5')) break;
    if (x('s.prompt.title === "Transfer the flag?"')) {
      const choice = name === 'C06-transfer-Yeo.json' ? 'rg' : name === 'C06-simultaneous-transfers.json' ? 'oneida' : 'stay';
      const available = json('s.prompt.options.map(o=>o.id)');
      x('act(s,' + JSON.stringify(available.includes(choice) ? choice : 'stay') + ')');
    } else if (x('s.prompt.kind === "info"')) x('act(s,"ok")');
    else break;
  }
  observations.fixtures[name] = { frames, result:json('s.result'),
    ledger:json('s.vpLog'), battles:json('s.coastal.battles'),
    gameLog:json('s.log.filter(l=>/Troops launched|Land Battle vs|Land Battle result|Harbor Gunnery Round|takes [0-9]+ hit|Dual Blockade|Breakout requirements|Heated Shot|flag transferred|shifts his flag/.test(l.text)).map(l=>l.text)') };
}
x(`function boundary(h='BR') {
 const s=newGame(h,1775);s.turn=3;s.lossesThisTurn=[];s.troops[h].available=0;
 s.convoys.US[3]={real:false,revealed:true};s.convoys.BR[3]={real:false,revealed:true};return s;
}
function tally(s) {return PROCS.tally.start(s,{A:{},L:{}});}
function reset(s) {return PROCS.tally.reset(s,{A:{},L:{}});}
var previous=boundary();previous.pendingConvoy.BR=[{status:'delayed',turn:2}];previous.zones.KIN.blockade='US';
previous.convoys.BR[3]={real:true,revealed:true};tally(previous);
var during=[previous.supply.BR,previous.pendingConvoy.BR[0].status];reset(previous);
var after=[previous.supply.BR,previous.pendingConvoy.BR[0].status];previous.turn=4;
previous.convoys.BR[4]={real:false,revealed:true};tally(previous);
var both=boundary();both.supply={US:10,BR:10};both.convoys.US[3].real=both.convoys.BR[3].real=true;
both.coastal.battles.push({side:'US',target:'HOME',zone:'KIN',result:'AS'});tally(both);
var below=boundary();below.supply={US:8,BR:0};below.coastal.battles.push({side:'US',target:'HOME',zone:'KIN',result:'AS'});tally(below);
var ct=boundary();ct.ships.sylph.box='makeReady';applyShipyard(ct,'US','BR','reduceAllConstruction',()=>{});
var oneHull=ct.ships.pike.steps;ct.ships.sylph.box='construction';applyShipyard(ct,'US','BR','reduceAllConstruction',()=>{});
var twoHulls=[ct.ships.pike.steps,ct.ships.sylph.steps];applyShipyard(ct,'US','BR','destroyAllConstruction',()=>{});
var hullScore=ct.vp.BR;var ledger=ct.vpLog.map(e=>e.n);tally(ct);
var capture=boundary(); captureShip(capture,'beres','US','Lake Combat');capture.coastal.cutouts.push({side:'US',result:'repulsed'});
newForce(capture,'US','NIA','Patrol',['madison','oneida']);var carry=newForce(capture,'BR','SOU','ArmySupport',['wolfe']);carry.troops=1;
capture.ships.wolfe.steps=2;capture.troopsReturning={BR:1,US:0};tally(capture);
var capturePoints=[capture.vp.US,capture.vp.BR,capture.ships.beres.steps,capture.ships.beres.owner];reset(capture);
`);
function boundary(name, expr, expected) {
  const result = json(expr);
  assert.deepEqual(result,expected,name);
  observations.independentBoundaries[name]=result;
}
boundary('Previous blockaded convoy flips at first unblocked F7 and scores at the following F5',
  '[during,after,previous.supply.BR,previous.pendingConvoy.BR.length]',[[3,'delayed'],[3,'arrived'],5,0]);
boundary('Both reach the final Supply box during one F5 and homeport success cannot unpin the marker',
  '[both.supply.US,both.supply.BR,both.fallOffensive,both.vp.US,both.vp.BR]',[12,12,'both',0,0]);
boundary('Attacker Success depletes defending supply down to −1 without crediting the attacker',
  '[below.supply.US,below.supply.BR]',[8,-1]);
boundary('Shipyard Damage 8–9 affects a group but not a lone hull, and destroyed hulls score once',
  '[oneHull,twoHulls,ct.ships.pike.box,ct.ships.sylph.box,hullScore,ledger,ct.vp.BR]',[3,[2,2],'sunk','sunk',34,[20,14],34]);
boundary('F1 capture and failed Cutting-Out resolve alongside one controlled zone and two unlaunched human Troops returning at F7',
  '[capturePoints,capture.troops.BR.available,capture.ships.beres.box,capture.zones.NIA.control]',[[11,1,1,'US'],2,'transit','US']);
// The two printed score columns, read down the map's VP table; all A/B versions use the same values.
const shipVP={wolfe:[16,32],rg:[14,28],moira:[7,14],melville:[6,12],beres:[5,10],sss:[5,10],pike:[20,40],madison:[16,32],sylph:[14,28],oneida:[7,14],tompkins:[4,8],fairam:[4,8],conquest:[4,8]};
const others=['asp','growler','hamilton','julia','lady','ontario','pert','raven','scourge'];
others.forEach(id=>{shipVP[id]=[2,4];});
let versions=0;
for (const d of json('SHIP_DEFS')){assert.deepEqual(d.vp,shipVP[d.base],d.id);versions++;}
observations.independentBoundaries.printedShipVP={baseShips:Object.keys(shipVP).length,counterVersions:versions,columns:['destroyed','captured']};
process.stdout.write(JSON.stringify(observations,null,2)+'\n');
