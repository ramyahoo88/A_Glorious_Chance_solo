# A Glorious Chance Solo
## v0.2.5 release and rules re-audit
18 November 2026 · Release commit aa6de34

**Fresh play passes. Two mid-turn v0.2.4 saves still need upgrade handling.** All three changes requested after the v0.2.4 audit worked when I replayed the original positions in v0.2.5. A game exported after the earlier build had already placed a Troops marker in Available or started the second Encounter can still carry the incorrect position forward.

| Case | Result in v0.2.5 |
|---|---|
| W01 · Troops withdrawn before F7 | The marker goes to the return queue, B20 makes no deployment, and the marker returns once at F7. Tracks shows the pending return. |
| W02 · Surrenders under Pursuit | Beresford is captured before the next Event. Passing or attacking later preserves the same owner and records one capture. |
| W03 · Old Rake choice | The v0.2.3 save names Royal George before selection. The candidate survives Undo and reload and the card returns once. |
| L01 · Save after the old withdrawal | An already returned marker can attack Kingston that turn. The focused July I turn finishes at −7 VP and British supply −1. |
| L02 · Save after the old Pursuit | The next command can still switch an earlier surrender from a British rescue to a U.S. capture. |

### Release identity
I pinned both main and release/v0.2.5 to aa6de34473e52a1908c77961e957c0127ac70d39. GitHub Pages was at 53078067ecc6f55b11053c7b9bd444895929dbdf. The public page opened directly and a normal reload of the earlier browser tab showed v0.2.5. Git listed no v0.2.5 tag at review. [Pinned release](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/aa6de34473e52a1908c77961e957c0127ac70d39) · [Pages commit](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/53078067ecc6f55b11053c7b9bd444895929dbdf) · [Public companion](https://ramyahoo88.github.io/A_Glorious_Chance_solo/)

I rebuilt the pinned source in a separate temporary directory and compared raw bytes with cmp. The clean build, both shipped GitHub copies, the Pages branch and the anonymous HTTP 200 response were **byte-identical at 296,920 bytes**.

`8e6f43c6ca0c0a6586850ac3ce55657ec72c5e4184bc8f620b4590482658b2a6`

The evidence ZIP contains the exact prior and revised positions, simulator scripts, complete browser choices, public release verification and both signed final ledgers.

<!-- page -->
## L01 · A save can preserve the early Troops return
**A player upgrading during this window can face a second attack from the same marker.** Both rulebooks put unlaunched Troops back in Available during F7. The LC5 withdrawal procedure prevents those Troops from launching this turn. Notes 23 and 69 apply this timing to both sides. B20's Kingston Army Support has an empty cell at zero Troops and Naval Balance −15 through +15. At one Troops marker in that band it uses American Force Package 7.

### Reproduce from a v0.2.4 Save export
Open v0.2.5, choose **Load**, then open `new-saves/L01_after_v024_withdrawal.json`. The seed is 185301 in July I, British campaign, after Wolfe has made Madison withdraw at Niagara. The prior round's British d10 6 plus Command gave D1W. Madison's Disengagement roll was 2. B20 is still in the Target row and the withdrawn marker is the only one in the available American pool.

| Action in v0.2.5 | Observed result |
|---|---|
| Read the Board’s Tracks panel immediately on import. | A.I. has 1 available and 2 on the Track. The F7 queue is empty. |
| Click Continue three times. | B20 deploys Package 7 to Kingston with that marker. |
| Click Continue six more times to the July I Tally. | One Troops marker lands, with Long Gun 17 and land roll 45 for Attacker Success. Britain gains 8 VP for capturing Fair American, the U.S. gains 1 VP for Lake Control, and British Convoy Supply falls from 1 to −1. Signed score −7. |

**Expected.** At the first prompt, zero should be Available and one should be due back. B20 should deploy no force. The matched position before withdrawal, `baseline-saves/W01_B20.json`, produces a signed score of 0 and British supply 1 in v0.2.5. F7 returns the marker once. The mid-turn export and an old browser autosave give the same erroneous result.

**Ordinary play also reaches this window.** In the British campaign at seed 188128, August II, a v0.2.4 withdrawal returned the only available American marker. Four prompts later B16 used it for fresh Army Support at Niagara. Load `new-saves/L01_natural_legacy_export.json` for that state. The legacy route launches and rolls 21 for Draw. The matched v0.2.5 route from before withdrawal launches no attack. This ordinary example adds a fight without changing the observed turn score.

### Smallest fix
Normalize a legacy save when its current turn clearly records this return and the marker is still in the Available box. Move the proven amount to the F7 queue once. Where a later action makes reconstruction uncertain, show a warning and point to a save from before the withdrawal. The existing fix queues the marker only while executing the withdrawal, and the load path leaves the old box intact. The state records its originating build under app. `src/engine_encounter.js:464` · `src/engine_deploy.js:154` · `src/engine_tally.js:148` · `src/ui.js:115` · `src/ui.js:635` · `src/state.js:30`

<!-- page -->
## L02 · A save can preserve an undecided Pursuit surrender
**An already surrendered ship can still change owners based on a later command.** The A05 card calls for a new Encounter. LC5.3 resolves the pending surrenders at the end of their Encounter. Project note 68 supplies the exact result for Pursuit by treating the pursued Defender as withdrawn for this settlement. [Project ruling](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/aa6de34473e52a1908c77961e957c0127ac70d39/RULES_NOTES.md#L95)

### Reproduce from a v0.2.4 Save export
Load `new-saves/L02_after_v024_pursuit.json`. U.S. campaign, seed 182304, July I, North Lake. Oneida attacked Earl of Moira. Gunnery d10 2 gave D1W, and Moira passed Disengagement and returned under Pursuit. Lord Beresford had already Struck Colors when the previous build drew Event #9. The saved screen opens at that Event.

1. Click **Continue**. The Command Decision still shows Beresford off board with Struck Colors.
2. **Pass** the Patrol command, **Confirm** zero Reaction ships, and **Continue** to the second Command Decision.
3. Choose **Pass**. Beresford rolls 4 and is rescued for Britain.
4. Use Undo to return to the same second command. Choose **Attack**, use the offered lineup, and continue through **Encounter ended**. Beresford is recorded as a U.S. capture. His capture is worth 10 VP at F1 if play proceeds to Tally.

The original pre-Pursuit position is `baseline-saves/W02_Pursuit_struck.json`. In v0.2.5, two Continues yield the capture notice before Event #9. Both later branches retain the capture and only one entry. The ordinary withdrawal control also settles the ship before play resumes.

### Ordinary play control
A v0.2.4 British campaign at seed 188007 left Ontario's U.S. surrender pending when Pursuit drew Event #24 in June I, South Lake. The two natural saves are `L02_natural_before_pursuit.json` and `L02_natural_after_pursuit.json` in new-saves/. I played this seed from Setup in Chrome on v0.2.5. Ontario was captured before Event #24 and the June I ledger credited Britain 4 VP once.

### Smallest fix
When a legacy save still has a prior Encounter's surrender pending, run the existing settlement at recovery with the original Pursuit side and reconcile the capture ledger once. Limit automatic changes to saves with clear evidence of the prior boundary. If the saved log and state cannot distinguish the two Encounters, make that limitation visible at load and use a pre-Pursuit save for recovery. The new logic runs in afterCombat, and the common load check only migrates a pending Rake choice. `src/engine_encounter.js:142` · `src/engine_encounter.js:490` · `src/engine_combat.js:557` · `src/ui.js:115` · `src/ui.js:132`

<!-- page -->
## Campaign and recovery evidence
Two full campaigns were played through the public page in desktop Chrome. I entered the seeds through Setup, used the visible controls from June I to September II and reconciled every signed Game Over row. The British game used a coastal policy that committed ships to Raids and Army Support. The U.S. game used a fleet policy with Patrols, available support and convoy escorts. The policies exercised the rules in different positions.

| Game | Played prompts | Independently summed final ledger |
|---|---|---|
| British · 188007 | 174 prompts, including 131 information confirmations | 31 rows. U.S. 29, Britain 50. −21, British Marginal Victory. |
| U.S. · 187033 | 100 prompts, including 71 information confirmations | 19 rows. U.S. 17, Britain 21. −4, Draw. |

| Turn | British seed 188007, signed change | U.S. seed 187033, signed change |
|---|---|---|
| June I | −9 | 0 |
| June II | −3 | −4 |
| July I | +12 | 0 |
| July II | −4 | 0 |
| August I | −5 | 0 |
| August II | −2 | +1 |
| September I | −7 | +1 |
| September II | −3 | −2 |

The U.S. run's final tally deducts 1 VP from Britain for Construction Delay. The British deduction adds 1 to the signed Game Score. Full prompt and action sequences, the turn ledgers and browser-exported final saves are in the evidence ZIP.

Chrome's native file chooser accepted the old positions and refused the original damaged procedure save without changing the open game. A July checkpoint survived export, import, Undo and replay. Reload recovered the identical in-progress game and **Review it** recovered the final British game. Command Decision and lineup previews both showed **4.5 vs 8** with Missed Signal. That strength carried into the roll and the chosen Surprise Tactic shifted the column.

Rake was checked on a v0.2.3 file, an old autosave directly at the choice, and a pending choice recovered from an old Undo snapshot. Lead, rear and random each hit the displayed ship in the shipped page's DOM. Chrome confirmed the random branch, one card returned, and the same candidate after Undo and reload. The printed source is A06 and the Living Playbook p.19. `src/engine_combat.js:557` · `src/ui.js:49`

<!-- page -->
## Coverage, rulings and release decision
### Published rules and components
I used the British Living Rules dated 7 August 2024, U.S. Living Rules dated 13 April 2024, Living Playbook dated 6 August 2024, errata updated 13 April 2024, VASSAL v1.0 component faces, and the two photographed 2023 player aids. I checked the rendered page columns for withdrawal and Strike timing, F7 and the Playbook's Pursuit and Rake examples. The American AI board used the project's published Long Gun attack precondition. [Publisher support](https://www.legionwargames.com/legion_AGC_GS.html) · [Living Playbook](https://khybergames.com/legionwargames/docs/AGC_Living_Playbook_as_of_6Aug2024.pdf) · [Errata](https://www.legionwargames.com/docs/AGC_errata_and_clarifications_rev_13Apr2024.pdf)

| Materials | Verification |
|---|---|
| Both Target decks | All 104 cards, four Troops rows and seven balance columns. All 2,912 cells matched. |
| Aids V and VI and both maps | All eleven force packages tested against empty and eligible pools. All 648 Hit Distribution die pairs across 18 columns, 70 Lake Combat cells and 60 Convoy Scatter cells matched. |
| Photographed Aid VII | Checked every die pair in all 15 columns. All 538 printed outcomes matched. Rolls 62 and 63 at zero Long Gun and three Troops remain unassigned in print. The app treats both as Attacker Success. |

The publisher's errata puts the two-space Convoy Supply loss on the defender for a successful Homeport attack. I kept that published correction. The exact capture-versus-rescue resolution under Pursuit is the documented project ruling. Remaining rule questions include the two Land Battle rolls, Package 8's choice among first forces that may leave a weak second pool, and return timing for used or negated Tactics other than Rake.

### Independent checks
All 195 repository assertions and 200 smoke games passed. I also reran the 28 previous-finding comparisons, 22 save and engine comparisons, 23 boundary comparisons and 29 extended checks, including ties, simultaneous Fall Offensive and the dual blockade early ending. The 11 new boundary assertions covered extra Troops in the F7 queue, a rescued attacker and captured defender in the same Pursuit, and synthetic dual-withdrawal rolls covering both fates.

The two 2,048-game engine batches used the same seeds 188000–188511, both campaigns and both fixed policies. In v0.2.4, 132 of 251 Pursuit transitions still held a surrender in the new Encounter. There were 90 early Troops returns and three same-turn re-embarks after a zero-to-one return. In v0.2.5 there were zero carried surrenders across 254 Pursuits, zero early returns and zero same-turn re-embarks through this route. Separate stock checks covered 512 campaigns, and a separate 512-game run examined routine withdrawals. These are regression observations from scripted play. Device installation, offline launch from a home-screen shortcut and physical-table time remain coverage gaps.

**Release verdict. Pass for fresh campaigns. Hold seamless upgrade sign-off for the two affected v0.2.4 save windows.** Prioritize the pending Pursuit surrender and the early Troops return on load. Until there is a migration, the matching pre-step saves demonstrate the recovery path and preserve the intended outcomes.
