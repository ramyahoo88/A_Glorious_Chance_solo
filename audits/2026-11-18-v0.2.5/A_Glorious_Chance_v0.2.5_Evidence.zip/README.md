# A Glorious Chance Solo v0.2.5 audit evidence

The reviewed code and released HTML came from aa6de34473e52a1908c77961e957c0127ac70d39. The public Pages file came from 53078067ecc6f55b11053c7b9bd444895929dbdf. Both and the separate rebuild have SHA-256 8e6f43c6ca0c0a6586850ac3ce55657ec72c5e4184bc8f620b4590482658b2a6. The report text is in audit.md. Source line references use the reviewed commit.

## Reproduce the save cases

Open the public page at https://ramyahoo88.github.io/A_Glorious_Chance_solo/ while it serves v0.2.5, or use dist/index.html from the pinned commit. Select **Load game** on Setup or **Load** in a game. Choose a JSON file or paste its full text.

| Save | Steps and result |
|---|---|
| new-saves/L01_after_v024_withdrawal.json | Seed 185301, July I. Board → Tracks shows one AI Troops available before F7. Click Continue three times for B20 and six more for Tally. That marker redeploys to Kingston, and the signed score is −7 with British supply −1. |
| baseline-saves/W01_B20.json | Same setup before the withdrawal. In v0.2.5 click Continue once. Board → Tracks shows zero available and one due back. Continue to Tally. British supply is 1 and the score is 0. Continue to Reset for one marker returned. |
| new-saves/L02_after_v024_pursuit.json | Seed 182304, July I, Event #9. Continue, Pass the Patrol command, Confirm zero Reaction ships, Continue to the next Command Decision and Pass. Beresford is rescued on 4. Undo to that command, choose Attack, accept the lineup and follow the next Continue prompts to Encounter ended. Beresford is captured by the U.S. Stop at Encounter ended in this focused fixture. |
| baseline-saves/W02_Pursuit_struck.json | Start before the Pursuit boundary. Two Continues display Beresford's U.S. capture before Event #9. Both later branches leave the same owner and exactly one capture. |
| new-saves/W03_legacy_Rake.json | A genuine v0.2.3 export at the choice. Royal George appears on the random button before committing. Choose him, Undo and reload to check the same candidate. |
| new-saves/L01_natural_legacy_export.json | Seed 188128, British campaign, August II. This is an old Save export following the naturally occurring early return. Follow the coastal policy to B16. It redeploys one U.S. marker to Niagara and the game rolls 21 for Draw. The matching new route skips this attack. |
| new-saves/L02_natural_after_pursuit.json | Seed 188007, British campaign, June I, Event #24. Continue to see Ontario still marked Struck Colors. In its pre-boundary companion file, one Continue in v0.2.5 moves Ontario to the British side before the Event. |

The strict migration assertions regenerate both focused exports using the v0.2.4 Save dialog. The exports preserve `state.app = "0.2.4"`. The Chrome probes replayed equivalent board and RNG positions. Their fixture creation-version field was 0.2.5 from the earlier test setup. A field-by-field comparison found no other differences. The released save checks give both versions the same treatment, which the DOM tests also confirmed. The natural exports came from unmodified old seeded campaigns.

## Repeat the independent checks

Run from the extracted archive. The commands use Git, Node 24, Python 3.12+, and jsdom 26.1.0 where indicated.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git project
git -C project checkout --detach aa6de34473e52a1908c77961e957c0127ac70d39
git -C project worktree add --detach "$PWD/v024" f15cdd39fa3fe93c86e999dee868178703ad2abc
git -C project worktree add --detach "$PWD/v023" ff616f1
python compare_release.py project
python verify_public.py project
npm --prefix project test
node next_rules.js project --require-rules
node recheck_engine.js project
node boundary_checks.js project
node edges.js project
node followup_rules.js project --require-rules
node new_boundaries.js project
node map_checks.js project
node paper_checks.js project
node export_data.js project
python verify_land_aid.py
```

verify_public.py reads the current public HTTP response. A later update can legitimately change that response. The component matrix checker needs the extracted images from a separately obtained VASSAL v1.0 module plus Pillow and NumPy. Run `python verify_component_grids.py /path/to/vmod/images` after the data export.

```sh
npm install --prefix audit-node jsdom@26.1.0
export NODE_PATH="$PWD/audit-node/node_modules"
node recheck_dom.js project
node legacy_dom.js project
node verify_legacy_rake.js project --require-rules
node migration_cases.js project v024 v023
node migration_cases.js project v024 v023 --require-migration
```

The last command must exit 1 for this release. It prints the rules expectations and observed values for L01 and L02. The ordinary controls pass in both cases, and the script also exercises all three Rake targets and the old autosave Undo history. recheck_dom.js drives the shipped FileReader handler and its normal callbacks in jsdom. public-browser-results.json separately records direct use of the native Chrome file picker, file download and visual prompts. 

```sh
node search_legacy_positions.js v024 188000 512 legacy
node search_legacy_positions.js project 188000 512 current
node natural_replays.js project v024
node campaigns.js project 183000 64
node campaigns.js project 187000 64
node timing_campaigns.js project 128
node campaign_controls.js project BR 188007 coast
node campaign_controls.js project US 187033 fleet
```

The two search batches each complete 2,048 games. Each seed uses both campaign sides and the coastal and fleet policies. The legacy run writes the natural before and after positions. Its same-turn re-embark check requires a zero-to-one return and the same single-marker supply immediately before a later Army Support deployment. natural_replays.js replays seed 188128's archived position in v0.2.5 and verifies the rule-correct branch alongside the old continuation.

## Full browser play

Use defaults at Setup. Select the campaign and enter its seed, then press Tab to commit it. The controls files list the exact buttons, assignments and selections in order. Every prompt title and turn matched in Chrome. Board mirroring is outside the control counts.

| Campaign | Seed | Prompts | Info confirmations | Keyboard and click actions in plan | Result |
|---|---:|---:|---:|---:|---|
| British | 188007 | 174 | 131 | 248 | −21, British Marginal Victory, U.S. 29 and Britain 50 |
| U.S. | 187033 | 100 | 71 | 234 | −4, Draw, U.S. 17 and Britain 21 |

The action counts are scheduled control changes, rather than individual keypresses. Chrome-final files are actual downloads. Import one, reload and choose **Review it** to inspect the finished score. The positive signed row for Britain's final Construction Delay subtracts 1 from British VP.

## File index

- public-release.log and literal-build-results.json record release verification. remote-refs.txt pins GitHub branch heads.
- migration-results.json and expected-migration-failures.log document both open legacy transitions. natural-results.json records the ordinary seeds and outcomes.
- new-boundary-results.json and followup-results.json contain the Pursuit and F7 controls. next-results.json, engine-results.json, boundary-results.json, edges-results.json, dom-results.json and legacy-results.json cover prior cases. 
- public-browser-results.json records the original and resumed positions in Chrome, preview comparisons, normalized ledgers and recovery results.
- Source provenance and SHA-256 are in source-manifest.json. Printed photographs, publisher artwork and raw rules are separate from this archive.

**Verdict.** Fresh campaigns pass. Hold seamless upgrade sign-off for the two v0.2.4 windows. Replay the transition from the earlier save to get the corrected result.
