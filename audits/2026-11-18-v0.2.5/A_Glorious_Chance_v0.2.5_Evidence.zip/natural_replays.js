// Replay positions captured during whole seeded v0.2.4 campaigns. No edits to the boards.
const {fs,path,assert,out,launch,st,button,start,step,loadText}=require('./page_helpers');
const {policy}=require('./campaigns');
const current=path.resolve(process.argv[2]), previous=path.resolve(process.argv[3]);
const previousHTML=fs.readFileSync(path.join(previous,'dist/index.html'),'utf8');
const E=require(path.join(current,'tools/bundle_engine.js'))();
const fixtures=path.join(out,'new-saves');
const filename=n=>path.join(fixtures,n+'.json');
const input=n=>fs.readFileSync(filename(n),'utf8');
const afterSave=(t,n)=>{
  button(t,'Save');const txt=t.doc.querySelector('#modal textarea').value;
  button(t,'Close',t.doc.querySelector('#modal'));
  fs.writeFileSync(filename(n),txt);return JSON.parse(txt).state;
};
const copy=x=>JSON.parse(JSON.stringify(x));
const available=s=>s.aiTroops.box.filter(m=>m.troops&&m.revealed).length;
function playTurn(s){
  const start=s.vp.US-s.vp.BR;
  const l0=s.log.length;
  const cohort=[];
  while(!s.over&&cohort.length<50){
    const p=s.prompt;
    cohort.push(p.title);
    if(/^Tally/.test(p.title))break;
    const a=policy(s,p,'coast');
    assert(!E.validateAnswer(s,p,a));E.act(s,a);
  }
  assert(cohort.at(-1).startsWith('Tally'));
  const l=s.log.slice(l0).map(x=>x.text);
  return {prompts:cohort,leaves:s.supply,supplyBR:s.supply.BR,delta:s.vp.US-s.vp.BR-start,score:s.vp.US-s.vp.BR,queue:s.troopsReturning,
    land:s.coastal.battles,lines:l.filter(t=>/Target Card B16:|Troops launched|land battle|Land Battle|Coastal mission aborted/.test(t))};
}
async function main(){
  const t=await launch(undefined,previousHTML);start(t,'BR',188128);
  const oldBefore=input('L01_natural_before_withdrawal');
  loadText(t,oldBefore);
  assert.equal(st(t).seed,188128);assert.equal(st(t).prompt.title,'Tactics');
  step(t);assert.equal(available(st(t)),1);
  const old=afterSave(t,'L01_natural_legacy_export');
  const newEntry=JSON.parse(oldBefore).state;
  assert(!E.validateAnswer(newEntry,newEntry.prompt,'ok'));E.act(newEntry,'ok');
  assert.deepStrictEqual([available(newEntry),newEntry.troopsReturning.US],[0,1]);
  const l01={seed:old.seed,turn:old.turn,legacy:playTurn(copy(old)),current:playTurn(newEntry)};
  assert(l01.legacy.lines.some(t=>t.includes('B16:')&&t.includes('Carrying 1 Troops marker(s)')));
  assert(l01.current.lines.some(t=>t.includes('B16:')&&t.includes('no AI Troops are Available')));
  assert(!l01.current.lines.some(t=>t.includes('Troops launched in Niagara')));
  const oldL02=JSON.parse(input('L02_natural_after_pursuit')).state;
  const beforeL02=JSON.parse(input('L02_natural_before_pursuit')).state;
  assert.equal(beforeL02.prompt.title,'Gunnery Round results');
  E.act(beforeL02,'ok');
  assert.equal(beforeL02.ships.ontario.owner,'BR');
  assert.equal(beforeL02.encounter.ships.ontario,'done');
  const l02={seed:oldL02.seed,turn:oldL02.turn,event:oldL02.prompt.eventCard,oldSurrender:{owner:oldL02.ships.ontario.owner,status:oldL02.encounter.ships.ontario},newSurrender:{owner:beforeL02.ships.ontario.owner,status:beforeL02.encounter.ships.ontario,winPrompt:beforeL02.prompt.title,text:beforeL02.prompt.text}};
  assert.deepStrictEqual(t.errors,[]);t.dom.window.close();
  fs.writeFileSync(path.join(out,'natural-results.json'),JSON.stringify({l01,l02},null,2)+'\n');
  console.log(JSON.stringify({l01:{seed:l01.seed,legacy:{roll:l01.legacy.land,score:l01.legacy.score,delta:l01.legacy.delta},current:{roll:l01.current.land,score:l01.current.score,delta:l01.current.delta}},l02},null,2));
}
main().catch(e=>{console.error(e);process.exitCode=1});
