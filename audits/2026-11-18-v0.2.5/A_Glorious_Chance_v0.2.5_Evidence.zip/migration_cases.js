// Drive both shipped HTML files and export the old positions through their real Save dialog.
// Exit 1 with --require-migration when a legacy transition still violates the new rule.
const {fs,path,assert,out,launch,st,button,start,step,loadText,ev,html}=require('./page_helpers');
const older=path.resolve(process.argv[3]);
const olderRake=process.argv[4]?path.resolve(process.argv[4]):null;
const prev=fs.readFileSync(path.join(older,'dist/index.html'),'utf8');
const dir=name=>path.join(out,name);
const fixtures=path.join(out,'new-saves'), result={};
const read=(name,folder=fixtures)=>fs.readFileSync(path.join(folder,name+'.json'),'utf8');
const save=(t,fname)=>{
  button(t,'Save');const txt=t.doc.querySelector('#modal textarea').value;
  button(t,'Close',t.doc.querySelector('#modal'));
  if(fname)fs.writeFileSync(path.join(fixtures,fname+'.json'),txt);
  return txt;
};
const text=(t)=>t.doc.querySelector('#proc').textContent;
const card=(t)=>st(t).log.filter(e=>e.text.includes('Target Card B20:')).at(-1)?.text;
const track=(t)=>Array.from(t.doc.querySelectorAll('#board div')).find(d=>d.textContent.startsWith('Troops You:')&&d.firstChild?.nodeName==='B')?.textContent;
const tally=(s)=>({vp:s.vp.US-s.vp.BR,supply:s.supply.BR,returns:s.troopsReturning.US,atKingston:s.log.some(l=>l.text.includes('Troops launched in Kingston'))});
const next=t=>button(t,'Continue',t.doc.querySelector('#proc'));
const later=(t,condition,limit=75)=>{for(let i=0;i<limit;i++){if(condition(st(t)))return;step(t);}throw Error('Position did not reach '+String(condition));};
const active=async (bytes,side='BR',saveHtml=html)=>{const t=await launch(undefined,saveHtml);start(t,side,185430);loadText(t,bytes);return t;};
const assertClean=t=>{assert.deepStrictEqual(t.errors,[]);t.dom.window.close();};

async function troops() {
  const original=read('W01_B20',dir('baseline-saves'));
  const old=await active(original,'BR',prev);next(old);
  const bytes=save(old,'L01_after_v024_withdrawal');
  const seeded=JSON.parse(bytes).state;assert.equal(seeded.app,'0.2.4');assert.equal(seeded.aiTroops.box.filter(m=>m.revealed&&m.troops).length,1);assert.equal(seeded.troopsReturning.US,0);
  const oldAuto=old.w.localStorage.getItem('agc_solo_companion_v1');
  const imported=await active(bytes);const resumed=await launch(oldAuto);button(resumed,'Continue it');
  const control=await active(original);next(control);
  const tracks=[track(imported),track(resumed),track(control)];
  for(const t of [imported,resumed,control])later(t,s=>s.prompt.title.startsWith('Tally'));
  result.L01={seed:seeded.seed,phaseBefore:'July I · the Niagara withdrawal is already applied, before enemy operations',tracks,earlierBuildLog:seeded.log.filter(e=>e.text.includes('Coastal mission aborted')).at(-1)?.text,
    expected:tally(st(control)),file:tally(st(imported)),autosave:tally(st(resumed)),B20:{legacy:card(imported),control:card(control)}};
  assert.deepStrictEqual(result.L01.file,result.L01.autosave);
  assert.deepStrictEqual(result.L01.expected,{vp:0,supply:1,returns:1,atKingston:false});
  for(const t of [old,imported,resumed,control])assertClean(t);
}
async function reachSecond(t) {
  let commands=0;
  const trace=[];
  for(let i=0;i<15;i++){
    const p=st(t).prompt;trace.push(p.title);
    if(p.kind==='choice'&&p.title.startsWith('Command Decision')&&p.options.some(o=>o.id==='pass')){
      if(++commands===2)return trace;
      button(t,'Pass',t.doc.querySelector('#proc'));
    }else step(t);
  }
  throw Error('Second Command Decision did not appear');
}
async function settleBranch(bytes,order) {
  const t=await active(bytes,'US');
  const trace=await reachSecond(t);
  button(t,order,t.doc.querySelector('#proc'));
  later(t,s=>s.prompt.title==='Encounter ended'||s.prompt.title.startsWith('C Enemy'),30);
  const s=st(t);
  const out={trace,order,owner:s.ships.beres.owner,entries:s.lossesThisTurn.filter(l=>l.id==='beres'),
    messages:s.log.filter(l=>/Beresford.*(?:CAPTURED|rescued|Struck Colors)/.test(l.text)).map(l=>l.text)};
  assertClean(t);return out;
}
async function pursuit() {
  const bytes=read('W02_Pursuit_struck',dir('baseline-saves'));
  const old=await active(bytes,'US',prev);next(old);next(old);
  assert.equal(st(old).app,'0.2.4');assert.equal(st(old).prompt.eventCard,9);assert.equal(st(old).encounter.ships.beres,'struck');
  const oldBytes=save(old,'L02_after_v024_pursuit');
  const oldAuto=old.w.localStorage.getItem('agc_solo_companion_v1');
  const legacy=await active(oldBytes,'US'), resumed=await launch(oldAuto);button(resumed,'Continue it');
  const stale={title:st(legacy).prompt.title,event:st(legacy).prompt.eventCard,owner:st(legacy).ships.beres.owner,oldStrike:st(legacy).encounter.ships.beres,afterContinue:text(legacy).slice(0,750)};
  assert.deepStrictEqual(st(legacy),st(resumed));
  const control=await active(bytes,'US');next(control);next(control);
  const boundary={title:st(control).prompt.title,event:st(control).prompt.eventCard,owner:st(control).ships.beres.owner,disengagedSteps:st(control).ships.moira.steps,settled:st(control).encounter.ships.beres, text:text(control)};
  assert.equal(boundary.owner,'US');assert.equal(boundary.settled,'done');assert.equal(boundary.event,undefined);
  const fixedBytes=save(control);
  const prior=await active(read('C02_ordinary_withdrawal',dir('baseline-saves')),'US');next(prior);next(prior);
  result.L02={seed:st(old).seed,legacyState:stale,v025Boundary:boundary,ordinaryOwner:st(prior).ships.beres.owner,unchangedAtAutosave:true,legacy:[],control:[]};
  for(const order of ['Pass','Attack']){
    result.L02.legacy.push(await settleBranch(oldBytes,order));
    result.L02.control.push(await settleBranch(fixedBytes,order));
  }
  assert(result.L02.control.every(a=>a.owner==='US'&&a.entries.length===1));
  for(const t of [old,legacy,resumed,prior,control])assertClean(t);
}
async function rake() {
  if(!olderRake)return;
  const old=await active(read('N07_N08',dir('original-saves')),'US',fs.readFileSync(path.join(olderRake,'dist/index.html'),'utf8'));
  next(old);const label=t=>st(t).prompt?.options?.find(x=>x.id==='random')?.label;
  assert.equal(label(old),'A random ship');
  const pendingAuto=old.w.localStorage.getItem('agc_solo_companion_v1');
  const exportBytes=save(old);button(old,'A random ship',old.doc.querySelector('#proc'));
  const legacyHit=st(old).log.map(l=>l.text).find(l=>l.startsWith('Rake: all hits'));
  assert.equal(legacyHit,'Rake: all hits on Royal George (A).');
  const afterAuto=old.w.localStorage.getItem('agc_solo_companion_v1');
  const direct=await active(exportBytes,'US'), resumed=await launch(pendingAuto), history=await launch(afterAuto);
  button(resumed,'Continue it');button(history,'Continue it');button(history,'↶ Undo');
  const states=[direct,resumed,history].map(st);const labels=[direct,resumed,history].map(label);
  assert(labels.every(l=>l==='Random ship: Royal George (A)'));
  assert(states.every(x=>JSON.stringify(x)===JSON.stringify(states[0])));
  result.W03={oldApplied:legacyHit,uptake:['pasted text','old autosave at the decision','Undo restores old autosave history'],labels,branches:[]};
  for(const [option,expected] of [['lead','Wolfe (A)'],['rear','Earl of Moira (A)'],['random','Royal George (A)']]){
    const p=st(direct).prompt.options.find(o=>o.id===option);button(direct,p.label,direct.doc.querySelector('#proc'));
    const s=st(direct),hit=s.log.map(l=>l.text).find(l=>l.startsWith('Rake: all hits'));
    const spent=s.deck.tacA.filter(x=>x==='A_rake').length;
    assert.equal(hit,'Rake: all hits on '+expected+'.');assert.equal(spent,1);
    button(direct,'↶ Undo');assert.deepStrictEqual(st(direct),states[0]);
    result.W03.branches.push({option,hit,cardCopies:spent,undoMatches:true});
  }
  for(const t of [old,direct,resumed,history])assertClean(t);
}
(async()=>{
  await troops();await pursuit();await rake();
  fs.writeFileSync(dir('migration-results.json'),JSON.stringify(result,null,2)+'\n');
  const correctTroops=JSON.stringify(result.L01.file)===JSON.stringify(result.L01.expected);
  const correctPursuit=result.L02.legacyState.oldStrike!=='struck'&&result.L02.legacy.every(x=>x.owner==='US');
  console.log(JSON.stringify({L01:{expected:result.L01.expected,legacy:result.L01.file,passes:correctTroops},L02:{legacyPending:result.L02.legacyState.oldStrike,legacy:result.L02.legacy.map(x=>x.owner),current:result.L02.control.map(x=>x.owner),passes:correctPursuit},W03:result.W03},null,2));
  if(process.argv.includes('--require-migration')&&!(correctTroops&&correctPursuit))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
