// Deterministic search in the previous engine. Decisions use only the visible prompt and roster.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {policy}=require('./campaigns');
const E=require(path.join(path.resolve(process.argv[2]),'tools/bundle_engine.js'))();
const [first,count]=[Number(process.argv[3]||188000),Number(process.argv[4]||512)];
const run=process.argv[5]==='current'?'current':'legacy';
const result={first,count,games:0,pursuits:0,earlyReturns:0,oldStrikeCases:[],reuse:[],campaignsWithOldStrike:0};
const available=s=>s.aiTroops.box.filter(m=>m.revealed&&m.troops).length;
const write=(n,s)=>{
 if(run==='legacy')fs.writeFileSync(path.join(__dirname,'new-saves',n+'.json'),JSON.stringify({state:s,undo:[]}));
};
for(let n=0;n<count;n++)for(const human of ['US','BR'])for(const style of ['fleet','coast']){
 const seed=first+n,s=E.newGame(human,seed,{cuttingOut:n%2===0,oa1Upgrades:n%4===0});
 E.run(s);
 let foundStrike=false,early=null,preReturn=null,steps=0;
 while(!s.over&&steps<1500){
  const p=s.prompt,a=policy(s,p,style),beforeLog=s.log.length,turn=s.turn,box=available(s);
  assert(!E.validateAnswer(s,p,a));
  const pending=Object.entries(s.encounter?.ships||{}).filter(([,v])=>v==='struck').map(([id])=>id);
  const pursuing=s.combat?.tac?.att?.id==='A_pursuit';
  const prePursuit=pursuing&&pending.length?JSON.parse(JSON.stringify(s)):null;
  const canReturn=Object.values(s.forces).some(f=>f.side===s.ai&&f.troops>0);
  if(!result.reuse.length&&canReturn&&!box)preReturn=JSON.parse(JSON.stringify(s));else preReturn=null;
  E.act(s,a);steps++;
  const log=s.log.slice(beforeLog).map(e=>e.text),ai=s.ai==='US'?'U.S.':'British';
  if(log.some(t=>t.startsWith(ai+' Coastal mission aborted'))&&available(s)>box){
   result.earlyReturns++;
   if(box===0&&available(s)===1)early={seed,human,style,turn,step:steps,preReturn};
  }
  if(early&&early.turn===s.turn&&box===1&&s.phase!=='tally'&&s.phase!=='reset'&&log.some(t=>/AI Deploys to .* Army Support mission:[\s\S]*Carrying 1 Troops/.test(t))){
   const deployed=log.find(t=>/AI Deploys to .* Army Support mission:[\s\S]*Carrying [1-3] Troops/.test(t));
   const record={seed,human,style,turn,returnAt:early.step,reembarkAt:steps,boxPrior:box,deployed};
   if(!result.reuse.length&&early.preReturn)write('L01_natural_before_withdrawal',early.preReturn);
   result.reuse.push(record);early=null;
  }
  if(early&&(s.turn!==early.turn||s.phase==='tally'))early=null;
  if(log.some(t=>t.startsWith('Pursuit! The withdrawal is cancelled and a new Encounter begins'))){
   result.pursuits++;
   const strikes=Object.entries(s.encounter?.ships||{}).filter(([,v])=>v==='struck').map(([id])=>id);
   if(strikes.length){
    if(!result.oldStrikeCases.length){
     if(prePursuit)write('L02_natural_before_pursuit',prePursuit);
     write('L02_natural_after_pursuit',s);
    }
    result.oldStrikeCases.push({seed,human,style,turn,step:steps,zone:s.encounter.zone,ships:strikes,owners:strikes.map(id=>s.ships[id].owner),answer:a,promptBefore:p.title,prompt:s.prompt.title,event:s.prompt.eventCard});
    foundStrike=true;
   }
  }
 }
 assert(s.over);result.games++;result.campaignsWithOldStrike+=+foundStrike;
}
fs.writeFileSync(path.join(__dirname,run+'-search.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({games:result.games,pursuits:result.pursuits,earlyReturns:result.earlyReturns,carriedSurrenders:result.oldStrikeCases.length,campaignsWithOldStrike:result.campaignsWithOldStrike,example:result.oldStrikeCases[0],sameTurnReuse:result.reuse.length,exampleReuse:result.reuse[0]},null,2));
