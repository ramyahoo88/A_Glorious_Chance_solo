// Audit harness for A Glorious Chance Solo Companion v0.2.8 (read-only use of the repo).
// const H = require('/home/claude/audit028/harness.js')();  H.X('js code')  runs inside the engine + ui.js context.
// Everything the app defines (newGame, act, run, PROCS, checkSaveState, encAdd, newForce, ...) is a global there.
// Helpers defined below (inside the context): fresh(side, seed), stageCombat(s, zone, usIds, brIds, att),
// waitAt(s, proc, pc, A, L), afterCombatCaller(s), playUntil(s, stopFn) – copied from tests/regression.js.
const fs = require('fs'), path = require('path'), vm = require('vm');
module.exports = function (repo) {
  repo = repo || '/home/claude/a_glorious_chance_solo';
  const files = JSON.parse(fs.readFileSync(path.join(repo, 'tools', 'files.json'))).engine;
  const src = files.map(f => fs.readFileSync(path.join(repo, 'src', f), 'utf8')).join('\n;\n') + '\n;installResume();\n' + fs.readFileSync(path.join(repo, 'src', 'ui.js'), 'utf8');
  const ctx = { console, Math, JSON, Object, Array, String, Number, Error, RegExp, Date, localStorage: { getItem() { return null; }, setItem() {} } };
  vm.createContext(ctx); vm.runInContext(src, ctx);
  const X = e => vm.runInContext(e, ctx);
  X(`
function fresh(side, seed) { const s = newGame(side, seed); s.turn = 2; s.phase = 'lake'; s.calls = []; s.prompt = null; s.lossesThisTurn = []; s.troopsReturning = { US: 0, BR: 0 }; return s; }
function waitAt(s, proc, pc, A, L) { s.calls = [{ proc, pc, A: A || {}, L: L || {} }]; s.prompt = info('Test position', 'Continue.'); }
function stageCombat(s, zone, us, br, att) {
  att = att || 'US';
  const u = newForce(s, 'US', zone, 'Patrol', us), b = newForce(s, 'BR', zone, 'Patrol', br);
  s.encounter = { zone, kind: 'normal', segment: 'patrol', ships: {}, side: {}, struckBy: {}, withdrawn: { BR: false, US: false },
    humanForce: (s.human === 'US' ? u : b).id, aiForce: (s.ai === 'US' ? u : b).id, wg: att, wgCard: 8, firstAttack: false };
  us.concat(br).forEach(id => encAdd(s, id));
  s.zones[zone].event = 8; s.deck.event = [9].concat(s.deck.event.filter(n => n !== 8 && n !== 9));
  s.combat = { att, def: OTHER[att], seq: att === 'US' ? 'A' : 'B', pos: 0, segment: 'patrol', col: { US: us.slice(), BR: br.slice() }, tows: {}, tac: { att: null, def: null }, gr: 0, roundAttackers: [], newSeq: false };
}
function afterCombatCaller(s) { s.calls.unshift({ proc: 'encounter', pc: 'afterCombat', A: {}, L: {} }); }
function playUntil(s, stop) {
  for (let i = 0; i < 400; i++) {
    if (stop(s)) return true;
    const p = s.prompt; if (!p) return false;
    let a = 'ok';
    if (p.kind === 'choice') a = (p.options.find(o => o.primary) || p.options[0]).id;
    else if (p.kind === 'select') a = p.initial || [];
    else if (p.kind === 'lineup') a = { attackers: p.candidates, tows: p.defaultTows || {} };
    act(s, a);
  }
  return false;
}`);
  return { X, ctx, repo };
};
