// How many prompts are information-only, with and without "pause after each A.I. move"; what titles recur most.
process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
const agg = {};
for (const confirm of [true, false]) {
  let games = 0, prompts = 0, info = 0; const titles = {};
  for (let i = 0; i < 64; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
    const s = E.newGame(side, 400000 + i, { confirmAiSteps: confirm, cuttingOut: i % 2 === 0 }); E.run(s); let n = 0;
    while (!s.over && n < 3000) { const p = s.prompt; prompts++; if (p.kind === 'info') { info++; const t = (p.title || '').replace(/\d+/g, '#').replace(/ in .*$/, ''); titles[t] = (titles[t] || 0) + 1; } E.act(s, policy(s, p, style)); n++; }
    games++;
  }
  agg[confirm ? 'confirmAiSteps on (default)' : 'confirmAiSteps off'] = { games, promptsPerGame: +(prompts / games).toFixed(1), infoPerGame: +(info / games).toFixed(1), infoShare: +(info / prompts).toFixed(3),
    topInfoTitles: Object.entries(titles).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([t, c]) => `${t}: ${(c / games).toFixed(1)}/game`) };
}
console.log(JSON.stringify(agg, null, 1));
