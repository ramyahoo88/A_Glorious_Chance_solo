// The "pause after each A.I. move" option must not change the game: same seed and decisions → same result.
process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
let same = 0, diff = 0; const ex = [];
for (let i = 0; i < 64; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const r = [true, false].map(confirm => { const s = E.newGame(side, 400000 + i, { confirmAiSteps: confirm, cuttingOut: i % 2 === 0 }); E.run(s); let n = 0;
    while (!s.over && n < 3000) { E.act(s, policy(s, s.prompt, style)); n++; } return { score: s.result.score, vp: s.vp, rng: s.rng, log: s.log.filter(l => l.kind === 'roll').length }; });
  if (JSON.stringify(r[0]) === JSON.stringify(r[1])) same++; else { diff++; if (ex.length < 3) ex.push({ side, seed: 400000 + i, style, on: r[0], off: r[1] }); }
}
console.log(JSON.stringify({ same, diff, ex }, null, 1));
