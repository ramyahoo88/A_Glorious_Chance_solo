// Trace representative games with the visible-information policy; check the ledger and victory level independently.
process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
const fs = require('fs');
const level = sc => sc <= -33 ? 'British Decisive Victory' : sc <= -22 ? 'British Victory' : sc <= -11 ? 'British Marginal Victory' : sc <= 10 ? 'Draw' : sc <= 21 ? 'U.S. Marginal Victory' : sc <= 32 ? 'U.S. Victory' : 'U.S. Decisive Victory';
const out = [];
for (const [side, seed, style] of [['BR', 191073, 'fleet'], ['US', 187033, 'fleet'], ['BR', 188007, 'coast'], ['US', 185401, 'coast']]) {
  const s = E.newGame(side, seed, { cuttingOut: true }); E.run(s);
  const perTurn = {}; let n = 0;
  while (!s.over && n < 3000) {
    const p = s.prompt, t = s.turn; perTurn[t] = perTurn[t] || { prompts: 0, info: 0, decisions: 0 };
    perTurn[t].prompts++; if (p.kind === 'info') perTurn[t].info++; else perTurn[t].decisions++;
    E.act(s, policy(s, p, style)); n++;
  }
  const us = s.vpLog.filter(v => v.side === 'US').reduce((a, v) => a + v.n, 0), br = s.vpLog.filter(v => v.side === 'BR').reduce((a, v) => a + v.n, 0);
  const cdRows = s.vpLog.filter(v => /Construction Delay/i.test(v.why));
  const indep = us - br;
  out.push({ side, seed, style, over: s.over, prompts: n, perTurn, vpUS: s.vp.US, vpBR: s.vp.BR, ledgerUS: us, ledgerBR: br, indepScore: indep, appScore: s.result && s.result.score, appLevel: s.result && s.result.level, expectedLevel: s.result && (s.result.forced ? '(forced)' : level(indep)), cdFinal: s.cd, cdRows: cdRows.map(r => `${r.side} ${r.n} ${r.why}`), rows: s.vpLog.length, forced: s.result && s.result.forced });
  fs.writeFileSync(`/home/claude/audit028/engine/final_${side}_${seed}.json`, JSON.stringify({ state: s, undo: [] }));
}
console.log(JSON.stringify(out.map(o => ({ ...o, perTurn: Object.entries(o.perTurn).map(([t, v]) => `${t}:${v.prompts}/${v.info}i`).join(' ') })), null, 1));
