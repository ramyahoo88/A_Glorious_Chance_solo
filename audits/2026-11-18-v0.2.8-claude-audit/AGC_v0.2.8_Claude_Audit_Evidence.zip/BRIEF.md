# Audit brief — A Glorious Chance Solo Companion v0.2.8 (shared by all audit agents)

You are one of several auditors working in parallel on an independent rules-and-release audit of a
single-file offline HTML app that runs the two solitaire campaigns of the board game
"A Glorious Chance: The Naval Struggle for Lake Ontario in the War of 1812" (Legion Wargames).
The human plays one side; the app runs the A.I. side, all decks, dice and bookkeeping.

## What you are reviewing (do NOT modify)
- Repository: /home/claude/a_glorious_chance_solo — release v0.2.8, commit ffd7317 (main is 67f161f; the only
  later commit adds audit documents). Treat it as READ-ONLY: never edit, build into, commit or push it.
- Sources: src/*.js (engine: state.js, data.js, data_aids.js, data_targets.js, rng.js, engine_core.js,
  engine_turn.js, engine_deploy.js, engine_encounter.js, engine_combat.js, engine_coastal.js, engine_tally.js,
  assign.js; UI: ui.js, main.js, style.css). Shipped app: dist/index.html.
- Project rulings and agreed variants: RULES_NOTES.md (notes 1–73). These are the project's decisions; do not
  re-report them as defects. You MAY flag a note that contradicts printed rules, labelled "ambiguous ruling".
- History of earlier fixes: CHANGELOG.md. Earlier audits: audits/*/ (PDF + evidence zip + response .md).

## Rules sources (the materials players receive) — establish expected behaviour from THESE first
- British Solo Living Rulebook 7 Aug 2024: /mnt/user-data/uploads/2165698c-AGC_Living_Rulebook_British_Solo_as_of_7aug2024.pdf (46 pp)
- U.S. Solo Living Rulebook 13 Apr 2024: /mnt/user-data/uploads/26b1f655-AGC_Living_Rulebook_US_Solo_as_of_13apr2024.pdf (46 pp)
- Living Playbook 6 Aug 2024: /mnt/user-data/uploads/674b20b7-AGC_Living_Playbook_as_of_6Aug2024.pdf (20 pp)
- Errata & clarifications rev 13 Apr 2024: /mnt/user-data/uploads/57ec412a-AGC_errata_and_clarifications_rev_13Apr2024.pdf
- Player-aid photographs (Aids V/VI/VII etc.): /mnt/user-data/uploads/052f2cf1-image.jpg, /mnt/user-data/uploads/8cc6ba15-image.jpg
- VASSAL v1.0 component images (cards, counters, maps, mats): /home/claude/agc/vmod/images/ (443 files; e.g.
  _0005_Tactic-A05.jpg). Extracted crops: /home/claude/agc/work/ (crt.png, events_*.png, aids/, etc.).
- Plain-text extractions (handy for grep, but CHECK LAYOUT on rendered pages whenever a table, column or
  diagram decides priority/timing): /home/claude/agc/src_text/{br_raw,us_raw,pb_raw}.txt
- Render pages to read layout: `pdftoppm -r 110 -f N -l N -png FILE /tmp/x` then view the PNG with the Read tool.
  Two-column pages: read both columns; tables: read every printed column/row, footnotes and outcome boxes.

## How to run the engine (the shipped logic, without a browser)
    const H = require('/home/claude/audit028/harness.js')();   // engine + ui.js in a vm context
    H.X(`var s = newGame('US', 12345); run(s); s.prompt`)      // every app function/const is a global in there
- Helpers inside the context: fresh(side, seed), stageCombat(s, zone, usIds, brIds, att), waitAt(s, proc, pc, A, L),
  afterCombatCaller(s), playUntil(s, stopFn). See tests/regression.js for ~150 worked examples of focused
  positions (forces, encounters, combat frames, tally/reset positions) and how to drive prompts with act(s, answer).
- Prompt kinds: info (answer 'ok'), choice (answer an option id), select (array of ids), lineup ({attackers, tows}),
  assign (see assign.js validateAssignment). validateAnswer(s, s.prompt, answer) tells you if an answer is legal.
- Seeded and deterministic: s.rng is the dice state; saving JSON.stringify(s) and reloading reproduces play exactly.
- A deterministic visible-information play policy is in /home/claude/audit028/policy_campaigns.js
  (exports policy(s, prompt, style) for style 'fleet' or 'coast'; it requires argv[2] = repo path when run).
- Repo tests: `cd /home/claude/a_glorious_chance_solo && npm test` (read-only; fine to run).

## What to produce
Work in your own folder /home/claude/audit028/agents/<your-area>/ (create it). For every CONFIRMED finding:
1. Title and priority (Blocker / High / Medium / Low), and whether it is a defect, an "ambiguous ruling"
   (rules unclear — state the question and both readings), or an "optional usability improvement".
2. Player impact (what goes wrong at the table/score).
3. Rule section / page / card (or design goal) giving the EXPECTED behaviour — derived independently from the
   printed source before reading the code's behaviour.
4. Exact reproduction: seed and board position, an importable save (write `{state, undo: []}` JSON — the app's
   Load accepts it), or a runnable node assertion script in your folder; include the dice results that matter.
5. Observed result.
6. Source file and line(s).
7. Smallest proposed fix.
VERIFY each finding by running it; discard anything you cannot reproduce. Do not report something a RULES_NOTES
note already decides (unless you label it an ambiguous ruling with the printed text that conflicts).
Also record what you checked that PASSED (briefly — areas, counts of cases, nearby cases), so coverage is clear.
Write everything to /home/claude/audit028/agents/<your-area>/findings.md (plus scripts/saves next to it).
Your final message must be a concise summary: each confirmed finding (one paragraph: title, priority, impact,
rule, repro file, file:line, fix), the coverage you checked, and any gaps. Do not edit the repository.
