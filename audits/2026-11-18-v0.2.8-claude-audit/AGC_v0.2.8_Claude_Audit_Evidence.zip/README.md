# Evidence for "A Glorious Chance Solo Companion — audit of v0.2.8"

Paths: scripts expect the repository at `/home/claude/a_glorious_chance_solo` and this folder at `/home/claude/audit028` (`harness.js`, `policy_campaigns.js`). Edit those two paths to run elsewhere. Saves are `{state, undo: []}` JSON. Load them in the app (Load → choose file, or paste) or with `checkSaveState` in the harness.

| Finding | Files |
|---|---|
| Release (§2) | `release/sha256.txt`, `release/remote-refs.txt` |
| M1 Missed Signal in A.I. decision | `agents/B_encounter_combat/saves/F1a_*.json`, `F1b_*.json`; `repro_findings.js` |
| M2 Round-2 untowed schooners | `agents/B_encounter_combat/saves/F2_natural_*.json`; `repro_findings.js` |
| M3 A.I. Pursuit vs your optional withdrawal | `agents/B_encounter_combat/saves/F3_*.json`; `repro_findings.js` |
| M4 OA1 Naval Balance | `agents/A_prep_lake_deploy/F01_oa1_naval_balance.js`, `F01_oa1_seed3_B1.json`, `scripts/oa1_scan.js` |
| M5 keyboard | `agents/D_ui_qol/scripts/repro_D1_keyboard.py`, `kbd_checks*.py`, `shots/K02_*` |
| M6 start screen overwrite | `agents/D_ui_qol/scripts/persist_checks.py`, `shots/P01_*` |
| M7 Adjust lake ship | `agents/D_ui_qol/saves/D5_*.json`, `scripts/adjust_lake.py`, `shots/ADJ4_*` |
| L1 Upgrade without deployment | `agents/A_prep_lake_deploy/F02_upgrade_without_deployment.js`, `F02_beresford_A26*.json` |
| L2 PE marker choice | `agents/A_prep_lake_deploy/F03_pe_distribution_choice.js`, `F03_three_forces_B1.json` |
| L3 Requisition | `agents/C_coastal_tally/assert_F1_requisition.js`, `R1_*.json`, `scripts/requisition_reduced.js` |
| L4 Flag transfer after Close Action | `agents/B_encounter_combat/saves/F4_*.json` |
| L5 A.I. preview with untowed | `agents/B_encounter_combat/saves/F5_*.json` |
| L6 Missed Signal left out | `agents/B_encounter_combat/saves/F6_*.json` |
| L7 Rainy Squalls preview | `agents/D_ui_qol/saves/Q_rainy_squalls_*.json` |
| L8 Land Battle text | `agents/D_ui_qol/saves/LB_manual_more_defenders.json`, `agents/C_coastal_tally/assert_F3_F4_text.js`, `shots/LB1_*` |
| L9 Empty Harbor Encounter | `agents/C_coastal_tally/assert_F3_F4_text.js` |
| L10 Phone scroll | `agents/D_ui_qol/scripts/scroll_repro.py`, `shots/SC1_*`, `SC2_*`, `runs/US280004_390.json` |
| L11 Keyboard reach | `agents/D_ui_qol/runs/kbd_reach.json`, `scripts/kbd_reach.py` |
| L12 Adjust VP | `agents/D_ui_qol/saves/ADJ_US280004_decision120.json`, `shots/ADJ2_*` |
| L13 A7 Troops box | `agents/D_ui_qol/saves/D7_*.json`, `shots/S02_*` |
| L14 Package Auto-fill | `agents/D_ui_qol/saves/PK_manual_package_prompt.json`, `scripts/pkg_repro.py`, `runs/pkg_repro.json`, `shots/PK1_*` |
| L15 Log 400 | `agents/D_ui_qol/runs/BR280009_fleet_1300_final_state.json`, `scripts/log_checks.py` |
| L16 Dialog layout | `agents/D_ui_qol/shots/DLG_*`, `A_US_dialog_*` |
| Q-B Harbor zone events | `agents/C_coastal_tally/scripts/harbor_zone_events.js`, `out_harbor_zone_events.txt` |
| Q-C / Q-E | `agents/B_encounter_combat/check_ambiguous.js` |
| Quality of life (§6) | `engine/qol_count.js` + `qol_count_out.json`; `engine/confirm_same.js` + `confirm_same_out.json`; `agents/D_ui_qol/runs/*` (`per_turn`), `scripts/bookkeeping.js`, `scripts/info_titles.js`, `scripts/a11y_checks.py`, `scripts/quota.py` |
| Representative games (§7) | `engine/trace.js`, `trace_out.json`, `final_*.json` |
| Passed checks (§7) | Target cards and grids: `agents/A_prep_lake_deploy/` (`*_tests.js`, `scripts/agrid.py`, `bgrid.py`, `headers.py`, `sim_invariants.js`, `trace_*.txt`). Combat tables, cards and sweeps: `agents/B_encounter_combat/` (`check_tables.js`, `check_tactics.js`, `sweep.js`, `logcheck.js`). Aid VII and oracles: `agents/C_coastal_tally/scripts/` + `out_*.txt`. Browser campaigns: `agents/D_ui_qol/runs/`, `scripts/play_campaign.py`, `replay.js` |
