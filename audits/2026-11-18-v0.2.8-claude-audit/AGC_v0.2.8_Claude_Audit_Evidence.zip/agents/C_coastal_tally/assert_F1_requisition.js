// F1 assertion: loads R1_requisition_reduced_at_Tally.json through the app's own save check, plays on with the
// default (primary) answers, and asserts the printed-rules expectation. Exits 1 while the defect is present.
const fs = require('fs'), path = require('path'), assert = require('assert');
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
H.ctx.__raw = fs.readFileSync(path.join(__dirname, 'R1_requisition_reduced_at_Tally.json'), 'utf8');
X(`var s = checkSaveState(JSON.parse(__raw).state);
   function step(s){ var p = s.prompt; act(s, p.kind==='info'?'ok':p.kind==='choice'?(p.options.find(o=>o.primary)||p.options[0]).id:p.kind==='select'?(p.initial||[]):p.kind==='lineup'?{attackers:p.candidates,tows:p.defaultTows||{}}:{forces:[],flagship:p.flagship}); }
   var g = 0; while (s.prompt && !(s.turn === 4 && s.prompt.kind === 'assign') && g++ < 400) step(s);
   var r = { turn: TURN_NAMES[s.turn], beres: [s.ships.beres.box, s.ships.beres.steps, isFull(s.ships.beres)], assignable: assignableShips(s,'BR').map(sh=>sh.id) };`);
const r = JSON.parse(X('JSON.stringify(r)'));
console.log(JSON.stringify(r));
try {
  assert.strictEqual(r.turn, 'August I');
  assert.ok(!(r.beres[0] === 'deployable' && !r.beres[2]), 'Lord Beresford is back from requisition in the Deployable area while still Reduced (should come back through In Transit / Repairing)');
  console.log('PASS'); process.exit(0);
} catch (e) { console.log('FAIL:', e.message); process.exit(1); }
