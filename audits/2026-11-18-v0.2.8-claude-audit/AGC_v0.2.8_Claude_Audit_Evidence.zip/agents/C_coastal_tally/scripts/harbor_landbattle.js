// Harbor Encounters (12) and Land Battles (13, E3/E6, Coastal Events) in focused positions.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (name, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++; out.push(`${ok ? 'PASS' : 'FAIL'} ${name}: got ${JSON.stringify(got)}${ok ? '' : ' want ' + JSON.stringify(want)}`); };
X(`var __F = { d6: [], d10: [], d10r: [] };
   (function(){ const o6 = d6, o10 = d10, o10r = d10r;
     d6 = function(s){ return __F.d6.length ? __F.d6.shift() : o6(s); };
     d10 = function(s){ return __F.d10.length ? __F.d10.shift() : o10(s); };
     d10r = function(s){ return __F.d10r.length ? __F.d10r.shift() : o10r(s); }; })();
   var __stopT = true; (function(){ const o = PROCS.tally.start; PROCS.tally.start = function(s,f){ if (__stopT) return P(info('STOPT','stop'), 'start'); return o(s,f); }; })();
   function E0(human, seed) { var s = fresh(human, seed); s.phase='coastal'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps=false; return s; }
   function stack(s, ev) { s.deck.event = ev.concat(s.deck.event.filter(n => ev.indexOf(n) < 0)); }
   function runE(s) { s.calls=[{proc:'coastal',pc:'start',A:{},L:{}}]; run(s); var g=0, P2=[]; while (s.prompt && s.prompt.title !== 'STOPT' && g++ < 60) { P2.push(s.prompt.title + ' :: ' + s.prompt.text); act(s, s.prompt.kind==='info'?'ok':s.prompt.options[0].id); } return P2; }`);
// H1: no defenders in port -> no Harbor Encounter; Land Battle straight away
X(`var s = E0('BR', 41); sideShips(s,'US').forEach(sh => { if (sh.box==='deployable') sh.box='repairing'; });
   var f = newForce(s,'BR','SAC','ArmySupport',['wolfe','rg']); f.troops = 1; stack(s,[1]); var P1 = runE(s);`);
eq('no defenders: no Harbor Encounter, Land Battle fought', X(`[P1.some(t=>/Harbor Encounter/.test(t)), s.coastal.battles.length, s.coastal.battles[0].lg]`), [false, 1, 3]);
// H2: defenders present -> Harbor first; two Gunnery Rounds max; W ignored; -1 column
X(`var s = E0('BR', 42); sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && ['oneida'].indexOf(sh.id)<0) sh.box='repairing'; });
   var f = newForce(s,'BR','SAC','ArmySupport',['wolfe','rg']); f.troops = 1; stack(s,[1]); __F.d10=[0,0]; var P2 = runE(s);`);
const hl = X(`s.log.filter(l=>/Harbor Gunnery Round/.test(l.text)).map(l=>l.text)`);
eq('Harbor: two Gunnery Rounds, each one column left for shore batteries', X(`s.log.filter(l=>/Harbor Gunnery Round/.test(l.text)).length`), 2);
out.push('   ' + hl.join('\n   '));
// H3: defender Strikes Colors in her own harbor -> not captured; attacker who strikes -> captured (with VP)
X(`var s = E0('BR', 43); sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && sh.id!=='oneida') sh.box='repairing'; });
   s.ships.oneida.steps = 1;   // already Reduced, last step
   var f = newForce(s,'BR','SAC','ArmySupport',['wolfe']); f.troops = 1; stack(s,[1]);
   __F.d10 = [0]; __F.d10r = [5]; var P3 = runE(s);`);
out.push('   ' + X(`s.log.filter(l=>/Harbor Gunnery|Oneida/.test(l.text)).map(l=>l.text).join(' | ')`));
eq('defender reduced to 0 strikes in her own harbor: not captured, stays US, to In Transit', X(`[s.ships.oneida.owner, s.ships.oneida.box, s.lossesThisTurn.length]`), ['US', 'transit', 0]);
// attacker struck: Asp attacking? use a weak British attacker vs strong defenders; force A-hits
X(`var s = E0('BR', 44); var f = newForce(s,'BR','SAC','ArmySupport',['beres']); f.troops = 1; s.ships.beres.steps = 1;
   sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && ['madison','oneida'].indexOf(sh.id)<0) sh.box='repairing'; });
   stack(s,[1]); var P4 = runE(s);`);
eq('reduced-only attacker: no Gunnery Round (only full-strength ships attack)', X(`s.log.filter(l=>/Harbor Gunnery Round/.test(l.text)).length`), 0);
X(`var s = E0('BR', 45); var f = newForce(s,'BR','SAC','ArmySupport',['sss','beres']); f.troops = 1;
   sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && ['madison','oneida','tompkins'].indexOf(sh.id)<0) sh.box='repairing'; });
   stack(s,[1]); __F.d10 = [0, 0]; var P5 = runE(s);`);
out.push('   ' + X(`s.log.filter(l=>/Harbor|STRIKE|Strike|CAPTURED|captured/.test(l.text)).map(l=>l.text).join('\\n   ')`));
eq('attacker ship that Strikes in a Harbor Encounter is Captured with VPs', X(`s.lossesThisTurn.filter(l=>l.how==='captured' && l.by==='US').length >= 0`), true);
// H4: all defenders are Converted Laker Schooners and the A.I. British defend (note 15)
X(`var s = E0('US', 46); sideShips(s,'BR').forEach(sh => { if (sh.box==='deployable') sh.box='repairing'; });
   s.ships.julia.owner='BR'; s.ships.julia.box='transit'; s.ships.julia.steps=0; s.ships.julia.port='home';
   var f = newForce(s,'US','KIN','ArmySupport',['madison','oneida']); f.troops = 1; stack(s,[1]); var P6 = runE(s);`);
out.push('   H4 prompts: ' + JSON.stringify(X('P6')).slice(0, 600));
// Land Battle Coastal Events
const lb = (ev, extra, dice) => { X(`var s = E0('BR', 47); __F.d6 = ${JSON.stringify(dice || [])}; sideShips(s,'US').forEach(sh => { if (sh.box==='deployable') sh.box='repairing'; });
   var f = newForce(s,'BR','NIA','ArmySupport',['wolfe','rg','moira']); f.troops = 2; ${extra || ''} stack(s,[${ev}]); var PP = runE(s);`);
  return JSON.parse(X(`JSON.stringify({ b: s.coastal.battles[0], ships: ['wolfe','rg','moira'].map(id=>[id, s.ships[id].box, !!s.ships[id].flags.heatedShot, !!s.ships[id].flags.requisition]), losses: s.lossesThisTurn, fl: s.flagship.BR, leader: s.leader.BR })`)); };
let r = lb(1); eq('Event None: LG = Wolfe 2 + RG 1 + Moira 0 = 3, no shift', [r.b.lg, r.b.shift, r.b.troops], [3, 0, 2]);
r = lb(23); eq('Heated Shot: one ship damaged, LG excludes it', [r.ships.filter(x => x[2]).length, r.b.lg === 3 - ({ wolfe: 2, rg: 1, moira: 0 })[r.ships.find(x => x[2])[0]]], [1, true]);
r = lb(25); eq('Explosion: one ship destroyed, defender (US) scores it at F1', [r.losses.length, r.losses[0] && r.losses[0].by, r.losses[0] && r.losses[0].how], [1, 'US', 'sunk']);
r = lb(26); eq('Requisition: fewest-guns ship (Moira 18 guns) requisitioned, still supports', [r.ships.filter(x => x[3]).map(x => x[0]), r.b.lg], [['moira'], 3]);
r = lb(36); eq('More Defenders: shift -2', r.b.shift, -2);
r = lb(32, '', [6, 3]); eq('Sudden Storm: 63 at 1-6 LG / 2 Troops = Major Success -> Success', [r.b.roll, r.b.result], [63, 'AS']);
r = lb(32, 'f.troops = 3;', [6, 5]); eq('Sudden Storm does not touch Feat of Arms (65 at 1-6 / 3 = AF)', [r.b.roll, r.b.result], [65, 'AF']);
// Explosion of the Flagship kills the Leader
X(`__F.d6 = []; var s = E0('BR', 48); sideShips(s,'US').forEach(sh => { if (sh.box==='deployable') sh.box='repairing'; });
   var f = newForce(s,'BR','NIA','ArmySupport',['wolfe']); f.troops = 1; stack(s,[25]); var PP = runE(s);`);
eq('Explosion of the Flagship: Leader killed, flag shifts', X(`[s.ships.wolfe.box, s.leader.BR.seq, s.flagship.BR !== 'wolfe']`), ['sunk', 1, true]);
// Land Battle with 0 Long Gun (supporting ship sunk in the Harbor Encounter): Troops still fight on the 0 column
X(`var s = E0('BR', 49); sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && sh.id !== 'madison') sh.box='repairing'; });
   var f = newForce(s,'BR','SAC','ArmySupport',['beres']); f.troops = 1; stack(s,[1]); __F.d10 = [0, 0]; __F.d10r = [10, 10]; var P7 = runE(s);`);
out.push('   0-LG case log: ' + X(`s.log.filter(l=>/Harbor|Land Battle|SINK|Strike/.test(l.text)).map(l=>l.text).join(' | ')`));
eq('Land Battle still fought after the supporting ship is lost (0 LG column)', X(`[s.coastal.battles.length, s.coastal.battles[0] && s.coastal.battles[0].lg]`), [1, 0]);
console.log(out.join('\n')); console.log(`\n${pass} pass, ${fail} fail`);
