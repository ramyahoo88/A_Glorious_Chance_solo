// Independent F-phase oracle (F1-F6 + 14.2) computed from the printed rules, compared with the engine's
// tally.start on positions reached by policy play. Dice that the engine rolls in F3.1/F4/F5.3 are read back
// from its own Tally lines; everything else is recomputed here from the pre-Tally state.
// usage: node tally_oracle.js [seeds=40] [startSeed=500000]
process.argv[2] = process.argv[2] && /^\d+$/.test(process.argv[2]) ? process.argv[2] : process.argv[2];
const REPO = '/home/claude/a_glorious_chance_solo';
const nSeeds = +(process.argv[2] || 40), start = +(process.argv[3] || 500000);
const savedArgv = process.argv.slice(); process.argv[2] = REPO;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
process.argv = savedArgv;
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, ctx = H.ctx;
X(`var __pre = []; (function(){ const o = PROCS.tally.start; PROCS.tally.start = function(s, f){ __pre.push(JSON.stringify(s)); return o(s, f); }; })();`);
// --- printed data (map VP summary, main-ship stars, steps from counters) ---
const VP = { wolfe: [16, 32], rg: [14, 28], moira: [7, 14], melville: [6, 12], beres: [5, 10], sss: [5, 10], pike: [20, 40], madison: [16, 32], sylph: [14, 28], oneida: [7, 14], tompkins: [4, 8], fairam: [4, 8], conquest: [4, 8] };
const vpOf = id => VP[id] || [2, 4];
const MAIN = new Set(['wolfe', 'rg', 'moira', 'melville', 'beres', 'sss', 'pike', 'madison', 'sylph', 'oneida', 'tompkins', 'fairam', 'conquest']);
const fullSteps = sh => ctx.SHIP_BY_ID === undefined ? X(`SHIP_BY_ID['${sh.id + (sh.ver || '')}'].full[4]`) : null;
const STEPS = {}; JSON.parse(X(`JSON.stringify(SHIP_DEFS.map(d=>[d.id,d.full[4]]))`)).forEach(([k, v]) => { STEPS[k] = v; });
const full = sh => sh.steps >= STEPS[sh.id + (sh.ver || '')];
const ZONES = ['YOR', 'NOR', 'KIN', 'NIA', 'SOU', 'SAC'], HOME = { US: 'SAC', BR: 'KIN' }, TEMP = { US: 'SOU', BR: 'YOR' }, OTH = { US: 'BR', BR: 'US' };
const RAIDVP = { KIN: 2, YOR: 1, SAC: 2, SOU: 1 };
const LBV = { AF: 3, AM: 2, AS: 1, DR: 0, DS: -1, DM: -2 };
function oracle(S, lines) {
  const vp = { US: 0, BR: 0 }, sup = Object.assign({}, S.supply), cd = Object.assign({}, S.cd);
  const add = (side, n) => { vp[side] += n; };
  const mv = (side, n) => { if (sup[side] >= 12) return; sup[side] = Math.max(-1, Math.min(12, sup[side] + n)); };
  const ships = Object.entries(S.ships).map(([k, v]) => Object.assign({ key: k }, v));
  const inZone = (z, side) => ships.filter(sh => sh.box === 'lake' && sh.zone === z && sh.owner === side);
  // F1
  S.lossesThisTurn.forEach(L => { if (L.by) add(L.by, L.how === 'sunk' ? vpOf(L.id)[0] : vpOf(L.id)[1]); });
  S.coastal.cutouts.filter(c => c.result === 'repulsed').forEach(c => add(OTH[c.side], 1));
  // F2.1 / F2.2
  const ctl = {}, blk = {}; ZONES.forEach(z => { ctl[z] = S.zones[z].control; blk[z] = S.zones[z].blockade; });
  ZONES.forEach(z => {
    const fu = inZone(z, 'US').filter(full), fb = inZone(z, 'BR').filter(full);
    if (fu.length && fb.length) ctl[z] = null;
    [['US', fu, fb], ['BR', fb, fu]].forEach(([sd, m, t]) => { if (m.reduce((a, sh) => a + sh.steps, 0) >= 5 && !t.length) ctl[z] = sd; });
  });
  const cond = (bl, z) => ctl[z] === bl && inZone(z, bl).filter(sh => full(sh) && MAIN.has(sh.id)).length >= 4 && !inZone(z, OTH[bl]).length;
  ZONES.forEach(z => { if (blk[z] && !cond(blk[z], z)) blk[z] = null; });                         // F2.3
  ['US', 'BR'].forEach(sd => { if (blk[HOME[sd]] === OTH[sd] || blk[TEMP[sd]] === OTH[sd]) ZONES.forEach(z => { if (ctl[z] === sd) ctl[z] = null; }); }); // F2.4 / 14.1.3
  ZONES.forEach(z => { if (ctl[z]) add(ctl[z], 1); });                                          // F2.5
  // F3.1 Shipyard
  const yardLines = lines.filter(l => /^F3\.1:/.test(l));
  let yi = 0; let niag = S.niagara;
  S.coastal.battles.forEach(b => {
    if (b.target === 'HOME' && (b.result === 'AM' || b.result === 'AF')) {
      const m = /2d6 (\d+)(\+2)? = (\d+)/.exec(yardLines[yi++] || ''); if (!m) throw new Error('no shipyard line');
      const t = +m[1] + (b.result === 'AF' ? 2 : 0); if (t !== +m[3]) throw new Error('shipyard DRM mismatch ' + m[0]);
      const vic = OTH[b.side];
      const cons = ships.filter(sh => sh.owner === vic && sh.box === 'construction').sort((a, c) => vpOf(c.id)[1] - vpOf(a.id)[1]);
      const row = t <= 4 ? [1] : t === 5 ? [1] : t <= 7 ? [1] : t <= 9 ? [2] : t <= 11 ? [2, 'one'] : [3, 'all'];
      cd[vic] += row[0];
      if (row[1] === 'one' && cons.length) add(b.side, vpOf(cons[0].id)[0]);
      if (row[1] === 'all') cons.forEach(sh => add(b.side, vpOf(sh.id)[0]));
    }
    if (b.target === 'NIA') niag = Math.max(0, Math.min(6, niag + (b.side === 'BR' ? 1 : -1) * LBV[b.result]));
  });
  if (S.turn === 7) {
    if (niag === 6 && ctl.NIA === 'BR' && blk.KIN !== 'US') add('BR', 10);
    if (niag === 0 && ctl.NIA !== 'BR') add('US', 10);
  }
  if (S.troops[S.human].available > 0) add(S.human, -S.troops[S.human].available);                    // F3.3
  // F4
  const milLines = lines.filter(l => /^F4: Local Militia/.test(l)); let mi = 0;
  const raidOK = [];
  S.coastal.raids.forEach(r => {
    let v = RAIDVP[r.zone], ok = true;
    if (r.events.includes('localMilitia')) { const d = +/1d6 (\d+)/.exec(milLines[mi++])[1]; if (d > r.guns) { v = 0; ok = false; } }
    if (r.events.includes('suppliesMoved')) { v = 0; ok = false; }
    if (r.events.includes('suddenStorm')) { v = RAIDVP[r.zone] === 2 ? 1 : 0; ok = false; }
    add(r.side, v); raidOK.push(ok);
  });
  // F5.1/F5.2
  [S.ai, S.human].forEach(sd => {
    const b = blk[HOME[sd]] === OTH[sd];
    S.pendingConvoy[sd].forEach(p => { if (p.status === 'arrived' && !b) mv(sd, 2); });
    const c = S.convoys[sd][S.turn];
    if (!c || !c.real) return;
    if (c.result === 'C') { mv(OTH[sd], 1); return; }
    if (c.result === 'D' || c.result === 'S' || b || c.delay) return;
    mv(sd, 2);
  });
  // F5.3
  S.coastal.battles.forEach(b => { if (b.target === 'HOME' && ['AS', 'AM', 'AF'].includes(b.result)) mv(OTH[b.side], -2); });
  const supLines = lines.filter(l => /^F5\.3: Raid on/.test(l)); let si = 0;
  S.coastal.raids.forEach((r, i) => {
    if (!raidOK[i]) return;
    const d = +/1d6 (\d+)/.exec(supLines[si++])[1];
    if (d >= (r.events.includes('suppliesBurned') ? 6 : 5)) { mv(r.side, 1); mv(OTH[r.side], -1); }
  });
  let fo = S.fallOffensive;
  if (!fo) { const u = sup.US >= 12, b = sup.BR >= 12; if (u && b) fo = 'both'; else if (u || b) { fo = u ? 'US' : 'BR'; add(fo, 5); } }
  // F6
  const usingTemp = sd => ships.some(sh => sh.owner === sd && sh.isolated && sh.box !== 'sunk' && sh.box !== 'outOfPlay');
  ['US', 'BR'].forEach(bl => { const v = OTH[bl]; [HOME[v]].concat(usingTemp(v) ? [TEMP[v]] : []).forEach(z => { if (blk[z] !== bl && cond(bl, z)) blk[z] = bl; }); });
  return { vp, sup, cd, niag, ctl, blk, fo };
}
let tallies = 0, mism = [], stats = { battles: 0, home: 0, nia: 0, raids: 0, militia: 0, storm: 0, moved: 0, burned: 0, yard: 0, loss: 0, cut: 0, fo: 0, blkPlaced: 0, blkRemoved: 0, convoyS: 0, convoyD: 0, convoyC: 0, pend: 0, turn7: 0, troopPen: 0, supMin: 0, sup12: 0 };
const games = [];
for (let i = 0; i < nSeeds; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const seed = start + i;
  X(`var s = newGame('${side}', ${seed}, {cuttingOut: ${i % 2 === 0}, oa1Upgrades: ${i % 4 === 0}}); run(s); __pre = [];`);
  let n = 0;
  while (!X('s.over') && n < 2000) {
    const s = ctx.s, p = s.prompt;
    const a = policy(s, p, style);
    X(`act(s, ${JSON.stringify(JSON.stringify(a))} && JSON.parse(${JSON.stringify(JSON.stringify(a))}))`);
    n++;
    const pres = X('__pre.length');
    if (pres) {
      const pre = JSON.parse(X('__pre[0]')); X('__pre = []');
      const T = ctx.s, lines = (T.prompt && /^Tally/.test(T.prompt.title)) ? T.prompt.text.split('\n') : [];
      const o = oracle(pre, lines);
      tallies++;
      const got = { vp: { US: T.vp.US - pre.vp.US, BR: T.vp.BR - pre.vp.BR }, sup: T.supply, cd: T.cd, niag: T.niagara, fo: T.fallOffensive };
      const ctlG = {}, blkG = {}; ZONES.forEach(z => { ctlG[z] = T.zones[z].control; blkG[z] = T.zones[z].blockade; });
      const diffs = [];
      if (JSON.stringify(got.vp) !== JSON.stringify(o.vp)) diffs.push(['vp', got.vp, o.vp]);
      if (JSON.stringify(got.sup) !== JSON.stringify(o.sup)) diffs.push(['supply', got.sup, o.sup]);
      if (JSON.stringify(got.cd) !== JSON.stringify(o.cd)) diffs.push(['cd', got.cd, o.cd]);
      if (got.niag !== o.niag) diffs.push(['niagara', got.niag, o.niag]);
      if ((got.fo || null) !== (o.fo || null)) diffs.push(['fallOffensive', got.fo, o.fo]);
      if (JSON.stringify(ctlG) !== JSON.stringify(o.ctl)) diffs.push(['control', ctlG, o.ctl]);
      if (JSON.stringify(blkG) !== JSON.stringify(o.blk)) diffs.push(['blockade', blkG, o.blk]);
      if (diffs.length) mism.push({ side, seed, style, turn: pre.turn, diffs });
      // coverage
      stats.battles += pre.coastal.battles.length; stats.home += pre.coastal.battles.filter(b => b.target === 'HOME').length; stats.nia += pre.coastal.battles.filter(b => b.target === 'NIA').length;
      stats.raids += pre.coastal.raids.length; pre.coastal.raids.forEach(r => { if (r.events.includes('localMilitia')) stats.militia++; if (r.events.includes('suddenStorm')) stats.storm++; if (r.events.includes('suppliesMoved')) stats.moved++; if (r.events.includes('suppliesBurned')) stats.burned++; });
      stats.yard += lines.filter(l => /^F3\.1/.test(l)).length; stats.loss += pre.lossesThisTurn.filter(l => l.by).length; stats.cut += pre.coastal.cutouts.length;
      if (!pre.fallOffensive && T.fallOffensive) stats.fo++;
      ZONES.forEach(z => { if (!pre.zones[z].blockade && T.zones[z].blockade) stats.blkPlaced++; if (pre.zones[z].blockade && !T.zones[z].blockade) stats.blkRemoved++; });
      ['US', 'BR'].forEach(sd => { const c = pre.convoys[sd][pre.turn]; if (c && c.result === 'S') stats.convoyS++; if (c && c.result === 'D') stats.convoyD++; if (c && c.result === 'C') stats.convoyC++; stats.pend += pre.pendingConvoy[sd].filter(p => p.status === 'arrived').length; if (T.supply[sd] === -1) stats.supMin++; if (T.supply[sd] === 12) stats.sup12++; });
      if (pre.turn === 7) stats.turn7++; if (pre.troops[pre.human].available > 0) stats.troopPen++;
    }
  }
  games.push({ side, seed, style, over: X('s.over'), turn: X('s.turn'), score: X('s.result && s.result.score'), level: X('s.result && s.result.level') });
}
console.log(JSON.stringify({ games: games.length, unfinished: games.filter(g => !g.over).length, tallies, mismatches: mism.length, stats }, null, 1));
if (mism.length) console.log(JSON.stringify(mism.slice(0, 10), null, 1));
