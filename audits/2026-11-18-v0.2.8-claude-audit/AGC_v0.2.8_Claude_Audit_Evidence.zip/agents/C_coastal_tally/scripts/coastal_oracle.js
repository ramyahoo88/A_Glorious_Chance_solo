// Coastal Action oracle: hooks the engine's Raid and Land Battle steps during policy play and checks each
// against the printed procedure (E2/E5, E3/E6, 12, 13, Player Aid VII, Coastal Event cards 20-38).
const REPO = '/home/claude/a_glorious_chance_solo';
const nSeeds = +(process.argv[2] || 40), start = +(process.argv[3] || 600000);
const savedArgv = process.argv.slice(); process.argv[2] = REPO;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
process.argv = savedArgv;
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, ctx = H.ctx;
X(`var __ev = [];
(function(){
  const oB = PROCS.coastal.asBattle, oR = PROCS.coastal.raid, oZ = PROCS.coastal.asZone, oS = PROCS.coastal.side;
  PROCS.coastal.side = function(s, f){ const r = oS(s, f); const side = f.L.order[f.L.si];
    if (side) __ev.push({ k: 'side', side, forces: Object.values(s.forces).filter(fr => fr.side === side).map(fr => ({ id: fr.id, mission: fr.mission, zone: fr.zone, troops: fr.troops, ended: fr.ended, ships: fr.ships.map(id => ({ id, steps: s.ships[id].steps, full: isFull(s.ships[id]), lg: lg(s.ships[id]), guns: guns(s.ships[id]) })) })) });
    return r; };
  PROCS.coastal.asZone = function(s, f){ const item = f.L.lz[0]; const pre = item ? { z: item.z, forces: item.forces.slice(), troops: item.forces.reduce((a, fid) => a + (s.forces[fid] ? s.forces[fid].troops : 0), 0),
      defenders: item ? sideShips(s, OTHER[f.L.side]).filter(sh => (sh.box === 'deployable' || sh.box === 'transit') && sh.port === homeportOfZone(s, OTHER[f.L.side], item.z)).map(sh => sh.id) : [] } : null;
    const r = oZ(s, f); if (pre) __ev.push(Object.assign({ k: 'launch', side: f.L.side, harbor: !!r.call }, pre)); return r; };
  PROCS.coastal.asBattle = function(s, f){ const item = f.L.cur;
    const before = item.forces.reduce((a, fid) => a.concat(s.forces[fid] ? s.forces[fid].ships : []), []).map(id => ({ id, steps: s.ships[id].steps, full: isFull(s.ships[id]), box: s.ships[id].box, lg: lg(s.ships[id]), guns: guns(s.ships[id]), flag: s.flagship[s.ships[id].owner] === id }));
    const r = oB(s, f); const lb = f.L.lb; const ev = EVENTS[lb.ev];
    __ev.push({ k: 'battle', side: f.L.side, zone: item.z, before, lb: JSON.parse(JSON.stringify(lb)), coastal: ev.coastal,
      after: before.map(b => ({ id: b.id, box: s.ships[b.id].box, heated: !!s.ships[b.id].flags.heatedShot, req: !!s.ships[b.id].flags.requisition })), auto: !s.options.manualLandBattle, answer: f.answer });
    return r; };
  PROCS.coastal.raid = function(s, f){ const fid = f.L.raids[0]; const fr = fid && s.forces[fid];
    const pre = fr ? { fid, zone: fr.zone, ships: fr.ships.map(id => ({ id, full: isFull(s.ships[id]), guns: guns(s.ships[id]) })) } : null; const n0 = s.coastal.raids.length;
    const r = oR(s, f); if (pre) { const ev = s.eventsDrawn[s.eventsDrawn.length - 1]; __ev.push(Object.assign({ k: 'raid', side: f.L.side, card: ev && ev.id, coastal: ev && EVENTS[ev.id].coastal, placed: s.coastal.raids.length > n0, rec: s.coastal.raids[s.coastal.raids.length - 1] }, pre)); }
    return r; };
})();`);
const AID = { '0/1': ['11-14', '15-23', '24-43', '44-65', '66', '-'], '0/2': ['11-13', '14-23', '24-41', '42-64', '65-66', '-'], '0/3': ['11-12', '13-21', '22-34', '35-63', '64-65', '66'],
  '1/1': ['11', '12-16', '21-34', '35-62', '63-66', '-'], '1/2': ['-', '11-14', '15-31', '32-61', '62-66', '-'], '1/3': ['-', '11-13', '14-26', '31-56', '61-64', '65-66'],
  '2/1': ['11', '12-13', '14-31', '32-55', '56-66', '-'], '2/2': ['-', '11-12', '13-26', '27-54', '55-66', '-'], '2/3': ['-', '11', '12-24', '25-53', '54-63', '64-66'],
  '3/1': ['11', '12', '13-24', '25-52', '53-66', '-'], '3/2': ['-', '11', '12-22', '23-51', '52-66', '-'], '3/3': ['-', '11', '12-21', '22-46', '51-62', '63-66'],
  '4/1': ['-', '11', '12-16', '21-44', '45-66', '-'], '4/2': ['-', '11', '12-15', '16-35', '36-66', '-'], '4/3': ['-', '11', '12-14', '15-33', '34-61', '62-66'] };
const ORD = ['DM', 'DS', 'DR', 'AS', 'AM', 'AF'];
const band = v => v <= 0 ? 0 : v <= 6 ? 1 : v <= 15 ? 2 : v <= 24 ? 3 : 4;
const aid = (lgv, t, sh, v) => { const b = Math.max(0, band(lgv) + sh), key = `${b}/${Math.min(3, t)}`; let r = null; AID[key].forEach((rg, i) => { if (rg === '-') return; const [lo, hi] = rg.split('-').map(Number); if (v >= lo && v <= (hi || lo)) r = ORD[i]; }); return r; };
const RAIDZ = { US: ['KIN', 'YOR'], BR: ['SAC', 'SOU'] };
let bad = [], st = { battles: 0, harbor: 0, harborSkippedNoDef: 0, ev: {}, raids: 0, raidPlaced: 0, raidNotPlaced: 0, lg0: 0, troops: {} };
for (let i = 0; i < nSeeds; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const seed = start + i;
  X(`var s = newGame('${side}', ${seed}, {cuttingOut: ${i % 2 === 0}}); run(s); __ev = [];`);
  let n = 0, pendingSide = null;
  while (!X('s.over') && n < 2000) {
    const a = policy(ctx.s, ctx.s.prompt, style);
    ctx.__a = a; X('act(s, __a)'); n++;
    const evs = JSON.parse(X('JSON.stringify(__ev)')); X('__ev = []');
    for (const e of evs) {
      if (e.k === 'side') { pendingSide = e; continue; }
      if (e.k === 'raid') {
        st.raids++; e.placed ? st.raidPlaced++ : st.raidNotPlaced++;
        const want = e.ships.some(x => x.full) && RAIDZ[e.side].includes(e.zone);
        if (want !== e.placed) bad.push({ seed, side, style, what: 'raid placement', e });
        if (e.placed) { const g = e.ships.reduce((a, x) => a + x.guns, 0); const evsWant = ['localMilitia', 'suppliesBurned', 'suppliesMoved', 'suddenStorm'].includes(e.coastal) ? [e.coastal] : [];
          if (e.rec.guns !== g || JSON.stringify(e.rec.events) !== JSON.stringify(evsWant)) bad.push({ seed, side, style, what: 'raid record', e }); }
      }
      if (e.k === 'launch') {
        if (e.defenders.length && !e.harbor) bad.push({ seed, side, style, what: 'harbor skipped with defenders', e });
        if (!e.defenders.length && e.harbor) bad.push({ seed, side, style, what: 'harbor with no defenders', e });
        if (e.harbor) st.harbor++; else if (e.z !== 'NIA') st.harborSkippedNoDef++;
        // which forces launch: Army Support, troops>0, >=1 full ship, zone NIA or enemy (temp) homeport zone
        const exp = pendingSide.forces.filter(f => f.mission === 'ArmySupport' && f.troops > 0 && f.zone === e.z && f.ships.some(x => x.full)).map(f => f.id).sort();
        if (JSON.stringify(exp) !== JSON.stringify(e.forces.slice().sort())) bad.push({ seed, side, style, what: 'launching forces', exp, e });
        const t = pendingSide.forces.filter(f => exp.includes(f.id)).reduce((a, f) => a + f.troops, 0);
        if (t !== e.troops) bad.push({ seed, side, style, what: 'troops launched', t, e });
        st.troops[t] = (st.troops[t] || 0) + 1;
      }
      if (e.k === 'battle') {
        st.battles++; st.ev[e.coastal] = (st.ev[e.coastal] || 0) + 1;
        const alive = e.after.filter(x => x.box === 'lake');
        const lgWant = e.before.filter(b => b.full && b.box === 'lake').filter(b => { const a = e.after.find(x => x.id === b.id); return a.box === 'lake' && !a.heated; }).reduce((a, b) => a + b.lg, 0);
        const shiftWant = e.coastal === 'moreDefenders' ? -2 : 0;
        const nHeated = e.after.filter(x => x.heated).length, nExpl = e.before.filter(b => b.box === 'lake').length - alive.length, nReq = e.after.filter(x => x.req).length;
        if (e.lb.lg !== lgWant) bad.push({ seed, side, style, what: 'Land Battle Long Gun', lgWant, e });
        if (e.lb.shift !== shiftWant || e.lb.storm !== (e.coastal === 'suddenStorm')) bad.push({ seed, side, style, what: 'shift/storm', e });
        if ((e.coastal === 'heatedShot') !== (nHeated === 1) && e.before.length) bad.push({ seed, side, style, what: 'heated shot', e });
        if ((e.coastal === 'explosion') !== (nExpl === 1) && e.before.length) bad.push({ seed, side, style, what: 'explosion', e });
        if (e.coastal === 'requisition' && nReq !== (e.before.some(b => b.box === 'lake') ? 1 : 0)) bad.push({ seed, side, style, what: 'requisition', e });
        if (e.coastal === 'requisition' && nReq === 1) { const g = Math.min(...e.before.filter(b => b.box === 'lake').map(b => b.guns)); const who = e.after.find(x => x.req); if (e.before.find(b => b.id === who.id).guns !== g) bad.push({ seed, side, style, what: 'requisition not fewest guns', e }); }
        if (e.lb.lg === 0) st.lg0++;
        if (e.auto) { const w0 = aid(e.lb.lg, e.lb.troops, e.lb.shift, e.lb.roll); const w = e.lb.storm && w0 === 'AM' ? 'AS' : w0; if (e.answer !== w0) bad.push({ seed, side, style, what: 'table lookup', w0, e }); }
        if (e.lb.target !== (e.zone === 'NIA' ? 'NIA' : 'HOME')) bad.push({ seed, side, style, what: 'target', e });
      }
    }
  }
}
console.log(JSON.stringify({ games: nSeeds * 4, problems: bad.length, st }, null, 1));
if (bad.length) console.log(JSON.stringify(bad.slice(0, 8), null, 1));
