// Full-turn trace (C, D, E, F) per campaign: prints the log lines for one rich turn, writes an importable save
// at the start of that turn's Enemy Operations Phase, and re-derives the VP ledger and supply by hand.
const fs = require('fs'), path = require('path');
const REPO = '/home/claude/a_glorious_chance_solo';
const savedArgv = process.argv.slice(); process.argv[2] = REPO;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
process.argv = savedArgv;
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, ctx = H.ctx;
X(`var __snapC = null; (function(){ const o = PROCS.turn.C1; PROCS.turn.C1 = function(s, f){ __snapC = JSON.stringify(s); return o(s, f); }; })();`);
const out = [];
for (const [side, seed, style] of [['US', 700101, 'coast'], ['BR', 700102, 'coast']]) {
  let best = null;
  for (let sd = seed; sd < seed + 30 && !best; sd++) {
    X(`var s = newGame('${side}', ${sd}, {cuttingOut:true}); run(s);`);
    let n = 0, snap = null, snapSave = null;
    while (!X('s.over') && n < 2000) {
      const before = X('JSON.stringify(s)');
      ctx.__a = policy(ctx.s, ctx.s.prompt, style); X('act(s, __a)'); n++;
      const sc = X('__snapC'); if (sc) { snap = sc; snapSave = before; X('__snapC = null'); }
      if (ctx.s.prompt && /^Reset/.test(ctx.s.prompt.title) && snap) {
        const pre = JSON.parse(snap), s = ctx.s;
        const tl = s.log.filter(l => l.turn === s.turn).map(l => l.text);
        const iC = tl.findIndex(t => /^C[1-3]:|Enemy Operations|Target Card/.test(t));
        const aiDep = tl.some(t => /AI Deploys to/.test(t) && tl.indexOf(t) > tl.findIndex(x => /^C3:/.test(x)) && tl.findIndex(x => /^C3:/.test(x)) >= 0);
        const raids = s.coastal.raids.length, battles = s.coastal.battles.length;
        if (aiDep && raids && battles && s.coastal.battles.some(b => b.target === 'HOME')) { best = { save: snapSave, side, seed: sd, turn: s.turn, pre, lines: tl, vpLog: s.vpLog.filter(v => v.turn === s.turn), supply: s.supply, coastal: s.coastal, tallyText: null }; break; }
      }
    }
  }
  if (!best) { out.push(`${side}: no rich turn found`); continue; }
  const file = path.join(__dirname, '..', `trace_${side}_${best.seed}_turn${best.turn}_beforeC1.json`);
  fs.writeFileSync(file, JSON.stringify({ state: JSON.parse(best.save), undo: [] }));
  out.push(`===== ${side === 'US' ? 'U.S.' : 'British'} campaign, seed ${best.seed}, ${['June I','June II','July I','July II','August I','August II','September I','September II'][best.turn]} (save at the last prompt before C1: ${path.basename(file)}) =====`);
  const startIdx = best.lines.findIndex(t => /^C[1-3]:/.test(t) || /no Enemy Operations/.test(t));
  best.lines.slice(Math.max(0, startIdx)).forEach(t => out.push('  ' + t));
  out.push('  -- engine VP ledger this turn: ' + JSON.stringify(best.vpLog.map(v => `${v.side} ${v.n} ${v.why}`)));
  out.push('  -- supply before C1 ' + JSON.stringify(best.pre.supply) + ' after Tally ' + JSON.stringify(best.supply));
}
fs.writeFileSync(path.join(__dirname, '..', 'turn_traces.txt'), out.join('\n'));
console.log(out.join('\n'));
