// F7 Reset oracle: compares the engine's reset with the printed F7 bullets on positions reached by policy play.
const REPO = '/home/claude/a_glorious_chance_solo';
const nSeeds = +(process.argv[2] || 30), start = +(process.argv[3] || 700000);
const savedArgv = process.argv.slice(); process.argv[2] = REPO;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
process.argv = savedArgv;
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, ctx = H.ctx;
X(`var __rs = []; (function(){ const o = PROCS.tally.reset; PROCS.tally.reset = function(s, f){ const pre = JSON.stringify(s); const r = o(s, f); __rs.push([pre, JSON.stringify(s)]); return r; }; })();`);
const STEPS = {}, RED = {}; JSON.parse(X(`JSON.stringify(SHIP_DEFS.map(d=>[d.id,d.full[4],d.red[4]]))`)).forEach(([k, v, r]) => { STEPS[k] = v; RED[k] = r; });
const key = sh => sh.id + (sh.ver || '');
let bad = [], st = { resets: 0, lakeFull: 0, lakeRed: 0, heated: 0, req: 0, iso: 0, troopsBack: 0, aiBack: 0, trackAvail: 0, aiTrack: 0, arrived: 0, markers: 0, isoLift: 0 };
for (let i = 0; i < nSeeds; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  X(`var s = newGame('${side}', ${start + i}, {cuttingOut: ${i % 2 === 0}}); run(s); __rs = [];`);
  let n = 0;
  while (!X('s.over') && n < 2000) {
    ctx.__a = policy(ctx.s, ctx.s.prompt, style); X('act(s, __a)'); n++;
    const rs = JSON.parse(X('JSON.stringify(__rs)')); X('__rs = []');
    for (const [preJ, postJ] of rs) {
      const A = JSON.parse(preJ), B = JSON.parse(postJ); st.resets++;
      const blk = sd => A.zones[{ US: 'SAC', BR: 'KIN' }[sd]].blockade === { US: 'BR', BR: 'US' }[sd];
      const err = m => bad.push({ seed: start + i, side, style, turn: A.turn, m });
      for (const id in A.ships) {
        const a = A.ships[id], b = B.ships[id], fullA = a.steps >= STEPS[key(a)];
        if (a.box === 'lake' || a.box === 'escortBox') {
          if (a.flags.heatedShot) { st.heated++; if (b.box !== 'ordinary' || !b.flags.damaged) err(`${id} heated shot -> ${b.box}`); continue; }
          if (a.flags.requisition) { st.req++; if (b.box !== 'requisitioned' || b.flags.reqUntil !== A.turn + 2) err(`${id} requisition -> ${b.box}`); continue; }
          fullA ? st.lakeFull++ : st.lakeRed++;
          const want = fullA ? 'deployable' : 'transit';
          if (b.box !== want || b.zone !== null || b.forceId !== null) err(`${id} lake ${fullA ? 'full' : 'reduced'} -> ${b.box}`);
          const iso = a.isolated && blk(a.owner);
          if (iso) st.iso++;
          if (b.port !== (iso ? 'temp' : 'home')) err(`${id} port ${b.port} (isolated ${a.isolated}, blockaded ${blk(a.owner)})`);
        } else if (a.box === 'transit' && fullA && b.box !== 'deployable') err(`${id} full in transit stays ${b.box}`);
        if (b.box !== 'sunk' && b.box !== 'outOfPlay' && b.steps < STEPS[key(b)] && b.steps < RED[key(b)]) err(`${id} keeps a Last Step/No Steps marker (${b.steps} < ${RED[key(b)]})`);
        if (a.steps < RED[key(a)] && a.box !== 'sunk' && a.box !== 'outOfPlay') st.markers++;
        if (a.isolated && !blk(a.owner)) { st.isoLift++; if (b.isolated) err(`${id} stays isolated after the Blockade lifted`); }
      }
      // Troops
      const h = A.human, ai = A.ai;
      const unl = sd => Object.values(A.forces).filter(f => f.side === sd).reduce((x, f) => x + (f.troops || 0), 0) + ((A.troopsReturning || {})[sd] || 0);
      const trackH = A.troops[h].track.filter(sp => sp <= A.supply[h]).length;
      const wantH = A.troops[h].available + unl(h) + trackH;
      if (unl(h)) st.troopsBack++; if (trackH) st.trackAvail++;
      if (B.troops[h].available !== wantH) err(`human Troops available ${B.troops[h].available} want ${wantH}`);
      const aiBoxA = A.aiTroops.box.filter(m => m.troops).length, aiBoxB = B.aiTroops.box.filter(m => m.troops).length;
      const aiTrack = A.aiTroops.track.filter(m => m.space <= A.supply[ai]);
      if (unl(ai)) st.aiBack++; if (aiTrack.length) st.aiTrack++;
      if (aiBoxB !== aiBoxA + unl(ai) + aiTrack.filter(m => m.troops).length) err(`AI Troops box ${aiBoxB} want ${aiBoxA + unl(ai) + aiTrack.filter(m => m.troops).length}`);
      if (B.aiTroops.box.length !== A.aiTroops.box.length + unl(ai) + aiTrack.length) err('AI box marker count');
      if (Object.keys(B.forces).length) err('forces not cleared');
      ['US', 'BR'].forEach(sd => A.pendingConvoy[sd].forEach((p, k) => { const q = B.pendingConvoy[sd][k]; const want = p.status === 'delayed' && !blk(sd) ? 'arrived' : p.status; if (want === 'arrived' && p.status === 'delayed') st.arrived++; if (q.status !== want) err(`pending convoy ${sd} ${q.status} want ${want}`); }));
      if (B.targetRow.length || B.tacPlayed.length) err('cards not reset');
    }
  }
}
console.log(JSON.stringify({ games: nSeeds * 4, problems: bad.length, st }, null, 1));
if (bad.length) console.log(JSON.stringify(bad.slice(0, 12), null, 1));
