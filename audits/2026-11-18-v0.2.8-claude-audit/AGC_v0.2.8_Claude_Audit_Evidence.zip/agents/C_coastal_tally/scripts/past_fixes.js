// Recheck of earlier fixes in this area (CHANGELOG 0.2.4 N03/N06/N11, 0.2.5 W01, 0.2.6/0.2.7 L01/F03/F04)
// with nearby cases that should behave differently.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (name, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++; out.push(`${ok ? 'PASS' : 'FAIL'} ${name}: got ${JSON.stringify(got)}${ok ? '' : ' want ' + JSON.stringify(want)}`); };
X(`var __F = { d6: [], d10: [], d10r: [] };
   (function(){ const o6 = d6, o10 = d10, o10r = d10r;
     d6 = function(s){ return __F.d6.length ? __F.d6.shift() : o6(s); };
     d10 = function(s){ return __F.d10.length ? __F.d10.shift() : o10(s); };
     d10r = function(s){ return __F.d10r.length ? __F.d10r.shift() : o10r(s); }; })();
   function T0(human, seed){ var s = fresh(human, seed); s.convoys.US[2]={real:false,revealed:true}; s.convoys.BR[2]={real:false,revealed:true}; s.coastal={raids:[],battles:[],cutouts:[]}; s.troops[s.human].available=0; s.phase='tally'; return s; }
   function yard(vic, res, dice, cons, extra) { var s = T0(vic === 'US' ? 'BR' : 'US', 61); s.cd[vic] = 0;
     sideShips(s, vic).forEach(sh => { if (sh.box === 'construction' && cons.indexOf(sh.id) < 0) sh.box = 'makeReady'; });
     if (extra) extra(s);
     s.coastal.battles = [{ side: OTHER[vic], target: 'HOME', zone: homeZone(vic), result: res }]; waitAt(s, 'tally', 'start'); __F.d6 = dice; act(s, 'ok'); return s; }`);
// ---- Shipyard Damage table, every row (map: Homeport Display; errata delay marker) ----
const Y = (vic, res, dice, cons, extra) => JSON.parse(X(`(function(){ var s = yard('${vic}', '${res}', ${JSON.stringify(dice)}, ${JSON.stringify(cons)}, ${extra || 'null'});
  return JSON.stringify({ cd: s.cd['${vic}'], steps: ${JSON.stringify(cons)}.map(id => [s.ships[id].box, s.ships[id].steps]), vp: s.vp[OTHER['${vic}']] - (s.zones && 0), line: s.prompt.text.split('\\n').find(l => /F3.1/.test(l)) }); })()`));
let r;
r = Y('US', 'AM', [1, 2], ['pike', 'sylph']); eq('2d6 3: Docks burned, CD+1, hulls untouched', [r.cd, r.steps], [1, [['construction', 3], ['construction', 3]]]);
r = Y('US', 'AM', [2, 3], ['pike', 'sylph'], "function(s){ s.ships.oneida.box='repairing'; s.ships.oneida.steps=1; }"); eq('2d6 5: CD+1, a Repairing ship gets a delay marker', [r.cd, X(`yard('US','AM',[2,3],['pike','sylph'],function(s){ s.ships.oneida.box='repairing'; s.ships.oneida.steps=1; }).ships.oneida.delay`)], [1, 2]);
r = Y('US', 'AM', [2, 3], ['pike', 'sylph']); eq('2d6 5 with nothing Repairing: CD+1 only', [r.cd, r.steps], [1, [['construction', 3], ['construction', 3]]]);
r = Y('US', 'AM', [3, 3], ['pike', 'sylph']); eq('2d6 6: CD+1, greatest-VP hull (Pike) flipped only', [r.cd, r.steps], [1, [['construction', 2], ['construction', 3]]]);
r = Y('BR', 'AM', [3, 4], ['melville']); eq('2d6 7 vs a lone hull (Melville): flipped', [r.cd, r.steps], [1, [['construction', 1]]]);
r = Y('US', 'AM', [4, 4], ['pike', 'sylph']); eq('N03 2d6 8 with two hulls: CD+2, both flipped', [r.cd, r.steps], [2, [['construction', 2], ['construction', 2]]]);
r = Y('BR', 'AM', [4, 5], ['melville']); eq('N03 nearby: 2d6 9 with one hull (Melville, 2 steps): CD+2, not flipped', [r.cd, r.steps], [2, [['construction', 2]]]);
r = Y('BR', 'AM', [4, 5], []); eq('N03 nearby: 2d6 9 with no hulls: CD+2', r.cd, 2);
r = Y('US', 'AM', [5, 5], ['pike', 'sylph']); eq('2d6 10: CD+2, Pike burned (+20 VP to the British)', [r.cd, r.steps.map(x => x[0]), r.vp], [2, ['sunk', 'construction'], 20]);
r = Y('US', 'AM', [6, 6], ['pike', 'sylph']); eq('2d6 12: CD+3, both burned (+34 VP)', [r.cd, r.steps.map(x => x[0]), r.vp], [3, ['sunk', 'sunk'], 34]);
r = Y('US', 'AF', [5, 5], ['pike', 'sylph']); eq('Feat of Arms +2: 10+2 = 12 row', [r.cd, r.steps.map(x => x[0]), /= 12/.test(r.line)], [3, ['sunk', 'sunk'], true]);
r = Y('US', 'AS', [6, 6], ['pike', 'sylph']); eq('Attacker Success: no Shipyard check', [r.cd, r.line === undefined], [0, true]);
// flipped hull: launched damaged -> Repairing one turn -> Make Ready -> Deployable (6.2 sidebar)
X(`var s = fresh('BR', 62); s.ships.melville.steps = 1; s.supply.BR = 4; s.cd.BR = 0; s.turn = 3; s.phase='prep'; s.calls=[{proc:'turn',pc:'A5',A:{},L:{}}];
   (function(){ const o = PROCS.turn.A6; PROCS.turn.A6 = function(s,f){ return P(info('STOP6','x'),'A6'); }; run(s); PROCS.turn.A6 = o; })();
   var b1 = [s.ships.melville.box, !!s.ships.melville.flags.builtDamaged];
   s.prompt=null; s.calls=[{proc:'turn',pc:'A3',A:{},L:{}}]; (function(){ const o = PROCS.turn.A4; PROCS.turn.A4 = function(s,f){ return P(info('STOP4','x'),'A4'); }; run(s); PROCS.turn.A4 = o; })();
   var b2 = [s.ships.melville.box, s.ships.melville.steps];`);
eq('damaged hull: A5 -> Repairing, next A3 -> Make Ready at full strength', X('[b1, b2]'), [['repairing', true], ['makeReady', 2]]);
// ---- N06: Last Step / No Steps markers at F7, nearby cases ----
const n06 = (id, steps, box) => X(`(function(){ var s = T0('BR', 63); ${box === 'lake' ? `newForce(s, s.ships['${id}'].owner, 'NOR', 'Patrol', ['${id}']);` : `s.ships['${id}'].box='${box}';`} s.ships['${id}'].steps = ${steps}; waitAt(s,'tally','reset'); act(s,'ok'); return [s.ships['${id}'].box, s.ships['${id}'].steps]; })()`);
eq('N06 Wolfe at 1 step (Last Step) -> In Transit, 2 steps', n06('wolfe', 1, 'lake'), ['transit', 2]);
eq('N06 Pike at 0 steps (No Steps) -> 2 steps', n06('pike', 0, 'lake'), ['transit', 2]);
eq('N06 Moira (2-step) at 0 -> 1 step', n06('moira', 0, 'lake'), ['transit', 1]);
eq('N06 nearby: Wolfe on her Reduced face (2) unchanged', n06('wolfe', 2, 'lake'), ['transit', 2]);
eq('N06 nearby: full-strength Wolfe -> Deployable, 3 steps', n06('wolfe', 3, 'lake'), ['deployable', 3]);
eq('N06 nearby: one-step schooner keeps 0', n06('asp', 0, 'lake'), ['transit', 0]);
eq('N06 nearby: sunk ship untouched', n06('rg', 0, 'sunk'), ['sunk', 0]);
// ---- N11: Troops never lost with their ships; launched Troops are ----
X(`var s = T0('BR', 64); var f = newForce(s,'BR','NIA','ArmySupport',['moira']); f.troops = 1; sinkShip(s, 'moira', 'US', 'Lake Combat'); var due = s.troopsReturning.BR;
   waitAt(s,'tally','reset'); act(s,'ok');`);
eq('N11 Force sunk with Troops aboard: 1 due back, Available at F7', X('[due, s.troops.BR.available]'), [1, 1]);
X(`var s = T0('BR', 65); var f = newForce(s,'BR','NIA','ArmySupport',['moira']); f.troops = 1; captureShip(s, 'moira', 'US', 'Struck Colors'); waitAt(s,'tally','reset'); act(s,'ok');`);
eq('N11 Force captured with Troops aboard: Troops back at F7', X('s.troops.BR.available'), 1);
X(`var s = fresh('BR', 66); s.phase='coastal'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps=false; s.troops.BR.available = 0;
   sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && sh.id!=='madison') sh.box='repairing'; });
   var f = newForce(s,'BR','SAC','ArmySupport',['beres']); f.troops = 1; s.deck.event = [1].concat(s.deck.event.filter(n=>n!==1)); __F.d10=[0]; __F.d10r=[10,10];
   s.calls=[{proc:'coastal',pc:'start',A:{},L:{}},]; s.calls.unshift({proc:'tally',pc:'reset',A:{},L:{}}); run(s); var g=0; while (s.prompt && g++<40) act(s, s.prompt.kind==='info'?'ok':s.prompt.options[0].id);`);
eq('N11 nearby: Troops launched, then the supporting ship sinks in the Harbor Encounter: Troops are spent (not returned)', X(`[s.ships.beres.box, s.coastal.battles.length, s.troops.BR.available]`), ['sunk', 1, 0]);
// ---- W01: withdrawn mission Troops wait for F7 (A.I. and human alike) ----
X(`var s = fresh('BR', 67); s.troops.BR.available = 0; var fa = newForce(s,'US','NIA','ArmySupport',['madison']); fa.troops = 1; var fh = newForce(s,'BR','NIA','ArmySupport',['moira']); fh.troops = 2;
   var box0 = aiTroopsInBox(s); abortCoastalMission(s, fa); abortCoastalMission(s, fh); var mid = [aiTroopsInBox(s) - box0, s.troops.BR.available, s.troopsReturning.US, s.troopsReturning.BR];
   s.phase='tally'; waitAt(s,'tally','reset'); act(s,'ok'); var after = [aiTroopsInBox(s) - box0, s.troops.BR.available];`);
eq('W01 aborted missions: nothing Available before F7 (A.I. 1 and yours 2 queued)', X('mid'), [0, 0, 1, 2]);
eq('W01 … all back at F7 (A.I. marker revealed in its box)', X('after'), [1, 2]);
// ---- L01/F03/F04 nearby: a stamped save is never upgraded; an old abort line from an earlier turn is ignored ----
X(`var s = fresh('BR', 68); s.phase='lake'; var n0 = s.aiTroops.box.length; returnAiTroops(s, 1);
   s.log.push({ turn: s.turn, phase: 'lake', text: 'U.S. Coastal mission aborted – 1 Troops marker(s) remain available for future use.', kind: 'info' });
   var stamped = JSON.parse(JSON.stringify(s)); stamped.build = APP_VERSION; var a = checkSaveState(JSON.parse(JSON.stringify(stamped)));
   var old = JSON.parse(JSON.stringify(s)); delete old.build; var b = checkSaveState(JSON.parse(JSON.stringify(old)));
   var prev = JSON.parse(JSON.stringify(old)); prev.log[prev.log.length-1].turn = prev.turn - 1; var c = checkSaveState(JSON.parse(JSON.stringify(prev)));`);
eq('L01 stamped (0.2.8) save with the old line: untouched', X('[aiTroopsInBox(a), a.troopsReturning.US]'), [X('aiTroopsInBox(stamped)'), 0]);
eq('L01 unstamped save, line this turn: marker moved to the F7 queue', X('[aiTroopsInBox(b), b.troopsReturning.US]'), [X('aiTroopsInBox(old)') - 1, 1]);
eq('L01 nearby: the old line from the previous turn is ignored', X('[aiTroopsInBox(c), c.troopsReturning.US]'), [X('aiTroopsInBox(prev)'), 0]);
X(`var t = JSON.parse(JSON.stringify(old)); t.phase = 'tally'; var d = checkSaveState(JSON.parse(JSON.stringify(t)));`);
eq('F04 nearby: unstamped Tally save where the A.I. never used the marker: left alone, no notice', X('[aiTroopsInBox(d), d.troopsReturning.US, (d.recovery||[]).length]'), [X('aiTroopsInBox(t)'), 0, 0]);
X(`var u = JSON.parse(JSON.stringify(old)); u.log.push({ turn: u.turn, phase: 'enemy', text: 'Target Card B20: x. Deployment table: Troops 1 row × Naval Balance “-15 to 15” column → blank.', kind: 'ai' }); var e2 = checkSaveState(JSON.parse(JSON.stringify(u)));`);
eq('F03 nearby: a later lookup on Troops row 1 -> notice, save left as saved', X('[aiTroopsInBox(e2), e2.troopsReturning.US, (e2.recovery||[]).length]'), [X('aiTroopsInBox(u)'), 0, 1]);
console.log(out.join('\n')); console.log(`\n${pass} pass, ${fail} fail`);
