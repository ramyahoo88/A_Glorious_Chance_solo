// Natural-play frequency of the Requisition-of-a-Reduced-ship case (policy play, both campaigns, both styles).
const REPO = '/home/claude/a_glorious_chance_solo';
const nSeeds = +(process.argv[2] || 60), start = +(process.argv[3] || 720000);
const savedArgv = process.argv.slice(); process.argv[2] = REPO;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
process.argv = savedArgv;
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, ctx = H.ctx;
X(`var __rq = []; (function(){ const o = PROCS.tally.reset; PROCS.tally.reset = function(s, f){
  Object.values(s.ships).forEach(sh => { if ((sh.box === 'lake' || sh.box === 'escortBox') && sh.flags.requisition) __rq.push({ id: sh.id, owner: sh.owner, full: isFull(sh), steps: sh.steps, turn: s.turn, human: s.human }); });
  return o(s, f); }; })();
  var __back = []; (function(){ const o = PROCS.turn.A3; PROCS.turn.A3 = function(s, f){ Object.values(s.ships).forEach(sh => { if (sh.box === 'deployable' && !isFull(sh)) __back.push({ id: sh.id, owner: sh.owner, steps: sh.steps, turn: s.turn, human: s.human }); }); return o(s, f); }; })();`);
let req = 0, reqRed = 0, games = 0, reducedDeployableAfterA2 = 0, samples = [];
for (let i = 0; i < nSeeds; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  X(`var s = newGame('${side}', ${start + i}, {cuttingOut: ${i % 2 === 0}}); run(s); __rq = []; __back = [];`); games++;
  let n = 0;
  while (!X('s.over') && n < 2000) { ctx.__a = policy(ctx.s, ctx.s.prompt, style); X('act(s, __a)'); n++; }
  const rq = JSON.parse(X('JSON.stringify(__rq)')), back = JSON.parse(X('JSON.stringify(__back)'));
  req += rq.length; const red = rq.filter(r => !r.full); reqRed += red.length;
  reducedDeployableAfterA2 += back.length;
  if (red.length && samples.length < 6) samples.push({ side, seed: start + i, style, red, back });
}
console.log(JSON.stringify({ games, requisitions: req, reducedRequisitions: reqRed, reducedShipsInDeployableAtA3: reducedDeployableAfterA2, samples }, null, 1));
