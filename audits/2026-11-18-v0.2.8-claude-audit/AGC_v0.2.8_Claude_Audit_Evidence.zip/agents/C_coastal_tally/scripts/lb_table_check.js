// Independent transcription of Player Aid VII (Land Battle Table) read from the photographed aid
// (/mnt/user-data/uploads/052f2cf1-image.jpg; crops lbt_left/right.png), compared with lbLookup for every
// column (5 Long Gun bands x 3 Troops) and every valid 2d6 11-66 roll, plus column shifts and >3 Troops.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
// rows: DM, DS, DR, AS, AM, AF ; '-' = no result. Typed from the photo, column by column.
const AID = {
  '0/1': ['11-14', '15-23', '24-43', '44-65', '66', '-'],
  '0/2': ['11-13', '14-23', '24-41', '42-64', '65-66', '-'],
  '0/3': ['11-12', '13-21', '22-34', '35-61', '64-65', '66'],
  '1/1': ['11', '12-16', '21-34', '35-62', '63-66', '-'],
  '1/2': ['-', '11-14', '15-31', '32-61', '62-66', '-'],
  '1/3': ['-', '11-13', '14-26', '31-56', '61-64', '65-66'],
  '2/1': ['11', '12-13', '14-31', '32-55', '56-66', '-'],
  '2/2': ['-', '11-12', '13-26', '27-54', '55-66', '-'],
  '2/3': ['-', '11', '12-24', '25-53', '54-63', '64-66'],
  '3/1': ['11', '12', '13-24', '25-52', '53-66', '-'],
  '3/2': ['-', '11', '12-22', '23-51', '52-66', '-'],
  '3/3': ['-', '11', '12-21', '22-46', '51-62', '63-66'],
  '4/1': ['-', '11', '12-16', '21-44', '45-66', '-'],
  '4/2': ['-', '11', '12-15', '16-35', '36-66', '-'],
  '4/3': ['-', '11', '12-14', '15-33', '34-61', '62-66'],
};
const ORDER = ['DM', 'DS', 'DR', 'AS', 'AM', 'AF'];
const rolls = []; for (let r = 1; r <= 6; r++) for (let b = 1; b <= 6; b++) rolls.push(r * 10 + b);
const aidResult = (key, v) => { const c = AID[key]; let res = null, n = 0; c.forEach((rg, i) => { if (rg === '-') return; const [lo, hi] = rg.split('-').map(Number); if (v >= lo && v <= (hi || lo)) { res = ORDER[i]; n++; } }); return { res, n }; };
const bandLG = [0, 3, 10, 20, 30];        // a representative Long Gun total inside each band
const bandEdges = [[0, 0], [1, 6], [7, 15], [16, 24], [25, 99]];
let checked = 0, mism = [], gaps = [], overlaps = [];
for (let band = 0; band < 5; band++) for (let t = 1; t <= 3; t++) for (const v of rolls) {
  const key = `${band}/${t}`, a = aidResult(key, v);
  if (a.n === 0) gaps.push(`${key} roll ${v}`);
  if (a.n > 1) overlaps.push(`${key} roll ${v}`);
  for (const lgv of [bandEdges[band][0], bandEdges[band][1], bandLG[band]]) {
    const got = JSON.parse(X(`JSON.stringify(lbLookup(${lgv}, ${t}, 0, ${v}))`));
    checked++;
    const want = a.res === null && key === '0/3' && (v === 62 || v === 63) ? 'AS' : a.res;  // RULES_NOTES 39
    if (got.result !== want || got.band !== band || got.troops !== t) mism.push({ lg: lgv, t, v, got: got.result, want });
  }
}
// shifts: More Defenders -2 (stops at the 0 column, note 40); >3 Troops use the 3-Troops column
const shiftCases = [[30, 1, -2, 2], [20, 2, -2, 1], [10, 3, -2, 0], [3, 1, -2, 0], [0, 2, -2, 0], [16, 1, -1, 2], [25, 3, -2, 2]];
const shiftRes = shiftCases.map(([lgv, t, sh, wantBand]) => { const r = JSON.parse(X(`JSON.stringify(lbLookup(${lgv},${t},${sh},44))`)); return { lgv, t, sh, band: r.band, wantBand, ok: r.band === wantBand }; });
const t4 = JSON.parse(X(`JSON.stringify(lbLookup(10, 4, 0, 64))`)), t3 = JSON.parse(X(`JSON.stringify(lbLookup(10, 3, 0, 64))`));
console.log(JSON.stringify({ checked, mismatches: mism, printedGaps: gaps, printedOverlaps: overlaps, shiftRes, fourTroopsUses3: t4.result === t3.result && t4.troops === 3 }, null, 1));
