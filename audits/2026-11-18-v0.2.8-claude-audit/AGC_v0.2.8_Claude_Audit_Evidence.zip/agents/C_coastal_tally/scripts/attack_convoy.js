// Attack Convoy secondary mission in the Enemy Operations Phase (11.3.1 case 2; C5) – both campaigns.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (name, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++; out.push(`${ok ? 'PASS' : 'FAIL'} ${name}: got ${JSON.stringify(got)}${ok ? '' : ' want ' + JSON.stringify(want)}`); };
X(`var __stopD = true; (function(){ const oD1 = PROCS.turn.D1; PROCS.turn.D1 = function(s,f){ if (__stopD) { s.phase='breakout'; return P(info('STOP','stop'), 'D1'); } return oD1(s,f); }; })();
function C0(human, seed) { var s = fresh(human, seed); s.phase='enemy'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps = false;
  s.convoys[s.human][2] = {real:true,revealed:true,delay:false,deployed:false,result:null}; s.convoys[s.human][3] = {real:false,revealed:true};
  s.convoys[s.ai][2] = {real:false,revealed:false}; return s; }
function cardWithCell(s, ids) { return ids.find(k => cardCell(s, TARGET_CARDS[k]).v); }
function runC(s) { s.calls = [{ proc: 'turn', pc: 'C1', A: {}, L: {} }]; run(s); var g = 0, T=[]; while (s.prompt && s.prompt.title !== 'STOP' && g++ < 80) { T.push(s.prompt.title); var p = s.prompt;
  act(s, p.kind === 'info' ? 'ok' : p.kind === 'lineup' ? {attackers:p.candidates,tows:p.defaultTows||{}} : p.kind==='select' ? (p.initial||[]) : (p.options.find(o=>o.primary)||p.options[0]).id); } return T; }`);
// U.S. campaign, unescorted U.S. Convoy: British A.I. Force rolls on the Scatter Table in Sacket's
X(`var s = C0('US', 51); var cid = cardWithCell(s, ['A31','A32','A33','A37','A38','A39']); s.targetRow = [{id: cid, revealed:false, removed:false, enc:false}]; var T = runC(s);`);
eq('U.S. campaign: card ' + X('cid') + ' -> Attack Convoy, unescorted -> Scatter Table result set', X(`[!!s.convoys.US[2].deployed, ['S','D','C'].indexOf(s.convoys.US[2].result) >= 0, s.convoyDeployed.US && s.convoyDeployed.US.zone]`), [true, true, 'SAC']);
out.push('   ' + X(`s.log.filter(l=>/Scatter|Convoy/.test(l.text)).map(l=>l.text).join(' | ')`));
// U.S. campaign, U.S. Escort in Sacket's: C2.2 returns the card (your ships are in that zone)
X(`var s = C0('US', 52); var cid = cardWithCell(s, ['A31','A32','A33','A37','A38','A39']); s.targetRow = [{id: cid, revealed:false, removed:false, enc:false}];
   newForce(s, 'US', 'SAC', 'Escort', ['oneida']); var T = runC(s);`);
eq('U.S. campaign: your Escort in Sacket\'s -> C2.2 removes the Sacket\'s card, Convoy untouched', X(`[s.targetRow[0].removed, !!s.convoys.US[2].deployed]`), [true, false]);
// U.S. campaign, no U.S. Convoy this turn: the card is a plain Patrol
X(`var s = C0('US', 53); s.convoys.US[2] = {real:false,revealed:true}; var cid = cardWithCell(s, ['A31','A32','A33','A37','A38','A39']); s.targetRow = [{id: cid, revealed:false, removed:false, enc:false}]; var T = runC(s);`);
eq('U.S. campaign: no Convoy -> British Patrol in Sacket\'s', X(`Object.values(s.forces).filter(f=>f.side==='BR').map(f=>f.mission+'@'+f.zone)`), ['Patrol@SAC']);
// British campaign, escort box empty: U.S. Force rolls on the Scatter Table in the card's zone
X(`var s = C0('BR', 54); var cid = cardWithCell(s, ['B21','B22','B43','B47','B48','B50']); s.targetRow = [{id: cid, revealed:false, removed:false, enc:false}]; var T = runC(s);`);
eq('British campaign: unescorted -> Scatter, Convoy marker in card zone', X(`[s.convoys.BR[2].deployed, ['S','D','C'].indexOf(s.convoys.BR[2].result)>=0, s.convoyDeployed.BR && s.convoyDeployed.BR.zone === TARGET_CARDS[cid].zone]`), [true, true, true]);
// British campaign, escort box ships: an escorted-Convoy Encounter in the card's zone
X(`var s = C0('BR', 55); var cid = cardWithCell(s, ['B21','B22','B43','B47','B48','B50']); s.targetRow = [{id: cid, revealed:false, removed:false, enc:false}];
   s.ships.moira.box = 'escortBox'; var T = runC(s);`);
eq('British campaign: Escort Convoy box ships deploy and fight (convoy Encounter)', X(`[s.log.some(l=>/escorted Convoy is attacked/.test(l.text)), s.ships.moira.box === 'lake' || s.ships.moira.box === 'transit' || s.ships.moira.box==='sunk' || s.ships.moira.owner==='US']`), [true, true]);
out.push('   ' + X(`T.join(' | ')`).slice(0, 400));
console.log(out.join('\n')); console.log(`\n${pass} pass, ${fail} fail`);
