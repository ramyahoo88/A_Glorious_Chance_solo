// Early endings: Dual Blockade (14.2) against you and against the A.I.; last-turn sudden death (5.1); Sept II final scoring.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (name, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++; out.push(`${ok ? 'PASS' : 'FAIL'} ${name}: got ${JSON.stringify(got)}${ok ? '' : ' want ' + JSON.stringify(want)}`); };
X(`function drain(s){ var g=0; while (s.prompt && g++<20) act(s, s.prompt.kind==='info'?'ok':s.prompt.options[0].id); return s; }
   function dualVsHuman(keepFull) { var s = fresh('BR', 91); s.turn = 4; s.coastal={raids:[],battles:[],cutouts:[]}; s.troops.BR.available=0; s.convoys.US[4]={real:false,revealed:true}; s.convoys.BR[4]={real:false,revealed:true};
     s.vp.US = 3; s.vp.BR = 20; s.cd.US = 2;
     s.ships.wolfe.owner='US'; s.ships.rg.owner='US';   // the A.I. needs 8 Main ships for two Blockades (two captured British ships)
     s.ships.pike.box='deployable'; s.ships.sylph.box='deployable';
     newForce(s,'US','KIN',['madison','oneida','tompkins','fairam'].length ? 'Patrol' : 'Patrol',['madison','oneida','tompkins','fairam']);
     newForce(s,'US','YOR','Patrol',['pike','sylph','wolfe','rg']);
     ['KIN','YOR'].forEach(z => { s.zones[z].control='US'; s.zones[z].blockade='US'; });
     s.ships.sss.isolated = true; s.ships.sss.port = 'temp';
     ['moira','beres','sss'].forEach(id => { s.ships[id].box = keepFull && id === 'moira' ? 'deployable' : 'repairing'; if (id==='moira') s.ships[id].port='home'; });
     s.calls=[{proc:'tally',pc:'start',A:{},L:{}}]; run(s); return drain(s); }`);
X(`var a = dualVsHuman(false);`);
eq('Dual Blockade of Kingston + York, no full-strength British ship in Kingston: U.S. Decisive Victory', X('[a.over, a.result.level, a.result.forced, a.result.score]'), [true, 'U.S. Decisive Victory (Dual Blockade)', 'US', X('a.vp.US - a.vp.BR')]);
eq('… Construction Delay is not deducted from the forced result', X('a.vpLog.some(v => /Construction Delay/.test(v.why))'), false);
X(`var b = dualVsHuman(true);`);
eq('nearby: a full-strength British ship in Kingston can break out -> the game goes on', X('[b.over, b.suddenDeath || null]'), [false, null]);
// 5.1 last-turn sudden death: the game ends at the start of Sept II with normal scoring (CD deducted)
X(`var c = fresh('US', 92); c.turn = 6; c.vp.US = 25; c.vp.BR = 0; c.cd.US = 3; Object.values(c.ships).forEach(sh => { if (sh.owner==='BR') { sh.box='sunk'; } });
   c.calls=[{proc:'turn',pc:'next',A:{},L:{}}]; run(c);`);
eq('5.1: no British ship eligible for Sept II -> game ends, score 25 - CD 3 = 22 (U.S. Victory)', X('[c.over, c.turn, c.result.score, c.result.level]'), [true, 7, 22, 'U.S. Victory']);
// Sept II: Tally then the game ends after Reset with CD deducted for both sides
X(`var d = fresh('BR', 93); d.turn = 7; d.coastal={raids:[],battles:[],cutouts:[]}; d.troops.BR.available=0; d.convoys.US[7]={real:false,revealed:true}; d.convoys.BR[7]={real:false,revealed:true};
   d.vp.US = 30; d.vp.BR = 8; d.cd.US = 1; d.cd.BR = 4; d.calls=[{proc:'turn',pc:'F',A:{},L:{}}]; run(d); drain(d);`);
eq('Sept II final: (30-1) - (8-4) = +25 U.S. Victory', X('[d.over, d.result.score, d.result.level]'), [true, 25, 'U.S. Victory']);
console.log(out.join('\n')); console.log(`\n${pass} pass, ${fail} fail`);
