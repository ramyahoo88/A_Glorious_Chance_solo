// Ambiguity probe: a Lake Zone Event already in force in the targeted zone during a Harbor Encounter.
// Minor Damage (Gunnery Rounds) is applied in the Harbor Encounter, Haze ("first Lake Combat Gunnery Round 1 to
// occur in this Lake Zone") is not.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
X(`var __F = { d10: [] }; (function(){ const o10 = d10; d10 = function(s){ return __F.d10.length ? __F.d10.shift() : o10(s); }; })();
   var __stopT = true; (function(){ const o = PROCS.tally.start; PROCS.tally.start = function(s,f){ return P(info('STOPT','stop'), 'start'); }; })();
   function harborWith(ev) { var s = fresh('BR', 71); s.phase='coastal'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps=false;
     sideShips(s,'US').forEach(sh => { if (sh.box==='deployable' && sh.id!=='madison') sh.box='repairing'; });
     var f = newForce(s,'BR','SAC','ArmySupport',['wolfe','rg']); f.troops = 1;
     s.zones.SAC.event = ev; if (ev) applyLakeEvent(s, EVENTS[ev], 'SAC');
     __F.d10 = [6]; s.calls=[{proc:'coastal',pc:'start',A:{},L:{}}]; run(s); var g=0; while (s.prompt && s.prompt.title!=='STOPT' && g++<40) act(s, s.prompt.kind==='info'?'ok':s.prompt.options[0].id);
     return s.log.filter(l=>/Harbor Gunnery Round 1|Minor Damage/.test(l.text)).map(l=>l.text); }`);
console.log('No zone event:  ', X('harborWith(null)'));
console.log('Haze (#16):     ', X('harborWith(16)'));
console.log('Minor Damage US (#33):', X('harborWith(33)'));
