// Enemy Operations (C1-C5) and Breakout (D) checks against the printed procedures.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (name, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++; out.push(`${ok ? 'PASS' : 'FAIL'} ${name}: got ${JSON.stringify(got)}${ok ? '' : ' want ' + JSON.stringify(want)}`); };
X(`var __stopD = true; (function(){ const oD1 = PROCS.turn.D1; PROCS.turn.D1 = function(s,f){ if (__stopD) { s.phase='breakout'; return P(info('STOP','stop'), 'D1'); } return oD1(s,f); }; })();
function C0(human, seed, keepAI) {
  var s = fresh(human, seed); s.phase='enemy'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps = false;
  s.convoys.US[2]={real:false,revealed:true}; s.convoys.BR[2]={real:false,revealed:true};
  sideShips(s, s.ai).forEach(sh => { if (keepAI.indexOf(sh.id) < 0 && sh.box === 'deployable') sh.box = 'repairing'; });
  return s; }
function rowOf(s, filt) { const deck = s.human === 'US' ? 'A' : 'B';
  return Object.keys(TARGET_CARDS).filter(k => TARGET_CARDS[k].deck === deck && TARGET_CARDS[k].mission === 'Patrol' && !TARGET_CARDS[k].cond && cardCell(s, TARGET_CARDS[k]).v && (!filt || filt(TARGET_CARDS[k]))).slice(0, 4).map(id => ({ id, revealed:false, removed:false, enc:false })); }
function runC(s) { s.calls = [{ proc: 'turn', pc: 'C1', A: {}, L: {} }]; run(s); var g = 0; while (s.prompt && s.prompt.title !== 'STOP' && g++ < 50) act(s, s.prompt.kind === 'info' ? 'ok' : (s.prompt.options ? s.prompt.options[0].id : [])); return s; }
function aiForces(s) { return Object.values(s.forces).filter(f => f.side === s.ai).map(f => f.ships.length); }`);
// British campaign: the phase ends when fewer than two A.I. ships remain
X(`var s = C0('BR', 31, ['madison']); s.targetRow = rowOf(s, c => ['NOR','YOR','NIA','SOU'].indexOf(c.zone) >= 0); runC(s);`);
eq('BR campaign, 1 A.I. Deployable ship: no Enemy Operations deployment', X('[aiForces(s), s.log.some(l => /fewer than two AI Deployable/.test(l.text))]'), [[], true]);
X(`var s = C0('BR', 31, ['madison','oneida','sylph']); s.ships.sylph.box='deployable'; s.targetRow = rowOf(s, c => ['NOR','YOR','NIA','SOU'].indexOf(c.zone) >= 0); runC(s); var nf2 = aiForces(s);`);
eq('BR campaign, 3 A.I. ships: Enemy Operations go on (at least one lookup)', X(`s.log.some(l => /Target Card B/.test(l.text))`), true);
X(`var s = C0('US', 32, ['sss']); s.targetRow = rowOf(s, c => ['NOR','YOR','NIA','SOU','SAC'].indexOf(c.zone) >= 0); runC(s);`);
eq('US campaign, 1 A.I. Deployable ship still deploys', X('aiForces(s)'), [1]);
// C2.2: cards for zones holding your ships are returned; C2.1 encounter cards returned
X(`var s = C0('US', 33, ['wolfe','rg','moira','beres','sss']); s.targetRow = rowOf(s); var z0 = TARGET_CARDS[s.targetRow[0].id].zone;
   newForce(s, 'US', z0, 'Patrol', ['oneida']); s.targetRow[1].enc = true; s.targetRow[1].revealed = true; runC(s);`);
eq('C2.1/C2.2: no A.I. Force in a zone with your ships; Encounter card skipped', X(`[Object.values(s.forces).filter(f=>f.side==='BR' && f.zone===z0).length, s.targetRow[0].removed, s.targetRow[1].removed]`), [0, true, true]);
// C1 Blockade: only Isolated (temp-port) Deployable A.I. ships take part
X(`var s = C0('US', 34, ['wolfe','rg','moira','beres','sss']); s.zones.KIN.blockade='US'; s.zones.KIN.control='US'; newForce(s,'US','KIN','Patrol',['madison','oneida','tompkins','fairam']);
   s.ships.sss.isolated = true; s.ships.sss.port = 'temp'; s.targetRow = rowOf(s, c => c.zone !== 'KIN'); runC(s);`);
eq('C1: blockaded A.I. deploys only its Isolated ship', X(`Object.values(s.forces).filter(f=>f.side==='BR').map(f=>f.ships.join())`), ['sss']);
X(`var s = C0('US', 34, ['wolfe','rg','moira','beres','sss']); s.zones.KIN.blockade='US'; s.zones.KIN.control='US'; newForce(s,'US','KIN','Patrol',['madison','oneida','tompkins','fairam']);
   s.targetRow = rowOf(s, c => c.zone !== 'KIN'); runC(s);`);
eq('C1: all A.I. ships blockaded -> no Enemy Operations', X(`[Object.values(s.forces).filter(f=>f.side==='BR').length, s.log.some(l=>/no Deployable ships/.test(l.text))]`), [0, true]);
X('__stopD = false');
// D: A.I. Breakout decision (British A.I. compares Carronade, U.S. A.I. compares Long Gun; equal -> stays, Convoy Delay)
const brk = (human, inPort, blockaders) => {
  X(`var s = fresh('${human}', 35); s.phase='breakout'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps=false; var ai = s.ai, hz = homeZone(ai);
     sideShips(s, ai).forEach(sh => { if (${JSON.stringify(inPort)}.indexOf(sh.id) < 0 && sh.box==='deployable') sh.box='repairing'; });
     ${JSON.stringify(inPort)}.forEach(id => { s.ships[id].box='deployable'; s.ships[id].port='home'; });
     s.zones[hz].blockade = s.human; s.zones[hz].control = s.human; newForce(s, s.human, hz, 'Patrol', ${JSON.stringify(blockaders)});
     s.convoys[ai][2] = {real:true,revealed:false,delay:false,deployed:false,result:null};
     var bc = aiBreakoutCheck(s, ai); s.calls=[{proc:'turn',pc:'D1',A:{},L:{}}]; run(s);`);
  return X(`[bc.label, bc.a, bc.b, s.encounter ? s.encounter.kind : null, !!s.convoys[ai][2].delay]`);
};
// British A.I.: Wolfe A Car 4 + RG A Car 4 = 8 vs Madison Car 4 + Oneida 3 = 7  -> breaks out
eq('British A.I. Carronade 8 > 7: Breakout', brk('US', ['wolfe', 'rg'], ['madison', 'oneida']), ['Carronade', 8, 7, 'breakout', false]);
eq('British A.I. Carronade 4 = 4: stays, Convoy Delay', brk('US', ['wolfe'], ['madison']), ['Carronade', 4, 4, null, true]);
eq('British A.I. Carronade 4 < 7: stays, Convoy Delay', brk('US', ['wolfe'], ['madison', 'oneida']), ['Carronade', 4, 7, null, true]);
// U.S. A.I.: Madison LG 2 + Oneida 1 = 3 vs Wolfe A LG 2 -> breaks out; Madison alone 2 vs 2 -> stays
eq('U.S. A.I. Long Gun 3 > 2: Breakout', brk('BR', ['madison', 'oneida'], ['wolfeA'.slice(0, 5)]), ['Long Gun', 3, 2, 'breakout', false]);
eq('U.S. A.I. Long Gun 2 = 2: stays, Convoy Delay', brk('BR', ['madison'], ['wolfe']), ['Long Gun', 2, 2, null, true]);
// Human Breakout choice: offered with blockaders on station and a full-strength ship in port; Pass delays your Convoy
X(`var s = fresh('US', 36); s.phase='breakout'; s.zones.SAC.blockade='BR'; s.zones.SAC.control='BR'; newForce(s,'BR','SAC','Patrol',['wolfe','rg','moira','beres']);
   s.convoys.US[2]={real:true,revealed:true,delay:false,deployed:false,result:null}; s.calls=[{proc:'turn',pc:'D1',A:{},L:{}}]; run(s); var t1 = s.prompt.title; act(s,'pass');`);
eq('human Breakout offered; Pass -> Convoy Delay', X('[t1, s.convoys.US[2].delay]'), ['D Breakout Attack?', true]);
X(`var s = fresh('US', 36); s.phase='breakout'; s.zones.SAC.blockade='BR'; s.zones.SAC.control='BR'; newForce(s,'BR','SAC','Patrol',['wolfe','rg','moira','beres']);
   sideShips(s,'US').forEach(sh => { if (sh.box==='deployable') sh.steps = 0; });
   s.convoys.US[2]={real:true,revealed:true,delay:false,deployed:false,result:null}; s.calls=[{proc:'turn',pc:'D1',A:{},L:{}}]; run(s);`);
eq('no full-strength ship in port: automatic Pass, Convoy Delay', X('[s.prompt && s.prompt.title, s.convoys.US[2].delay]'), [X('s.prompt && s.prompt.title'), true]);
// Breakout END reroll: 14.3.2
X(`var cnt = 0, ends = 0; for (var sd = 1; sd <= 300; sd++) { var s = fresh('US', 4000 + sd); stageCombat(s, 'SAC', ['madison'], ['wolfe'], 'US'); s.encounter.kind = 'breakout';
   s.calls = [{ proc: 'combat', pc: 'start', A: { attacker: 'US', segment: 'patrol', decided: true }, L: {} }]; try { run(s); var g=0; while (s.prompt && g++ < 30 && !s.log.some(l=>/Gunnery Round 1/.test(l.text))) act(s, s.prompt.kind==='info'?'ok':(s.prompt.kind==='lineup'?{attackers:s.prompt.candidates,tows:{}}:(s.prompt.options?s.prompt.options[0].id:[]))); } catch(e) {}
   var gr = s.log.filter(l => /Gunnery Round 1/.test(l.text)); if (gr.length) { cnt++; if (/→ End\\b|END –/.test(gr[0].text)) ends++; } }`);
eq('Breakout Gunnery Round 1 never resolves as END (300 seeds)', X('[cnt > 200, ends]'), [true, 0]);
X(`var cnt2 = 0, ends2 = 0; for (var sd = 1; sd <= 300; sd++) { var s = fresh('US', 4000 + sd); stageCombat(s, 'SAC', ['madison'], ['wolfe'], 'US');
   s.calls = [{ proc: 'combat', pc: 'start', A: { attacker: 'US', segment: 'patrol', decided: true }, L: {} }]; try { run(s); var g=0; while (s.prompt && g++ < 30 && !s.log.some(l=>/Gunnery Round 1/.test(l.text))) act(s, s.prompt.kind==='info'?'ok':(s.prompt.kind==='lineup'?{attackers:s.prompt.candidates,tows:{}}:(s.prompt.options?s.prompt.options[0].id:[]))); } catch(e) {}
   var gr = s.log.filter(l => /Gunnery Round 1/.test(l.text)); if (gr.length) { cnt2++; if (/→ End[^,]/.test(gr[0].text + " ")) ends2++; } }`);
eq('control: same seeds as a normal Encounter do give END', X('ends2 > 10'), true);
console.log(out.join('\n')); console.log(`\n${pass} pass, ${fail} fail`);
