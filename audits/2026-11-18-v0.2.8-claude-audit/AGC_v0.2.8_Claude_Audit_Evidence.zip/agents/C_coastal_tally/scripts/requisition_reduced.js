// Finding probe: a Reduced ship taken by the Requisition Coastal Event (cards 26-28) comes back from requisition
// into the Deployable area still Reduced (and keeps a Last Step marker), skipping In Transit / Repairing.
const fs = require('fs'), path = require('path');
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
X(`var __stopTally = false, __stopA4turn = -1; (function(){ const oT = PROCS.tally.start; PROCS.tally.start = function(s,f){ if (__stopTally) return P(info('STOPT','stop'), 'start'); return oT(s,f); };
     const oA4 = PROCS.turn.A4; PROCS.turn.A4 = function(s,f){ if (s.turn === __stopA4turn && !f.L['__seen' + s.turn]) { f.L['__seen' + s.turn] = true; return P(info('STOPA4','stop'), 'A4'); } return oA4(s,f); }; })();
   function drive(s, stop) { var g=0; while (s.prompt && s.prompt.title !== stop && g++ < 400) { var p = s.prompt; act(s, p.kind==='info'?'ok':p.kind==='choice'?(p.options.find(o=>o.primary)||p.options[0]).id:p.kind==='select'?(p.initial||[]):p.kind==='lineup'?{attackers:p.candidates,tows:p.defaultTows||{}}:{forces:[],flagship:p.flagship}); } return s.prompt && s.prompt.title; }`);
// British campaign, July I (turn 2) Coastal Action: Wolfe (full) + Lord Beresford (Reduced) on an Army Support mission to Niagara.
X(`var s = fresh('BR', 81); s.phase='coastal'; s.coastal={raids:[],battles:[],cutouts:[]}; s.troops.BR.available = 0;
   var f = newForce(s,'BR','NIA','ArmySupport',['wolfe','beres']); f.troops = 1; s.ships.beres.steps = 1;   // Beresford on her Reduced side
   s.deck.event = [26].concat(s.deck.event.filter(n => n !== 26));                                          // Requisition (card 26)
   s.calls = [{ proc: 'turn', pc: 'E', A: {}, L: {} }]; run(s); drive(s, 'Tally – July I');`);
fs.writeFileSync(path.join(__dirname, '..', 'R1_requisition_reduced_at_Tally.json'), JSON.stringify({ state: JSON.parse(X('JSON.stringify(s)')), undo: [] }));
const r = {};
r.tally = X(`[s.prompt.title, s.ships.beres.flags.requisition, s.log.filter(l=>/Requisition:/.test(l.text)).map(l=>l.text).pop()]`);
X(`__stopA4turn = 3; drive(s, 'STOPA4'); var j2 = [TURN_NAMES[s.turn], s.ships.beres.box, s.ships.beres.steps];`); r.julyII = X('j2');
X(`__stopA4turn = 4; act(s,'ok'); drive(s, 'STOPA4'); var a1 = [TURN_NAMES[s.turn], s.ships.beres.box, s.ships.beres.steps, isFull(s.ships.beres)];`); r.augI = X('a1');
X(`fs_save = JSON.stringify(s);`);
fs.writeFileSync(path.join(__dirname, '..', 'R1_requisition_reduced_back_AugI_A4.json'), JSON.stringify({ state: JSON.parse(X('fs_save')), undo: [] }));
X(`var pool = assignableShips(s, 'BR').map(sh => sh.id + ':' + sh.steps);`); r.assignable = X('pool');
// control: a Reduced ship that simply returns at F7 goes to In Transit -> Repairing -> Deployable at full strength
X(`var c = fresh('BR', 82); newForce(c,'BR','NIA','Patrol',['beres']); c.ships.beres.steps = 1; c.phase='tally'; waitAt(c,'tally','reset'); act(c,'ok'); var c1 = [c.ships.beres.box, c.ships.beres.steps];`);
r.control = X('c1');
// Last Step marker kept: Wolfe at 1 step requisitioned
X(`var w = fresh('BR', 83); w.phase='tally'; newForce(w,'BR','NIA','ArmySupport',['wolfe']); w.ships.wolfe.steps = 1; w.ships.wolfe.flags.requisition = true; waitAt(w,'tally','reset'); act(w,'ok'); var w1 = [w.ships.wolfe.box, w.ships.wolfe.steps];`);
r.wolfeLastStep = X('w1');
console.log(JSON.stringify(r, null, 1));
// Same F7 branch: a requisitioned ship that is marked Isolated in this Tally (F6) keeps port 'home'
X(`var q = fresh('BR', 84); q.phase='tally'; q.coastal={raids:[],battles:[],cutouts:[]}; q.troops.BR.available=0;
   newForce(q,'BR','NIA','ArmySupport',['moira']); q.ships.moira.flags.requisition = true; newForce(q,'BR','NOR','Patrol',['sss']);
   q.zones.KIN.control = 'US'; newForce(q,'US','KIN','Patrol',['madison','oneida','tompkins','fairam']);
   waitAt(q,'tally','start'); act(q,'ok'); act(q,'ok'); var iso = [q.zones.KIN.blockade, ['moira','sss'].map(id => [id, q.ships[id].box, q.ships[id].isolated, q.ships[id].port])];`);
console.log('Isolated in the same Tally:', JSON.stringify(X('iso')), '<- Sir Sidney Smith goes to the Isolated (temp) area; requisitioned Moira keeps port home');
X(`q.turn = q.ships.moira.flags.reqUntil; q.prompt = null; q.calls = [{proc:'turn', pc:'A2', A:{}, L:{}}];
   (function(){ const o = PROCS.turn.A3; PROCS.turn.A3 = function(s,f){ return P(info('STOPA3','x'),'A3'); }; run(q); PROCS.turn.A3 = o; })();
   var ret = [TURN_NAMES[q.turn], q.zones.KIN.blockade, q.ships.moira.box, q.ships.moira.port, q.ships.moira.isolated, assignableShips(q,'BR').map(sh=>sh.id)];`);
console.log('Back from requisition with Kingston still Blockaded:', JSON.stringify(X('ret')), '<- Moira is Isolated but sits in the blockaded Kingston Deployable area, so she cannot be assigned');
