// Boundary checks for Coastal Action and Tally & Reset (expected values from the printed rules).
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
X(`var __F = { d6: [], d10: [], d10r: [] };
   (function(){ const o6 = d6, o10 = d10, o10r = d10r;
     d6 = function(s){ return __F.d6.length ? __F.d6.shift() : o6(s); };
     d10 = function(s){ return __F.d10.length ? __F.d10.shift() : o10(s); };
     d10r = function(s){ return __F.d10r.length ? __F.d10r.shift() : o10r(s); }; })();
   function T0(side, seed){ var s = fresh(side, seed); s.convoys.US[2] = {real:false,revealed:true}; s.convoys.BR[2] = {real:false,revealed:true}; s.convoys.US[3] = {real:false,revealed:true}; s.convoys.BR[3] = {real:false,revealed:true}; s.coastal = {raids:[],battles:[],cutouts:[]}; s.troops[s.human].available = 0; s.phase='tally'; return s; }
   function tally(s){ waitAt(s, 'tally', 'start'); act(s, 'ok'); return s; }`);
let pass = 0, fail = 0; const out = [];
const eq = (name, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); ok ? pass++ : fail++; out.push(`${ok ? 'PASS' : 'FAIL'} ${name}: got ${JSON.stringify(got)}${ok ? '' : ' want ' + JSON.stringify(want)}`); };
// ---- Convoy Supply track edges (F5, F5.3, 5.4; sidebar "beyond -1 ignored") ----
X(`var s = T0('US', 1); s.supply.US = 0; s.coastal.battles = [{side:'BR', target:'HOME', zone:'SAC', result:'AS'}]; tally(s);`);
eq('US at 0, enemy Land Battle success vs Homeport (-2) -> -1 (clamped)', X('s.supply.US'), -1);
X(`var s = T0('US', 1); s.supply.US = -1; s.coastal.battles = [{side:'BR', target:'HOME', zone:'SAC', result:'AF'}]; __F.d6=[1,1]; tally(s);`);
eq('US at -1, enemy Feat of Arms vs Homeport -> stays -1', X('s.supply.US'), -1);
X(`var s = T0('BR', 2); s.supply.BR = 10; s.convoys.BR[2] = {real:true,revealed:true,delay:false,deployed:false,result:null}; s.coastal.battles = [{side:'US', target:'HOME', zone:'KIN', result:'AS'}]; tally(s);`);
eq('BR 10 +2 convoy -> 12 (Fall Offensive), then enemy -2 is ignored at 12', X('[s.supply.BR, s.fallOffensive, s.vp.BR]'), [12, 'BR', 5]);
X(`var s = T0('BR', 3); s.supply.BR = 10; s.supply.US = 11; s.convoys.BR[2] = {real:true,revealed:true,delay:false,deployed:false,result:null}; s.convoys.US[2] = {real:true,revealed:true,delay:false,deployed:false,result:null}; tally(s);`);
eq('both sides reach 12 in the same F5 -> no VPs', X('[s.supply.US, s.supply.BR, s.fallOffensive, s.vp.US, s.vp.BR]'), [12, 12, 'both', 0, 0]);
X(`var s = T0('BR', 4); s.supply.US = 12; s.fallOffensive = 'US'; s.supply.BR = 11; s.convoys.BR[2] = {real:true,revealed:true,delay:false,deployed:false,result:null}; tally(s);`);
eq('second side to reach 12 scores nothing', X('[s.supply.BR, s.vp.BR]'), [12, 0]);
X(`var s = T0('BR', 5); s.supply.US = 12; s.supply.BR = 3; s.coastal.raids = [{side:'BR', zone:'SAC', forceId:'x', guns:20, events:[]}]; __F.d6=[6]; tally(s);`);
eq('raid 5-6 vs a side at 12: raider +1, defender stays at 12', X('[s.supply.BR, s.supply.US, s.vp.BR]'), [4, 12, 2]);
X(`var s = T0('BR', 6); s.supply.BR = 12; s.fallOffensive='BR'; s.convoys.US[2] = {real:true,revealed:true,delay:false,deployed:false,result:'C'}; tally(s);`);
eq('convoy captured by a side already at 12 -> stays 12, owner no advance', X('[s.supply.BR, s.supply.US]'), [12, 1]);
X(`var s = T0('US', 7); s.supply.US = 2; s.convoys.US[2] = {real:true,revealed:true,delay:false,deployed:false,result:'S'}; tally(s); var p1 = s.supply.US; waitAt(s,'tally','reset'); act(s,'ok');`);
eq('scattered convoy: no advance now, Arrived at F7', X('[p1, s.pendingConvoy.US.map(p=>p.status)]'), [2, ['arrived']]);
X(`s.turn = 3; s.coastal={raids:[],battles:[],cutouts:[]}; s.lossesThisTurn=[]; s.zones.SAC.blockade='BR'; s.zones.SAC.control='BR'; newForce(s,'BR','SAC','Patrol',['wolfe','rg','moira','beres']); tally(s);`);
eq('Arrived convoy while Blockaded stays pending (no +2)', X('[s.supply.US, s.pendingConvoy.US.length]'), [2, 1]);
// ---- Raid VPs and Coastal Events (F4 / F5.3, cards 20-22, 32-35) ----
const raid = (side, zone, events, guns, dice) => { X(`var s = T0('${side === 'US' ? 'BR' : 'US'}', 8); s.coastal.raids = [{side:'${side}', zone:'${zone}', forceId:'x', guns:${guns}, events:${JSON.stringify(events)}}]; __F.d6=${JSON.stringify(dice)}; tally(s);`); return X(`[s.vp.US - 0, s.vp.BR - 0, s.supply.US, s.supply.BR]`); };
eq('US raid Kingston, d6 4 -> +2 VP, no supply', raid('US', 'KIN', [], 10, [4]), [2, 0, 1, 1]);
eq('US raid York, d6 5 -> +1 VP, US +1 / BR -1', raid('US', 'YOR', [], 10, [5]), [1, 0, 2, 0]);
eq('BR raid Sackets -> 2 VP (British)', raid('BR', 'SAC', [], 10, [1]), [0, 2, 1, 1]);
eq('BR raid South Lake, d6 6 -> 1 VP, BR +1, US -1', raid('BR', 'SOU', [], 10, [6]), [0, 1, 0, 2]);
eq('Local Militia 1d6 3 > 2 guns -> no VP, no supply roll', raid('US', 'KIN', ['localMilitia'], 2, [3, 6]), [0, 0, 1, 1]);
eq('Local Militia 1d6 2 = 2 guns -> raid stands; supply d6 5', raid('US', 'KIN', ['localMilitia'], 2, [2, 5]), [2, 0, 2, 0]);
eq('Supplies Burned: d6 5 is not enough', raid('US', 'KIN', ['suppliesBurned'], 9, [5]), [2, 0, 1, 1]);
eq('Supplies Burned: d6 6 seizes', raid('US', 'KIN', ['suppliesBurned'], 9, [6]), [2, 0, 2, 0]);
eq('Supplies Moved: no VP, no supply', raid('BR', 'SAC', ['suppliesMoved'], 9, [6]), [0, 0, 1, 1]);
eq('Sudden Storm on a 2-VP target: 1 VP, no supply', raid('BR', 'SAC', ['suddenStorm'], 9, [6]), [0, 1, 1, 1]);
eq('Sudden Storm on a 1-VP target: 0 VP', raid('US', 'YOR', ['suddenStorm'], 9, [6]), [0, 0, 1, 1]);
// ---- Niagara Front and Army Victory (F3.2 / F3.2.1) ----
const nia = (side, res, start, turn, ctl, kinBlk) => { X(`var s = T0('US', 9); s.turn=${turn}; s.niagara=${start}; s.zones.NIA.control=${JSON.stringify(ctl)}; ${ctl ? `newForce(s,'${ctl}','NIA','Patrol', ${ctl === 'BR' ? "['wolfe','rg']" : "['madison','oneida']"});` : ''} ${kinBlk ? "s.zones.KIN.blockade='US'; s.zones.KIN.control='US'; newForce(s,'US','KIN','Patrol',['pike','sylph','madison','oneida'].filter(x=>s.ships[x].box!=='lake')); s.ships.pike.box='lake'; s.ships.sylph.box='lake';" : ''} s.coastal.battles=[{side:'${side}', target:'NIA', zone:'NIA', result:'${res}'}]; tally(s);`); return X('[s.niagara, s.vp.US, s.vp.BR]'); };
eq('BR AF at 4 -> 6 (clamped 7), turn 6 no victory check', nia('BR', 'AF', 4, 6, 'BR', false).slice(0, 1), [6]);
eq('US DM (British Major Success) moves right 2', nia('US', 'DM', 3, 2, null, false)[0], 5);
eq('US DS moves right 1; BR DS moves left 1', [nia('US', 'DS', 3, 2, null, false)[0], nia('BR', 'DS', 3, 2, null, false)[0]], [4, 2]);
eq('Sept II: BR Success to Fort George + BR control of Niagara -> -10 VP', nia('BR', 'AS', 5, 7, 'BR', false), [6, 0, 10 + 1]);
eq('Sept II: US AF to Burlington, Niagara Contested -> +10', nia('US', 'AF', 2, 7, null, false), [0, 10, 0]);
eq('Sept II: US at Burlington but Niagara British -> no victory', nia('US', 'AS', 1, 7, 'BR', false), [0, 0, 1]);
// ---- Victory levels with Construction Delay deducted (3.3.2) ----
const lvl = (us, br, cdUS, cdBR) => { X(`var s = fresh('US', 10); s.vp.US=${us}; s.vp.BR=${br}; s.cd.US=${cdUS}; s.cd.BR=${cdBR}; endGame(s);`); return X('[s.result.score, s.result.level]'); };
[[33, 0, 0, 0, 'U.S. Decisive Victory'], [32, 0, 0, 0, 'U.S. Victory'], [22, 0, 0, 0, 'U.S. Victory'], [21, 0, 0, 0, 'U.S. Marginal Victory'], [11, 0, 0, 0, 'U.S. Marginal Victory'], [10, 0, 0, 0, 'Draw'],
 [0, 10, 0, 0, 'Draw'], [0, 11, 0, 0, 'British Marginal Victory'], [0, 21, 0, 0, 'British Marginal Victory'], [0, 22, 0, 0, 'British Victory'], [0, 32, 0, 0, 'British Victory'], [0, 33, 0, 0, 'British Decisive Victory'],
 [35, 0, 3, 0, 'U.S. Victory'], [0, 13, 0, 2, 'British Marginal Victory'], [0, 12, 0, 2, 'Draw'], [12, 0, 2, 0, 'Draw'], [20, 20, 0, 0, 'Draw']].forEach(([u, b, cu, cb, want]) => {
  const r = lvl(u, b, cu, cb); eq(`final US ${u} BR ${b} CD ${cu}/${cb}`, r[1], want);
});
// ---- Fall Offensive + land battle in the same F5: order 5.1 then 5.3 ----
X(`var s = T0('US', 11); s.supply.US = 11; s.convoys.US[2] = {real:true,revealed:true,delay:false,deployed:false,result:null}; s.coastal.battles=[{side:'BR', target:'HOME', zone:'SAC', result:'AS'}]; tally(s);`);
eq('US 11 +2 -> 12 then enemy success -2 ignored (stays 12, +5)', X('[s.supply.US, s.vp.US]'), [12, 5]);
console.log(out.join('\n')); console.log(`\n${pass} pass, ${fail} fail`);
