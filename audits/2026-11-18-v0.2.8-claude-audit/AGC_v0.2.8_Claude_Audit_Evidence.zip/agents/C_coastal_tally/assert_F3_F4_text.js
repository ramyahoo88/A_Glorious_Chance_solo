// F3: the manual Land Battle prompt tells the player to shift "-2 column(s) left".
// F4: a Harbor Encounter screen with an empty defender list when the A.I. British port holds only Converted Laker Schooners.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let bad = 0;
X(`var s = fresh('BR', 47); s.phase='coastal'; s.coastal={raids:[],battles:[],cutouts:[]}; s.options.confirmAiSteps=false; s.options.manualLandBattle=true;
   sideShips(s,'US').forEach(sh => { if (sh.box==='deployable') sh.box='repairing'; });
   var f = newForce(s,'BR','NIA','ArmySupport',['wolfe','rg','moira']); f.troops = 1; s.deck.event=[36].concat(s.deck.event.filter(n=>n!==36));
   s.calls=[{proc:'coastal',pc:'start',A:{},L:{}}]; run(s); var g=0; while (s.prompt && s.prompt.kind==='info' && g++<20) act(s,'ok'); var t3 = s.prompt.text;`);
const t3 = X('t3'); const m = /shifted [^,]* left/.exec(t3);
console.log('F3 prompt:', m && m[0]); if (/shifted -\d/.test(t3)) { bad++; console.log('F3 FAIL: negative number with "left"'); }
X(`var u = fresh('US', 46); u.phase='coastal'; u.coastal={raids:[],battles:[],cutouts:[]}; u.options.confirmAiSteps=false;
   sideShips(u,'BR').forEach(sh => { if (sh.box==='deployable') sh.box='repairing'; });
   u.ships.julia.owner='BR'; u.ships.julia.box='transit'; u.ships.julia.steps=0; u.ships.julia.port='home';   // captured earlier this turn
   var fu = newForce(u,'US','KIN','ArmySupport',['madison','oneida']); fu.troops = 1; u.deck.event=[1].concat(u.deck.event.filter(n=>n!==1));
   u.calls=[{proc:'coastal',pc:'start',A:{},L:{}}]; run(u); var titles=[]; var g=0; while (u.prompt && g++<20 && !/^Tally/.test(u.prompt.title)) { titles.push(u.prompt.title + ' :: ' + u.prompt.text.slice(0,140)); act(u, u.prompt.kind==='info'?'ok':u.prompt.options[0].id); }`);
const titles = JSON.parse(X('JSON.stringify(titles)')); const h = titles.find(t => /^Harbor Encounter ::/.test(t));
console.log('F4 screen:', h); if (h && /in port: \./.test(h)) { bad++; console.log('F4 FAIL: Harbor Encounter announced with no defenders'); }
process.exit(bad ? 1 : 0);
