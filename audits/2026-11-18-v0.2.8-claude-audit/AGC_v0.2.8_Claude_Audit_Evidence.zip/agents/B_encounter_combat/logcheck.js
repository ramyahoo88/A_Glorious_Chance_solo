// Log-consistency check over full campaigns: every printed die roll in Lake Combat is re-read against the
// printed tables (LCT cell for column + modified roll, Strike Check bands, Disengagement 1-3, Leader Casualty
// 2-9/10/11+, untowed-schooner DRM bands, Close Action roll <= difference, Melee 150%, Hit Distribution).
// node logcheck.js [startSeed] [count]
const ARGS = process.argv.slice(2); process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const H = require('/home/claude/audit028/harness.js')();
const ctx = H.ctx;
const start = +(ARGS[0] || 500000), count = +(ARGS[1] || 100);
const PRINTED = ['A6 A2W A2 A1/D1 D1 D1W D2', 'A5 A2 A1W D1 D1W D2 D2W', 'A4 A1W A1 D1W D2 D2W D3', 'A3 A1 End D2 D2W D3 A1/D3W',
  'A3 End A1/D1 D2W D3 A1/D3W D4', 'A2 A1/D1 D1 A1/D2 D3W D4 D4W', 'A1 D1 D1W D3W D4 D4W A1/D5', 'A1 D1W A1/D2 D3 D4W A1/D5 D6',
  'End D2 A1/D2W A1/D3W D5 D5W A1/D7', 'A1/D1 D2W D3 A1/D4 A1/D6 D6 D7'].map(r => r.split(' '));
const COLS = ['1:2-', '1:1.5', '1:1', '1.5:1', '2:1', '2.5:1', '3:1+'];
const HD = { 1: [36], 2: [18, 18], 3: [12, 12, 12], 4: [9, 9, 9, 9], 5: [7, 7, 8, 7, 7], 6: [6, 6, 6, 6, 6, 6], 7: [5, 5, 5, 6, 5, 5, 5], 8: [3, 5, 5, 5, 5, 5, 5, 3], 9: Array(9).fill(4),
  10: [2, 4, 4, 4, 4, 4, 4, 4, 4, 2], 11: [1, 4, 4, 4, 5, 4, 4, 4, 4, 1, 1], 12: Array(12).fill(3), 13: [1].concat(Array(11).fill(3), [2]), 14: [2].concat(Array(10).fill(3), [2, 1, 1]),
  15: [2, 2, 2, 2, 2, 2, 4, 4, 4, 2, 2, 2, 2, 2, 2], 16: [2, 2, 2, 2, 2, 2, 2, 4, 4, 2, 2, 2, 2, 2, 2, 2], 17: [2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2], 18: Array(18).fill(2) };
const hdPos = (n, v) => { const idx = (Math.floor(v / 10) - 1) * 6 + (v % 10 - 1); let acc = 0; for (let i = 0; i < HD[n].length; i++) { acc += HD[n][i]; if (idx < acc) return i + 1; } };
const c = { lct: 0, strike: 0, dis: 0, leader: 0, untowed: 0, ca: 0, melee: 0, hd: 0, flagTry: 0 }, bad = [];
const B = (k, t, why) => { if (bad.length < 40) bad.push(`${k}: ${why} | ${t}`); };
for (let i = 0; i < count; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const s = ctx.newGame(side, start + i, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 4 === 0 });
  ctx.run(s); let n = 0;
  while (!s.over && n++ < 2500) {
    const was = s.log.length; ctx.act(s, policy(s, s.prompt, style));
    for (const { text: t } of s.log.slice(was)) {
      let m;
      if ((m = /^Gunnery Round [12]: .*→ column (\S+?)(?: \([^)]*\))?\. d10 (.*?)(?: \[(.*)\])? → (\S+)/.exec(t))) {
        const col = COLS.indexOf(m[1]); const rolls = m[2].split(', then ');
        const drms = m[3] ? m[3].split('; ').map(x => +(/^([+\-−]?\d+)/.exec(x)[1].replace('−', '-'))) : [];
        const drm = drms.reduce((a, b) => a + b, 0);
        rolls.forEach(r => { const mm = /^(\d)(?:([+-]\d+)=(\d))? (\S+)$/.exec(r); if (!mm) return B('LCT', t, 'unparsed roll ' + r); c.lct++;
          const raw = +mm[1], mod = Math.max(0, Math.min(9, raw + drm)); if (mm[3] !== undefined && +mm[3] !== mod) B('LCT', t, 'modified roll'); if (PRINTED[mod][col] !== mm[4]) B('LCT', t, `cell ${mod}/${m[1]} is ${PRINTED[mod][col]}`); });
        const um = /([-\d]+) untowed Laker Schooners \((\d+), d6 (\d)\)/.exec(t);
        if (um) { c.untowed++; const n_ = +um[2], r = +um[3]; const want = r <= n_ / 2 ? -2 : r <= n_ ? -1 : 0; if (+um[1] !== want) B('untowed', t, 'want ' + want); }
      }
      if ((m = /Strike Check (\d+)([+-]\d+)? – (FIGHT ON|STRIKES COLORS|Strikes Colors|SINKS)/.exec(t))) {
        c.strike++; const tot = +m[1] + (+m[2] || 0); const want = tot <= 2 ? 'FIGHT ON' : tot <= 8 ? 'STRIKES' : 'SINKS'; if (!m[3].toUpperCase().startsWith(want)) B('strike', t, 'want ' + want);
        if (+m[1] < 1 || +m[1] > 10) B('strike', t, 'd10 read 1-10');
      }
      if ((m = /Disengagement Check (.*) – (DISENGAGED|fails)/.exec(t))) {
        c.dis++; const rr = m[1].split(', ').map(x => { const q = /^(\d)(-\d+)?$/.exec(x); return +q[1] + (+q[2] || 0); });
        const ok = rr.some(v => v <= 3), last = rr[rr.length - 1];
        if ((m[2] === 'DISENGAGED') !== ok || (m[2] === 'DISENGAGED' && last > 3)) B('dis', t, 'band 1-3');
      }
      if ((m = /Leader Casualty Check \(.*\): 2d6 (\d+)(?:\+(\d+))? – (no effect|wounded|KILLED)/.exec(t))) {
        c.leader++; const tot = +m[1] + (+m[2] || 0); const want = tot >= 11 ? 'KILLED' : tot === 10 ? 'wounded' : 'no effect'; if (m[3] !== want) B('leader', t, 'want ' + want);
      }
      if ((m = /tries to shift his flag – 2d6 (\d+): (KILLED|wounded)/.exec(t)) || (m = /shifts his flag to .* \(2d6 (\d+)\)/.exec(t))) {
        c.flagTry++; const r = +m[1]; const want = r >= 11 ? 'KILLED' : r === 10 ? 'wounded' : undefined; if (m[2] !== want) B('flag', t, 'band');
      }
      if ((m = /\(CA (\d+)\) vs .* \(CA (\d+)\): d10 (\d+) (≤|>) (-?\d+) – (HIT|MELEE)/.exec(t)) || (m = /^(.*?) vs .*: d10 (\d+) > (-?\d+) – /.exec(t) && null)) {
        c.ca++; const diff = +m[1] - +m[2]; if (+m[5] !== diff) B('CA', t, 'difference'); if ((+m[3] <= diff) !== (m[4] === '≤')) B('CA', t, 'compare'); if (+m[1] < 2 * +m[2]) B('CA', t, 'not 2:1');
      }
      if ((m = /MELEE (\d)\+(\d+)=(\d+) vs (\d)\+(\d+)=(\d+) – (.*)$/.exec(t))) {
        c.melee++; const ma = +m[3], md = +m[6]; const cap = /CAPTURED/.test(m[7]); if (cap !== (ma >= 1.5 * md || md >= 1.5 * ma)) B('melee', t, '150%');
        if (ma !== +m[1] + +m[2] || md !== +m[4] + +m[5]) B('melee', t, 'sum');
      }
      if ((m = /hit distribution \((\d+)-ship column[^)]*\): (.*)\.$/.exec(t))) {
        const N = +m[1]; m[2].split(', ').forEach(x => { const q = /^(\d\d)→#(\d+)/.exec(x); if (!q) return; c.hd++; if (HD[N] && hdPos(N, +q[1]) !== +q[2]) B('hitdist', t, `col ${N} roll ${q[1]}`); });
      }
    }
  }
}
console.log('checked:', JSON.stringify(c));
console.log(bad.length ? bad.join('\n') : 'no inconsistencies');
