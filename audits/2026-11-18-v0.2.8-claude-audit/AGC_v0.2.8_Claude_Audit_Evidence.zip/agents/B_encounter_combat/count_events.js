// Frequency of the F3 / F4 situations in policy play.
const ARGS = process.argv.slice(2); process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const H = require('/home/claude/audit028/harness.js')();
const ctx = H.ctx;
const start = +(ARGS[0] || 900000), count = +(ARGS[1] || 250);
const r = { games: 0, pursuitVsHuman: 0, pursuitVsHumanWithStruck: 0, humanFlagReducedInCA: 0 };
for (let i = 0; i < count; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const s = ctx.newGame(side, start + i, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 4 === 0 }); ctx.run(s); r.games++;
  let n = 0;
  while (!s.over && n++ < 2500) {
    const p = s.prompt, flag = s.flagship[s.human], wasSteps = s.ships[flag].steps, inCA = !!(s.combat && /^Close Action Round/.test(p.title || '')) ;
    const caPending = s.calls.some(f => f.proc === 'combat' && (f.pc === 'ca2'));
    const was = s.log.length; ctx.act(s, policy(s, p, style));
    const add = s.log.slice(was).map(l => l.text);
    if (add.some(t => /^Pursuit! The withdrawal is cancelled/.test(t)) && s.combat === null || add.some(t => /^Pursuit! The withdrawal is cancelled/.test(t))) {
      // pursued side = defender of the Round that triggered it
      const gr = s.log.map(l => l.text).filter(t => /^Gunnery Round [12]: /.test(t)).pop();
      const def = /vs (U\.S\.|British) /.exec(gr)[1] === 'U.S.' ? 'US' : 'BR';
      if (def === s.human) { r.pursuitVsHuman++; if (add.some(t => /CAPTURED by the/.test(t))) r.pursuitVsHumanWithStruck++; }
    }
    if (add.some(t => new RegExp('^' + ctx.def(s.ships[flag]).name.replace(/[()]/g, '.') + '.* takes 1 hit\\(s\\) and is flipped').test(t)) && add.some(t => /\(CA \d+\) vs /.test(t)) && s.flagship[s.human] === flag && s.encounter && s.encounter.ships[flag] === 'in') r.humanFlagReducedInCA++;
  }
}
console.log(JSON.stringify(r));
