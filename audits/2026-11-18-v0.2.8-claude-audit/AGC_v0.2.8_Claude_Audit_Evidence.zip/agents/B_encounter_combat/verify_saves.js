// Loads every save in ./saves through the app's own checkSaveState and replays the key step.
const fs = require('fs'), path = require('path');
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
const dir = path.join(__dirname, 'saves');
const steps = {
  'F1a_AI_missed_signal_attacks_below_1to1.json': [`act(s,'confront')`, `s.prompt.text`],
  'F1b_AI_declines_counting_your_missed_signal_ship.json': [`act(s,'confront')`, `s.prompt.text`],
  'F2_natural_AI_US_before_Gunnery_Round_2.json': [`act(s,'ok')`, `s.log.map(l=>l.text).find(t=>/^Gunnery Round 2:/.test(t))`],
  'F3_AI_pursuit_vs_your_optional_withdrawal.json': [`act(s,'ok'); var _t1 = s.prompt.title; act(s,'ok')`, `_t1 + ' → ' + s.prompt.title + ': ' + s.prompt.text`],
  'F4_flagship_reduced_in_close_action.json': [`act(s,'ok')`, `s.prompt.text`],
  'F5_preview_vs_AI_US_attack_without_untowed.json': [`act(s,'confront')`, `s.prompt.text`],
  'F6_missed_signal_ship_left_out_of_line.json': [`act(s,{attackers:['madison'],tows:{}})`, `'missedSignalUsed=' + !!s.zones.NOR.flags.missedSignalUsed + ' pending=' + missedSignalShip(s)`],
};
for (const f of fs.readdirSync(dir).sort()) {
  const txt = fs.readFileSync(path.join(dir, f), 'utf8');
  X(`var s = checkSaveState(JSON.parse(${JSON.stringify(txt)}).state);`);
  const [a, show] = steps[f];
  X(a);
  console.log(`${f}\n  build ${X('s.build')} | ${X(show).replace(/\n/g, ' / ').slice(0, 330)}`);
}
