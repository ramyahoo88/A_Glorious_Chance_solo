// Reproductions for the confirmed findings (A Glorious Chance Solo Companion v0.2.8, commit ffd7317).
// node repro_findings.js        -> prints each check; "REPRODUCED" means the defect shows, "control ok" means
//                                  the nearby case behaves as expected. Also writes importable saves to ./saves/.
const fs = require('fs'), path = require('path');
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
const SAVES = path.join(__dirname, 'saves');
let bad = 0;
const check = (label, cond, info) => { console.log(`${cond ? 'REPRODUCED' : 'NOT reproduced'} – ${label}${info ? '\n    ' + info : ''}`); if (!cond) bad++; };
const control = (label, cond, info) => { console.log(`${cond ? 'control ok' : 'CONTROL FAILED'} – ${label}${info ? '\n    ' + info : ''}`); if (!cond) bad++; };
const save = (name) => { const txt = X(`JSON.stringify({state: s, undo: []})`); fs.writeFileSync(path.join(SAVES, name), txt);
  // the save must pass the app's own loader
  X(`var __chk = checkSaveState(JSON.parse(${JSON.stringify(txt)}).state)`); return txt; };
const line = re => X(`(s.prompt ? s.prompt.text : '').split('\\n').find(l => ${re}.test(l)) || ''`);

/* ---------------------------------------------------------------- F1 Missed Signal and the A.I. attack test */
console.log('\n== F1  A.I. LC1 precondition counts the Missed Signal ship ==');
// (a) U.S. campaign: Wolfe (A.I.) missed the signal. Preview 0.59:1, but the A.I. counts Wolfe (1.41:1) and attacks.
X(`var s = fresh('US', 101);
var _u = newForce(s,'US','NOR','Patrol',['madison']); var _b = newForce(s,'BR','NOR','Patrol',['wolfe','rg']);
s.zones.NOR.event = 35; s.zones.NOR.flags.missedSignal = 'wolfe';
s.deck.event = [20].concat(s.deck.event.filter(n=>n!==20));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', humanForces:[_u.id], aiForces:[_b.id], peNum:1}, L:{}}];
run(s); act(s,'ok');`);
save('F1a_AI_missed_signal_attacks_below_1to1.json');
let prev = line('/^Odds if the A\\.I\\. attacks/');
X(`act(s,'confront')`);
let dec = X('s.prompt.title + ": " + s.prompt.text');
X(`act(s,'ok'); while (s.prompt && !/Gunnery Round/.test(s.prompt.text)) act(s, s.prompt.kind==='choice' ? s.prompt.options[0].id : 'ok');`);
let gr1 = X(`s.log.map(l=>l.text).find(t=>/^Gunnery Round 1:/.test(t))`);
check('A.I. attacks although the first Round is below 1:1', /A\.I\. attacks|attacks!/.test(dec) && /0\.59:1/.test(gr1), `${prev}\n    ${dec.replace(/\n/g, ' ')}\n    ${gr1}`);
// (b) the human's Missed Signal ship (Gen. Pike) is counted: the A.I. declines although its first Round would be 6.5:1
X(`var s = fresh('US', 102);
var _u = newForce(s,'US','NOR','Patrol',['pike','tompkins']); var _b = newForce(s,'BR','NOR','Patrol',['wolfe','moira']);
s.zones.NOR.event = 13; s.zones.NOR.flags.missedSignal = 'pike';
s.deck.event = [20].concat(s.deck.event.filter(n=>n!==20));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', humanForces:[_u.id], aiForces:[_b.id], peNum:1}, L:{}}];
run(s); act(s,'ok');`);
save('F1b_AI_declines_counting_your_missed_signal_ship.json');
prev = line('/^Odds if the A\\.I\\. attacks/');
X(`act(s,'confront')`);
dec = X('s.prompt.title + ": " + s.prompt.text');
check('A.I. declines although the first Round would be 6.5:1', /declines battle/.test(dec) && /6\.5:1/.test(prev), `${prev}\n    ${dec.replace(/\n/g, ' ')}`);
// control: same position without Missed Signal – preview and decision agree (1.41:1, attack)
X(`var s = fresh('US', 101);
var _u = newForce(s,'US','NOR','Patrol',['madison']); var _b = newForce(s,'BR','NOR','Patrol',['wolfe','rg']);
s.zones.NOR.event = 9; s.deck.event = [20].concat(s.deck.event.filter(n=>n!==20));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', humanForces:[_u.id], aiForces:[_b.id], peNum:1}, L:{}}];
run(s); act(s,'ok');`);
prev = line('/^Odds if the A\\.I\\. attacks/'); X(`act(s,'confront')`); dec = X('s.prompt.text');
control('no Missed Signal: preview 1.41:1 = decision 1.41:1', /1\.41:1/.test(prev) && /1\.41:1/.test(dec), prev);

/* ---------------------------------------------------------------- F2 A.I. U.S. Gunnery Round 2 with untowed schooners */
console.log('\n== F2  A.I. U.S. passes the Round-2 test only without its untowed schooners, then fires with them ==');
X(`var s = fresh('BR', 138);
var _u = newForce(s,'US','NOR','Patrol',['madison','oneida','tompkins','fairam']); var _b = newForce(s,'BR','NOR','Patrol',['wolfe','rg']);
s.zones.NOR.event = 9; s.deck.event = [2,3].concat(s.deck.event.filter(n=>n!==2 && n!==3));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', aiForces:[_u.id], humanForces:[_b.id], peNum:1}, L:{}}];
run(s); var _g = 0;
while (s.prompt && _g++ < 40 && !(s.prompt.title === 'Weather Gage recheck')) {
  if (s.prompt.kind==='choice') act(s, s.prompt.options.find(o=>o.id==='stay') ? 'stay' : s.prompt.options[0].id); else act(s,'ok');
}`);
save('F2_natural_AI_US_before_Gunnery_Round_2.json');
const plan = X(`(function(){ var c=s.combat; var att=colShips(c,c.att).filter(id=>isFull(s.ships[id]) && s.encounter.ships[id]==='in'); return JSON.stringify(aiPlanFor(s,'US',att,colShips(c,c.def),false)); })()`);
X(`act(s,'ok')`);
const gr2 = X(`s.log.map(l=>l.text).find(t=>/^Gunnery Round 2:/.test(t))`);
check('Round-2 test passes only without Fair American (1.08:1), Round fought with her at 1.31:1 (needs 1.5:1)', /without its untowed/.test(plan) && /U\.S\. 17 vs British 13 = 1\.31:1/.test(gr2) && /untowed Laker Schooners \(1,/.test(gr2), `plan: ${plan}\n    ${gr2}`);
X(`var s = fresh('BR', 2201); stageCombat(s, 'NOR', ['madison','tompkins'], ['wolfe','rg'], 'US');
s.combat.tows = {madison:'tompkins'}; s.combat.pos = 2; s.combat.gr = 1; s.combat.roundAttackers=['madison','tompkins'];
waitAt(s, 'combat', 'next'); act(s,'ok');`);
control('control: no untowed schooner in the column – Round 2 fought with the ships the test approved (14 vs 13)', /U\.S\. 14 vs British 13/.test(X(`s.log.map(l=>l.text).find(t=>/^Gunnery Round 2:/.test(t)) || ''`)));

/* ---------------------------------------------------------------- F3 Pursuit pre-empts your optional withdrawal */
console.log('\n== F3  A.I. Pursuit cancels a W you were never offered; your struck ship is then captured ==');
X(`var s = fresh('US', 8);
stageCombat(s, 'NOR', ['oneida','tompkins','fairam'], ['wolfe','rg','moira'], 'BR');
s.combat.tac.att = {id:'A_pursuit', used:false, negated:false};
waitAt(s, 'combat', 'grRoll', {}, {st:'GR1'}); afterCombatCaller(s);`);
save('F3_AI_pursuit_vs_your_optional_withdrawal.json');
X(`var _titles = []; act(s,'ok'); _titles.push(s.prompt.title); var _r1 = s.prompt.text; act(s,'ok'); _titles.push(s.prompt.title); var _r2 = s.prompt.text;`);
check('no "Withdrawal result against you" choice; Pursuit captures Fair American', X('_titles.indexOf("Withdrawal result against you") < 0') && /Pursuit!/.test(X('_r1')) && /Fair American is CAPTURED/.test(X('_r2')), `${X('_titles.join(" → ")')}\n    ${X('_r1').split('\n').filter(l=>/D1W|STRIKES|Pursuit/.test(l)).join(' | ')}\n    ${X('_r2').replace(/\n/g, ' ')}`);
X(`var s = fresh('US', 8);
stageCombat(s, 'NOR', ['oneida','tompkins','fairam'], ['wolfe','rg','moira'], 'BR');
waitAt(s, 'combat', 'grRoll', {}, {st:'GR1'}); afterCombatCaller(s); act(s,'ok');`);
control('control: same roll without Pursuit – you are asked whether to withdraw', X('s.prompt.title') === 'Withdrawal result against you', X('s.prompt.title'));

/* ---------------------------------------------------------------- F4 no flag transfer after a Close Action hit */
console.log('\n== F4  Flagship Reduced in Close Action: no flag transfer offered, Command DRM lost ==');
X(`var s = fresh('BR', 6);
stageCombat(s, 'NOR', ['pike'], ['sss','melville'], 'US'); s.flagship.BR = 'melville';
s.combat.pos = 4; s.combat.gr = 2; s.combat.roundAttackers=['pike'];
waitAt(s, 'combat', 'next'); afterCombatCaller(s);
s.deck.event = [25].concat(s.deck.event.filter(n=>n!==25));`);
save('F4_flagship_reduced_in_close_action.json');
X(`var _seen = []; act(s,'ok'); var _ca = s.prompt.text; _seen.push(s.prompt.title); act(s,'ok'); _seen.push(s.prompt.title); act(s, []); _seen.push(s.prompt.title); act(s,'ok'); _seen.push(s.prompt.title);
act(s,'attack'); _seen.push(s.prompt.title); var _opts = JSON.stringify(flagTransferOptions(s,'BR')); var _cands = JSON.stringify(s.prompt.candidates);
act(s,{attackers:s.prompt.candidates,tows:{}}); var _g=0; while (s.prompt && _g++<10) { _seen.push(s.prompt.title); act(s, s.prompt.kind==='choice' ? s.prompt.options[0].id : 'ok'); }
var _gr = s.log.map(l=>l.text).find(t=>/^Gunnery Round 1: British/.test(t));`);
check('Melville (Flagship) Reduced by Close Action, still Engaged; no transfer prompt; Reaction attack without +1 Command', /Lord Melville .*fails, remains Engaged/.test(X('_ca')) && X('_seen.indexOf("Transfer the flag?") < 0') && !/Command/.test(X('_gr')),
  `${X('_ca').split('\n').filter(l => /Melville/.test(l)).join(' | ')}\n    prompts: ${X('_seen.join(" → ")')}\n    transfer options at the Reaction Segment line-up: ${X('_opts')}; attackers offered ${X('_cands')}\n    ${X('_gr')}`);
X(`var s = fresh('BR', 9); stageCombat(s,'NOR',['madison','oneida'],['melville','sss'],'US'); s.flagship.BR='melville';
var _found=false; for (var k=0;k<200 && !_found;k++){ var _t = fresh('BR', 9+k); stageCombat(_t,'NOR',['madison','oneida'],['melville','sss'],'US'); _t.flagship.BR='melville'; waitAt(_t,'combat','grRoll',{},{st:'GR1'}); afterCombatCaller(_t); act(_t,'ok'); if (_t.prompt.title==='Transfer the flag?') _found=true; }`);
control('control: Flagship Reduced in a Gunnery Round – the transfer is offered', X('_found'));

/* ---------------------------------------------------------------- F5 preview ignores the A.I. U.S. retry without untowed schooners */
console.log('\n== F5  Command Decision "Odds if the A.I. attacks" vs the A.I. U.S. attack actually made ==');
X(`var s = fresh('BR', 501);
var _u = newForce(s,'US','NIA','ArmySupport',['fairam','conquest','pike']); var _b = newForce(s,'BR','NIA','Patrol',['wolfe','rg']);
s.ships.wolfe.ver='B'; s.ships.rg.ver='B';
s.zones.NIA.event = 9; s.deck.event = [2].concat(s.deck.event.filter(n=>n!==2));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NIA', kind:'normal', aiForces:[_u.id], humanForces:[_b.id], peNum:1}, L:{}}];
run(s); act(s,'ok');`);
save('F5_preview_vs_AI_US_attack_without_untowed.json');
prev = line('/^Odds if the A\\.I\\. attacks/'); X(`act(s,'confront')`); dec = X('s.prompt.text');
X(`act(s,'ok'); while (s.prompt && !s.log.some(l=>/^Gunnery Round 1:/.test(l.text))) act(s, s.prompt.kind==='choice' ? s.prompt.options[0].id : 'ok');`);
gr1 = X(`s.log.map(l=>l.text).find(t=>/^Gunnery Round 1:/.test(t))`);
check('preview 25 vs 18 = 1.39:1, A.I. attacks without Conquest at 22 vs 18 = 1.22:1', /25 vs 18/.test(prev) && /U\.S\. 22 vs British 18/.test(gr1), `${prev}\n    ${dec}\n    ${gr1}`);

/* ---------------------------------------------------------------- F6 Missed Signal not used when the ship is left out */
console.log('\n== F6  Missed Signal is not used up when you leave the selected ship out of your attack ==');
X(`var s = fresh('US', 31);
var _u = newForce(s,'US','NOR','Patrol',['madison','oneida']); var _b = newForce(s,'BR','NOR','Patrol',['wolfe','rg']);
s.zones.NOR.event = 13; s.zones.NOR.flags.missedSignal = 'oneida';
s.deck.event = [2].concat(s.deck.event.filter(n=>n!==2));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', humanForces:[_u.id], aiForces:[_b.id], peNum:1}, L:{}}];
run(s); act(s,'ok'); act(s,'attack');`);
save('F6_missed_signal_ship_left_out_of_line.json');
X(`act(s,{attackers:['madison'], tows:{}});`);
check('first Round assembled without Oneida, Missed Signal still pending', X('!s.zones.NOR.flags.missedSignalUsed && missedSignalShip(s) === "oneida"'));

console.log(`\n${bad ? bad + ' check(s) did not behave as described' : 'all findings reproduced, all controls ok'}`);
