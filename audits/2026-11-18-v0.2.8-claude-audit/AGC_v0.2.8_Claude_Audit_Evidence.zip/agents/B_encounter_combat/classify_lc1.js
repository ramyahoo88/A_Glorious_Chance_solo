// Re-plays every "A.I. Gunnery Round below its LC1 threshold" case recorded by sweep.js and shows its cause.
const ARGS = process.argv.slice(2); process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const H = require('/home/claude/audit028/harness.js')();
const ctx = H.ctx;
const file = ARGS[0], start = +ARGS[1];
const st = JSON.parse(require('fs').readFileSync(file));
const tally = {};
for (const c of st.lc1Below) {
  const i = c.seed - start;
  const s = ctx.newGame(c.side, c.seed, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 4 === 0 }); ctx.run(s);
  let n = 0, cause = '?';
  while (!s.over && n++ < 2500) {
    const was = s.log.length; ctx.act(s, policy(s, s.prompt, c.style));
    const add = s.log.slice(was).map(l => l.text);
    const k = add.findIndex(t => t.startsWith(c.t.slice(0, 60)));
    if (k >= 0) {
      const back = s.log.slice(Math.max(0, s.log.length - 40)).map(l => l.text);
      const j = back.lastIndexOf(back.find(t => t.startsWith(c.t.slice(0, 60))));
      const ctxLines = back.slice(0, j);
      const lastCombat = ctxLines.map((t, q) => /^LAKE COMBAT/.test(t) ? q : -1).filter(q => q >= 0).pop();
      const seg = ctxLines.slice(lastCombat);
      cause = seg.some(t => /^Missed Signal: /.test(t)) ? 'Missed Signal ship sat out' : seg.some(t => /BREAKOUT/.test(t)) ? 'Breakout (waived)' : 'other: ' + seg.join(' | ').slice(0, 300);
      break;
    }
  }
  tally[cause] = (tally[cause] || 0) + 1;
  console.log(c.seed, c.side, c.style, 'turn', c.turn, c.ratio, '<', c.thr, '→', cause);
}
console.log(tally);
