// Table checks: Lake Combat Table (70 cells, transcribed independently from the printed map / work/crt.png),
// Hit Distribution columns 2-18 (read from the British Living Rulebook p.32 embedded image, see tools/),
// odds column boundaries. Run: node check_tables.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (n, g, w) => { const a = JSON.stringify(g), b = JSON.stringify(w); if (a === b) pass++; else { fail++; out.push(`FAIL ${n}: got ${a} want ${b}`); } };
// Printed LCT (read from the map, rows 0-9, columns 1:2 or less .. 3:1+)
const PRINTED = [
  'A6 A2W A2 A1/D1 D1 D1W D2', 'A5 A2 A1W D1 D1W D2 D2W', 'A4 A1W A1 D1W D2 D2W D3', 'A3 A1 End D2 D2W D3 A1/D3W',
  'A3 End A1/D1 D2W D3 A1/D3W D4', 'A2 A1/D1 D1 A1/D2 D3W D4 D4W', 'A1 D1 D1W D3W D4 D4W A1/D5', 'A1 D1W A1/D2 D3 D4W A1/D5 D6',
  'End D2 A1/D2W A1/D3W D5 D5W A1/D7', 'A1/D1 D2W D3 A1/D4 A1/D6 D6 D7'].map(r => r.split(' '));
const crt = JSON.parse(X('JSON.stringify(CRT)'));
for (let r = 0; r < 10; r++) for (let c = 0; c < 7; c++) eq(`LCT row ${r} col ${c}`, crt[r][c], PRINTED[r][c]);
// parse of every cell
for (let r = 0; r < 10; r++) for (let c = 0; c < 7; c++) {
  const code = PRINTED[r][c];
  const want = { aHits: 0, dHits: 0, aW: false, dW: false, end: code === 'End' };
  if (code !== 'End') code.split('/').forEach(p => { const m = /^([AD])(\d)(W?)$/.exec(p); if (m[1] === 'A') { want.aHits = +m[2]; want.aW = !!m[3]; } else { want.dHits = +m[2]; want.dW = !!m[3]; } });
  const got = JSON.parse(X(`(function(){const p=parseCrt(${JSON.stringify(code)}); return JSON.stringify({aHits:p.aHits,dHits:p.dHits,aW:p.aW,dW:p.dW,end:p.end});})()`));
  eq(`parse ${code}`, got, want);
}
// Hit Distribution: printed block sizes (positions 1..n) per column, read from the p.32 table
const HD = {
  1: [36], 2: [18, 18], 3: [12, 12, 12], 4: [9, 9, 9, 9], 5: [7, 7, 8, 7, 7], 6: [6, 6, 6, 6, 6, 6], 7: [5, 5, 5, 6, 5, 5, 5],
  8: [3, 5, 5, 5, 5, 5, 5, 3], 9: [4, 4, 4, 4, 4, 4, 4, 4, 4], 10: [2, 4, 4, 4, 4, 4, 4, 4, 4, 2], 11: [1, 4, 4, 4, 5, 4, 4, 4, 4, 1, 1],
  12: Array(12).fill(3), 13: [1].concat(Array(11).fill(3), [2]), 14: [2].concat(Array(10).fill(3), [2, 1, 1]),
  15: [2, 2, 2, 2, 2, 2, 4, 4, 4, 2, 2, 2, 2, 2, 2], 16: [2, 2, 2, 2, 2, 2, 2, 4, 4, 2, 2, 2, 2, 2, 2, 2],
  17: [2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2], 18: Array(18).fill(2) };
for (let n = 1; n <= 18; n++) {
  const want = []; HD[n].forEach((k, i) => { for (let j = 0; j < k; j++) want.push(i + 1); });
  const got = JSON.parse(X(`(function(){const o=[]; for(let r=1;r<=6;r++) for(let b=1;b<=6;b++) o.push(hitPosition(${n},r,b)); return JSON.stringify(o);})()`));
  eq(`HitDist column ${n} (36 results)`, got, want);
}
// Odds columns: exact boundaries with half-point strengths (all strengths are multiples of 0.5)
const cases = [[1, 2, 0], [2, 4, 0], [2.5, 5, 0], [3, 6.5, 0], [2, 3, 1], [4, 6, 1], [6.5, 9.75, 1], [5.5, 8.25, 1], [9.5, 14.25, 1], [3, 4, 1], [1, 1, 2], [7.5, 7.5, 2],
  [3, 2, 3], [16.5, 11, 3], [19.5, 13, 3], [4, 2, 4], [11, 5.5, 4], [5, 2, 5], [27.5, 11, 5], [12.5, 5, 5], [3, 1, 6], [16.5, 5.5, 6], [100, 0.5, 6], [5, 0, 6]];
cases.forEach(([a, d, col]) => eq(`odds ${a}:${d}`, X(`crtColumnForRatio(${d} ? ${a}/${d} : 99)`), col));
// exhaustive: every a,d in 0.5 steps up to 60: column from exact rational comparison
let bad = 0;
const cols = JSON.parse(X(`(function(){const o=[]; for(let A=1;A<=120;A++) for(let D=1;D<=120;D++){ o.push(crtColumnForRatio((A/2)/(D/2))); } return JSON.stringify(o);})()`));
let k = 0;
for (let A = 1; A <= 120; A++) for (let D = 1; D <= 120; D++) {
  const want = 2 * A < D * 4 / 3 ? 0 : A < D ? 1 : 2 * A < 3 * D ? 2 : A < 2 * D ? 3 : 2 * A < 5 * D ? 4 : A < 3 * D ? 5 : 6;  // A/D vs 2/3,1,1.5,2,2.5,3
  if (cols[k++] !== want) bad++;
}
eq('odds column, all 14,400 half-point pairs (exact rational boundaries)', bad, 0);
console.log(out.join('\n'));
console.log(`check_tables: ${pass} passed, ${fail} failed`);
