// Tactic cards: card faces (vmod _00NN_Tactic-*.jpg / work/tactics_*.png) vs data.js and tacticValid / negation.
// Expected values are written from the printed cards and LC3, not from the code.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0; const out = [];
const eq = (n, g, w) => { const a = JSON.stringify(g), b = JSON.stringify(w); if (a === b) pass++; else { fail++; out.push(`FAIL ${n}: got ${a} want ${b}`); } };
// printed faces: [name, deck, symbol, colour bar, side restriction]
const FACES = {
  A_sweep: ['Sweep Up & Fire', 'A', 'square', 'white', 'US'], A_surprise: ['Surprise', 'A', 'star', 'lavender', null], A_rake: ['Rake', 'A', 'star', 'salmon', null],
  A_pursuit: ['Pursuit', 'A', 'arrow', 'yellow', null], A_outmaneuver: ['Outmaneuver', 'A', 'heart', 'salmon', null], A_grapple: ['Grapple', 'A', 'diamond', 'teal', 'BR'],
  A_firstshot: ['First Shot', 'A', 'club', 'lavender', null], A_rof: ['Rate of Fire', 'A', 'club', 'green', null],
  D_repel: ['Repel', 'D', 'circle', 'teal', 'US'], D_rof: ['Rate of Fire', 'D', 'club', 'green', null], D_rake: ['Rake', 'D', 'heart', 'salmon', null],
  D_outmaneuver: ['Outmaneuver', 'D', 'heart', 'salmon', null], D_mutual: ['Mutual Support', 'D', 'diamond', 'lavender', null], D_openrange: ['Open Range', 'D', 'square', 'white', 'BR'],
  D_firstshot: ['First Shot', 'D', 'club', 'lavender', null], D_escape: ['Escape', 'D', 'club', 'yellow', null] };
const T = JSON.parse(X('JSON.stringify(TACTICS)'));
eq('10 Attacker cards, 2 Dummies', [T.filter(t => t.deck === 'A').length, T.filter(t => t.deck === 'A' && t.dummy).length], [10, 2]);
eq('10 Defender cards, 2 Dummies (Playbook p.20 draw shows two)', [T.filter(t => t.deck === 'D').length, T.filter(t => t.deck === 'D' && t.dummy).length], [10, 2]);
Object.keys(FACES).forEach(id => { const t = T.find(x => x.id === id), f = FACES[id]; eq('face ' + id, [t.name, t.deck, t.sym, t.color, t.only || null], f); });
// Event card symbols (read from the 37 card faces) – the Weather Gage card used for invalidation
const EVSYM = { 1: 'club heart star', 6: 'heart diamond', 7: 'club diamond square circle', 11: 'heart diamond', 12: 'club diamond circle', 13: 'heart diamond', 14: 'heart diamond',
  16: 'club heart arrow square star', 17: 'club heart arrow square star', 19: 'club heart diamond arrow square star', 20: 'club heart diamond arrow square star', 21: 'club heart diamond arrow square star',
  23: 'club heart arrow square star', 26: 'club diamond square circle', 27: 'heart diamond', 28: 'club diamond circle', 29: 'heart diamond', 33: 'club heart star', 34: 'heart diamond', 35: 'heart diamond' };
const WG = id => id === 30 ? null : id <= 19 ? 'A' : 'B';
for (let id = 1; id <= 38; id++) {
  const e = JSON.parse(X(`JSON.stringify(EVENTS[${id}])`));
  eq(`event ${id} symbols`, e.sym.slice().sort(), (EVSYM[id] ? EVSYM[id].split(' ') : []).sort());
  eq(`event ${id} Weather Gage`, e.wg, WG(id));
}
// tacticValid: every card x every WG card x side x attacker/defender x segment
let n = 0;
for (const human of ['US', 'BR']) for (const att of ['US', 'BR']) for (const seg of ['patrol', 'reaction']) for (let ev = 1; ev <= 38; ev++) {
  if (ev === 30) continue;
  X(`var s = fresh('${human}', 5); stageCombat(s,'NOR',['madison','oneida'],['wolfe','rg'],'${att}'); s.combat.segment='${seg}'; s.encounter.wgCard=${ev};`);
  for (const id of Object.keys(FACES).concat(['A_dummy1', 'D_dummy2'])) for (const side of ['US', 'BR']) {
    const t = T.find(x => x.id === id);
    const role = side === att ? 'A' : 'D';
    if (t.deck !== role) continue;    // a side only ever draws from its role's deck
    let want = !t.dummy;
    if (want && FACES[id][4] && FACES[id][4] !== side) want = false;
    if (want && EVSYM[ev] && EVSYM[ev].split(' ').includes(FACES[id][2])) want = false;
    if (want && id === 'A_surprise' && seg !== 'patrol') want = false;
    if (want && id === 'A_sweep') want = false;   // Madison is not a Laker Schooner
    eq(`valid ${id} ${side} ${role} ev${ev} ${seg}`, X(`tacticValid(s,'${id}','${side}')`), want); n++;
  }
}
// Sweep Up & Fire: valid only for an all-untowed-Laker-Schooner U.S. attack, not against an all-Laker British Force
X(`var s = fresh('BR', 6); stageCombat(s,'NOR',['tompkins','fairam'],['wolfe'],'US'); s.encounter.wgCard=2;`);
eq('Sweep valid: two untowed Laker Schooners attacking', X(`tacticValid(s,'A_sweep','US')`), true);
X(`s.combat.col.US=['madison','tompkins']; s.combat.tows={madison:'tompkins'};`);
eq('Sweep invalid: towed schooner / non-Laker in the attack', X(`tacticValid(s,'A_sweep','US')`), false);
X(`s.combat.col.US=['tompkins','fairam']; s.combat.tows={}; s.ships.hamilton.owner='BR'; s.combat.col.BR=['hamilton'];`);
eq('Sweep invalid against a British Force of reflagged Laker Schooners only', X(`tacticValid(s,'A_sweep','US')`), false);
// colour-bar cancellation + explicit negations, all 64 pairs
const OTHERS = { US: 'BR', BR: 'US' };
const A = Object.keys(FACES).filter(k => k[0] === 'A'), D = Object.keys(FACES).filter(k => k[0] === 'D');
let pairs = 0;
for (const a of A) for (const d of D) {
  const attSide = FACES[a][4] || (FACES[d][4] ? OTHERS[FACES[d][4]] : 'US');
  const defSide = OTHERS[attSide];
  if (FACES[d][4] && FACES[d][4] !== defSide) continue;          // impossible pairing (both cards side-restricted the same way)
  const usCol = a === 'A_sweep' ? ['tompkins', 'fairam'] : ['madison'];
  // the human attacks and picks a; the A.I. defends and draws only d (valid for it)
  X(`var s = fresh('${attSide}', 7); stageCombat(s,'NOR',${JSON.stringify(usCol)},['wolfe'],'${attSide}'); s.encounter.wgCard=2; s.deck.tacA=['${a}']; s.deck.tacD=['${d}']; waitAt(s,'combat','tactics2'); s.calls[0].L={hDrawn:['${a}'],hDeck:'A'}; s.calls[0].answer='${a}'; s.prompt=null; run(s);`);
  const same = FACES[a][3] === FACES[d][3];
  const wantAtt = same || (d === 'D_repel' && a === 'A_grapple') || (d === 'D_mutual' && (a === 'A_rake' || a === 'A_outmaneuver'));
  eq(`negation ${a} vs ${d}`, X(`[s.combat.tac.att && s.combat.tac.att.id, s.combat.tac.def && s.combat.tac.def.id, !!s.combat.tac.att.negated, !!s.combat.tac.def.negated]`), [a, d, wantAtt, same]); pairs++;
}
console.log(out.slice(0, 20).join('\n'));
console.log(`check_tactics: ${pass} passed, ${fail} failed (${n} validity cases, ${pairs} Attacker/Defender pairs)`);
