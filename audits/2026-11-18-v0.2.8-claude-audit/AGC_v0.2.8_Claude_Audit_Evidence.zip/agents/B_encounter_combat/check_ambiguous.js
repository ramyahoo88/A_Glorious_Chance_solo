// Demonstrates the behaviour behind the "ambiguous ruling" items A1 and A3.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
// A1 – Rainy Squalls applies again to a later Encounter's Patrol Segment after a Reaction Segment in the same zone
X(`var s = fresh('US', 41);
var _u = newForce(s,'US','NOR','Patrol',['madison','oneida']); var _b = newForce(s,'BR','NOR','Patrol',['wolfe']);
s.zones.NOR.event = 19; s.zones.NOR.flags.rainy = true;
s.deck.event = [2, 3].concat(s.deck.event.filter(n=>n!==2 && n!==3));
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', humanForces:[_u.id], aiForces:[_b.id], peNum:1}, L:{}}];
run(s); var _g=0; while (s.prompt && _g++<30) { var _k=s.prompt.kind; if (_k==='select') act(s,[]); else if (_k==='lineup') act(s,{attackers:s.prompt.candidates,tows:{}}); else if (_k==='choice') act(s, s.prompt.options.find(o=>o.id==='pass') && s.encounter && s.encounter.segment==='reaction' ? 'pass' : s.prompt.options[0].id); else act(s,'ok'); }
var _first = s.log.map(l=>l.text).filter(t=>/Rainy|Reaction Segment Weather|LAKE COMBAT/.test(t));
var _b2 = newForce(s,'BR','NOR','Patrol',['rg']); var _u2 = newForce(s,'US','NOR','Patrol',['sylph']);
s.deck.event = [4].concat(s.deck.event.filter(n=>n!==4)); s.log=[];
s.calls = [{proc:'encounter', pc:'start', A:{zone:'NOR', kind:'normal', humanForces:[_u2.id], aiForces:[_b2.id], peNum:2}, L:{}}];
run(s); act(s,'ok'); act(s,'attack'); act(s,{attackers:s.prompt.candidates,tows:{}});
var _second = s.log.map(l=>l.text).filter(t=>/Rainy|LAKE COMBAT/.test(t));`);
console.log('A1 Encounter 1:', X('_first.join(" | ")'));
console.log('A1 Encounter 2 (same zone, same turn):', X('_second.join(" | ")'));
// A3 – Defender Rake is spent automatically in the Defender's first Gunnery Round
X(`var s = fresh('BR', 42); stageCombat(s,'NOR',['madison','oneida'],['wolfe','rg'],'US'); s.combat.tac.def = {id:'D_rake', used:false, negated:false};
waitAt(s,'combat','grRoll',{},{st:'GR1'}); act(s,'ok');`);
console.log('A3 human Defender, Round 1:', X(`s.log.map(l=>l.text).find(t=>/^Gunnery Round 1/.test(t))`), '| Rake used:', X('s.combat.tac.def.used'));
