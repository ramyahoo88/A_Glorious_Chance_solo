// Counts A.I. Command Decisions (Confront/Bypass prompts) where the A.I.'s LC1 verdict would change if its odds
// test used the first Round's ships (Missed Signal ship left out on both sides, as the preview and the Round do).
const ARGS = process.argv.slice(2); process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const H = require('/home/claude/audit028/harness.js')();
const ctx = H.ctx, X = H.X;
const start = +(ARGS[0] || 800000), count = +(ARGS[1] || 250);
const r = { decisions: 0, withMS: 0, attackButShouldNot: 0, declineButShould: 0, examples: [] };
for (let i = 0; i < count; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const s = ctx.newGame(side, start + i, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 4 === 0 }); ctx.run(s);
  let n = 0;
  while (!s.over && n++ < 2500) {
    const p = s.prompt;
    if (p.kind === 'choice' && /^Command Decision – the A\.I\./.test(p.title)) {
      r.decisions++;
      const ms = ctx.missedSignalShip(s);
      if (ms) {
        r.withMS++;
        ctx.__s = s;
        const v = JSON.parse(X(`(function(){ var s=__s, ai=s.ai, h=s.human, ms=missedSignalShip(s);
          var cands = encIds(s, ai).filter(id => isFull(s.ships[id])); if (ai === 'BR') cands = cands.filter(id => !isCLS(s.ships[id]));
          var now = aiPlanFor(s, ai, cands, encIds(s, h), false).ships.length > 0;
          var first = aiPlanFor(s, ai, cands.filter(id => id !== ms), encIds(s, h).filter(id => id !== ms), false).ships.length > 0;
          return JSON.stringify([now, first]); })()`));
        if (v[0] && !v[1]) r.attackButShouldNot++;
        if (!v[0] && v[1]) r.declineButShould++;
        if (v[0] !== v[1] && r.examples.length < 6) r.examples.push({ seed: start + i, side, style, turn: s.turn, ms, appAttacks: v[0] });
      }
    }
    ctx.act(s, policy(s, p, style));
  }
}
console.log(JSON.stringify(r, null, 1));
