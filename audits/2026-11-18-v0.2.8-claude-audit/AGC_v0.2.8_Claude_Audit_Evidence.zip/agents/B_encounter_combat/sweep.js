// Campaign sweep for the Encounter / Lake Combat area (v0.2.8, read-only use of the repo).
// node sweep.js [startSeed] [count]
// Plays full campaigns with the shared deterministic visible-information policy and checks:
//  (a) every Gunnery Round line: odds column = printed column for the ratio (+ Surprise shift)
//  (b) Command Decision previews vs the first Round actually fought (human attack / A.I. attack)
//  (c) A.I. attacks fought below the LC1 threshold for the ships actually in the Round
//  (d) save -> checkSaveState(JSON) -> continue reproduces the same log (sampled mid-Encounter)
const ARGS = process.argv.slice(2); process.argv[2] = '/home/claude/a_glorious_chance_solo';
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, ctx = H.ctx;
const start = +(ARGS[0] || 300000), count = +(ARGS[1] || 20);
const stats = { games: 0, prompts: 0, grLines: 0, colMismatch: [], cmdHuman: 0, cmdHumanMismatch: [], cmdAI: 0, cmdAIMismatch: [], lc1Below: [], reloads: 0, reloadDiff: [], errors: [], aiDraw: {}, humanDraw: {}, struck: 0 };
const crtCol = r => r < 2 / 3 ? 0 : r < 1 ? 1 : r < 1.5 ? 2 : r < 2 ? 3 : r < 2.5 ? 4 : r < 3 ? 5 : 6;
const COLS = ['1:2-', '1:1.5', '1:1', '1.5:1', '2:1', '2.5:1', '3:1+'];
function playSteps(s, style, n) { for (let i = 0; i < n && s.prompt && !s.over; i++) ctx.act(s, policy(s, s.prompt, style)); }
for (let i = 0; i < count; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const seed = start + i;
  const s = ctx.newGame(side, seed, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 4 === 0 });
  ctx.run(s);
  let n = 0, pending = null, logSeen = 0;
  try {
    while (!s.over && n < 2500) {
      const p = s.prompt;
      // (b) remember Command Decision previews
      if (p.kind === 'choice' && /^Command Decision/.test(p.title)) {
        const m1 = /Odds if you attack with all full-strength ships: ([\d.]+) vs ([\d.]+)/.exec(p.text);
        const m2 = /Odds if the A\.I\. attacks: ([\d.]+) vs ([\d.]+)/.exec(p.text);
        pending = { human: m1 ? [+m1[1], +m1[2]] : null, ai: m2 ? [+m2[1], +m2[2]] : null, turn: s.turn, at: s.log.length, seed, side, style };
      }
      // (d) sampled save/reload inside an Encounter
      if (s.encounter && (n % 7 === 3)) {
        const snap = JSON.stringify({ state: s, undo: [] });
        const a = JSON.parse(snap).state, b = ctx.checkSaveState(JSON.parse(snap).state);
        playSteps(a, style, 25); playSteps(b, style, 25);
        stats.reloads++;
        const la = JSON.stringify(a.log.slice(-40)), lb = JSON.stringify(b.log.slice(-40));
        if (la !== lb || a.rng !== b.rng) stats.reloadDiff.push({ seed, side, style, n, title: p.title });
      }
      if (pending && /declines battle|does not attack|breaks off/.test(p.title)) pending = null;
      const ans = policy(s, p, style);
      if (pending && /^Command Decision/.test(p.title) && ans === 'pass') pending = null;
      const wasLog = s.log.length;
      ctx.act(s, ans); n++;
      const added = s.log.slice(wasLog).map(l => l.text);
      added.forEach(t => {
        const ma = /^A\.I\. drew (.*) → plays/.exec(t); if (ma) { const k = ma[1] ? ma[1].split(', ').length : 0; stats.aiDraw[k] = (stats.aiDraw[k] || 0) + 1; }
        if (/STRIKES COLORS/.test(t)) stats.struck++;
      });
      if (p.kind === 'choice' && p.tactic) { const mh = /You drew: (.*)\./.exec(p.text); const k = mh ? mh[1].split(', ').length : 0; stats.humanDraw[k] = (stats.humanDraw[k] || 0) + 1; }
      added.forEach((t, k) => {
        if (pending && /^LAKE COMBAT in /.test(t)) { if (pending.started) pending = null; else pending.started = true; }
        if (pending && /^Rainy Squalls: skip/.test(t)) pending = null;
        const m = /^Gunnery Round ([12]): (U\.S\.|British) ([\d.]+) vs (U\.S\.|British) ([\d.]+).*?= ([\d.∞]+):1 → column (\S+?)( \(\+1 Surprise\))?\. /.exec(t);
        if (!m) return;
        stats.grLines++;
        const a = +m[3], d = +m[5];
        let col = d > 0 ? crtCol(a / d) : 6; if (m[8]) col = Math.min(6, col + 1);
        if (COLS[col] !== m[7]) stats.colMismatch.push({ seed, side, style, t });
        if (m[1] === '1' && pending && pending.started && s.turn === pending.turn) {
          const attSide = m[2] === 'U.S.' ? 'US' : 'BR';
          const isHuman = attSide === s.human;
          const prev = isHuman ? pending.human : pending.ai;
          if (prev) {
            if (isHuman) stats.cmdHuman++; else stats.cmdAI++;
            // the human policy always attacks with every candidate, so the preview must match exactly
            if (prev[0] !== a || prev[1] !== d) (isHuman ? stats.cmdHumanMismatch : stats.cmdAIMismatch).push({ seed, side, style, turn: s.turn, preview: prev, fought: [a, d], line: t.slice(0, 160) });
          }
          pending = null;
        }
        // (c) A.I. attack below LC1 for the ships in the Round
        const attSide = m[2] === 'U.S.' ? 'US' : 'BR';
        if (attSide === s.ai && d > 0) {
          const unt = /\[[^\]]*untowed Laker Schooners \((\d+), d6/.exec(t);
          const thr = attSide === 'US' && unt ? 1.5 : 1;
          if (a / d < thr && !/BREAKOUT/.test(s.log.slice(Math.max(0, wasLog - 60), wasLog).map(l => l.text).join('|'))) stats.lc1Below.push({ seed, side, style, turn: s.turn, ratio: +(a / d).toFixed(2), thr, t: t.slice(0, 170) });
        }
      });
      if (p.kind === 'choice' && /^Command Decision/.test(p.title) === false && !s.encounter) pending = null;
    }
  } catch (e) { stats.errors.push({ seed, side, style, n, e: String(e.stack).slice(0, 300) }); }
  stats.games++; stats.prompts += n;
}
const show = a => a.slice(0, 6).map(x => JSON.stringify(x)).join('\n  ');
console.log(`games ${stats.games}, prompts ${stats.prompts}, Gunnery Round lines ${stats.grLines}, column mismatches ${stats.colMismatch.length}`);
console.log(`Command Decision -> human GR1 compared ${stats.cmdHuman}, mismatches ${stats.cmdHumanMismatch.length}\n  ${show(stats.cmdHumanMismatch)}`);
console.log(`Command Decision -> A.I. GR1 compared ${stats.cmdAI}, mismatches ${stats.cmdAIMismatch.length}\n  ${show(stats.cmdAIMismatch)}`);
console.log(`A.I. Gunnery Rounds fought below LC1 threshold (non-Breakout): ${stats.lc1Below.length}\n  ${show(stats.lc1Below)}`);
console.log(`save/reload continuations ${stats.reloads}, differences ${stats.reloadDiff.length}\n  ${show(stats.reloadDiff)}`);
console.log(`Tactic cards drawn per draw – A.I. (5 wanted): ${JSON.stringify(stats.aiDraw)}; human (4 wanted, prompt shown): ${JSON.stringify(stats.humanDraw)}`);
console.log(`errors ${stats.errors.length}\n  ${show(stats.errors)}`);
require('fs').writeFileSync(__dirname + `/sweep_${start}_${count}.json`, JSON.stringify(stats, null, 1));
