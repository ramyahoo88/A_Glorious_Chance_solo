# Overlay row-boundary grid lines and row labels onto upscaled column groups of the p.32 Hit Distribution table.
import sys
from PIL import Image, ImageDraw
im = Image.open(sys.argv[1]).convert('RGB')
out = sys.argv[2]
x0c, dx, y11, dy = 89.0, 35.28, 509.0, 11.67
labels = [f'{a}{b}' for a in range(1, 7) for b in range(1, 7)]
groups = [(2, 7), (7, 12), (12, 15), (15, 19)]
S = 3
for gi, (a, b) in enumerate(groups):
    xa = int(x0c + (a - 2) * dx - dx / 2) - 2; xb = int(x0c + (b - 1 - 2) * dx + dx / 2) + 2
    ya = int(y11 - dy / 2) - 4; yb = int(y11 + 35.5 * dy) + 4
    crop = im.crop((xa, ya, xb, yb)).resize(((xb - xa) * S, (yb - ya) * S), Image.LANCZOS)
    W = crop.width + 60
    canvas = Image.new('RGB', (W + 60, crop.height + 30), 'white'); canvas.paste(crop, (60, 0))
    d = ImageDraw.Draw(canvas)
    for i in range(37):
        y = (y11 - dy / 2 + i * dy - ya) * S
        d.line([(55, y), (W, y)], fill=(0, 160, 255) if i % 6 else (255, 0, 255), width=1)
    for i, l in enumerate(labels):
        y = (y11 + i * dy - ya) * S
        d.text((5, y - 6), l, fill='black'); d.text((W + 5, y - 6), l, fill='black')
    for n in range(a, b):
        x = (x0c + (n - 2) * dx - xa) * S + 60
        d.text((x - 6, crop.height + 8), str(n), fill='red')
    canvas.save(f'{out}_{gi}.png')
