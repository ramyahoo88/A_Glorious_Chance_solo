# Reads the Hit Distribution table (British LR p.32 embedded image) by locating the black digit glyphs in each
# column and reconstructing box boundaries from the glyph centres.
import sys
from PIL import Image
import numpy as np
from scipy import ndimage
im = np.array(Image.open(sys.argv[1]).convert('RGB')).astype(int)
x0c, dx = 89.0, 35.28      # column "2" centre, spacing (original pixels)
y11, dy = 509.0, 11.67     # row "11" centre, row pitch
R, G, B = im[..., 0], im[..., 1], im[..., 2]
black = (R < 90) & (G < 90) & (B < 90)
res = {}
for n in range(2, 19):
    xc = x0c + (n - 2) * dx
    xa, xb = int(xc - 15), int(xc + 15)
    ya, yb = int(y11 - dy / 2) - 2, int(y11 + 35.5 * dy) + 2
    sub = black[ya:yb, xa:xb]
    lab, k = ndimage.label(sub)
    objs = ndimage.find_objects(lab)
    blobs = []
    for i, sl in enumerate(objs):
        h = sl[0].stop - sl[0].start; w = sl[1].stop - sl[1].start
        cnt = (lab[sl] == i + 1).sum()
        if cnt < 6 or h < 4: continue
        blobs.append(((sl[0].start + sl[0].stop) / 2 + ya, sl[0].start + ya, sl[0].stop + ya, (sl[1].start + sl[1].stop) / 2 + xa))
    # merge blobs on the same line (two-digit numbers)
    blobs.sort()
    merged = []
    for b in blobs:
        if merged and abs(b[0] - merged[-1][0]) < 4: merged[-1] = ((merged[-1][0] + b[0]) / 2, min(merged[-1][1], b[1]), max(merged[-1][2], b[2]), 0)
        else: merged.append(b)
    centres = [(m[0] - y11) / dy for m in merged]   # in row units, 0 = row "11"
    res[n] = centres
    print(n, len(centres), ' '.join('%.2f' % c for c in centres))
