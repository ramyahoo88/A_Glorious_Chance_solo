// Lake Action Phase B1/B2: Possible Encounter numbering and distribution, marker transfer/discard,
// Encounter Check (spyglass / false alarm / Gale redraw), no A.I. Deployable ships. node lake_tests.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0;
const eq = (n, g, w) => { if (JSON.stringify(g) === JSON.stringify(w)) pass++; else { fail++; console.log('FAIL', n, JSON.stringify(g), 'want', JSON.stringify(w)); } };
X(`function lakePos(seed, rowIds, forces) {
  var s = newGame('BR', seed); s.turn = 2; s.phase = 'lake'; s.lossesThisTurn = []; s.troopsReturning = {US:0,BR:0};
  s.coastal = {raids:[], battles:[], cutouts:[]}; s.pe = []; s.peNext = 1; s.eventsDrawn = []; s.turnFlags = {}; s.convoyDeployed = {US:null, BR:null};
  var F = forces.map(function(fr){ return newForce(s, 'BR', fr[0], 'Patrol', fr[1]).id; });
  s.targetRow = rowIds.map(function(id){ return { id: id, revealed: false, removed: false, enc: false }; });
  s.calls = [{ proc: 'turn', pc: 'B1', A: {}, L: {} }]; s.prompt = null; run(s); s.F = F; return s; }`);
// Row: B2(SAC) B21(NOR) B36(SAC) B9(NIA) B37(SAC) B49(YOR) B38(SAC); forces: 3 in SAC, 1 in NOR
X(`var s = lakePos(1, ['B2','B21','B36','B9','B37','B49','B38'], [['SAC',['wolfe']],['SAC',['rg']],['SAC',['moira']],['NOR',['sss']]]);`);
eq('B1 asks which Sacket\'s Force gets the first marker', X('[s.prompt.kind, s.prompt.options.length]'), ['choice', 3]);
X(`act(s, s.F[1]);`);
eq('PE numbers follow the row order', X('s.pe.map(function(p){ return [p.num, p.zone, p.idx]; })'), [[1, 'SAC', 0], [2, 'NOR', 1], [3, 'SAC', 2], [4, 'SAC', 4], [5, 'SAC', 6]]);
eq('Markers rotate from the chosen Force through the others, evenly', X('s.pe.filter(function(p){return p.zone==="SAC";}).map(function(p){ return s.F.indexOf(p.forceId); })'), [1, 2, 0, 1]);
eq('… and no further choice is offered for the 2nd/3rd/4th Sacket\'s markers (10.1.2 lets you choose them)', X('[s.prompt.kind, s.prompt.title]'), ['info', 'B1 Possible Encounters']);
// Two Forces, three markers: PE1→A, PE2→B, PE3→B is legal under 10.1.2 but cannot be produced
let reachable = new Set();
for (const first of [0, 1]) {
  X(`var t = lakePos(2, ['B2','B36','B37'], [['SAC',['wolfe']],['SAC',['rg']]]); act(t, t.F[${first}]);`);
  reachable.add(X('t.pe.map(function(p){ return t.F.indexOf(p.forceId); }).join("")'));
}
eq('Two Forces, three markers: only A-B-A and B-A-B are reachable (A-B-B, B-A-A are not)', [...reachable].sort(), ['010', '101']);
// B2: Force gone but another Force in the zone → transfer; none → discard
X(`var u = lakePos(3, ['B2','B36'], [['SAC',['wolfe']],['SAC',['rg']]]); act(u, u.F[0]); act(u, 'ok');`);
// u now at B2 Encounter Check of PE1 (Wolfe). Instead rewind: stage directly
X(`var v = lakePos(3, ['B2'], [['SAC',['wolfe']],['SAC',['rg']]]); act(v, v.F[0]);
   removeShipFromForce(v, 'wolfe'); v.ships.wolfe.box = 'transit'; v.deck.event = [21].concat(v.deck.event.filter(function(n){return n!==21;}));
   act(v, 'ok');`);
eq('B2: PE1\'s Force has left – marker transferred to the other Force in the zone', X(`[v.pe[0].forceId === v.F[1], /transferred/.test(v.log.map(function(l){return l.text;}).join(' '))]`), [true, true]);
X(`var w = lakePos(3, ['B2'], [['SAC',['wolfe']]]); removeShipFromForce(w, 'wolfe'); w.ships.wolfe.box = 'transit'; act(w, 'ok');`);
eq('B2: no Force left in the zone – marker discarded', X('w.pe[0].status'), 'discarded');
// Gale is redrawn; spyglass card → Encounter; no spyglass → false alarm
X(`var g = lakePos(4, ['B49'], [['YOR',['wolfe']]]); g.deck.event = [30, 21].concat(g.deck.event.filter(function(n){return n!==30 && n!==21;})); act(g, 'ok');`);
eq('Gale drawn for the check is discarded and redrawn (#21: false alarm)', X('[g.pe[0].status, g.eventsDrawn.map(function(e){return e.id;})]'), ['discarded', [30, 21]]);
X(`var h = lakePos(4, ['B49'], [['YOR',['wolfe']]]); h.deck.event = [20].concat(h.deck.event.filter(function(n){return n!==20;})); act(h, 'ok');`);
eq('Event #20 (spyglass) → Encounter, card revealed', X('[h.pe[0].status, h.targetRow[0].revealed]'), ['encounter', true]);
// No A.I. Deployable ships: all PEs discarded, straight to C1
X(`var k = lakePos(5, ['B2','B36'], [['SAC',['wolfe']]]); Object.values(k.ships).forEach(function(sh){ if (sh.owner==='US' && sh.box==='deployable') sh.box='ordinary'; }); act(k, 'ok');`);
eq('No A.I. Deployable ships: every PE discarded', X('k.pe.map(function(p){return p.status;})'), ['discarded', 'discarded']);
// Blockaded A.I. ships still count as Deployable in Lake Action (note 47)
X(`var m = lakePos(5, ['B2'], [['SAC',['wolfe','rg','moira','beres']]]); m.zones.SAC.blockade = 'BR'; m.deck.event = [21].concat(m.deck.event.filter(function(n){return n!==21;})); act(m, 'ok');`);
eq('Blockaded A.I. ships still allow Encounter Checks', X('m.pe[0].status'), 'discarded');
console.log(`lake_tests: ${pass} passed, ${fail} failed`);
