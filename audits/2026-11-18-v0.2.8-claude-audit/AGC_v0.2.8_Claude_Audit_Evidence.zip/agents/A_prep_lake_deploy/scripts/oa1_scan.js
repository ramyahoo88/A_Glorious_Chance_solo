// Scan natural U.S.-campaign games with OA1 on: when OA1 upgrades ships at the first Encounter,
// compare the app's recalculated Naval Balance with the A6 value minus the upgrading ships' VP.
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let hits = 0;
for (let seed = 1; seed <= 200 && hits < 6; seed++) {
  X(`var s = newGame('US', ${seed}, {oa1Upgrades:true}); run(s); var nbA6 = null;`);
  for (let i = 0; i < 400; i++) {
    if (X('s.over') || X('s.turn') > 1) break;
    const p = X('s.prompt');
    if (X(`s.stepLabel`) === 'A7 Assign Ships' && X('nbA6') === null) X(`nbA6 = s.nb`);
    let a = 'ok';
    if (p.kind === 'choice') a = (p.options.find(o => o.primary) || p.options[0]).id;
    else if (p.kind === 'select') a = p.initial || [];
    else if (p.kind === 'lineup') a = { attackers: p.candidates, tows: p.defaultTows || {} };
    else if (p.kind === 'assign') a = { forces: [{ mission: 'Patrol', zone: 'KIN', ships: p.ships, troops: 0 }], flagship: p.flagship };
    const before = X('s.log.length');
    X(`act(s, ${JSON.stringify(a)})`);
    const nl = X(`s.log.slice(${before}).map(l=>l.text)`);
    const oa = nl.find(t => /^OA1 upgrade roll/.test(t));
    if (oa && /go to Make Ready/.test(oa)) {
      const up = X(`Object.values(s.ships).filter(sh=>sh.box==='makeReady' && sh.flags.upgrading).map(sh=>vpCapture(sh))`);
      const expected = X('nbA6') + up.reduce((x, y) => x + y, 0);
      console.log(`seed ${seed} turn ${X('s.turn')}: A6 NB ${X('nbA6')} (band ${X('navalBalanceBand(nbA6)')}); ${oa}; app recalculates NB ${X('s.nb')} (band ${X('s.nbBand')}); A6 value less upgrading ships = ${expected} (band ${X('navalBalanceBand(' + expected + ')')}); next: ${nl.filter(t=>!/^OA1/.test(t)).join(' | ').slice(0,200)}`);
      hits++; break;
    }
    if (nl.some(t => /^OA1 upgrade roll/.test(t))) break;
  }
}
