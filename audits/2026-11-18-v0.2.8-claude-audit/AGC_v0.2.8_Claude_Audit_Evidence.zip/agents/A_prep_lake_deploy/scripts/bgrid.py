# Independent reading of B-deck (British Solo) Target Card grids: cluster binarised cell glyphs,
# then label the clusters by eye (montage written to /tmp/bclusters.png).
import sys, json, glob, re
from PIL import Image, ImageDraw
IMG = '/home/claude/agc/vmod/images'
xs = [142 + i * (812 - 142) / 7 for i in range(8)]
ys = [(318, 364), (370, 416), (422, 468), (474, 520)]
cells = []  # (card, r, c, mask(frozenset), crop)
for f in sorted(glob.glob(IMG + '/_0*_Target-B *.jpg')):
    n = int(re.search(r'Target-B (\d+)', f).group(1))
    im = Image.open(f).convert('L')
    for r, (y0, y1) in enumerate(ys):
        for c in range(7):
            x0, x1 = int(xs[c]) + 5, int(xs[c + 1]) - 5
            crop = im.crop((x0, y0 + 4, x1, y1 - 4))
            w, h = crop.size
            pts = [(x, y) for y in range(h) for x in range(w) if crop.getpixel((x, y)) < 90]
            if pts:
                mx = min(p[0] for p in pts); my = min(p[1] for p in pts)
                mask = frozenset((x - mx, y - my) for x, y in pts)
            else:
                mask = frozenset()
            cells.append(('B%d' % n, r, c, mask, crop))
clusters = []  # [rep_mask, members]
def dist(a, b):
    if not a and not b: return 0
    return len(a ^ b) / max(1, len(a | b))
for cell in cells:
    for cl in clusters:
        if dist(cl[0], cell[3]) < 0.35:
            cl[1].append(cell); break
    else:
        clusters.append([cell[3], [cell]])
print('clusters', len(clusters), [len(cl[1]) for cl in clusters])
W = 100; H = 50
mont = Image.new('L', (W * 2, H * len(clusters)), 255)
d = ImageDraw.Draw(mont)
for i, cl in enumerate(clusters):
    mont.paste(cl[1][0][4].resize((W - 20, H - 6)), (0, i * H))
    d.text((W + 5, i * H + 15), 'cl%d n=%d' % (i, len(cl[1])), fill=0)
mont.save('/tmp/bclusters.png')
json.dump({'%s,%d,%d' % (c[0], c[1], c[2]): i for i, cl in enumerate(clusters) for c in cl[1]}, open(sys.argv[1], 'w'))
