# Montage of every Target Card's header text and bottom symbol strip, 6 cards per sheet.
import glob, re
from PIL import Image
IMG = '/home/claude/agc/vmod/images'
def key(f):
    m = re.search(r'Target-([AB]) (\d+)', f); return (m.group(1), int(m.group(2)))
files = sorted(glob.glob(IMG + '/_0*_Target-[AB] *.jpg'), key=key)
S = 0.62
for i in range(0, len(files), 6):
    parts = []
    for f in files[i:i + 6]:
        im = Image.open(f).convert('RGB')
        a = im.crop((60, 62, 860, 228)); b = im.crop((60, 528, 860, 604))
        st = Image.new('RGB', (800, 166 + 76 + 6), (255, 255, 255)); st.paste(a, (0, 0)); st.paste(b, (0, 166))
        parts.append(st.resize((int(800 * S), int(248 * S))))
    out = Image.new('RGB', (parts[0].width, sum(p.height for p in parts)), (0, 0, 0))
    y = 0
    for p in parts: out.paste(p, (0, y)); y += p.height
    out.save('/tmp/hdr_%02d.png' % (i // 6))
print(len(files))
