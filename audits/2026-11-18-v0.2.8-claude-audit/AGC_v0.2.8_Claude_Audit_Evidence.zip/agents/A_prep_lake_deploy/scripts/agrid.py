# Independent pixel reading of the A-deck (U.S. Solo) Target Card deployment grids.
# A cell holds a ship icon if it has many dark (brown/black) pixels; the empty pink/grey gradient has none.
import sys, json, glob, re
from PIL import Image
IMG = '/home/claude/agc/vmod/images'
xs = [142 + i * (812 - 142) / 7 for i in range(8)]
ys = [(318, 364), (370, 416), (422, 468), (474, 520)]
out = {}
for f in sorted(glob.glob(IMG + '/_00*_Target-A *.jpg')):
    n = int(re.search(r'Target-A (\d+)', f).group(1))
    im = Image.open(f).convert('RGB')
    assert im.size == (900, 660), im.size
    rows = []
    for (y0, y1) in ys:
        r = ''
        for c in range(7):
            x0, x1 = int(xs[c]) + 6, int(xs[c + 1]) - 6
            dark = 0; tot = 0
            for y in range(y0 + 6, y1 - 6):
                for x in range(x0, x1):
                    p = im.getpixel((x, y)); tot += 1
                    if sum(p) < 300: dark += 1
            r += '1' if dark / tot > 0.04 else '0'
        rows.append(r)
    out['A%d' % n] = rows
json.dump(out, open(sys.argv[1], 'w'), indent=0)
print(len(out), 'cards read')
