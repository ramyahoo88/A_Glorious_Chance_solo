// Trace turns 1-2 of a game through A and B; prints prompts and log lines.
// node trace.js US|BR seed
process.argv[2] = process.argv[2] || 'US';
const side = process.argv[2], seed = +(process.argv[3] || 7);
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
X(`var s = newGame('${side}', ${seed}, {cuttingOut:true}); run(s); var __seen = 0;`);
function dumpLog() { const L = X(`s.log.slice(__seen).map(l => '['+l.turn+' '+l.phase+'] '+l.text)`); X(`__seen = s.log.length`); L.forEach(t => console.log('  LOG', t)); }
for (let i = 0; i < 300; i++) {
  dumpLog();
  if (X(`s.turn`) >= 2 || X('s.over')) break;
  const p = X(`s.prompt`);
  console.log(`PROMPT [${X('s.stepLabel')}] ${p.kind}: ${p.title} :: ${(p.text || '').replace(/\n/g, ' | ').slice(0, 400)}`);
  let a = 'ok';
  if (p.kind === 'choice') a = (p.options.find(o => o.primary) || p.options[0]).id;
  else if (p.kind === 'select') a = p.initial || [];
  else if (p.kind === 'lineup') a = { attackers: p.candidates, tows: p.defaultTows || {} };
  else if (p.kind === 'assign') {
    // put everything on Patrol in the enemy home zone except one ship in North Lake / Niagara
    const ships = p.ships.slice(); const forces = [];
    const enemy = side === 'US' ? 'KIN' : 'SAC';
    if (ships.length > 2) forces.push({ mission: 'Patrol', zone: 'NOR', ships: [ships.pop()], troops: 0 });
    if (ships.length > 2) forces.push({ mission: 'Patrol', zone: 'NIA', ships: [ships.pop()], troops: 0 });
    forces.push({ mission: 'Patrol', zone: enemy, ships, troops: 0 });
    a = { forces, flagship: p.flagship };
    console.log('  ANSWER assign', JSON.stringify(a));
  }
  const err = X(`validateAnswer(s, s.prompt, ${JSON.stringify(a)})`);
  if (err) { console.log('  invalid answer', err); break; }
  X(`act(s, ${JSON.stringify(a)})`);
}
