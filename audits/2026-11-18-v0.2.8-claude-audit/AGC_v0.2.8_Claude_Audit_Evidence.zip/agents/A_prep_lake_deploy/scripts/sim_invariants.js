// Random-play simulation with invariants for the Preparation and Lake Action phases.
// node sim_invariants.js [games]
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
const N = +(process.argv[2] || 100);
X(`var __bad = 0; var __r = 12345; function rnd(n){ __r = (Math.imul(__r, 1103515245) + 12345) >>> 0; return (__r >>> 8) % n; }
function pickAnswer(s) {
  var p = s.prompt;
  if (p.kind === 'info') return 'ok';
  if (p.kind === 'choice') { var o = p.options.filter(function(x){ return !x.disabled; }); return o[rnd(o.length)].id; }
  if (p.kind === 'lineup') return { attackers: p.candidates, tows: p.defaultTows || {} };
  if (p.kind === 'select') { for (var t = 0; t < 20; t++) { var a = p.items.filter(function(){ return rnd(3) === 0; }).map(function(i){ return i.id; }).slice(0, p.max); if (a.length >= (p.min || 0) && !validateAnswer(s, p, a)) return a; } return p.initial || []; }
  if (p.kind === 'assign') {
    var ids = p.ships.slice(), forces = [], zones = ZONES.slice();
    while (ids.length) {
      var k = 1 + rnd(Math.min(4, ids.length)); var sh = ids.splice(0, k);
      var ms = Object.keys(p.missions); var m = ms[rnd(ms.length)]; var z = p.missions[m][rnd(p.missions[m].length)];
      var fr = { mission: m, zone: z, ships: sh, troops: 0 };
      if (m === 'ArmySupport') fr.troops = Math.min(p.troops - forces.reduce(function(a,f){return a+f.troops;},0), troopCapacity(s, sh));
      if (rnd(4) === 0) continue;
      if (validateAnswer(s, p, { forces: forces.concat([fr]), flagship: p.flagship })) { fr.mission = 'Patrol'; fr.troops = 0; fr.zone = zones[rnd(6)]; }
      if (!validateAnswer(s, p, { forces: forces.concat([fr]), flagship: p.flagship })) forces.push(fr);
    }
    return { forces: forces, flagship: p.flagship };
  }
  throw new Error('prompt ' + p.kind);
}`);
const viol = {};
const bad = (k, info) => { viol[k] = (viol[k] || 0) + 1; if (viol[k] <= 2) console.log('VIOLATION', k, info); };
let games = 0, deploys = 0, pes = 0, turns = 0;
for (let g = 0; g < N; g++) {
  const side = g % 2 ? 'BR' : 'US';
  X(`__r = ${g * 7919 + 1}; var s = newGame('${side}', ${1000 + g}, { cuttingOut: ${g % 3 === 0}, oa1Upgrades: ${g % 4 === 1}, confirmAiSteps: ${g % 5 !== 0} }); run(s);`);
  let steps = 0, lastLog = 0;
  while (!X('s.over') && steps++ < 3000) {
    const label = X('s.stepLabel');
    // A6/A10 invariants checked when the A10 prompt or B1 is reached
    X(`var __a = pickAnswer(s);`);
    const beforeLog = X('s.log.length');
    const preRow = X('cardCell && s.targetRow.length');
    X(`act(s, __a);`);
    const newLines = X(`s.log.slice(${beforeLog}).map(function(l){ return l.text; })`);
    for (const t of newLines) {
      let m;
      if ((m = /^Naval Balance ([+-]?\d+) → band/.exec(t)) && X('s.turn') > 0) {
        if (X('s.nb') !== X('computeNavalBalance(s)')) bad('A6 NB mismatch', t);
      }
      if ((m = /^Drew (\d+) Target Cards/.exec(t))) {
        const n = +m[1], want = X('NB_CARDS[s.human][s.nbBand]');
        if (n !== want) bad('A10 count', t);
        const len = X('s.targetRow.length'); const blk = X('isBlockaded(s, s.ai)');
        if (len !== n && !(blk && len === n + 1)) bad('row length', len + ' vs ' + n);
        if (X('s.turn') === 7 && X('s.targetRow.some(function(c){ return TARGET_CARDS[c.id].lastTurn; })')) bad('final-turn card drawn', t);
        if (blk) { const z = X('s.targetRow.map(function(c){ return TARGET_CARDS[c.id].zone; })'); const hz = X('homeZone(s.ai)'); const i = z.findIndex(x => x !== hz); if (z.slice(i < 0 ? z.length : i).includes(hz)) bad('blockade shift', z.join(',')); }
      }
      if (/^B1: Possible Encounters/.test(t)) {
        pes++;
        const idx = X('s.pe.map(function(p){ return p.idx; })');
        for (let i = 1; i < idx.length; i++) if (idx[i] < idx[i - 1]) bad('PE order', idx.join(','));
      }
      if ((m = /^Target Card (\w+): .*Deployment table: Troops (\d) row × Naval Balance “([^”]+)” column/.exec(t)) && !/OA1/.test(newLines.join(' '))) {
        // the logged row/column must match the state's row and band at this moment (before any embark)
      }
      if (/AI Deploys to/.test(t)) {
        deploys++;
        X(`(function(){ var fs = Object.values(s.forces).filter(function(f){ return f.side === s.ai && f.origin === 'targetCard'; }); var f = fs[fs.length-1]; var f2 = fs[fs.length-2]; [f, f2].forEach(function(x){ if (x && x.mission === 'ArmySupport' && x.deployPhase && (!x.troops || x.troops > troopCapacity(s, x.ships)) && s.log.length && /Carrying|Army Support mission/.test(s.log[s.log.length-1].text)) __bad++; }); })()`);
        if (X('typeof __bad !== "undefined" && __bad')) { bad('AS troops', t); X('__bad = 0'); }
      }
    }
  }
  if (!X('s.over')) bad('game did not finish', side + ' ' + (1000 + g) + ' ' + X('s.stepLabel'));
  games++; turns += X('s.turn') + 1;
}
console.log(`games ${games}, turns ${turns}, B1 placements ${pes}, A.I. deployments ${deploys}; violations:`, JSON.stringify(viol));
