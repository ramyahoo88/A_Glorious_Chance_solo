// F01 – OA1: the Naval Balance recalculated after an OA1 upgrade counts only U.S. ships still in port.
// U.S. campaign, seed 3, OA1 on. All U.S. ships are assigned to a Kingston Patrol in A7 (June I).
// node F01_oa1_naval_balance.js   (writes F01_oa1_seed3_B1.json, loadable with Load)
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, fs = require('fs'), assert = require('assert');
X(`var s = newGame('US', 3, {oa1Upgrades:true}); run(s);`);
function answer() {
  const p = X('s.prompt'); let a = 'ok';
  if (p.kind === 'choice') a = (p.options.find(o => o.primary) || p.options[0]).id;
  else if (p.kind === 'select') a = p.initial || [];
  else if (p.kind === 'assign') a = { forces: [{ mission: 'Patrol', zone: 'KIN', ships: p.ships, troops: 0 }], flagship: p.flagship };
  X(`act(s, ${JSON.stringify(a)})`);
}
while (X('s.prompt.title') !== 'B1 Possible Encounters') answer();
fs.writeFileSync(__dirname + '/F01_oa1_seed3_B1.json', X('JSON.stringify({state: s, undo: []})'));
const nbA6 = X('s.nb'), usAtSea = X(`sumBy(sideShips(s,'US').filter(sh=>sh.box==='lake'), vpCapture)`);
console.log('A6 Naval Balance', nbA6, 'band', X('s.nbBand'), '| U.S. ships at sea (capture VP)', usAtSea);
const before = X('s.log.length');
answer(); // B1 info -> B2 Encounter Check
const L = X(`s.log.slice(${before}).map(l=>l.text)`);
L.forEach(t => console.log('  ', t));
const upgr = X(`Object.values(s.ships).filter(sh=>sh.flags.upgrading).map(sh=>sh.id)`);
console.log('upgrading:', upgr, '| app Naval Balance now', X('s.nb'), 'band', X('s.nbBand'));
const expectNb = nbA6 + X(`sumBy(Object.values(s.ships).filter(sh=>sh.flags.upgrading), vpCapture)`);
console.log('expected (A6 value less the upgrading ships):', expectNb, 'band', X(`navalBalanceBand(${expectNb})`),
  '→ card', X(`s.targetRow.find(c=>c.enc).id`), 'row 0 cell at that band =', X(`TARGET_CARDS[s.targetRow.find(c=>c.enc).id].grid[0][navalBalanceBand(${expectNb})]`));
assert.deepStrictEqual(upgr, ['wolfe']);
assert.strictEqual(X('s.nb'), -62);           // observed: the U.S. ships on the lake are left out
assert.strictEqual(X('s.nbBand'), 1);
assert.ok(X(`Object.values(s.forces).some(f=>f.side==='BR')`), 'the British deploy on the ≤-26 column');
assert.strictEqual(expectNb, 32);             // expected band 5 (≥+26): A8 row 0 is blank there – no Deployment
console.log('F01 reproduced.');
