// F02 – U.S. campaign: a 7.1 Upgrade Check (or the OA1 roll) is made for British ships that then do not Deploy
// because the Army Support Force cannot carry a Troops marker (EN1.1 / 9.1.4: 4 Close Action per marker).
// Position: Lake Action, your Patrol Force (Oneida) in Sacket's with PE1 on Target Card A26 (Sacket's – Army Support);
// the only British Deployable ship is Lord Beresford (A) (CA 3); 3 A.I. Troops Available; Naval Balance band −15..+15.
// node F02_upgrade_without_deployment.js   (writes F02_beresford_A26.json and F02_beresford_A26_OA1.json)
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, fs = require('fs'), assert = require('assert');
function position(oa1, rng) {
  X(`var s = fresh('US', 182401); s.options.oa1Upgrades = ${oa1}; s.turn = 2;
     var fr = newForce(s, 'US', 'SAC', 'Patrol', ['oneida']);
     sideShips(s, 'BR').forEach(function(sh){ if (sh.box === 'deployable' && sh.id !== 'beres') sh.box = 'repairing'; });
     ['wolfe','rg','moira','sss'].forEach(function(id){ s.ships[id].steps = def(s.ships[id]).red[4]; });
     s.nb = 0; s.nbBand = 3; s.aiTroops.box = [{troops:true,revealed:true},{troops:true,revealed:true},{troops:true,revealed:true}];
     s.targetRow = [{ id: 'A26', revealed: false, enc: false, removed: false }];
     s.pe = [{ num: 1, idx: 0, zone: 'SAC', forceId: fr.id, status: 'possible' }];
     s.deck.event = [8].concat(s.deck.event.filter(function(id){ return id !== 8; }));
     waitAt(s, 'turn', 'B2'); s.rng = ${rng};`);
}
// 7.1 (no OA1): find a dice state where the 50/50 roll upgrades her
let rng = 1;
for (; rng < 50; rng++) { position(false, rng); X(`var t = JSON.parse(JSON.stringify(s)); act(t, 'ok');`); if (X(`t.ships.beres.ver`) === 'B') break; }
position(false, rng);
fs.writeFileSync(__dirname + '/F02_beresford_A26.json', X('JSON.stringify({state: s, undo: []})'));
X(`act(s, 'ok');`);
const L = X(`s.log.map(l=>l.text).filter(t=>/Upgrade|A26|carry/.test(t))`);
L.forEach(t => console.log('  ', t));
console.log('7.1: rng', rng, '| Beresford version', X('s.ships.beres.ver'), '| British Forces on the map', X(`Object.values(s.forces).filter(f=>f.side==='BR').length`), '| PE1', X('s.pe[0].status'));
assert.strictEqual(X(`TARGET_CARDS.A26.grid[3][3]`), '1');                 // ship icon: row 3, column −15..+15
assert.strictEqual(X(`Object.values(s.forces).filter(f=>f.side==='BR').length`), 0);   // nothing Deploys …
assert.strictEqual(X('s.ships.beres.ver'), 'B');                            // … yet she was upgraded for good
// OA1: the once-per-turn roll is spent (and can send her to Make Ready) although nothing Deploys
let r2 = 1;
for (; r2 < 80; r2++) { position(true, r2); X(`var t = JSON.parse(JSON.stringify(s)); act(t, 'ok');`); if (X(`t.ships.beres.box`) === 'makeReady') break; }
position(true, r2);
fs.writeFileSync(__dirname + '/F02_beresford_A26_OA1.json', X('JSON.stringify({state: s, undo: []})'));
X(`act(s, 'ok');`);
X(`s.log.map(l=>l.text).filter(t=>/OA1|A26|carry|Naval Balance/.test(t))`).forEach(t => console.log('  ', t));
console.log('OA1: rng', r2, '| Beresford box', X('s.ships.beres.box'), '| oa1Done', X('s.turnFlags.oa1Done'));
assert.strictEqual(X('s.turnFlags.oa1Done'), true);
console.log('F02 reproduced.');
