// F03 – B1 / 10.1.2: with several of your Forces in one Lake Zone you may choose which Force receives each
// Possible Encounter marker after the first (keeping the distribution even); the app asks only for the first
// marker and then rotates in a fixed order, so some legal placements cannot be made.
// British campaign, turn 3. Your Forces in Sacket's: F1 Patrol (Wolfe, Royal George), F2 Army Support (Lord Beresford,
// Sir Sidney Smith, 1 Troops), F3 Raid (Earl of Moira). Row: B2, B36, B37 (all Sacket's) → three markers.
// node F03_pe_distribution_choice.js  (writes F03_three_forces_B1.json, saved at the B1 choice)
const H = require('/home/claude/audit028/harness.js')();
const X = H.X, fs = require('fs'), assert = require('assert');
function pos() {
  X(`var s = newGame('BR', 4401); s.turn = 2; s.phase = 'lake'; s.lossesThisTurn = []; s.troopsReturning = {US:0,BR:0};
     s.coastal = {raids:[], battles:[], cutouts:[]}; s.pe = []; s.peNext = 1; s.eventsDrawn = []; s.turnFlags = {}; s.convoyDeployed = {US:null, BR:null};
     var A = newForce(s, 'BR', 'SAC', 'Patrol', ['wolfe','rg']).id, B = newForce(s, 'BR', 'SAC', 'ArmySupport', ['beres','sss'], {troops: 1}).id, Cc = newForce(s, 'BR', 'SAC', 'Raid', ['moira']).id;
     s.targetRow = ['B2','B36','B37'].map(function(id){ return { id: id, revealed: false, removed: false, enc: false }; });
     s.calls = [{ proc: 'turn', pc: 'B1', A: {}, L: {} }]; s.prompt = null; run(s); var F = [A, B, Cc];`);
}
pos();
fs.writeFileSync(__dirname + '/F03_three_forces_B1.json', X('JSON.stringify({state: s, undo: []})'));
console.log('Prompt:', X('s.prompt.title'), '–', X('s.prompt.options.map(o=>o.id).join(", ")'));
const reach = new Set();
for (let first = 0; first < 3; first++) {
  pos(); X(`act(s, F[${first}]);`);
  console.log(`first marker on F${first + 1}: next prompt "${X('s.prompt.title')}" → ` + X(`s.pe.map(function(p){ return 'PE' + p.num + '→F' + (F.indexOf(p.forceId) + 1); }).join(', ')`));
  reach.add(X(`s.pe.map(function(p){ return F.indexOf(p.forceId) + 1; }).join('')`));
}
// 10.1.2 allows any order in which the three Forces each get one marker (6 orders); the app can make 3
const legal = ['123', '132', '213', '231', '312', '321'];
const missing = legal.filter(o => !reach.has(o));
console.log('legal orders not reachable:', missing.join(' '));
assert.deepStrictEqual([...reach].sort(), ['123', '231', '312']);
console.log('F03 reproduced.');
