// A.I. deployment from a revealed Target Card: row/column lookup, Troops capacity, package #8 split,
// mission conditions, Convoy procedures. node deploy_tests.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0;
const eq = (n, g, w) => { if (JSON.stringify(g) === JSON.stringify(w)) pass++; else { fail++; console.log('FAIL', n, JSON.stringify(g), 'want', JSON.stringify(w)); } };
X(`function deployPos(side, seed, card, opts) {
  opts = opts || {};
  var s = newGame(side, seed, opts.options || {}); s.turn = opts.turn != null ? opts.turn : 2; s.phase = opts.phase || 'enemy';
  s.lossesThisTurn = []; s.troopsReturning = {US:0, BR:0}; s.coastal = {raids:[], battles:[], cutouts:[]}; s.pe = []; s.eventsDrawn = []; s.turnFlags = {};
  s.convoyDeployed = {US:null, BR:null};
  s.aiTroops.box = []; for (var t = 0; t < (opts.box || 0); t++) s.aiTroops.box.push({troops:true, revealed:true});
  if (opts.pool) Object.values(s.ships).forEach(function(sh){ if (sh.owner === s.ai && opts.pool.indexOf(sh.id) < 0 && sh.box === 'deployable') { sh.box = 'ordinary'; } if (sh.owner === s.ai && opts.pool.indexOf(sh.id) >= 0) { sh.box = 'deployable'; sh.steps = def(sh).full[4]; } });
  s.nb = opts.nb || 0; s.nbBand = navalBalanceBand(s.nb);
  s.targetRow = [{ id: card, revealed: false, removed: false, enc: false }];
  if (opts.setup) opts.setup(s);
  s.calls = [{ proc: 'aiDeploy', pc: 'start', A: { cardIdx: 0, zone: TARGET_CARDS[card].zone, phase: s.phase, encounter: !!opts.encounter, humanForceId: opts.hf || null, peNum: 1 }, L: {} }];
  s.prompt = null; run(s);
  var g = 0; while (s.prompt && s.prompt.kind === 'info' && g++ < 20 && s.calls.length && s.calls[s.calls.length-1].proc === 'aiDeploy') act(s, 'ok');
  return s; }
 function aiForces(s) { return Object.values(s.forces).filter(function(f){ return f.side === s.ai; }).map(function(f){ return { m: f.mission, z: f.zone, t: f.troops, ships: f.ships.slice().sort() }; }); }`);
const START = ['madison', 'oneida', 'tompkins', 'fairam', 'conquest', 'asp', 'growler', 'hamilton', 'julia', 'lady', 'ontario', 'pert', 'raven', 'scourge'];
// B20 Kingston Army Support: row 3 at band 3 = package 7
// #7 with Hamilton: CA 5+3+2+1+1+1 = 13 → 3 Troops; without Hamilton: 12 → exactly 3; without Hamilton and Conquest: 11 → 2
X(`var s1 = deployPos('BR', 5, 'B20', { box: 3, pool: ${JSON.stringify(START)} });`);
eq('B20 row 3 band 3 → package 7, CA 13 carries 3', X('[s1.prompt ? s1.prompt.title : null, aiForces(s1).map(f=>[f.m,f.z,f.t]), aiTroopsInBox(s1)]'), [null, [['ArmySupport', 'KIN', 3]], 0]);
X(`var s2 = deployPos('BR', 5, 'B20', { box: 3, pool: ${JSON.stringify(START.filter(x => x !== 'hamilton'))} });`);
eq('CA exactly 12 → carries all 3', X('[aiForces(s2).map(f=>f.t), aiTroopsInBox(s2)]'), [[3], 0]);
X(`var s3 = deployPos('BR', 5, 'B20', { box: 3, pool: ${JSON.stringify(START.filter(x => x !== 'hamilton' && x !== 'conquest'))} });`);
eq('CA 11 → carries 2, one stays Available', X('[aiForces(s3).map(f=>f.t), aiTroopsInBox(s3)]'), [[2], 1]);
eq('… row for the next card = 1 Available + 2 embarked = 3', X('cardCell(s3, TARGET_CARDS.B20).row'), 3);
// Embarked Troops count toward the row, even with an empty box (B33 row 2 band 4 → 8 needs box Troops → no Deployment)
X(`var s4 = deployPos('BR', 6, 'B9', { box: 0, pool: ${JSON.stringify(START)}, setup: function(s){ newForce(s, 'US', 'NIA', 'ArmySupport', ['pike'], {troops: 2}); s.ships.pike.box='lake'; } });`);
eq('row counts embarked Troops (box 0 + 2 embarked → row 2)', X('cardCell(s4, TARGET_CARDS.B9).row'), 2);
// Army Support card with Troops only embarked: no Deployment
X(`var s5 = deployPos('BR', 6, 'B20', { box: 0, pool: ${JSON.stringify(START)}, setup: function(s){ s.ships.pike.owner='US'; newForce(s, 'US', 'NIA', 'ArmySupport', ['pike'], {troops: 1}); } });`);
eq('AS card, Troops only embarked → no Deployment', X('aiForces(s5).length'), 1);
// row capped at 3
X(`var s6 = deployPos('BR', 6, 'B20', { box: 5, pool: ${JSON.stringify(START)} });`);
eq('5 Troops → row 3', X('s6.lastRow = cardCell(s6, TARGET_CARDS.B20).row'), 3);
// Package #8 (B20 row 2 band 3 = 8): with Pike – 1st Force Pike (CA 9 → 2 Troops), 2nd 22 LG on Patrol
const FULL = START.concat(['pike', 'sylph']);
X(`var s7 = deployPos('BR', 7, 'B20', { box: 2, pool: ${JSON.stringify(FULL)} });`);
eq('#8 two Forces in Kingston', X('aiForces(s7).map(f=>[f.m,f.z,f.t,f.ships.length])'), [['ArmySupport', 'KIN', 2, 1], ['Patrol', 'KIN', 0, 8]]);
// #8 in an Encounter: 1d6 picks which Force fights; both stay
let odd = 0, even = 0;
for (let seed = 1; seed <= 40; seed++) {
  X(`var s8 = deployPos('BR', ${seed}, 'B20', { box: 2, pool: ${JSON.stringify(FULL)}, encounter: true, phase: 'lake' }); var r8 = s8.calls.length ? null : null;`);
  const L = X(`s8.log.map(l=>l.text).filter(t=>/Package #8 roll/.test(t))[0] || ''`);
  if (/odd/.test(L)) odd++; if (/even/.test(L)) even++;
}
eq('#8 Encounter roll happens and both parities occur', [odd > 5, even > 5, odd + even], [true, true, 40]);
// Troops at capacity boundary for U.S. campaign (A.I. British deploy all): A26 Sacket's AS row 1 band 3 = 0? use row 2
X(`var s9 = deployPos('US', 3, 'A26', { box: 3, pool: ['beres'] });`);
eq('A26 British: only Beresford (CA 3) → cannot carry → no Deployment', X('[cardCell(s9, TARGET_CARDS.A26), aiForces(s9).length]'), [{ row: 3, col: 3, v: 1 }, 0]);
X(`var s10 = deployPos('US', 3, 'A26', { box: 3, pool: ['beres', 'moira', 'melville'] });`);
eq('A26 British: CA 3+4+3 = 10 → 2 Troops', X('aiForces(s10).map(f=>[f.m,f.t])'), [['ArmySupport', 2]]);
console.log(`deploy_tests: ${pass} passed, ${fail} failed`);
// W01 nearby: Troops waiting for F7 (aborted mission) are neither Available nor embarked; a Troops marker still
// in the box can embark on a second Army Support Force (B20 row 1 band 3 = #7)
X(`var w1 = deployPos('BR', 9, 'B20', { box: 1, pool: ${JSON.stringify(START)}, setup: function(s){ s.troopsReturning = { US: 2, BR: 0 }; } });`);
eq('W01 nearby: 2 Troops waiting for F7 + 1 Available → row 1, the Available marker embarks', X('[aiForces(w1).map(f=>[f.m,f.t]), aiTroopsInBox(w1), w1.troopsReturning.US]'), [[['ArmySupport', 1]], 0, 2]);
X(`var w2 = deployPos('BR', 9, 'B20', { box: 0, pool: ${JSON.stringify(START)}, setup: function(s){ s.troopsReturning = { US: 2, BR: 0 }; } });`);
eq('W01 nearby: only Troops waiting for F7 → row 0, no Army Support Deployment', X('[cardCell(w2, TARGET_CARDS.B20).row, aiForces(w2).length]'), [0, 0]);
console.log(`deploy_tests (W01 nearby): ${pass} passed, ${fail} failed`);
// Manual packages option: the select prompt lists the Deployable pool; #8 asks for the second stack; empty = no Deployment
X(`var mp = deployPos('BR', 7, 'B20', { box: 2, pool: ${JSON.stringify(FULL)}, options: { manualPackages: true } });`);
eq('manual #8: select prompt for the package', X('[mp.prompt.kind, mp.prompt.pkg, mp.prompt.allowSplit, mp.prompt.items.length]'), ['select', 8, true, 16]);
X(`act(mp, ['pike','madison','sylph','tompkins','fairam','conquest','oneida','growler','julia']);`);
eq('manual #8: second-stack prompt', X('[mp.prompt.title, mp.prompt.max]'), ['Force Package #8 – second stack', 8]);
X(`act(mp, ['madison','sylph','tompkins','fairam','conquest','oneida','growler','julia']); var g9 = 0; while (mp.prompt && mp.prompt.kind === 'info' && g9++ < 5 && mp.calls.length && mp.calls[mp.calls.length-1].proc === 'aiDeploy') act(mp, 'ok');`);
eq('manual #8: Army Support stack (Pike, 2 Troops) + Patrol stack', X('aiForces(mp).map(f=>[f.m,f.t,f.ships.length])'), [['ArmySupport', 2, 1], ['Patrol', 0, 8]]);
X(`var me = deployPos('BR', 7, 'B20', { box: 2, pool: ${JSON.stringify(FULL)}, options: { manualPackages: true } }); act(me, []);`);
eq('manual: empty selection = no Deployment', X('[aiForces(me).length, aiTroopsInBox(me)]'), [0, 2]);
console.log(`deploy_tests (manual packages): ${pass} passed, ${fail} failed`);
