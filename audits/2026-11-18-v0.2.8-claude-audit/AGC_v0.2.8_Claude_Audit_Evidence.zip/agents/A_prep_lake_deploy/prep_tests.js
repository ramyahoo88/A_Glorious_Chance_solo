// Preparation Phase A9/A10 (removal symbols, draw count, Blockade left-shift), B1 numbering, B2 marker handling.
// node prep_tests.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0;
const eq = (n, g, w) => { if (JSON.stringify(g) === JSON.stringify(w)) pass++; else { fail++; console.log('FAIL', n, JSON.stringify(g), 'want', JSON.stringify(w)); } };
const ok = (n, c, i) => eq(n + (i ? ' (' + i + ')' : ''), !!c, true);
X(`function rowAt(side, seed, opts) {
  opts = opts || {};
  var s = newGame(side, seed); s.turn = opts.turn != null ? opts.turn : 2; s.phase = 'prep';
  s.nb = opts.nb || 0; s.nbBand = navalBalanceBand(s.nb);
  if (opts.setup) opts.setup(s);
  s.calls = [{ proc: 'turn', pc: 'A9', A: {}, L: {} }]; s.prompt = null; run(s);
  return s; }`);
// draw counts per band, both maps
for (const [side, counts] of [['US', [10, 10, 9, 8, 7, 6, 6]], ['BR', [6, 6, 7, 8, 9, 10, 10]]]) {
  const nbs = [-70, -69, -26, -25, -16, -15, 15, 16, 25, 26, 59, 60, -999, 999];
  const bands = [0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 0, 6];
  nbs.forEach((nb, i) => eq(`${side} NB ${nb} → band ${bands[i]} → ${counts[bands[i]]} cards`, X(`(function(){ var s = rowAt('${side}', 3, {nb: ${nb}}); return [s.nbBand, s.targetRow.length]; })()`), [bands[i], counts[bands[i]]]));
}
// Removal symbols
let lt = 0, iso = 0, both = 0;
for (let seed = 1; seed <= 30; seed++) {
  lt += X(`(function(){ var s = rowAt('BR', ${seed}, {turn: 7}); return s.targetRow.concat(s.deck.target.map(function(id){return {id:id};})).filter(function(c){ return TARGET_CARDS[c.id].lastTurn; }).length + (s.targetRow.length + s.deck.target.length === 22 ? 0 : 100); })()`);
  iso += X(`(function(){ var s = rowAt('US', ${seed}, {setup: function(s){ s.ships.sss.isolated = true; s.ships.sss.port = 'temp'; }}); return s.targetRow.concat(s.deck.target.map(function(id){return {id:id};})).filter(function(c){ return TARGET_CARDS[c.id].isolated; }).length + (s.targetRow.length + s.deck.target.length === 43 ? 0 : 100); })()`);
  both += X(`(function(){ var s = rowAt('US', ${seed}, {turn: 7, setup: function(s){ s.ships.sss.isolated = true; s.ships.sss.port = 'temp'; }}); return (s.targetRow.length + s.deck.target.length); })()`);
}
eq('Sept II (British deck): 28 final-turn cards removed, 22 left', lt, 0);
eq('A.I. British with an Isolated ship: 11 hourglass cards removed, 43 left', iso, 0);
eq('Sept II + Isolated (U.S. deck): 54 − 15 − 11 + 7 overlapping = 35 left', both / 30, 54 - 15 - 11 + X(`Object.values(TARGET_CARDS).filter(function(c){return c.deck==='A' && c.lastTurn && c.isolated;}).length`));
// Blockade left-shift: AI homeport zone cards to the left, order kept; if none drawn, one from the deck
let shifted = 0, searched = 0, total = 0;
for (let seed = 1; seed <= 60; seed++) {
  for (const side of ['US', 'BR']) {
    const hz = side === 'US' ? 'KIN' : 'SAC';
    const r = X(`(function(){ var s = rowAt('${side}', ${seed}, {setup: function(s){ s.zones['${hz}'].blockade = '${side}'; }});
      var z = s.targetRow.map(function(c){ return TARGET_CARDS[c.id].zone; });
      var k = z.filter(function(x){ return x === '${hz}'; }).length;
      return { z: z, k: k, n: s.targetRow.length, want: NB_CARDS['${side}'][s.nbBand] }; })()`);
    total++;
    const firstNon = r.z.findIndex(z => z !== hz);
    const leftOk = r.z.slice(firstNon < 0 ? r.z.length : firstNon).every(z => z !== hz);
    if (leftOk && r.k >= 1) shifted++;
    if (r.n === r.want + 1) { searched++; if (r.k !== 1) console.log('search added more than one?', r); }
  }
}
eq('Blockade: every row starts with the A.I. homeport cards (at least one)', shifted, total);
ok('Blockade: some rows needed the search (one card added)', searched > 0, searched);
// order of the other cards is kept: compare with the unblockaded draw from the same seed
eq('Blockade: other cards keep their order', X(`(function(){ var a = rowAt('BR', 9).targetRow.map(function(c){return c.id;}); var b = rowAt('BR', 9, {setup: function(s){ s.zones.SAC.blockade = 'BR'; }}).targetRow.map(function(c){return c.id;});
   var na = a.filter(function(id){ return TARGET_CARDS[id].zone !== 'SAC'; }), nb = b.filter(function(id){ return TARGET_CARDS[id].zone !== 'SAC'; }); return JSON.stringify(na) === JSON.stringify(nb); })()`), true);
// Blockade of the HUMAN homeport does not shift
eq('Human homeport blockaded: no shift / no search', X(`(function(){ var a = rowAt('BR', 9).targetRow.map(function(c){return c.id;}); var b = rowAt('BR', 9, {setup: function(s){ s.zones.KIN.blockade = 'US'; }}).targetRow.map(function(c){return c.id;}); return JSON.stringify(a) === JSON.stringify(b); })()`), true);
// No SAC card left at all (Sept II + A.I. Isolated): nothing to search, no crash
eq('Sept II + Isolated, Sacket\'s blockaded: no Sacket\'s card exists – row unchanged length', X(`(function(){ var s = rowAt('BR', 4, {turn: 7, setup: function(s){ s.zones.SAC.blockade = 'BR'; s.ships.raven.isolated = true; s.ships.raven.port='temp'; }}); return [s.targetRow.length, s.targetRow.filter(function(c){return TARGET_CARDS[c.id].zone==='SAC';}).length]; })()`), [8, 0]);
console.log(`prep_tests: ${pass} passed, ${fail} failed`);
// N10 nearby: the only enemy ships to cut out are Isolated ships at Charlotte (Temporary Homeport)
X(`var n10 = newGame('BR', 182309, {cuttingOut: true}); n10.turn = 2; n10.phase = 'prep';
   sideShips(n10, 'US').forEach(function(sh){ if (sh.box === 'deployable') sh.box = 'ordinary'; });
   n10.ships.oneida.box = 'deployable'; n10.ships.oneida.isolated = true; n10.ships.oneida.port = 'temp';
   waitAt(n10, 'turn', 'A7'); act(n10, 'ok'); var pz = n10.prompt.missions.CuttingOut;`);
eq('N10 nearby: Cutting-Out offered only against Charlotte (South Lake)', X('pz'), ['SOU']);
eq('N10 nearby: … Sacket\'s refused', X(`validateAnswer(n10, n10.prompt, { flagship: n10.prompt.flagship, forces: [{ mission: 'CuttingOut', zone: 'SAC', ships: ['wolfe'], troops: 0 }] }) !== null`), true);
eq('N10 nearby: ships In Ordinary / Repairing are not targets', X(`(function(){ var s = newGame('BR', 4, {cuttingOut:true}); s.turn = 2; sideShips(s,'US').forEach(function(sh){ if (sh.box==='deployable') sh.box='ordinary'; }); s.ships.oneida.box='repairing'; return cuttingOutTargets(s, 'BR', 'SAC').length; })()`), 0);
console.log(`prep_tests (N10 nearby): ${pass} passed, ${fail} failed`);
