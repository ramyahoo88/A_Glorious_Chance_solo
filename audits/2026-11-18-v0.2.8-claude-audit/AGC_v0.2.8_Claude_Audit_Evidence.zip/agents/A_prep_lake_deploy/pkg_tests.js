// Force Package selector (Player Aid V, 5.3.1, RULES_NOTES 35-38) against independently derived expectations.
// node pkg_tests.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0;
const ok = (name, cond, info) => { if (cond) pass++; else { fail++; console.log('FAIL', name, info || ''); } };
// outcomes over many RNG states: set of sorted ship lists
function outcomes(pkg, pool, troops) {
  const res = X(`(function(){ var out = {}; for (var k = 1; k <= 300; k++) { var s = newGame('BR', k); s.turn = 2;
     s.aiTroops.box = []; for (var t = 0; t < ${troops || 0}; t++) s.aiTroops.box.push({troops:true, revealed:true});
     var pool = ${JSON.stringify(pool)}.map(function(id){ return s.ships[id]; });
     var r = forcePackageSelect(s, ${pkg}, pool);
     var key = r.ok ? r.ships.slice().sort().join('+') + (r.ships2 ? ' | ' + r.ships2.slice().sort().join('+') : '') : 'FAIL';
     out[key] = (out[key] || 0) + 1; } return out; })()`);
  return res;
}
const keys = o => Object.keys(o).sort();
const MAINS = ['pike', 'madison', 'sylph', 'oneida', 'tompkins', 'fairam', 'conquest'];
const MAINS0 = ['madison', 'oneida', 'tompkins', 'fairam', 'conquest'];               // before Pike and Sylph are built
const SECS = ['asp', 'growler', 'hamilton', 'julia', 'lady', 'ontario', 'pert', 'raven', 'scourge'];
const FULL = MAINS.concat(SECS), START = MAINS0.concat(SECS);
const srt = a => a.slice().sort().join('+');
// #1 All Main Ships
ok('#1 full pool → all Mains', JSON.stringify(keys(outcomes(1, FULL))) === JSON.stringify([srt(MAINS)]));
ok('#1 Secondaries only → no Deployment', JSON.stringify(keys(outcomes(1, SECS))) === '["FAIL"]');
ok('#1 empty pool → no Deployment', JSON.stringify(keys(outcomes(1, []))) === '["FAIL"]');
// #2 28 LG: Mains LG 10+6+4+3+3+2+1 = 29 → the only 6-ship set is all Mains but Oneida
ok('#2 full pool → all Mains but Oneida', JSON.stringify(keys(outcomes(2, FULL))) === JSON.stringify([srt(MAINS.filter(x => x !== 'oneida'))]), JSON.stringify(outcomes(2, FULL)));
ok('#2 start pool (13 + 9 LG) → no Deployment', JSON.stringify(keys(outcomes(2, START))) === '["FAIL"]');
// #3 22 LG full pool: 4 Mains: {pike,sylph}+{tompkins,fairam}|{tompkins,conquest}|{fairam,conquest}|{tompkins,madison}
const e3 = [['pike', 'sylph', 'tompkins', 'fairam'], ['pike', 'sylph', 'tompkins', 'conquest'], ['pike', 'sylph', 'fairam', 'conquest'], ['pike', 'sylph', 'tompkins', 'madison']].map(srt).sort();
ok('#3 full pool → the four 4-Main sets', JSON.stringify(keys(outcomes(3, FULL))) === JSON.stringify(e3), JSON.stringify(outcomes(3, FULL)));
// #3 start pool: Mains 13 + all 9 LG of Secondaries (exactly 22) → all Mains + every Secondary with LG
ok('#3 start pool → all Mains + all LG Secondaries', JSON.stringify(keys(outcomes(3, START))) === JSON.stringify([srt(MAINS0.concat(SECS.filter(x => x !== 'asp' && x !== 'lady')))]), JSON.stringify(outcomes(3, START)));
// #4 16 LG: pike+sylph only
ok('#4 full pool → Pike + Sylph', JSON.stringify(keys(outcomes(4, FULL))) === JSON.stringify([srt(['pike', 'sylph'])]));
// #4 start pool: 13 + 3 → all Mains + 2 Secondaries (one 2-LG + one 1-LG, or Growler+Julia)
{ const o = outcomes(4, START); const good = keys(o).every(k => { const sec = k.split('+').filter(x => SECS.includes(x)); return k.split('+').filter(x => MAINS0.includes(x)).length === 5 && sec.length === 2; });
  ok('#4 start pool → all Mains + exactly 2 Secondaries', good, JSON.stringify(o)); }
// #5 18: pike+sylph + one of madison/tompkins/fairam/conquest
ok('#5 full pool', JSON.stringify(keys(outcomes(5, FULL))) === JSON.stringify(['madison', 'tompkins', 'fairam', 'conquest'].map(x => srt(['pike', 'sylph', x])).sort()), JSON.stringify(outcomes(5, FULL)));
// #6 20: pike+sylph+tompkins only
ok('#6 full pool', JSON.stringify(keys(outcomes(6, FULL))) === JSON.stringify([srt(['pike', 'sylph', 'tompkins'])]));
ok('#6 start pool (22 LG available) → all Mains + Secondaries totalling 7 with fewest ships (Growler, Julia + three 1-LG = 5)', keys(outcomes(6, START)).every(k => k.split('+').length === 10 && k.includes('growler') && k.includes('julia')), JSON.stringify(outcomes(6, START)));
// #7 all Mains + Secondaries with LG and/or CA (not Asp, Lady)
ok('#7 full pool', JSON.stringify(keys(outcomes(7, FULL))) === JSON.stringify([srt(FULL.filter(x => x !== 'asp' && x !== 'lady'))]));
ok('#7 only Asp + Lady → no Deployment', JSON.stringify(keys(outcomes(7, ['asp', 'lady']))) === '["FAIL"]');
// #8 needs Troops; 1st = fewest Mains CA ≥ 8 (Pike alone); 2nd = 22 LG from the rest (Mains first)
ok('#8 no Troops → no Deployment', JSON.stringify(keys(outcomes(8, FULL, 0))) === '["FAIL"]');
{ const o = outcomes(8, FULL, 2); ok('#8 full pool: 1st Force = Pike', keys(o).every(k => k.split(' | ')[0] === 'pike'), JSON.stringify(o));
  ok('#8 full pool: 2nd Force = remaining Mains (19 LG) + 2 Secondaries', keys(o).every(k => { const s2 = k.split(' | ')[1].split('+'); return ['madison', 'sylph', 'oneida', 'tompkins', 'fairam', 'conquest'].every(m => s2.includes(m)) && s2.length === 8; }), JSON.stringify(o)); }
{ const o = outcomes(8, START, 1); ok('#8 start pool: Mains CA 5+3+2+1+1 = 12 → 1st Force Madison+Oneida; 2nd needs 22 LG of 12+9 → no Deployment', JSON.stringify(keys(o)) === '["FAIL"]', JSON.stringify(o)); }
{ const o = outcomes(8, MAINS.filter(x => x !== 'pike').concat(SECS), 1); ok('#8 no Pike: RULES_NOTES 57 random split (some rolls fail)', keys(o).includes('FAIL') && keys(o).some(k => k !== 'FAIL'), JSON.stringify(o)); }
// #9
ok('#9 full pool → Lady + Asp (0 CA, 0 LG)', JSON.stringify(keys(outcomes(9, FULL))) === JSON.stringify([srt(['lady', 'asp'])]));
ok('#9 no Lady → Asp + one 1-LG 0-CA Secondary', JSON.stringify(keys(outcomes(9, FULL.filter(x => x !== 'lady')))) === JSON.stringify(['ontario', 'pert', 'raven', 'scourge'].map(x => srt(['asp', x])).sort()), JSON.stringify(outcomes(9, FULL.filter(x => x !== 'lady'))));
ok('#9 Lady only → no Deployment', JSON.stringify(keys(outcomes(9, ['lady', 'madison']))) === '["FAIL"]');
ok('#9 Hamilton (CA 1) is never picked', !keys(outcomes(9, ['hamilton', 'growler', 'julia'])).some(k => k.includes('hamilton')));
// #10
{ const o = outcomes(10, FULL); ok('#10 two random Secondaries', keys(o).every(k => k.split('+').length === 2 && k.split('+').every(x => SECS.includes(x))) && keys(o).length > 20, keys(o).length); }
ok('#10 one Secondary → no Deployment', JSON.stringify(keys(outcomes(10, ['asp', 'pike']))) === '["FAIL"]');
// #11 five steps (Lady = 2 steps)
{ const o = outcomes(11, FULL); ok('#11 ≥5 steps of Secondaries, none extra', keys(o).every(k => { const l = k.split('+'); const st = l.reduce((a, x) => a + (x === 'lady' ? 2 : 1), 0); return l.every(x => SECS.includes(x)) && st >= 5 && st <= 6; }), JSON.stringify(o).slice(0, 300)); }
ok('#11 4 steps of Secondaries → no Deployment', JSON.stringify(keys(outcomes(11, ['asp', 'growler', 'julia', 'pert', 'pike']))) === '["FAIL"]');
ok('#11 exactly 5 steps (Lady + 3) → all of them', JSON.stringify(keys(outcomes(11, ['lady', 'asp', 'growler', 'julia']))) === JSON.stringify([srt(['lady', 'asp', 'growler', 'julia'])]));
console.log(`pkg_tests: ${pass} passed, ${fail} failed`);
