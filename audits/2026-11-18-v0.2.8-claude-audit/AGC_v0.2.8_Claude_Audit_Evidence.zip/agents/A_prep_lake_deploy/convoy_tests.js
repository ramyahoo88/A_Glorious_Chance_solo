// Convoy Encounters (11.3.1 cases 1 and 2), Scatter Table outcomes and Convoy Supply edges; rechecks of
// 0.2.4 N01 / N02 / N10 and 0.2.5 W01 with nearby cases. node convoy_tests.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0;
const eq = (n, g, w) => { if (JSON.stringify(g) === JSON.stringify(w)) pass++; else { fail++; console.log('FAIL', n, JSON.stringify(g), 'want', JSON.stringify(w)); } };
const say = '(function(){})';
X(`function board(human, card, aiPool, opts) {
  opts = opts || {};
  var s = fresh(human, opts.seed || 182301); s.options.cuttingOut = true; s.turn = 2;
  var zone = TARGET_CARDS[card].zone;
  var fr = newForce(s, human, opts.zone || zone, opts.mission || 'Patrol', opts.mine || (human === 'BR' ? ['wolfe'] : ['madison']));
  sideShips(s, s.ai).forEach(function(sh){ if (sh.box === 'deployable' && aiPool.indexOf(sh.id) < 0) sh.box = 'ordinary'; });
  s.nb = 0; s.nbBand = 3; s.aiTroops.box = [];
  s.convoys[s.ai][2] = { real: opts.aiConvoy !== false, revealed: false, delay: false, deployed: false, result: null };
  s.convoys[s.ai][3] = { real: opts.aiConvoy === false, revealed: false, delay: false, deployed: false, result: null };
  s.convoys[human][2] = { real: !!opts.myConvoy, revealed: true, delay: false, deployed: false, result: null };
  s.convoys[human][3] = { real: !opts.myConvoy, revealed: true, delay: false, deployed: false, result: null };
  if (opts.setup) opts.setup(s, fr);
  s.targetRow = [{ id: card, revealed: false, enc: false, removed: false }];
  s.pe = [{ num: 1, idx: 0, zone: zone, forceId: fr.id, status: 'possible' }];
  s.deck.event = [8].concat(s.deck.event.filter(function(id){ return id !== 8; }));
  waitAt(s, 'turn', 'B2'); s.rng = opts.rng || 1; s.HF = fr.id; return s; }
 function texts(s) { return s.log.map(function(l){ return l.text; }).join(' || '); }`);
// --- 11.3.1 case 1, British campaign (A.I. U.S. Convoy, Sacket's Escort card) ---
X(`var a = board('BR', 'B2', ['growler','julia','pert']); act(a, 'ok'); act(a, 'ok');`);   // B2 row0 band3 = #10 (two random Secondaries)
eq('BR Escort card: Convoy revealed, escorted by package #10, kind convoy', X(`[a.convoys.US[2].revealed, a.convoyDeployed.US && a.convoyDeployed.US.zone, Object.values(a.forces).filter(f=>f.side==='US').map(f=>[f.mission,f.ships.length])[0], a.encounter && a.encounter.kind]`), [true, 'SAC', ['Escort', 2], 'convoy']);
X(`var b = board('BR', 'B2', ['growler']); act(b, 'ok');`);
eq('N01 nearby: one Secondary for #10 → unescorted, Scatter roll with Wolfe\'s 22 guns (row 22-42)', X(`[/Convoy Scatter Table: 22 guns/.test(b.prompt.text), b.convoys.US[2].result !== null]`), [true, true]);
X(`var c = board('BR', 'B2', ['growler','julia'], { aiConvoy: false }); act(c, 'ok'); act(c, 'ok');`);
eq('No A.I. Convoy this turn → Escort card is a Patrol (package #10 deploys as Patrol)', X(`[c.convoys.US[2].revealed, Object.values(c.forces).filter(f=>f.side==='US').map(f=>f.mission)[0], c.encounter && c.encounter.kind]`), [true, 'Patrol', 'normal']);
X(`var d = board('BR', 'B2', ['growler'], { aiConvoy: false }); act(d, 'ok');`);
eq('N01 nearby: No Convoy + unfillable package → plain no-Deployment (no Scatter roll)', X(`[/Scatter/.test(texts(d)), d.pe[0].status === 'ended' || /no enemy/.test(d.prompt.title)]`), [false, true]);
X(`var e = board('BR', 'B2', ['growler','julia'], { setup: function(s){ s.convoyDeployed.US = { zone: 'SAC' }; s.convoys.US[2].deployed = true; } }); act(e, 'ok');`);
eq('Convoy already Deployed → Escort card is a Patrol', X(`Object.values(e.forces).filter(f=>f.side==='US').map(f=>f.mission)[0]`), 'Patrol');
// --- U.S. campaign: A.I. British Convoy, A17 Niagara Escort card (row 0 band 3 = ship icon) ---
X(`var f = board('US', 'A17', ['wolfe','rg','moira','beres','sss'], { zone: 'NIA' }); act(f, 'ok'); act(f, 'ok');`);
eq('US Escort card: British Convoy + all Deployable British ships as escort in Niagara', X(`[f.convoyDeployed.BR && f.convoyDeployed.BR.zone, Object.values(f.forces).filter(x=>x.side==='BR').map(x=>[x.mission,x.zone,x.ships.length])[0], f.encounter && f.encounter.kind]`), [['NIA'][0], ['Escort', 'NIA', 5], 'convoy']);
X(`var g = board('US', 'A17', [], { zone: 'NIA' }); act(g, 'ok');`);
eq('No British Deployable ships at B2: the PE is discarded before any check (10.2), Convoy untouched', X(`[g.pe[0].status, /Encounter Check|Scatter/.test(texts(g)), g.convoys.BR[2].result]`), ['discarded', false, null]);
X(`var g2 = board('US', 'A17', ['beres'], { zone: 'NIA', setup: function(s){ s.options.oa1Upgrades = true; } }); g2.rng = 3; act(g2, 'ok');`);
eq('OA1 sends the only escort to Make Ready → Convoy unescorted, Scatter roll', X(`[/OA1 upgrade roll/.test(texts(g2)), g2.ships.beres.box, /Convoy Scatter Table/.test(g2.prompt.text) || /no longer Deploys/.test(texts(g2))]`), [true, 'makeReady', true]);
// --- Scatter outcomes → Convoy Supply (F5) with track edges ---
for (const [res, sup, other, want] of [['S', 3, 3, [3, 3, 1]], ['D', 3, 3, [3, 3, 0]], ['C', 3, 11, [3, 12, 0]], ['C', 3, 12, [3, 12, 0]], ['C', -1, 5, [-1, 6, 0]], [null, 11, 3, [12, 3, 0]], [null, 12, 3, [12, 3, 0]]]) {
  eq(`F5 U.S. Convoy ${res || 'arrives'} (U.S. ${sup}, British ${other})`, X(`(function(){ var s = fresh('US', 5); s.turn = 2; s.supply.US = ${sup}; s.supply.BR = ${other};
     s.convoys.US[2] = { real: true, revealed: true, delay: false, deployed: ${!!res}, result: ${JSON.stringify(res)} }; convoySupply(s, 'US', ${say});
     return [s.supply.US, s.supply.BR, s.pendingConvoy.US.length]; })()`), want);
}
eq('Supply cannot go below −1', X(`(function(){ var s = fresh('US', 5); s.supply.BR = -1; moveSupply(s, 'BR', -2, 'test'); return s.supply.BR; })()`), -1);
// --- 11.3.1 case 2, British campaign, Enemy Operations: B21 North Lake, Attack British Convoy ---
X(`function c2(escortShips, seed) { var s = fresh('BR', seed || 77); s.turn = 2; s.phase = 'enemy';
     s.convoys.BR[2] = { real: true, revealed: true, delay: false, deployed: false, result: null }; s.convoys.BR[3] = { real: false, revealed: true };
     escortShips.forEach(function(id){ s.ships[id].box = 'escortBox'; });
     sideShips(s, 'US').forEach(function(sh){ if (sh.box === 'deployable' && ['madison','oneida','tompkins','fairam','conquest','growler','julia','hamilton','ontario','pert','raven','scourge','asp','lady'].indexOf(sh.id) < 0) sh.box = 'ordinary'; });
     s.aiTroops.box = []; s.nb = 0; s.nbBand = 3; s.targetRow = [{ id: 'B21', revealed: true, enc: false, removed: false }];
     s.calls = [{ proc: 'aiDeploy', pc: 'start', A: { cardIdx: 0, zone: 'NOR', phase: 'enemy', encounter: false }, L: {} }]; s.prompt = null; run(s); return s; }`);
X(`var h = c2(['wolfe','rg']); var hp = h.prompt.text; act(h, 'ok');`);
eq('C phase, B21 (#11 random Secondaries): British Convoy + Escort box ships in North Lake, escorted Encounter', X(`[h.convoyDeployed.BR && h.convoyDeployed.BR.zone, h.ships.wolfe.zone, h.encounter && h.encounter.kind]`), ['NOR', 'NOR', 'convoy']);
X(`var k = c2([]); var kp = k.prompt; act(k, 'ok'); var kk = k.prompt;`);
eq('C phase, no Escort box ships → Scatter roll with the A.I. Force\'s guns', X(`/without an escort/.test(kk.text) && /Convoy Scatter Table/.test(kk.text)`), true);
eq('Lake Action (British campaign): the same card is a plain Patrol (ruling)', X(`effectiveMission(k, TARGET_CARDS.B21, 'lake').mission`), 'Patrol');
// --- U.S. campaign, Lake Action: A31 Sacket's Attack U.S. Convoy with an Escort Force in Sacket's ---
X(`var m = board('US', 'A31', ['wolfe','rg','moira','beres','sss'], { myConvoy: true, mine: ['oneida'], setup: function(s){ newForce(s, 'US', 'SAC', 'Escort', ['madison']); } }); act(m, 'ok'); act(m, 'ok');`);
eq('US Lake Action A31: your Escort Force and the triggering Force both defend the Convoy', X(`m.encounter ? Object.keys(m.encounter.ships).filter(id=>m.ships[id].owner==='US').sort() : texts(m).slice(-300)`), ['madison', 'oneida']);
X(`var n = board('US', 'A31', ['wolfe','rg','moira','beres','sss'], { myConvoy: true, mine: ['oneida'] }); act(n, 'ok'); act(n, 'ok');`);
eq('US Lake Action A31, no Escort Force: Scatter roll and the Encounter ends (note 12)', X(`[/without an escort/.test(n.prompt.text), n.convoys.US[2].result !== null]`), [true, true]);
console.log(`convoy_tests: ${pass} passed, ${fail} failed`);
// N02 nearby: blank cell (B37 row 0, band 0) on a confirmed Encounter → Encounter Ended → Cutting-Out aborts;
// control: no A.I. Deployable ships → PEs discarded unchecked → the Cutting-Out goes ahead
for (const [name, pool, nb, want] of [['N02 nearby: blank cell', ['madison', 'oneida'], -80, ['ended', true]], ['N02 nearby control: no A.I. Deployable ships', [], -80, ['discarded', false]]]) {
  X(`var q = board('BR', 'B37', ${JSON.stringify(pool)}, { mission: 'CuttingOut', setup: function(s){ s.cuttingOutUsed.BR = true; s.nb = ${nb}; s.nbBand = navalBalanceBand(${nb}); if (!${pool.length}) { s.ships.madison.box = 'makeReady'; } } });
     act(q, 'ok'); playUntil(q, function(z){ return z.prompt && /^Tally/.test(z.prompt.title); });`);
  eq(name, X(`[q.pe[0].status, !!(q.forces[q.HF] && q.forces[q.HF].ended)]`), want);
  eq(name + ' – Cutting-Out result', X(`/Cutting-Out mission aborts/.test(texts(q))`), want[1]);
}
console.log(`convoy_tests (N02 nearby): ${pass} passed, ${fail} failed`);
