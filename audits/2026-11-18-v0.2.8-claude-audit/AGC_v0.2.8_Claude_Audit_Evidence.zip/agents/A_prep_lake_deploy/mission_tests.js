// effectiveMission: every card condition against the printed card text. node mission_tests.js
const H = require('/home/claude/audit028/harness.js')();
const X = H.X;
let pass = 0, fail = 0;
const eq = (n, g, w) => { if (JSON.stringify(g) === JSON.stringify(w)) pass++; else { fail++; console.log('FAIL', n, JSON.stringify(g), 'want', JSON.stringify(w)); } };
const em = (side, card, setup, phase) => X(`(function(){ var s = newGame('${side}', 3); s.turn = 2; s.convoyDeployed = {US:null,BR:null}; s.aiTroops.box = [{troops:true,revealed:true}]; ${setup || ''}; return effectiveMission(s, TARGET_CARDS['${card}'], '${phase || 'lake'}').mission; })()`);
// Raid (Patrol)
eq('A41 Raid, no A.I. Raid in Sacket\'s', em('US', 'A41'), 'Raid');
eq('A41 Raid, A.I. Raid already in Sacket\'s → Patrol', em('US', 'A41', `newForce(s,'BR','SAC','Raid',['sss'])`), 'Patrol');
eq('A41 Raid, A.I. Raid in another zone → Raid', em('US', 'A41', `newForce(s,'BR','SOU','Raid',['sss'])`), 'Raid');
eq('B4 Raid, human Raid in Kingston does not count', em('BR', 'B4', `newForce(s,'BR','KIN','Raid',['sss'])`), 'Raid');
// Cutting-Out
eq('A34 Cutting-Out, option off → none', em('US', 'A34'), null);
eq('A34 Cutting-Out, option on', em('US', 'A34', `s.options.cuttingOut = true`), 'CuttingOut');
eq('A34 Cutting-Out, A.I. already used it → none', em('US', 'A34', `s.options.cuttingOut = true; s.cuttingOutUsed.BR = true`), null);
eq('A34 Cutting-Out, only the human used his → still Deploys', em('US', 'A34', `s.options.cuttingOut = true; s.cuttingOutUsed.US = true`), 'CuttingOut');
// Patrol (Cutting-Out) if the human uses a Temporary Homeport
eq('A43 no U.S. Temporary Homeport → Patrol', em('US', 'A43', `s.options.cuttingOut = true`), 'Patrol');
eq('A43 U.S. using Charlotte → Cutting-Out', em('US', 'A43', `s.options.cuttingOut = true; s.ships.oneida.isolated = true; s.ships.oneida.port = 'temp'`), 'CuttingOut');
eq('A43 U.S. using Charlotte, A.I. Cutting-Out used → does not Deploy (card text)', em('US', 'A43', `s.options.cuttingOut = true; s.cuttingOutUsed.BR = true; s.ships.oneida.isolated = true`), null);
eq('B12 British using York → Cutting-Out', em('BR', 'B12', `s.options.cuttingOut = true; s.ships.sss.isolated = true; s.ships.sss.port = 'temp'`), 'CuttingOut');
// Niagara Front
eq('A10 Niagara Front in Fort George → none', em('US', 'A10', `s.niagara = 6`), null);
eq('A10 Niagara Front one space short → Army Support', em('US', 'A10', `s.niagara = 5`), 'ArmySupport');
eq('A10 Niagara Front in Burlington Heights → Army Support', em('US', 'A10', `s.niagara = 0`), 'ArmySupport');
eq('B5 Niagara Front in Burlington Heights → none', em('BR', 'B5', `s.niagara = 0`), null);
eq('B5 Niagara Front in Fort George → Army Support', em('BR', 'B5', `s.niagara = 6`), 'ArmySupport');
// Pike / Sylph unbuilt
eq('A25 both under construction → Army Support', em('US', 'A25'), 'ArmySupport');
eq('A25 Pike Deployable, Sylph in Repairing → Army Support', em('US', 'A25', `s.ships.pike.box='deployable'; s.ships.sylph.box='repairing'`), 'ArmySupport');
eq('A25 Pike in Make Ready, Sylph Deployable → none', em('US', 'A25', `s.ships.pike.box='makeReady'; s.ships.sylph.box='deployable'`), null);
eq('A25 Sylph captured, in the British Repairing area, Pike Deployable → none', em('US', 'A25', `s.ships.pike.box='deployable'; s.ships.sylph.owner='BR'; s.ships.sylph.box='repairing'`), null);
eq('A26 (no condition) with both built → Army Support', em('US', 'A26', `s.ships.pike.box='deployable'; s.ships.sylph.box='deployable'`), 'ArmySupport');
// Army Support with no A.I. Troops in the box
eq('A26 no A.I. Troops in the box → none', em('US', 'A26', `s.aiTroops.box = []`), null);
eq('A26 unrevealed marker only → none', em('US', 'A26', `s.aiTroops.box = [{troops:true, revealed:false}]`), null);
// Attack Convoy
eq('A31 U.S. Convoy running → Attack Convoy (Lake Action, U.S. campaign)', em('US', 'A31', `s.convoys.US[2] = {real:true, revealed:true}`), 'AttackConvoy');
eq('A31 Convoy runs next turn → Patrol', em('US', 'A31', `s.convoys.US[3] = {real:true, revealed:true}; s.convoys.US[2] = {real:false}`), 'Patrol');
eq('A31 Convoy already Deployed → Patrol', em('US', 'A31', `s.convoys.US[2] = {real:true, revealed:true}; s.convoyDeployed.US = {zone:'SAC'}`), 'Patrol');
eq('B21 Lake Action, British campaign → Patrol (ruling)', em('BR', 'B21', `s.convoys.BR[2] = {real:true, revealed:true}`), 'Patrol');
eq('B21 Enemy Operations → Attack Convoy', em('BR', 'B21', `s.convoys.BR[2] = {real:true, revealed:true}`, 'enemy'), 'AttackConvoy');
console.log(`mission_tests: ${pass} passed, ${fail} failed`);
