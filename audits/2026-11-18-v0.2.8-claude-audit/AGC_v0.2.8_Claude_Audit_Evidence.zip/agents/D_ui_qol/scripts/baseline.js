// Node baseline: play a campaign with the visible-information policy, tally prompts per turn.
// usage: node baseline.js SIDE SEED STYLE [opts-json]
process.argv[2] = process.argv[2]; const side = process.argv[2], seed = +process.argv[3], style = process.argv[4] || 'fleet';
const opts = JSON.parse(process.argv[5] || '{}');
const repo = '/home/claude/a_glorious_chance_solo';
const save = process.argv.slice(); process.argv[2] = repo;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const E = require(repo + '/tools/bundle_engine.js')();
const s = E.newGame(side, seed, opts); E.run(s);
const per = {}; const titles = {}; let n = 0;
while (!s.over && n < 3000) {
  const p = s.prompt; const t = s.turn;
  per[t] = per[t] || { prompts: 0, info: 0, choice: 0, select: 0, lineup: 0, assign: 0 };
  per[t].prompts++; per[t][p.kind]++;
  const key = p.kind + ' | ' + p.title.replace(/\d+/g, '#');
  titles[key] = (titles[key] || 0) + 1;
  E.act(s, policy(s, p, style)); n++;
}
const ledger = s.vpLog.reduce((a, v) => a + (v.side === 'US' ? v.n : -v.n), 0);
console.log(JSON.stringify({ side, seed, style, n, over: s.over, turn: s.turn, result: s.result, ledger, per }, null, 0));
if (process.env.TITLES) console.log(Object.entries(titles).sort((a, b) => b[1] - a[1]).map(([k, v]) => v + '\t' + k).join('\n'));
