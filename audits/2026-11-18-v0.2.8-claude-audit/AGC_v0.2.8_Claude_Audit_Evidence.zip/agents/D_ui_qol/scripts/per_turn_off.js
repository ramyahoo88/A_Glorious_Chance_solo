const fs = require('fs');
const H = require('/home/claude/audit028/harness.js')();
H.X('var window = this;'); H.X(fs.readFileSync(__dirname + '/policy_page.js', 'utf8'));
for (const [side, seed] of [['US', 280004], ['BR', 280002]]) {
  const r = H.X(`(() => { const s = newGame('${side}', ${seed}, { confirmAiSteps: false }); run(s); const per = {}; let n = 0;
    while (!s.over && n++ < 3000) { const p = s.prompt; const T = per[s.turn] = per[s.turn] || { prompts: 0, info: 0, decisions: 0 }; T.prompts++; if (p.kind === 'info') T.info++; else T.decisions++; act(s, __policy(s, p, 'sensible')); }
    return { per, score: s.result.score }; })()`);
  console.log(side, seed, 'score', r.score, JSON.stringify(r.per));
}
