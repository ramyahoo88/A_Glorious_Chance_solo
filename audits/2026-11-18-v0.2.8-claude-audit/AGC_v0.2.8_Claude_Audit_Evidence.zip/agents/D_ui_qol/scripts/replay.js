// Replay the answers a browser run gave, in the engine alone, and compare the finished state with the browser's.
// usage: node replay.js runs/TAG.json
const fs = require('fs'); const run = JSON.parse(fs.readFileSync(process.argv[2]));
const fin = JSON.parse(fs.readFileSync(process.argv[2].replace('.json', '_final_state.json'))).state;
const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
const s = E.newGame(run.side, run.seed, run.opts || {}); E.run(s);
for (const a of run.answers) { const e = E.validateAnswer(s, s.prompt, a); if (e) { console.log('INVALID', s.prompt.title, e); process.exit(1); } E.act(s, a); }
const strip = o => JSON.stringify(Object.assign({}, o, { build: null }));
console.log(run.side, run.seed, 'answers', run.answers.length, 'over', s.over, 'identical final state:', strip(s) === strip(fin), 'score', s.result && s.result.score);
if (strip(s) !== strip(fin)) for (const k of Object.keys(s)) if (JSON.stringify(s[k]) !== JSON.stringify(fin[k])) console.log(' differs:', k);
