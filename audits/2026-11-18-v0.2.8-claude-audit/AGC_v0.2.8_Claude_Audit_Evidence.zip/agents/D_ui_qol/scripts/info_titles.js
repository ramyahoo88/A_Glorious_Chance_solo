const fs = require('fs');
const H = require('/home/claude/audit028/harness.js')();
H.X('var window = this;'); H.X(fs.readFileSync(__dirname + '/policy_page.js', 'utf8'));
const out = H.X(`(() => { const agg = {}; const streaks = []; 
  for (const [side, seed] of [['US', 280004], ['BR', 280002]]) for (const pause of [true, false]) {
    const s = newGame(side, seed, { confirmAiSteps: pause }); run(s); let n = 0, streak = 0;
    while (!s.over && n < 3000) { const p = s.prompt;
      if (p.kind === 'info') { streak++; const k = (pause ? 'on ' : 'off ') + side + ' ' + p.title.replace(/\\d+/g, '#').replace(/ – (June|July|August|September|Sept)[^]*$/, ' – <turn>'); agg[k] = (agg[k] || 0) + 1; }
      else { if (streak) streaks.push((pause ? 'on ' : 'off ') + side + ' ' + streak); streak = 0; }
      act(s, __policy(s, p, 'sensible')); n++; }
  }
  return { agg, streaks }; })()`);
const lines = Object.entries(out.agg).sort((a, b) => a[0].localeCompare(b[0]));
console.log(lines.map(([k, v]) => v + '\t' + k).join('\n'));
const st = {}; out.streaks.forEach(x => { const [m, sd, n] = x.split(' '); const k = m + ' ' + sd; st[k] = st[k] || []; st[k].push(+n); });
for (const k in st) console.log('streaks of consecutive Continue', k, 'max', Math.max(...st[k]), 'mean', (st[k].reduce((a, b) => a + b, 0) / st[k].length).toFixed(1), 'count>=4', st[k].filter(x => x >= 4).length, 'n', st[k].length);
