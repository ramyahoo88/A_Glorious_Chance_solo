# Header/Tracks vs state on every fixture save (unusual positions: blockades, Isolated ships, Troops due at F7, recovery notices).
import json, glob
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
CHK = (HERE / 'check_page.js').read_text()
files = sorted(glob.glob('/home/claude/gpt_re7/ev/fixtures/*.json') + glob.glob('/home/claude/gpt_re7/ev/positions-found/*.json') + glob.glob('/home/claude/gpt_re7/ev/legacy/*.json') + glob.glob(str(OUT / 'saves' / '*.json')))
res = {}; errors = []
with sync_playwright() as p:
    b = launch(p)
    for W, H in ((1300, 900), (390, 844)):
        pg = new_page(b, W, H, errors); pg.context.add_init_script(CHK); fresh_setup(pg); start(pg, 'US', 1)
        for f in files:
            load_text(pg, open(f).read())
            if pg.evaluate("document.getElementById('modal').classList.contains('open')"):
                res[f'{f.split("/")[-1]}@{W}'] = 'refused: ' + pg.inner_text('#modal .err')[:100]; pg.click("#modal button:has-text('Close')"); continue
            c = pg.evaluate("__check()")
            due = pg.evaluate("[G_STATE.troopsReturning && G_STATE.troopsReturning[G_STATE.human], G_STATE.troopsReturning && G_STATE.troopsReturning[G_STATE.ai]]")
            res[f'{f.split("/")[-1]}@{W}'] = {'mismatches': c['out'], 'overflow': c['overflow'], 'due_you_ai': due, 'tracks_troops_line': [l for l in pg.inner_text('#board .panel').split('\n') if l.startswith('Troops')][:1]}
        pg.close()
    b.close()
bad = {k: v for k, v in res.items() if isinstance(v, str) or v['mismatches'] or v['overflow']}
print('files', len(files), 'checks', len(res), 'problems', json.dumps(bad, indent=1))
print(json.dumps({k: v for k, v in res.items() if not isinstance(v, str) and (v['due_you_ai'][0] or v['due_you_ai'][1])}, indent=1, ensure_ascii=False)); print(errors[:5])
(OUT / 'runs' / 'fixture_checks.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
