# Find what changes when a game is reopened with "Continue it" (reload) at decision N of a recorded run.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
run = json.loads((OUT / 'runs' / (sys.argv[1] + '.json')).read_text()); stops = [int(x) for x in sys.argv[2].split(',')]
def walk(a, b, path=''):
    if type(a) != type(b): return [f'{path}: {json.dumps(a)[:150]} -> {json.dumps(b)[:150]}']
    if isinstance(a, dict):
        out = []
        for k in set(a) | set(b):
            if k not in a: out.append(f'{path}.{k}: (absent) -> {json.dumps(b[k])[:150]}')
            elif k not in b: out.append(f'{path}.{k}: {json.dumps(a[k])[:150]} -> (absent)')
            else: out += walk(a[k], b[k], path + '.' + k)
        return out
    if isinstance(a, list):
        if len(a) != len(b): return [f'{path}: len {len(a)} -> {len(b)}']
        out = []
        for i, (x, y) in enumerate(zip(a, b)): out += walk(x, y, f'{path}[{i}]')
        return out
    return [] if a == b else [f'{path}: {json.dumps(a)[:150]} -> {json.dumps(b)[:150]}']
errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, run['side'], run['seed'], run.get('opts') or {})
    for i, a in enumerate(run['answers']):
        if i in stops:
            S1 = json.loads(pg.evaluate("JSON.stringify(G_STATE)")); t = pg.evaluate("G_STATE.prompt.title")
            pg.reload(); pg.click("text=Continue it"); S2 = json.loads(pg.evaluate("JSON.stringify(G_STATE)"))
            d = walk(S1, S2); print('decision', i, 'prompt', t, 'differences', len(d)); [print('   ', x) for x in d[:12]]
            if i == max(stops): break
        realize(pg, a, {'clicks': 0, 'notes': []})
    b.close()
