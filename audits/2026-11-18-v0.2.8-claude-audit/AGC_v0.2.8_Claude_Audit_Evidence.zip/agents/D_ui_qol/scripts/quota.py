# How much localStorage room does one autosave take (file:// origin; GitHub Pages apps of one account share one origin too)?
import json
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg)
    quota = pg.evaluate("""() => { localStorage.clear(); let lo = 0, hi = 20e6; while (hi - lo > 1000) { const mid = Math.floor((lo + hi) / 2); try { localStorage.setItem('q', 'x'.repeat(mid)); lo = mid; } catch (e) { hi = mid; } } localStorage.clear(); return lo; }""")
    # largest autosave seen: replay the BR fleet run with Undo history
    run = json.loads((OUT / 'runs' / 'BR280009_fleet_1300.json').read_text())
    start(pg, run['side'], run['seed'])
    for a in run['answers']: realize(pg, a, {'clicks': 0, 'notes': []})
    size = pg.evaluate("localStorage.getItem(SAVE_KEY).length")
    print(json.dumps({'quota_chars': quota, 'autosave_chars_at_game_end': size, 'share': round(size / quota, 2), 'undo_in_memory': pg.evaluate("UNDO.length")}))
    b.close()
