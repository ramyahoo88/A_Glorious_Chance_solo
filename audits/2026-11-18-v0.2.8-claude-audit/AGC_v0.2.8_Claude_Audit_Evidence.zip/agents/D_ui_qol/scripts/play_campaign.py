# Play one complete campaign through the real page controls and record per-turn workload and UI checks.
# usage: python3 play_campaign.py SIDE SEED STYLE WIDTH HEIGHT TAG [opts-json]
import sys, json, re, time
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
side, seed, style, W, H, tag = sys.argv[1], int(sys.argv[2]), sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
opts = json.loads(sys.argv[7]) if len(sys.argv) > 7 else {}
AI_TITLES = re.compile(r"^(A10 Target Cards drawn|B1 Possible Encounters|Encounter Check PE\d+|C Enemy Operations|Encounter( \d*)? – no enemy|AI Deployment|Convoy found!|Your Convoy is attacked!|Encounter \d+: enemy sighted)$")
BOARD_VERBS = re.compile(r"\b(Lay out|Place|Remove|Move|Flip|Return|Reveal|Put|Set)\b")
errors = []
CHECK_JS = r"""() => {
  const s = G_STATE, out = [];
  const txt = id => (document.getElementById(id) || {}).innerText || '';
  const hdr = txt('hdr');
  // header
  const vpm = /VP U\.S\. \/ Br\.\s*([+−±]\d+) \/ ([+−±]\d+)/.exec(hdr);
  const num = t => (t[0] === '−' ? -1 : 1) * Number(t.slice(1));
  if (!vpm || num(vpm[1]) !== s.vp.US || num(vpm[2]) !== -s.vp.BR) out.push('header VP ' + (vpm && vpm[0]) + ' vs state ' + s.vp.US + '/' + s.vp.BR);
  const gm = /Game Score\s*([+-]?\d+)\s*\n?\s*([^\n]*)/.exec(hdr);
  const score = s.vp.US - s.vp.BR;
  if (!gm || Number(gm[1]) !== score) out.push('header score ' + (gm && gm[1]) + ' vs ' + score);
  const lvl = Math.abs(score) <= 10 ? 'Draw' : (score > 0 ? 'U.S.' : 'British') + (Math.abs(score) >= 33 ? ' Decisive Victory' : Math.abs(score) >= 22 ? ' Victory' : ' Marginal Victory');
  if (gm && gm[2].trim() !== lvl) out.push('header level ' + gm[2] + ' vs ' + lvl);
  // tracks panel
  const tr = (document.querySelector('#board .panel') || {}).innerText || '';
  [['US', 'U.S.'], ['BR', 'British']].forEach(([sd, nm]) => {
    const m = new RegExp(nm.replace('.', '\\.') + ' Convoy Supply\\s+(-?\\d+) · Construction Delay (\\d+)').exec(tr);
    if (!m || +m[1] !== s.supply[sd] || +m[2] !== s.cd[sd]) out.push(`tracks ${sd} ${m && m[0]} vs ${s.supply[sd]}/${s.cd[sd]}`);
  });
  const trks = document.querySelectorAll('#board .trk');
  ['US', 'BR'].forEach((sd, i) => { const on = trks[i] && trks[i].querySelector('i.on'); if (!on || +on.textContent !== s.supply[sd]) out.push(`track highlight ${sd} ${on && on.textContent} vs ${s.supply[sd]}`); });
  const h = s.human, due = sd => (s.troopsReturning && s.troopsReturning[sd]) || 0;
  const tm = /Troops\s+You: (\d+) available(?:, (\d+) due back at F7)?/.exec(tr);
  if (!tm || +tm[1] !== s.troops[h].available || +(tm[2] || 0) !== due(h)) out.push(`tracks troops you ${tm && tm[0]} vs ${s.troops[h].available}/${due(h)}`);
  const am = /A\.I\.: (\d+) available(?:, (\d+) due back at F7)?/.exec(tr);
  const aiAvail = s.aiTroops.box.filter(m => m.revealed && m.troops).length;
  if (!am || +am[1] !== aiAvail || +(am[2] || 0) !== due(s.ai)) out.push(`tracks troops ai ${am && am[0]} vs ${aiAvail}/${due(s.ai)}`);
  const nf = document.querySelector('#board .niag span.on');
  if (!nf || [...document.querySelectorAll('#board .niag span')].indexOf(nf) !== s.niagara) out.push('niagara highlight');
  // board: every non-sunk ship appears once (zone or port), chip text matches steps
  const chips = [...document.querySelectorAll('#board .ship .nm')].map(e => e.textContent.replace('★ ', ''));
  return { out, overflow: document.documentElement.scrollWidth > window.innerWidth + 1, scrollW: document.documentElement.scrollWidth, chips: chips.length };
}"""
POS_JS = r"""() => { const t = document.querySelector('#proc .ptitle'); const b = document.querySelector('#proc button.primary, #btn-ok, #proc .optcard');
  const r = t ? t.getBoundingClientRect() : null, rb = b ? b.getBoundingClientRect() : null;
  return { scrollY: window.scrollY, titleTop: r && r.top, titleVisible: !!r && r.top >= 0 && r.top < innerHeight, btnVisible: !!rb && rb.top >= 0 && rb.bottom <= innerHeight, procScroll: document.getElementById('proc').scrollTop, docH: document.documentElement.scrollHeight }; }"""
def parse_odds(t):
    m = re.search(r"([\d.]+) vs ([\d.]+) = ([\d.∞]+):1 \(([^)]+)\)", t); return m and (float(m[1]), float(m[2]), m[3], m[4])
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, W, H, errors)
    fresh_setup(pg); pg.screenshot(path=str(SHOTS / f'{tag}_000_setup.png'), full_page=False)
    start(pg, side, seed, opts)
    per = {}; recs = []; shot_keys = set(); n = 0; pending_odds = []; odds_checks = []; t0 = time.time()
    seen_log = 0; answers = []; ui_notes = []; check_fail = []; overflow = []; pos_issues = []; max_save = 0
    while n < 4000:
        st = pg.evaluate("({over: G_STATE.over, turn: G_STATE.turn, p: G_STATE.prompt, log: G_STATE.log.length})")
        if st['over']: break
        pr = st['p']; turn = st['turn']; kind = pr['kind']; title = pr['title']
        T = per.setdefault(turn, {'prompts': 0, 'info': 0, 'info_ai_step': 0, 'info_board_instr': 0, 'choice': 0, 'select': 0, 'lineup': 0, 'assign': 0, 'clicks': 0, 'decisions': 0})
        T['prompts'] += 1; T[kind] += 1
        if kind == 'info':
            if AI_TITLES.match(title): T['info_ai_step'] += 1
            if BOARD_VERBS.search(pr.get('text') or ''): T['info_board_instr'] += 1
        else: T['decisions'] += 1
        key = kind + '|' + re.sub(r'\d+', '#', title)
        if key not in shot_keys and len(shot_keys) < 60:
            shot_keys.add(key); pg.screenshot(path=str(SHOTS / f"{tag}_{n:03d}_{re.sub('[^A-Za-z0-9]+', '_', key)[:50]}.png"), full_page=False)
        # odds previews
        ptxt = pg.inner_text('#proc')
        if title.startswith('Command Decision'):
            you = re.search(r"Odds if you attack[^:]*: ([^\n]*)", ptxt); ai = re.search(r"Odds if the A\.I\. attacks: ([^\n]*)", ptxt)
            pending_odds = [po for po in pending_odds if po['src'] != 'CD']
            pending_odds.append({'src': 'CD', 'turn': turn, 'title': title, 'you': you and parse_odds(you[1]), 'ai': ai and parse_odds(ai[1]), 'text_you': you and you[1], 'text_ai': ai and ai[1]})
        if kind == 'lineup':
            m = re.search(r"First-Round Gunnery strength ([^\n]*)", ptxt)
            mm = m and re.search(r"([\d.]+) vs ([\d.]+) → ([\d.∞]+):1 \(([^)]+)\)", m[1])
            pending_odds.append({'src': 'lineup', 'turn': turn, 'txt': m and m[1], 'you': mm and (float(mm[1]), float(mm[2]), mm[3], mm[4])})
        ans = pg.evaluate("([st]) => __policy(G_STATE, G_STATE.prompt, st)", [style])
        rec = {'clicks': 0, 'notes': []}
        pid = pr['id']
        answers.append(ans)
        realize(pg, ans, rec)
        if kind == 'info': rec['clicks'] += 1
        if kind == 'choice': rec['clicks'] += 1
        T['clicks'] += rec['clicks']
        if rec['notes']: ui_notes.append({'n': n, 'turn': turn, 'title': title, 'notes': rec['notes']})
        n += 1
        after = pg.evaluate("({id: G_STATE.prompt && G_STATE.prompt.id, over: G_STATE.over, err: UI.err})")
        if after['err']: ui_notes.append({'n': n, 'title': title, 'UI.err': after['err']})
        if after['id'] == pid and not after['over']: ui_notes.append({'n': n, 'title': title, 'stuck': True}); break
        # new log lines → Gunnery Round 1 vs previews
        new = pg.evaluate(f"G_STATE.log.slice({st['log']}).map(l => l.text)")
        for line in new:
            g = re.match(r"Gunnery Round 1: (U\.S\.|British) ([\d.]+) vs (?:U\.S\.|British) ([\d.]+)(?: \(Haze: no Long Guns\))? = ([\d.∞]+):1 → column (\S+)", line)
            if g and pending_odds:
                att = 'US' if g[1] == 'U.S.' else 'BR'; human = side
                for po in pending_odds:
                    exp = po['you'] if att == human else po.get('ai')
                    odds_checks.append({'src': po['src'], 'turn': po['turn'], 'attacker': 'human' if att == human else 'AI', 'preview': exp, 'applied': (float(g[2]), float(g[3]), g[4], g[5]), 'match_strength': bool(exp) and exp[0] == float(g[2]) and exp[1] == float(g[3]), 'line': line})
                pending_odds = []
        if any(l.startswith('Encounter ended') or 'Encounter ends' in l for l in new) and pending_odds and not any('Gunnery Round 1' in l for l in new):
            pass
        if kind in ('choice',) and title.startswith('Command Decision') and ans in ('pass', 'bypass'):
            pass
        c = pg.evaluate(CHECK_JS)
        if c['out']: check_fail.append({'n': n, 'turn': turn, 'after': title, 'out': c['out']})
        if c['overflow']: overflow.append({'n': n, 'title': title, 'scrollW': c['scrollW']})
        pos = pg.evaluate(POS_JS)
        if not pos['titleVisible'] and not after['over']: pos_issues.append({'n': n, 'after': title, **pos})
    final = pg.evaluate("G_STATE")
    # Game Over screen: sum the ledger rows independently
    pg.screenshot(path=str(SHOTS / f'{tag}_999_gameover.png'), full_page=False)
    pg.screenshot(path=str(SHOTS / f'{tag}_999_gameover_full.png'), full_page=True)
    rows = pg.evaluate("""() => [...document.querySelectorAll('#proc table.ref tr')].slice(1).map(tr => [...tr.children].map(td => td.textContent))""")
    def sv(t): return (-1 if t[0] == '−' else 1) * int(t[1:])
    ledger_sum = sum(sv(r[2]) for r in rows)
    proc_txt = pg.inner_text('#proc'); hdr_txt = pg.inner_text('#hdr')
    fs = re.search(r"Final Game Score: ([+−±]\d+)\n([^\n]+)", proc_txt)
    hs = re.search(r"Game Score\s*([+-]?\d+)", hdr_txt)
    saveLen = pg.evaluate("(localStorage.getItem(SAVE_KEY) || '').length")
    res = {'side': side, 'seed': seed, 'style': style, 'viewport': [W, H], 'opts': opts, 'prompts': n, 'secs': round(time.time() - t0, 1),
           'per_turn': per, 'ui_notes': ui_notes, 'check_fail': check_fail[:20], 'n_check_fail': len(check_fail), 'overflow': overflow[:5], 'n_overflow': len(overflow),
           'title_offscreen_after_action': len(pos_issues), 'pos_examples': pos_issues, 'odds_checks': odds_checks,
           'gameover': {'rows': len(rows), 'ledger_sum': ledger_sum, 'final_text': fs and [fs[1], fs[2]], 'header_score': hs and hs[1], 'result': final['result'], 'vp': final['vp']},
           'autosave_chars': saveLen, 'answers': answers, 'errors': errors[:20]}
    (OUT / 'runs').mkdir(exist_ok=True)
    (OUT / 'runs' / f'{tag}.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
    (OUT / 'runs' / f'{tag}_final_state.json').write_text(json.dumps({'state': final, 'undo': []}))
    print(json.dumps({k: res[k] for k in ('side', 'seed', 'prompts', 'secs', 'n_check_fail', 'n_overflow', 'title_offscreen_after_action', 'gameover', 'autosave_chars', 'errors')}, ensure_ascii=False))
    print('ui_notes', json.dumps(ui_notes[:10], ensure_ascii=False))
    print('odds', json.dumps([(o['src'], o['attacker'], o['match_strength'], o['preview'], o['applied']) for o in odds_checks], ensure_ascii=False))
    b.close()
