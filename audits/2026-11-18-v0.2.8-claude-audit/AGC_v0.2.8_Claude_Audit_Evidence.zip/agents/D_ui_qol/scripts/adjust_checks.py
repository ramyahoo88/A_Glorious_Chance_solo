# Adjust dialog: a manual VP correction and the Game Over VP table; other Adjust fields.
import sys, json, re
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
run = json.loads((OUT / 'runs' / 'US280004_1300.json').read_text())
res = {}; errors = []
def sv(t): return (-1 if t[0] == '−' else 1) * int(t[1:])
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
    for a in run['answers'][:120]: realize(pg, a, {'clicks': 0, 'notes': []})
    (OUT / 'saves' / 'ADJ_US280004_decision120.json').write_text(pg.evaluate("saveText()"))
    vp0 = pg.evaluate("G_STATE.vp.US")
    pg.click("#hdr button:has-text('Adjust')")
    lab = pg.locator("#modal label:has-text('U.S. VP')").first
    lab.locator('input').fill(str(vp0 + 3)); lab.locator("button:has-text('Set')").click()
    res['log_after_adjust'] = pg.evaluate("G_STATE.log.slice(-1)[0].text"); res['vpLog_rows_after_adjust'] = pg.evaluate("G_STATE.vpLog.length")
    pg.screenshot(path=str(SHOTS / 'ADJ1_adjust_dialog.png'))
    pg.click("#modal button:has-text('Close')")
    for a in run['answers'][120:]:
        if pg.evaluate("G_STATE.over"): break
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
    rows = pg.evaluate("[...document.querySelectorAll('#proc table.ref tr')].slice(1).map(tr => [...tr.children].map(td => td.textContent))")
    txt = pg.inner_text('#proc'); fs = re.search(r"Final Game Score: ([+−±]\d+)", txt)
    res['gameover'] = {'final_score_shown': fs[1], 'ledger_rows_sum': sum(sv(r[2]) for r in rows), 'header': re.search(r"Game Score\s*([+-]?\d+)", pg.inner_text('#hdr'))[1], 'manual_row_present': any('anual' in r[3] for r in rows)}
    pg.screenshot(path=str(SHOTS / 'ADJ2_gameover_ledger_after_manual_vp.png'), full_page=True)
    # Adjust fields offered
    pg.click("#hdr button:has-text('Adjust')")
    res['adjust_fields'] = pg.evaluate("[...document.querySelectorAll('#modal label')].map(l => l.childNodes[0].textContent.trim())")
    res['adjust_box_options'] = pg.evaluate("[...document.querySelectorAll('#modal select')[1].options].map(o => o.textContent)")
    pg.click("#modal button:has-text('Close')")
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False)); print(errors)
(OUT / 'runs' / 'adjust_checks.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
