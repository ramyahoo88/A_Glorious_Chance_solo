window.__check = () => {
  const s = G_STATE, out = [];
  const txt = id => (document.getElementById(id) || {}).innerText || '';
  const hdr = txt('hdr');
  // header
  const vpm = /VP U\.S\. \/ Br\.\s*([+−±]\d+) \/ ([+−±]\d+)/.exec(hdr);
  const num = t => (t[0] === '−' ? -1 : 1) * Number(t.slice(1));
  if (!vpm || num(vpm[1]) !== s.vp.US || num(vpm[2]) !== -s.vp.BR) out.push('header VP ' + (vpm && vpm[0]) + ' vs state ' + s.vp.US + '/' + s.vp.BR);
  const gm = /Game Score\s*([+-]?\d+)\s*\n?\s*([^\n]*)/.exec(hdr);
  const score = s.vp.US - s.vp.BR;
  if (!gm || Number(gm[1]) !== score) out.push('header score ' + (gm && gm[1]) + ' vs ' + score);
  const lvl = Math.abs(score) <= 10 ? 'Draw' : (score > 0 ? 'U.S.' : 'British') + (Math.abs(score) >= 33 ? ' Decisive Victory' : Math.abs(score) >= 22 ? ' Victory' : ' Marginal Victory');
  if (gm && gm[2].trim() !== lvl) out.push('header level ' + gm[2] + ' vs ' + lvl);
  // tracks panel
  const tr = (document.querySelector('#board .panel') || {}).innerText || '';
  [['US', 'U.S.'], ['BR', 'British']].forEach(([sd, nm]) => {
    const m = new RegExp(nm.replace('.', '\\.') + ' Convoy Supply\\s+(-?\\d+) · Construction Delay (\\d+)').exec(tr);
    if (!m || +m[1] !== s.supply[sd] || +m[2] !== s.cd[sd]) out.push(`tracks ${sd} ${m && m[0]} vs ${s.supply[sd]}/${s.cd[sd]}`);
  });
  const trks = document.querySelectorAll('#board .trk');
  ['US', 'BR'].forEach((sd, i) => { const on = trks[i] && trks[i].querySelector('i.on'); if (!on || +on.textContent !== s.supply[sd]) out.push(`track highlight ${sd} ${on && on.textContent} vs ${s.supply[sd]}`); });
  const h = s.human, due = sd => (s.troopsReturning && s.troopsReturning[sd]) || 0;
  const tm = /Troops\s+You: (\d+) available(?:, (\d+) due back at F7)?/.exec(tr);
  if (!tm || +tm[1] !== s.troops[h].available || +(tm[2] || 0) !== due(h)) out.push(`tracks troops you ${tm && tm[0]} vs ${s.troops[h].available}/${due(h)}`);
  const am = /A\.I\.: (\d+) available(?:, (\d+) due back at F7)?/.exec(tr);
  const aiAvail = s.aiTroops.box.filter(m => m.revealed && m.troops).length;
  if (!am || +am[1] !== aiAvail || +(am[2] || 0) !== due(s.ai)) out.push(`tracks troops ai ${am && am[0]} vs ${aiAvail}/${due(s.ai)}`);
  const nf = document.querySelector('#board .niag span.on');
  if (!nf || [...document.querySelectorAll('#board .niag span')].indexOf(nf) !== s.niagara) out.push('niagara highlight');
  // board: every non-sunk ship appears once (zone or port), chip text matches steps
  const chips = [...document.querySelectorAll('#board .ship .nm')].map(e => e.textContent.replace('★ ', ''));
  return { out, overflow: document.documentElement.scrollWidth > window.innerWidth + 1, scrollW: document.documentElement.scrollWidth, chips: chips.length };
};
