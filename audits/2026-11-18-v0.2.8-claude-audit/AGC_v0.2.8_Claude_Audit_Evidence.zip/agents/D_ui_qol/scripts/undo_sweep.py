# Full-campaign Undo/redo sweep through the page: after every decision press Undo (state must equal the one before),
# then give the same answer again (state must equal the first result). Every 15 decisions: reload → Continue it.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
side, seed, W, H = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
errors = []; bad = []; n = 0; reloads = 0
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, W, H, errors); fresh_setup(pg); start(pg, side, seed)
    while not pg.evaluate("G_STATE.over") and n < 400:
        S0 = pg.evaluate("JSON.stringify(G_STATE)"); title = pg.evaluate("G_STATE.prompt.title")
        ans = pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')")
        realize(pg, ans, {'clicks': 0, 'notes': []}); S1 = pg.evaluate("JSON.stringify(G_STATE)")
        pg.click("#hdr button:has-text('Undo')")
        if pg.evaluate("JSON.stringify(G_STATE)") != S0: bad.append(('undo', n, title))
        realize(pg, ans, {'clicks': 0, 'notes': []})
        if pg.evaluate("JSON.stringify(G_STATE)") != S1: bad.append(('redo', n, title))
        n += 1
        if n % 15 == 0:
            pg.reload(); pg.click("text=Continue it"); reloads += 1
            if pg.evaluate("JSON.stringify(G_STATE)") != S1: bad.append(('reload', n, title))
    out = {'side': side, 'seed': seed, 'viewport': W, 'decisions': n, 'over': pg.evaluate("G_STATE.over"), 'score': pg.evaluate("G_STATE.result && G_STATE.result.score"), 'reloads': reloads, 'mismatches': bad, 'errors': errors}
    print(json.dumps(out)); (OUT / 'runs' / f'undo_sweep_{side}{seed}_{W}.json').write_text(json.dumps(out, indent=1))
    b.close()
