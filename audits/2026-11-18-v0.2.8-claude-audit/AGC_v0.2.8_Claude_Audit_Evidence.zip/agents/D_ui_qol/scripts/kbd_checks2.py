# Keyboard: Undo button + Enter at an information prompt; Close button inside a dialog + Enter.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
res = {}; errors = []
def pid(pg): return pg.evaluate("G_STATE && G_STATE.prompt && [G_STATE.prompt.id, G_STATE.prompt.kind, G_STATE.prompt.title]")
def to_info(pg):
    while pg.evaluate("G_STATE.prompt.kind") != 'info':
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
    to_info(pg); pg.click('#btn-ok'); to_info(pg)
    before = pid(pg); ul = pg.evaluate("UNDO.length")
    pg.focus("#hdr button:has-text('Undo')"); pg.keyboard.press('Enter')
    res['Undo focused + Enter at info prompt'] = {'before': before, 'after': pid(pg), 'undo_len_before': ul, 'undo_len_after': pg.evaluate("UNDO.length")}
    to_info(pg); before = pid(pg)
    pg.click("#hdr button:has-text('Settings')"); pg.focus("#modal button:has-text('Close')"); pg.keyboard.press('Enter')
    res['Settings dialog: Close focused + Enter at info prompt'] = {'before': before, 'after': pid(pg), 'dialog_still_open': pg.evaluate("document.getElementById('modal').classList.contains('open')")}
    pg.click("#modal button:has-text('Close')")
    to_info(pg); before = pid(pg)
    pg.click("#hdr button:has-text('Reference')"); pg.keyboard.press('PageDown'); pg.keyboard.press('ArrowDown')
    res['Reference: PageDown/ArrowDown'] = {'before': before, 'after': pid(pg)}
    pg.keyboard.press('Space')
    res['Reference: then Space'] = {'before': before, 'after': pid(pg), 'log_tail': pg.evaluate("G_STATE.log.slice(-2).map(l => l.text)")}
    pg.screenshot(path=str(SHOTS / 'K02_reference_open_game_advanced_behind.png'))
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False)); print(errors)
(OUT / 'runs' / 'kbd_checks2.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
