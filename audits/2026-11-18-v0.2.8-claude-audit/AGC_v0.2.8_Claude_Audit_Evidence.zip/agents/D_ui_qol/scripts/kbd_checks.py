# Keyboard behaviour: Enter/Space on a focused header button while an information prompt is pending.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
res = {}; errors = []
def pid(pg): return pg.evaluate("G_STATE && G_STATE.prompt && [G_STATE.prompt.id, G_STATE.prompt.kind, G_STATE.prompt.title]")
with sync_playwright() as p:
    b = launch(p)
    for W, H in ((1300, 900), (390, 844)):
        tag = f'@{W}'
        pg = new_page(b, W, H, errors); fresh_setup(pg); start(pg, 'US', 280004)
        # play to the first information prompt after A7 (A10 Target Cards drawn)
        while pg.evaluate("G_STATE.prompt.kind") != 'info':
            realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
        before = pid(pg); undo_len = pg.evaluate("UNDO.length")
        # 1. mouse-click Reference (focus stays on the header button), then press Space to scroll the dialog
        pg.click("#hdr button:has-text('Reference')")
        focus = pg.evaluate("document.activeElement && document.activeElement.textContent")
        modal_open = pg.evaluate("document.getElementById('modal').classList.contains('open')")
        pg.keyboard.press('Space')
        after = pid(pg)
        res['Reference open + Space' + tag] = {'focus': focus, 'modal_open': modal_open, 'prompt_before': before, 'prompt_after': after, 'advanced_behind_modal': before != after,
                                              'modal_still_open': pg.evaluate("document.getElementById('modal').classList.contains('open')")}
        pg.screenshot(path=str(SHOTS / f'K01_reference_space_advanced{tag}.png'))
        pg.click("#modal button:has-text('Close')")
        # 2. keyboard user: focus the Undo button and press Enter
        pg.evaluate("UNDO.length")
        before = pid(pg); ul = pg.evaluate("UNDO.length")
        pg.focus("#hdr button:has-text('Undo')"); pg.keyboard.press('Enter')
        after = pid(pg)
        res['Undo focused + Enter' + tag] = {'before': before, 'after': after, 'undo_len_before': ul, 'undo_len_after': pg.evaluate("UNDO.length"), 'expected': 'Undo (stack shrinks, earlier prompt)'}
        # 3. focus Save and press Enter: should open the Save dialog
        while pg.evaluate("G_STATE.prompt.kind") != 'info':
            realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
        before = pid(pg)
        pg.focus("#hdr button:has-text('Save')"); pg.keyboard.press('Enter')
        res['Save focused + Enter' + tag] = {'before': before, 'after': pid(pg), 'save_dialog_open': pg.evaluate("document.getElementById('modal').classList.contains('open') && document.getElementById('modal').innerText.includes('Save game')")}
        if pg.evaluate("document.getElementById('modal').classList.contains('open')"): pg.click("#modal button:has-text('Close')")
        # 4. New game focused + Enter
        while pg.evaluate("G_STATE.prompt.kind") != 'info':
            realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
        before = pid(pg)
        pg.focus("#hdr button:has-text('New game')"); pg.keyboard.press('Enter')
        res['New game focused + Enter' + tag] = {'before': before, 'after': pid(pg), 'confirm_open': pg.evaluate("document.getElementById('modal').classList.contains('open')")}
        # 5. Escape closes a dialog? focus moves into dialog?
        pg.click("#hdr button:has-text('Settings')")
        res['dialog focus/escape' + tag] = {'focus_in_modal': pg.evaluate("document.getElementById('modal').contains(document.activeElement)"),
             'role': pg.evaluate("document.getElementById('modal').getAttribute('role')"), 'aria_modal': pg.evaluate("document.getElementById('modal').getAttribute('aria-modal')")}
        pg.keyboard.press('Escape')
        res['dialog focus/escape' + tag]['open_after_Escape'] = pg.evaluate("document.getElementById('modal').classList.contains('open')")
        # Tab order while modal open: does focus reach the board behind the dialog?
        seq = []
        for i in range(6):
            pg.keyboard.press('Tab'); seq.append(pg.evaluate("(() => { const a = document.activeElement; return (document.getElementById('modal').contains(a) ? 'modal:' : 'behind:') + (a.textContent || a.tagName).slice(0, 20); })()"))
        res['dialog focus/escape' + tag]['tab_sequence'] = seq
        pg.close()
    res['errors'] = errors
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False))
(OUT / 'runs' / 'kbd_checks.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
