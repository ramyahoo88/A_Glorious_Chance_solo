# Repro: manual Force Package #4 (16 Long Gun) – helper Auto-fill sometimes picks 8 ships where the rule (and automatic mode) give 7.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
save = (OUT / 'saves' / 'PK_manual_package_prompt.json').read_text()
res = {'autofill_counts': []}; errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'BR', 1)
    load_text(pg, save)
    res['prompt'] = pg.inner_text('#proc .ptitle'); res['instruction'] = [l for l in pg.inner_text('#proc .ptext').split('\n') if 'fewest' in l]
    pg.locator('#proc .banner select').select_option('lg'); pg.fill('#proc .banner input[type=number]', '16')
    shot = False
    for i in range(15):
        pg.click("#proc .banner button:has-text('Auto-fill')")
        sel = pg.evaluate("UI.local.sel.map(id => shipName(G_STATE, id))"); res['autofill_counts'].append(len(sel))
        if len(sel) == 8 and not shot:
            shot = True; res['eight_ship_pick'] = sel; res['helper_line'] = pg.inner_text('#proc .banner').split('\n')[0]
            pg.screenshot(path=str(SHOTS / 'PK1_helper_autofill_8_ships_pkg4.png'))
            before = pg.evaluate("Object.keys(G_STATE.forces)")
            pg.click("#proc button.primary:has-text('Confirm')")
            while pg.evaluate("G_STATE.prompt.kind") == 'info' and not pg.evaluate("(b) => Object.values(G_STATE.forces).some(f => b.indexOf(String(f.id)) < 0)", before): pg.click('#btn-ok')
            res['deployed'] = pg.evaluate("(b) => Object.values(G_STATE.forces).filter(f => b.indexOf(String(f.id)) < 0).map(f => f.ships.map(id => shipName(G_STATE, id)))", before)
            break
    res['automatic_mode_same_pool'] = json.loads(save)['state'] and pg.evaluate("(() => { const d = JSON.parse(arguments[0]); return 0; })", ) if False else None
    b.close()
print(json.dumps(res, indent=1)); print(errors)
(OUT / 'runs' / 'pkg_repro.json').write_text(json.dumps(res, indent=1))
