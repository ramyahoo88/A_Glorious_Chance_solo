# Manual Force Packages (British campaign): helper Auto-fill vs automatic Player Aid V selection, and selection vs deployed Force.
import sys, json, re
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 280002
res = []; errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'BR', seed, {'manualPackages': True})
    n = 0
    while not pg.evaluate("G_STATE.over") and n < 400:
        pr = pg.evaluate("G_STATE.prompt")
        if pr['kind'] == 'select' and pr.get('pkg'):
            pkg = pr['pkg']
            auto = pg.evaluate("(() => { const s = JSON.parse(JSON.stringify(G_STATE)); const pool = G_STATE.prompt.items.map(i => s.ships[i.id]); const r = forcePackageSelect(s, G_STATE.prompt.pkg, pool); return r.ok ? { ships: r.ships, ships2: r.ships2 || null, text: r.text } : { ships: [], why: r.why }; })()")
            rec = {'n': n, 'turn': pg.evaluate("G_STATE.turn"), 'pkg': pkg, 'auto': auto}
            need = {2: 28, 3: 22, 4: 16, 5: 18, 6: 20}.get(pkg)
            if need:
                pg.locator('#proc .banner select').select_option('lg'); pg.fill('#proc .banner input[type=number]', str(need))
                pg.click("#proc .banner button:has-text('Auto-fill')")
                sel = pg.evaluate("UI.local.sel.slice()"); rec['helper'] = sel; rec['helper_msg'] = pg.inner_text('#proc .banner')[:200]
                rec['helper_vs_auto_count'] = [len(sel), len(auto['ships'])]
                if len(rec.get('helper', [])) != len(auto['ships']) and not any(r.get('shot') for r in res):
                    rec['shot'] = True; pg.screenshot(path=str(SHOTS / f'PK1_helper_autofill_pkg{pkg}.png'), full_page=False)
                ans = sel
            else:
                ans = auto['ships'] + (auto.get('ships2') or [])
            # tick exactly `ans` and confirm, then compare with the Force that deploys
            ids = [it['id'] for it in pr['items']]
            for i, iid in enumerate(ids):
                cb = pg.locator('.sel-list label input[type=checkbox]').nth(i)
                if cb.is_checked() != (iid in ans): cb.click()
            before_forces = pg.evaluate("Object.keys(G_STATE.forces)")
            pg.click("#proc button.primary:has-text('Confirm')")
            # package 8 second stack
            if pg.evaluate("G_STATE.prompt && /second stack/.test(G_STATE.prompt.title)"):
                for i, iid in enumerate(pg.evaluate("G_STATE.prompt.items.map(i => i.id)")):
                    if iid in (auto.get('ships2') or []): pg.locator('.sel-list label input[type=checkbox]').nth(i).click()
                pg.click("#proc button.primary:has-text('Confirm')")
            # advance until the A.I. Force exists (Upgrade/info prompts in between)
            for _ in range(6):
                newf = pg.evaluate("(b) => Object.values(G_STATE.forces).filter(f => b.indexOf(String(f.id)) < 0 && f.side === G_STATE.ai).map(f => f.ships)", before_forces)
                if newf: break
                if pg.evaluate("G_STATE.prompt && G_STATE.prompt.kind") == 'info': pg.click('#btn-ok')
                else: break
            rec['deployed'] = newf
            rec['deployed_matches_selection'] = sorted(sum(newf, [])) == sorted(ans) if newf else (not ans)
            res.append(rec); n += 1; continue
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []}); n += 1
    b.close()
print(json.dumps([{k: v for k, v in r.items() if k not in ('helper_msg',)} for r in res], indent=0)[:6000]); print(errors[:5])
(OUT / 'runs' / f'pkg_checks_{seed}.json').write_text(json.dumps(res, indent=1))
