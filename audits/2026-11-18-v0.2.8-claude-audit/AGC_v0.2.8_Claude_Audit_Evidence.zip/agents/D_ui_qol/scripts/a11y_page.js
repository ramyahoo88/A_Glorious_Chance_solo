// In-page accessibility/usability measurements for the current screen.
window.__a11y = function () {
  const vis = e => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const parse = c => { const m = (c.match(/[\d.]+/g) || [0, 0, 0, 0]).map(Number); return { r: m[0], g: m[1], b: m[2], a: m.length > 3 ? m[3] : 1 }; };
  const blend = (f, b, a) => ({ r: f.r * a + b.r * (1 - a), g: f.g * a + b.g * (1 - a), b: f.b * a + b.b * (1 - a), a: 1 });
  const L = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
  function bgOf(e) { // composite background colours from the root down to e
    const chain = []; let x = e; while (x) { chain.unshift(x); x = x.parentElement; }
    let bg = { r: 255, g: 255, b: 255, a: 1 };
    for (const n of chain) { const cs = getComputedStyle(n); let c = parse(cs.backgroundColor); if (cs.backgroundImage !== 'none' && c.a === 0) continue; if (c.a > 0) bg = blend(c, bg, c.a); }
    return bg;
  }
  function opacityOf(e) { let o = 1, x = e; while (x) { o *= +getComputedStyle(x).opacity; x = x.parentElement; } return o; }
  function contrast(e) {
    const bg = bgOf(e); const o = opacityOf(e); let fg = parse(getComputedStyle(e).color); fg = blend(fg, bg, fg.a);
    // opacity fades text and own background toward what is behind the faded subtree (approximation: page background)
    const page = bgOf(document.body); const fgE = blend(fg, page, o), bgE = blend(bg, page, o);
    const a = L(fgE), b = L(bgE); return +(((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)).toFixed(2));
  }
  const W = innerWidth;
  const targets = [...document.querySelectorAll('button, select, input, textarea, .asg-ship, .optcard, .sel-list label, #lake .zone')].filter(vis).filter(e => !e.closest('#modal:not(.open)'));
  const small = targets.map(e => { const r = e.getBoundingClientRect(); return { t: (e.textContent || e.value || e.type || e.tagName).trim().slice(0, 28), tag: e.tagName.toLowerCase() + (e.className ? '.' + String(e.className).split(' ')[0] : ''), w: Math.round(r.width), h: Math.round(r.height) }; });
  const tooWide = [...document.querySelectorAll('body *')].filter(vis).filter(e => e.getBoundingClientRect().right > W + 1 && !e.closest('table') && !e.closest('#modal:not(.open)')).map(e => e.tagName + '.' + e.className).slice(0, 8);
  // text sizes
  const texts = [...document.querySelectorAll('body *')].filter(vis).filter(e => [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()));
  const fsz = {}; texts.forEach(e => { const s = Math.round(parseFloat(getComputedStyle(e).fontSize) * 10) / 10; fsz[s] = (fsz[s] || 0) + 1; });
  const lowC = texts.map(e => ({ e, c: contrast(e) })).filter(x => x.c < 4.5).map(x => ({ t: x.e.textContent.trim().slice(0, 30), cls: x.e.tagName.toLowerCase() + '.' + String(x.e.className).split(' ').join('.'), c: x.c, fs: getComputedStyle(x.e).fontSize, disabled: !!x.e.closest('button:disabled') }));
  return { viewport: [innerWidth, innerHeight], docW: document.documentElement.scrollWidth, overflow: document.documentElement.scrollWidth > W + 1, docH: document.documentElement.scrollHeight,
    targets: small.length, under24: small.filter(x => x.h < 24 || x.w < 24), under44: small.filter(x => x.h < 44).length, tooWide, fontSizes: fsz, lowContrast: lowC };
};
