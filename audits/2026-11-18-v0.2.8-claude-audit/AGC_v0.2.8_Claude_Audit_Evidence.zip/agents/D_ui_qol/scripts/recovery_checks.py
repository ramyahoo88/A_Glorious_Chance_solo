# Recovery notice (E01), damaged-save refusal (R01, cut-off text, wrong JSON), storage-full warning. usage: WIDTH HEIGHT
import sys, json, pathlib
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
W, H = int(sys.argv[1]), int(sys.argv[2]); tag = f'@{W}'
E01 = pathlib.Path('/home/claude/gpt_re7/ev/fixtures/E01_old_B35_at_package_picker.json')
R01 = pathlib.Path('/home/claude/gpt_re7/ev/R01_invalid_procedure.json')
res = {}; errors = []
def banner(pg):
    e = pg.query_selector('#proc .banner.recovery'); return e.inner_text() if e else ''
def S(pg): return pg.evaluate("JSON.stringify(G_STATE)")
def step(pg, n=1):
    for _ in range(n): realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, W, H, errors); fresh_setup(pg); start(pg, 'US', 280004); step(pg, 6)
    # --- recovery notice
    pg.click("#hdr button:has-text('Load')"); pg.set_input_files("#modal input[type=file]", str(E01)); pg.wait_for_timeout(300)
    r = {'on_open': banner(pg)[:200], 'UI.err_line': pg.inner_text('#proc .err:last-child') if pg.query_selector('#proc > .err') else ''}
    pg.screenshot(path=str(SHOTS / f'R01_recovery_panel{tag}.png'))
    S_open = S(pg)
    pg.reload(); pg.click("text=Continue it"); r['after_reload'] = bool(banner(pg)); r['reload_equal'] = S(pg) == S_open
    txt = pg.evaluate("saveText()"); load_text(pg, txt); r['after_export_import'] = bool(banner(pg)); r['export_import_equal'] = S(pg) == S_open
    pg.click("#hdr button:has-text('Save')")
    with pg.expect_download() as dl: pg.click("#modal button:has-text('Download .json')")
    f = OUT / 'downloads' / f'E01_reexport{tag}.json'; dl.value.save_as(str(f)); pg.click("#modal button:has-text('Close')")
    r['download_has_recovery'] = bool(json.loads(f.read_text())['state'].get('recovery'))
    pg.click('#proc button.primary'); r['after_a_move'] = bool(banner(pg))
    pg.click("#hdr button:has-text('Undo')"); r['after_undo'] = bool(banner(pg))
    pg.click("#proc .banner.recovery button:has-text('Load an earlier save')"); r['load_earlier_opens_dialog'] = pg.evaluate("document.getElementById('modal').classList.contains('open') && document.getElementById('modal').innerText.includes('Load game')")
    pg.click("#modal button:has-text('Close')")
    pg.click("#proc .banner.recovery button:has-text('Keep playing')"); r['after_keep_playing'] = bool(banner(pg))
    r['keep_playing_undoable'] = None
    pg.click("#hdr button:has-text('Undo')"); r['undo_after_keep_playing_brings_banner_back'] = bool(banner(pg))
    pg.click("#proc .banner.recovery button:has-text('Keep playing')")
    pg.reload(); pg.click("text=Continue it"); r['after_keep_reload'] = bool(banner(pg))
    # contrast of the recovery panel text and its buttons
    load_text(pg, E01.read_text())
    r['contrast'] = pg.evaluate("""() => {
      const lum = c => { const m = c.match(/[\\d.]+/g).map(Number); const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(m[0]) + 0.7152 * f(m[1]) + 0.0722 * f(m[2]); };
      const bg = e => { while (e) { const c = getComputedStyle(e).backgroundColor; if (c && !/rgba\\(0, 0, 0, 0\\)|transparent/.test(c)) return c; e = e.parentElement; } return 'rgb(255,255,255)'; };
      const ratio = e => { const a = lum(getComputedStyle(e).color), b = lum(bg(e)); return +(((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)).toFixed(2)); };
      const p = document.querySelector('#proc .banner.recovery');
      return { panel_text: ratio(p), bold: ratio(p.querySelector('b')), buttons: [...p.querySelectorAll('button')].map(ratio), panel_bg: bg(p), size: getComputedStyle(p).fontSize,
               btn_heights: [...p.querySelectorAll('button')].map(x => Math.round(x.getBoundingClientRect().height)) }; }""")
    res['recovery'] = r
    # --- damaged saves: current game must be untouched (state, autosave, Undo length)
    pg.click("#proc .banner.recovery button:has-text('Keep playing')")
    S_before = S(pg); auto_before = pg.evaluate("localStorage.getItem(SAVE_KEY)"); ul = pg.evaluate("UNDO.length")
    d = {}
    for name, txt in (('R01 invalid procedure (paste)', R01.read_text()), ('cut-off text', pg.evaluate("saveText()")[:5000]), ('not a save', '{"hello": 1}'), ('empty', '')):
        load_text(pg, txt); msg = pg.inner_text('#modal .err')
        d[name] = {'message': msg[:180], 'state_unchanged': S(pg) == S_before, 'autosave_unchanged': pg.evaluate("localStorage.getItem(SAVE_KEY)") == auto_before, 'undo_len_unchanged': pg.evaluate("UNDO.length") == ul, 'dialog_open': pg.evaluate("document.getElementById('modal').classList.contains('open')")}
        if name.startswith('R01'): pg.screenshot(path=str(SHOTS / f'R02_damaged_refused{tag}.png'))
        pg.click("#modal button:has-text('Close')")
    pg.click("#hdr button:has-text('Load')"); pg.set_input_files("#modal input[type=file]", str(R01)); pg.wait_for_timeout(300)
    d['R01 (file chooser)'] = {'message': pg.inner_text('#modal .err')[:180], 'state_unchanged': S(pg) == S_before, 'autosave_unchanged': pg.evaluate("localStorage.getItem(SAVE_KEY)") == auto_before}
    pg.click("#modal button:has-text('Close')")
    # damaged autosave on the setup screen
    pg.evaluate("(t) => localStorage.setItem(SAVE_KEY, t)", R01.read_text()); pg.reload()
    pg.click("text=Continue it"); d['damaged autosave → Continue it'] = {'message': pg.inner_text('.banner .err')[:200], 'still_setup': pg.is_visible("text=Start campaign")}
    res['damaged'] = d
    # --- storage full
    pg.evaluate("(t) => localStorage.setItem(SAVE_KEY, t)", json.dumps({'state': json.loads(S_before), 'undo': []})); pg.reload(); pg.click("text=Continue it")
    pg.evaluate("(() => { window.__realSet = Storage.prototype.setItem; Storage.prototype.setItem = function () { throw new DOMException('Quota exceeded', 'QuotaExceededError'); }; return 1; })()")
    step(pg); sf = {'warning_after_failed_autosave': 'Not autosaved' in pg.inner_text('#hdr'), 'header_text': pg.inner_text('#hdr').split('\n')[:12]}
    pg.screenshot(path=str(SHOTS / f'R03_storage_full{tag}.png'))
    pg.click("#hdr button:has-text('Undo')"); sf['warning_after_undo_still_failing'] = 'Not autosaved' in pg.inner_text('#hdr')
    pg.evaluate("(() => { Storage.prototype.setItem = window.__realSet; return 1; })()"); step(pg)
    sf['warning_cleared_when_storage_works'] = 'Not autosaved' not in pg.inner_text('#hdr')
    # Settings toggle while storage fails: is the failure reported?
    pg.evaluate("(() => { Storage.prototype.setItem = function () { throw new DOMException('Quota exceeded', 'QuotaExceededError'); }; return 1; })()")
    pg.click("#hdr button:has-text('Settings')"); pg.click("#modal label:has-text('Pause after each') input"); pg.click("#modal button:has-text('Close')")
    sf['settings_change_with_failing_storage_warns'] = 'Not autosaved' in pg.inner_text('#hdr')
    pg.evaluate("(() => { Storage.prototype.setItem = window.__realSet; return 1; })()")
    res['storage_full'] = sf
    res['errors'] = errors
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False))
(OUT / 'runs' / f'recovery_checks{tag}.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
