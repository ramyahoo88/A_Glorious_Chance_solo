const repo = '/home/claude/a_glorious_chance_solo'; process.argv[2] = repo;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const E = require(repo + '/tools/bundle_engine.js')();
const seen = {};
for (const side of ['US', 'BR']) for (const st of ['coast', 'fleet']) for (let seed = 280001; seed < 280013; seed++) {
  const s = E.newGame(side, seed, { cuttingOut: true }); E.run(s); let n = 0;
  while (!s.over && n++ < 3000) { const p = s.prompt; if (p.kind === 'choice') { const k = p.title.replace(/\d+/g, '#'); seen[k] = seen[k] || new Set(); p.options.forEach(o => seen[k].add(o.id + '=' + o.label.slice(0, 40) + (o.primary ? '*' : ''))); } E.act(s, policy(s, p, st)); }
}
for (const k in seen) console.log(k, '\n   ', [...seen[k]].join(' | '));
