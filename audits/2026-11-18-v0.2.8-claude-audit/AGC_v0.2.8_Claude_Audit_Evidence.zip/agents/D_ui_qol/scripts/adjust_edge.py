# Adjust → Ships during Lake Combat: does the game survive manual corrections to ships in the current Encounter?
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
run = json.loads((OUT / 'runs' / 'US280004_1300.json').read_text())
CASES = [('pike', 'sunk', None, None), ('pike', None, None, 'BR'), ('madison', None, 0, None), ('wolfe', 'deployable', None, None)]
res = []; errors = []
with sync_playwright() as p:
    b = launch(p)
    for sid, box, steps, owner in CASES:
        errs = []; pg = new_page(b, 1300, 900, errs); fresh_setup(pg); start(pg, 'US', 280004)
        for a in run['answers'][:75]: realize(pg, a, {'clicks': 0, 'notes': []})
        pg.click("#hdr button:has-text('Adjust')")
        sels = pg.locator('#modal select')
        sels.nth(0).select_option(sid)
        if box: sels.nth(1).select_option(box)
        if steps is not None: pg.fill('#modal input[max="3"]', str(steps))
        if owner: sels.nth(2).select_option(owner)
        pg.click("#modal button:has-text('Apply')"); pg.click("#modal button:has-text('Close')")
        r = {'case': f'{sid} box={box} steps={steps} owner={owner}', 'prompt': pg.evaluate("G_STATE.prompt.title")}
        n = 0; stuck = None
        while not pg.evaluate("G_STATE.over") and n < 120:
            pid = pg.evaluate("G_STATE.prompt.id")
            try: realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
            except Exception as e: stuck = 'policy/realize: ' + str(e)[:150]; break
            if pg.evaluate("UI.err"): stuck = 'UI.err: ' + pg.evaluate("UI.err")[:200]; break
            if pg.evaluate("G_STATE.prompt && G_STATE.prompt.id") == pid: stuck = 'no progress'; break
            n += 1
        r.update({'decisions_after': n, 'over_or_turn': pg.evaluate("G_STATE.over || G_STATE.turn"), 'stuck': stuck, 'page_errors': errs[:3]})
        if stuck: pg.screenshot(path=str(SHOTS / f"ADJ3_{sid}_{box or ''}{owner or ''}{'' if steps is None else steps}.png"))
        res.append(r); pg.close()
    b.close()
for r in res: print(json.dumps(r, ensure_ascii=False))
(OUT / 'runs' / 'adjust_edge.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
