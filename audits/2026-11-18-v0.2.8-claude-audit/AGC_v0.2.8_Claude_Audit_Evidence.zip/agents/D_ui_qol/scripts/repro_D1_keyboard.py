# Repro D1 with plain clicks: U.S. campaign, seed 280004, defaults.
#   June I (this turn) → Confirm (In Ordinary) → Confirm assignments (no Forces) → "A10 Target Cards drawn"
#   a) click Reference, press Space         → game advances behind the open dialog (A.I. Target Cards revealed)
#   b) Tab to Undo, press Enter             → game advances instead of undoing
#   c) focus Save, press Enter              → game advances, Save dialog does not open
from playwright.sync_api import sync_playwright
import sys, json; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
errors = []; out = {}
def P(pg): return pg.evaluate("[G_STATE.prompt.title, UNDO.length, document.getElementById('modal').classList.contains('open')]")
def setup(pg):
    fresh_setup(pg); start(pg, 'US', 280004)
    pg.click("#proc button:has-text('June I (this turn)')"); pg.click("#proc button.primary:has-text('Confirm')"); pg.click("#proc button.primary:has-text('Confirm assignments')")
with sync_playwright() as p:
    b = launch(p)
    pg = new_page(b, 1300, 900, errors); setup(pg); out['start'] = P(pg)
    pg.click("#hdr button:has-text('Reference')"); pg.keyboard.press('Space'); out['a) Reference + Space'] = P(pg); pg.close()
    pg = new_page(b, 1300, 900, errors); setup(pg)
    pg.focus("#hdr button:has-text('Undo')"); pg.keyboard.press('Enter'); out['b) Undo + Enter'] = P(pg); pg.close()
    pg = new_page(b, 1300, 900, errors); setup(pg)
    pg.focus("#hdr button:has-text('Save')"); pg.keyboard.press('Enter'); out['c) Save + Enter'] = P(pg); pg.close()
    pg = new_page(b, 1300, 900, errors); setup(pg)
    pg.focus("#hdr button:has-text('Undo')"); pg.keyboard.press('Space'); out['d) Undo + Space'] = P(pg); pg.close()
    b.close()
print(json.dumps(out, indent=1)); print(errors)
