# Phone-width (and desktop) usability measurements at the first occurrence of each kind of screen.
import sys, json, re
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
A11Y = (HERE / 'a11y_page.js').read_text()
W, H = int(sys.argv[1]), int(sys.argv[2]); tag = f'@{W}'
res = {}; errors = []
WANT = re.compile(r'^(assign|lineup|select|choice\|Command Decision|choice\|LC# Tactics|choice\|A# Schedule|choice\|B# Possible|info\|Gunnery Round results|info\|Tally|info\|Reset|info\|Land Battle result|info\|A# Target Cards drawn|info\|Encounter #: enemy sighted|choice\|Rake|choice\|Withdrawal|choice\|Transfer)')
with sync_playwright() as p:
    b = launch(p)
    for side, seed in (('US', 280004), ('BR', 280002)):
        pg = new_page(b, W, H, errors); pg.context.add_init_script(A11Y); fresh_setup(pg)
        if side == 'US': res['setup' + tag] = pg.evaluate("__a11y()"); pg.screenshot(path=str(SHOTS / f'A_setup{tag}.png'), full_page=True)
        start(pg, side, seed); seen = set(); n = 0
        while not pg.evaluate("G_STATE.over") and n < 400:
            pr = pg.evaluate("G_STATE.prompt"); key = pr['kind'] + '|' + re.sub(r'\d+', '#', pr['title'])
            k2 = key.split(' – ')[0] if key.startswith('info|Tally') or key.startswith('info|Reset') else key
            if WANT.match(k2) and k2 not in seen:
                seen.add(k2); pg.evaluate("window.scrollTo(0, 0)")
                m = pg.evaluate("__a11y()"); m['screen'] = key; res[f'{side} {k2}{tag}'] = m
                pg.screenshot(path=str(SHOTS / f"A_{side}_{re.sub('[^A-Za-z0-9]+', '_', k2)[:40]}{tag}.png"), full_page=True)
            realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []}); n += 1
        pg.evaluate("window.scrollTo(0, 0)"); res[f'{side} Game Over{tag}'] = pg.evaluate("__a11y()")
        pg.screenshot(path=str(SHOTS / f'A_{side}_gameover{tag}.png'), full_page=True)
        # dialogs
        for dlg in ('Reference', 'Settings', 'Adjust', 'Save', 'Load'):
            pg.click(f"#hdr button:has-text('{dlg}')"); m = pg.evaluate("__a11y()")
            m['modal_scrollW'] = pg.evaluate("(() => { const i = document.querySelector('#modal .inner'); return [i.scrollWidth, i.clientWidth, i.scrollHeight, i.clientHeight]; })()")
            m['tables_wider_than_modal'] = pg.evaluate("[...document.querySelectorAll('#modal table')].map(t => [Math.round(t.getBoundingClientRect().width), document.querySelector('#modal .inner').clientWidth])")
            res[f'{side} dialog {dlg}{tag}'] = m
            pg.screenshot(path=str(SHOTS / f'A_{side}_dialog_{dlg}{tag}.png'))
            pg.click("#modal button:has-text('Close')")
        res[f'{side} log entries / log box height{tag}'] = pg.evaluate("[document.querySelectorAll('#log div').length, G_STATE.log.length, Math.round(document.getElementById('log').getBoundingClientRect().height)]")
        pg.close()
    res['errors'] = errors
    b.close()
(OUT / 'runs' / f'a11y{tag}.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
for k, v in res.items():
    if isinstance(v, dict): print(k, '| overflow', v['overflow'], v['docW'], '| targets', v['targets'], '<24:', len(v['under24']), '<44h:', v['under44'], '| lowC', len(v['lowContrast']), '| wide', v['tooWide'][:2], '| fonts', sorted(v['fontSizes'].items(), key=lambda x: float(x[0]))[:3])
    else: print(k, v)
