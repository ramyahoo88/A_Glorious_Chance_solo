// Choices with a single enabled option (forced clicks) and select prompts with no real alternative, per recorded run.
const fs = require('fs');
const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
for (const f of process.argv.slice(2)) {
  const run = JSON.parse(fs.readFileSync(f)); const s = E.newGame(run.side, run.seed, run.opts || {}); E.run(s);
  const forced = {}, choiceN = {}; let selEmpty = 0, selN = 0;
  for (const a of run.answers) { const p = s.prompt;
    if (p.kind === 'choice') { const k = p.title.replace(/\d+/g, '#'); choiceN[k] = (choiceN[k] || 0) + 1; if (p.options.filter(o => !o.disabled).length === 1) forced[k] = (forced[k] || 0) + 1; }
    if (p.kind === 'select') { selN++; if (!p.items.length) selEmpty++; }
    E.act(s, a); }
  console.log(run.side, run.seed, 'choices', JSON.stringify(choiceN), '\n  single-option', JSON.stringify(forced), '\n  select prompts', selN, 'with no items', selEmpty);
}
