# Long logs: how many entries can the player reach in the Log panel at Game Over of a long game?
import json
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1)
    load_text(pg, (OUT / 'runs' / 'BR280009_fleet_1300_final_state.json').read_text())
    first = pg.evaluate("G_STATE.log.slice(0, 6).map(l => l.text)")
    shown = pg.evaluate("[...document.querySelectorAll('#log div')].map(d => d.textContent)")
    res = {'log_entries': pg.evaluate("G_STATE.log.length"), 'shown_with_filter_all': len(shown),
           'first_entries_visible': [any(f in t for t in shown) for f in first], 'first_entries': first[:6],
           'oldest_shown': shown[-1][:120]}
    for k in ('player', 'roll', 'ai', 'vp', 'combat'):
        pg.select_option('#board .panel h2 select', k); res['filter ' + k] = pg.evaluate("document.querySelectorAll('#log div').length")
    print(json.dumps(res, indent=1, ensure_ascii=False))
    b.close()
