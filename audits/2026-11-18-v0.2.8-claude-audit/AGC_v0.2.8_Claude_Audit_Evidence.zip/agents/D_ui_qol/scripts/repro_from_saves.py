# Re-run each finding from the delivered save files with plain page controls (1300×900).
import json, re
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
SV = OUT / 'saves'; out = {}; errors = []
def sv(t): return (-1 if t[0] == '−' else 1) * int(t[1:])
with sync_playwright() as p:
    b = launch(p)
    # D5: Adjust on a lake ship (A10, Madison in a Kingston Patrol Force)
    pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1); load_text(pg, (SV / 'D5_US280004_A10_Madison_on_lake.json').read_text())
    pg.click("#hdr button:has-text('Adjust')"); pg.locator('#modal select').nth(0).select_option('madison')
    out['D5 ship list label / box preselected'] = [pg.locator('#modal select').nth(0).evaluate("s => s.options[s.selectedIndex].text"), pg.locator('#modal select').nth(1).input_value()]
    pg.fill('#modal input[max="3"]', '2'); pg.click("#modal button:has-text('Apply')")
    out['D5 Madison after changing steps only'] = pg.evaluate("[G_STATE.ships.madison.box, G_STATE.ships.madison.zone, G_STATE.ships.madison.forceId, G_STATE.log.slice(-1)[0].text]")
    pg.close()
    # D5b: at the lineup
    pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1); load_text(pg, (SV / 'D5_US280004_lineup_Kingston.json').read_text())
    pg.click("#hdr button:has-text('Adjust')"); pg.locator('#modal select').nth(0).select_option('madison'); pg.fill('#modal input[max="3"]', '2'); pg.click("#modal button:has-text('Apply')"); pg.click("#modal button:has-text('Close')")
    out['D5b lineup after Adjust'] = [pg.locator("#proc button.primary:has-text('Attack with these ships')").is_disabled(), pg.locator('#proc .err').first.inner_text()]
    pg.close()
    # D6: Adjust VP then finish the game
    pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1); load_text(pg, (SV / 'ADJ_US280004_decision120.json').read_text())
    pg.click("#hdr button:has-text('Adjust')"); lab = pg.locator("#modal label:has-text('U.S. VP')").first; v = int(lab.locator('input').input_value()); lab.locator('input').fill(str(v + 3)); lab.locator("button:has-text('Set')").click(); pg.click("#modal button:has-text('Close')")
    while not pg.evaluate("G_STATE.over"):
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
    rows = pg.evaluate("[...document.querySelectorAll('#proc table.ref tr')].slice(1).map(tr => tr.children[2].textContent)")
    out['D6 final score shown vs ledger rows sum'] = [re.search(r"Final Game Score: ([+−±]\d+)", pg.inner_text('#proc'))[1], sum(sv(r) for r in rows)]
    pg.close()
    # D7: troops input shows 1 while the Force holds 0
    pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1); load_text(pg, (SV / 'D7_US280004_A7_with_3_Troops.json').read_text())
    pg.click("#proc button:has-text('+ Add Force')"); pg.locator('.asg-force select').nth(0).select_option('ArmySupport')
    for name in ('Madison', 'Oneida'):
        pg.locator('.asg-force .asg-ship', has_text=name).first.click()
    t = pg.locator('.asg-force input[type=number]'); t.fill('0'); t.press('Tab')
    out['D7 input shows / held / error'] = [pg.locator('.asg-force input[type=number]').input_value(), pg.evaluate("UI.local.forces[0].troops"), pg.locator('#proc .err').first.inner_text()]
    pg.screenshot(path=str(SHOTS / 'S02_troops_input_shows_1_holds_0.png'))
    pg.close()
    # D9: Rainy Squalls
    pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1); load_text(pg, (SV / 'Q_rainy_squalls_CD.json').read_text())
    odds = re.search(r"Odds if you attack[^\n]*", pg.inner_text('#proc'))[0]; zone_tags = pg.evaluate("[...document.querySelectorAll('#lake .zone.enc .tag')].map(t => t.textContent)")
    pg.click("#proc button:has-text('Attack')"); prev = re.search(r"First-Round Gunnery strength[^\n]*", pg.inner_text('#proc'))[0]
    n0 = pg.evaluate("G_STATE.log.length"); pg.click("#proc button.primary:has-text('Attack with these ships')")
    out['D9 Rainy Squalls'] = {'CD': odds, 'zone tags': zone_tags, 'lineup preview': prev, 'what happened': pg.evaluate(f"G_STATE.log.slice({n0}).map(l => l.text).slice(0, 4)")}
    pg.close()
    b.close()
print(json.dumps(out, indent=1, ensure_ascii=False)); print(errors)
(OUT / 'runs' / 'repro_from_saves.json').write_text(json.dumps(out, indent=1, ensure_ascii=False))
