# Desktop screenshots of the Settings and Adjust dialogs.
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
    for d in ('Settings', 'Adjust'):
        pg.click(f"#hdr button:has-text('{d}')"); pg.locator('#modal .inner').screenshot(path=str(SHOTS / f'DLG_{d}@1300.png')); pg.click("#modal button:has-text('Close')")
    b.close()
