# Undo / reload ("Continue it") / Save (download + copy) / Load (file + paste) / Review / New game / Start-over-autosave.
# Deep-compares G_STATE (rng included) after every restore. usage: persist_checks.py WIDTH HEIGHT
import sys, json, pathlib
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
W, H = int(sys.argv[1]), int(sys.argv[2]); tag = f'@{W}'
res = {}; errors = []
DL = OUT / 'downloads'; DL.mkdir(exist_ok=True)
def step(pg, n=1):
    for _ in range(n):
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
def S(pg): return pg.evaluate("JSON.stringify(G_STATE)")
def diff(a, b):
    a, b = json.loads(a), json.loads(b)
    return [k for k in set(a) | set(b) if a.get(k) != b.get(k)]
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, W, H, errors)
    pg.context.grant_permissions(['clipboard-read', 'clipboard-write'])
    fresh_setup(pg); start(pg, 'US', 280004)
    checkpoints = [3, 40, 52, 58, 75]   # A7 editor / mid-turn / inside Lake Combat (turn 4) / Tally
    done = 0
    for cp in checkpoints:
        step(pg, cp - done); done = cp
        S0 = S(pg); title0 = pg.evaluate("G_STATE.prompt.title"); r = {'at': title0}
        # Undo after one action
        step(pg); done += 1; S1 = S(pg)
        pg.click("#hdr button:has-text('Undo')"); r['undo_equal'] = S(pg) == S0; r['undo_diff'] = diff(S(pg), S0)
        r['undo_rendered_title'] = pg.inner_text('#proc .ptitle') == title0
        step(pg); done_state = S(pg); r['redo_same_dice'] = done_state == S1
        # reload → Continue it
        pg.reload(); pg.add_script_tag(content=POLICY_JS)
        r['setup_banner'] = pg.inner_text('.banner')[:90]
        pg.click("text=Continue it"); r['reload_equal'] = S(pg) == S1; r['reload_diff'] = diff(S(pg), S1)
        r['undo_after_reload_len'] = pg.evaluate("UNDO.length")
        # Save: download
        pg.click("#hdr button:has-text('Save')")
        with pg.expect_download() as dl:
            pg.click("#modal button:has-text('Download .json')")
        f = DL / f'cp{cp}{tag}_{dl.value.suggested_filename}'; dl.value.save_as(str(f))
        r['download_name'] = dl.value.suggested_filename
        saved = json.loads(f.read_text()); r['download_equal'] = json.dumps(saved['state'], separators=(',', ':')) == json.dumps(json.loads(S1), separators=(',', ':'))
        r['download_undo'] = saved.get('undo')
        # Save: copy text
        pg.click("#modal button:has-text('Copy save text')")
        r['copy_msg'] = pg.inner_text('#modal .muted').strip()
        try: clip = pg.evaluate("navigator.clipboard.readText()")
        except Exception as e: clip = 'ERR ' + str(e)[:80]
        r['copy_equal'] = clip == pg.evaluate("saveText()")
        pg.click("#modal button:has-text('Close')")
        # play on 2 steps, then Load the downloaded file through the file chooser
        step(pg, 2); S3 = S(pg)
        pg.click("#hdr button:has-text('Load')"); pg.set_input_files("#modal input[type=file]", str(f)); pg.wait_for_timeout(300)
        r['load_file_equal'] = S(pg) == S1; r['load_file_diff'] = diff(S(pg), S1); r['modal_closed_after_load'] = not pg.evaluate("document.getElementById('modal').classList.contains('open')")
        pg.click("#hdr button:has-text('Undo')"); r['undo_after_load_returns_previous'] = S(pg) == S3
        # Load pasted text (the copied text)
        load_text(pg, clip if not clip.startswith('ERR') else f.read_text()); r['load_paste_equal'] = S(pg) == S1
        # play forward from the loaded game: same dice as the original line?
        step(pg); r['continue_after_load_same_as_original'] = json.loads(S(pg))['rng'] == json.loads(done_state)['rng'] if cp == checkpoints[0] else None
        S_now = S(pg)
        res[f'cp{cp}'] = r
        done += 0
        # resynchronise the step counter with the current position
        done = pg.evaluate("G_STATE.promptSeq") and done
    res['undo_stack_in_memory'] = pg.evaluate("UNDO.length"); res['autosave_undo'] = pg.evaluate("JSON.parse(localStorage.getItem(SAVE_KEY)).undo.length")
    # New game: Cancel keeps; Abandon clears autosave
    Sx = S(pg); pg.click("#hdr button:has-text('New game')"); pg.click("#modal button:has-text('Cancel')")
    res['new_game_cancel_keeps'] = S(pg) == Sx
    # Start campaign on the setup screen while an autosave exists (no confirmation?)
    pg.reload(); pg.add_script_tag(content=POLICY_JS)
    res['setup_has_continue_banner'] = pg.is_visible("text=Continue it")
    pg.screenshot(path=str(SHOTS / f'P01_setup_with_saved_game{tag}.png'))
    pg.click("text=Start campaign")
    res['start_campaign_confirm_shown'] = pg.evaluate("document.getElementById('modal').classList.contains('open')")
    res['start_campaign_undo_available'] = pg.evaluate("UNDO.length")
    pg.reload(); res['after_start_reload_banner'] = pg.inner_text('.banner')[:90]
    res['old_game_recoverable'] = json.loads(pg.evaluate("localStorage.getItem(SAVE_KEY)"))['state']['rng'] == json.loads(Sx)['rng']
    # Load a saved game from the setup screen while an autosave exists
    pg.click("text=Continue it"); step(pg, 5); Sy = S(pg); pg.reload()
    other = (OUT / 'runs' / 'BR280002_1300_final_state.json').read_text()
    pg.click("#app button:has-text('Load a saved game')"); pg.fill("#modal textarea", other); pg.click("text=Load pasted text")
    res['setup_load_replaces_autosave_without_confirm'] = json.loads(pg.evaluate("localStorage.getItem(SAVE_KEY)"))['state']['human'] == 'BR'
    res['setup_load_undo_len'] = pg.evaluate("UNDO.length")
    # Review a finished game
    pg.reload(); res['finished_banner'] = pg.inner_text('.banner')[:90]
    pg.click("text=Review it"); fin = json.loads(other)['state']
    res['review_equal'] = json.loads(S(pg)) == fin or diff(S(pg), json.dumps(fin))
    res['review_screen'] = pg.inner_text('#proc')[:160]
    pg.screenshot(path=str(SHOTS / f'P02_review_finished{tag}.png'), full_page=True)
    res['errors'] = errors
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False))
(OUT / 'runs' / f'persist_checks{tag}.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
