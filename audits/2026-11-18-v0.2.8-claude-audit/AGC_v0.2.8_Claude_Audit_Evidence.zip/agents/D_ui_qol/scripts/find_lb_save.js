// Find a natural manual Land Battle prompt with a More Defenders column shift and save it.
const fs = require('fs');
const H = require('/home/claude/audit028/harness.js')();
H.X('var window = this;'); H.X(fs.readFileSync(__dirname + '/policy_page.js', 'utf8'));
const r = H.X(`(() => {
  for (let seed = 280001; seed < 280400; seed++) for (const side of ['US', 'BR']) {
    const s = newGame(side, seed, { manualLandBattle: true }); run(s); let n = 0;
    while (!s.over && n++ < 600) {
      const p = s.prompt;
      if (p.landBattle && p.landBattle.shift) {
        const lb = p.landBattle; const auto = lbLookup(lb.lg, lb.troops, lb.shift, lb.roll);
        return { side, seed, n, lb, auto, text: p.text, save: JSON.stringify({ state: s, undo: [] }) };
      }
      if (p.landBattle) { const lb = p.landBattle; act(s, lbLookup(lb.lg, lb.troops, lb.shift, lb.roll).result); continue; }
      act(s, __policy(s, p, 'sensible'));
    }
  }
  return null; })()`);
if (!r) { console.log('none'); process.exit(); }
fs.writeFileSync(__dirname + '/../saves/LB_manual_more_defenders.json', r.save); delete r.save; console.log(JSON.stringify(r, null, 1));
