# A7 assignment editor: what the controls show vs what is validated/applied.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
res = {}; errors = []
W, H = int(sys.argv[1]), int(sys.argv[2]); tag = f'@{W}'
def to_assign(pg):
    while not pg.evaluate("G_STATE.prompt.kind === 'assign' && G_STATE.prompt.troops > 0"):
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
def view(pg):
    f = pg.locator('.asg-force').nth(0)
    return {'input_shows': f.locator('input[type=number]').input_value() if f.locator('input[type=number]').count() else None,
            'local_troops': pg.evaluate("UI.local.forces[0].troops"),
            'error_shown': pg.locator('#proc .err').first.inner_text() if pg.locator('#proc .err').count() else '',
            'confirm_disabled': pg.locator("#proc button.primary:has-text('Confirm assignments')").is_disabled(),
            'capacity_label': f.inner_text().split('(capacity')[1].split(')')[0].strip() if '(capacity' in f.inner_text() else None}
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, W, H, errors); fresh_setup(pg); start(pg, 'US', 280004); to_assign(pg)
    pr = pg.evaluate("G_STATE.prompt"); res['troops_available'] = pr['troops']; res['missions'] = {k: v for k, v in pr['missions'].items()}
    pg.click("#proc button:has-text('+ Add Force')")
    pg.locator('.asg-force').nth(0).locator('select').nth(0).select_option('ArmySupport')
    res['after_choosing_ArmySupport'] = view(pg)
    pg.locator('.asg-force').nth(0).locator('.asg-ship').nth(0).click()   # one ship
    res['one_ship'] = view(pg)
    t = pg.locator('.asg-force').nth(0).locator('input[type=number]')
    for val in ('0', '', '1.5', '-1', '9'):
        t = pg.locator('.asg-force').nth(0).locator('input[type=number]'); t.fill(val); t.press('Tab')
        res[f'typed {val!r}'] = view(pg)
        if val in ('0', ''): pg.screenshot(path=str(SHOTS / f'S01_troops_typed_{val or "empty"}{tag}.png'))
    # engine acceptance of what the editor would send at "typed 0": the button state already reflects validateAnswer
    # mission change back and forth
    pg.locator('.asg-force').nth(0).locator('select').nth(0).select_option('Patrol'); res['back_to_Patrol'] = view(pg)
    pg.locator('.asg-force').nth(0).locator('select').nth(0).select_option('ArmySupport'); res['ArmySupport_again'] = view(pg)
    # flagship select change is applied?
    opts = pr['flagshipOptions']; other = [o for o in opts if o != pr['flagship']][0]
    pg.locator('#proc .row select').first.select_option(other)
    res['flagship_local'] = pg.evaluate("UI.local.flagship"); res['flagship_wanted'] = other
    b.close()
print(json.dumps(res, indent=1)); print(errors)
(OUT / 'runs' / f'assign_checks{tag}.json').write_text(json.dumps(res, indent=1))
