// Package helper (manual mode Auto-fill) vs the automatic Player Aid V selection for the same pool.
const H = require('/home/claude/audit028/harness.js')();
const out = H.X(`(() => {
  const s = newGame('BR', 280002); run(s);
  const pool = deployable(s, 'US');
  const desc = pool.map(sh => shipName(s, sh.id) + (isMain(sh) ? ' [Main]' : '') + ' LG ' + lg(sh));
  const res = {};
  for (const pkg of [2, 3, 4, 5, 6]) {
    const need = PKG_LG_NEED[pkg];
    const auto = forcePackageSelect(JSON.parse(JSON.stringify(s)), pkg, pool.map(sh => sh));
    const counts = {}; let worst = null;
    for (let i = 0; i < 2000; i++) { const sel = pkgAutoFill(s, pool.map(sh => sh.id), { type: 'lg', n: need }); counts[sel.length] = (counts[sel.length] || 0) + 1; if (!worst || sel.length > worst.length) worst = sel; }
    res[pkg] = { need, autoShips: auto.ok ? auto.ships.length : 0, autoText: auto.text || auto.why, helperShipCounts: counts, helperWorst: worst.map(id => shipName(s, id)) };
  }
  return { pool: desc, res };
})()`);
console.log(JSON.stringify(out, null, 1));
