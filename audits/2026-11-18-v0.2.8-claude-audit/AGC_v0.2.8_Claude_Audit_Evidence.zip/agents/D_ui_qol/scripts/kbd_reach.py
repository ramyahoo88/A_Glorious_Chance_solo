# Keyboard-only reachability: can the A7 ship chips and the Tactic cards be reached with Tab and activated with Enter/Space?
import json
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
run = json.loads((OUT / 'runs' / 'US280004_1300.json').read_text()); errors = []; res = {}
def tab_walk(pg, n=120):
    seen = []
    pg.evaluate("document.activeElement && document.activeElement.blur()")
    for _ in range(n):
        pg.keyboard.press('Tab')
        seen.append(pg.evaluate("(() => { const a = document.activeElement; return a ? a.tagName.toLowerCase() + '.' + (a.className || '') + ':' + (a.textContent || a.value || '').trim().slice(0, 18) : null; })()"))
    return seen
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
    while pg.evaluate("G_STATE.prompt.kind") != 'assign': realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
    pg.click("#proc button:has-text('+ Add Force')")
    seen = tab_walk(pg)
    res['A7: ship chips present'] = pg.evaluate("document.querySelectorAll('.asg-ship').length")
    res['A7: ship chips reached by Tab'] = sum(1 for s in seen if s and s.startswith('span.asg-ship'))
    res['A7: chip tabindex/role'] = pg.evaluate("[document.querySelector('.asg-ship').getAttribute('tabindex'), document.querySelector('.asg-ship').getAttribute('role')]")
    pg.click("#hdr button:has-text('Undo')")
    for a in run['answers'][len(pg.evaluate("UNDO")) if False else 0:0]: pass
    b.close()
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
    for a in run['answers']:
        if pg.evaluate("G_STATE.prompt.tactic"): break
        realize(pg, a, {'clicks': 0, 'notes': []})
    seen = tab_walk(pg, 80)
    res['Tactics: cards present'] = pg.evaluate("document.querySelectorAll('#proc .optcard').length")
    res['Tactics: cards reached by Tab'] = sum(1 for s in seen if s and 'optcard' in s)
    res['Tactics: other buttons in the prompt'] = pg.evaluate("[...document.querySelectorAll('#proc button')].map(b => b.textContent)")
    b.close()
print(json.dumps(res, indent=1)); print(errors)
(OUT / 'runs' / 'kbd_reach.json').write_text(json.dumps(res, indent=1))
