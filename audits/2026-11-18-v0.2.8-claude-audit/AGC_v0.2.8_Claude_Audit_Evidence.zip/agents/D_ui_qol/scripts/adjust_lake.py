# Adjust → Ships on a ship that is on the lake: change only her steps, then look at box/Force; and the lineup afterwards.
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
run = json.loads((OUT / 'runs' / 'US280004_1300.json').read_text())
res = {}; errors = []
with sync_playwright() as p:
    b = launch(p)
    for at, sid in ((3, 'madison'), (75, 'madison')):
        pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
        for a in run['answers'][:at]: realize(pg, a, {'clicks': 0, 'notes': []})
        before = pg.evaluate(f"(() => {{ const sh = G_STATE.ships['{sid}']; return {{ box: sh.box, zone: sh.zone, steps: sh.steps, force: sh.forceId }}; }})()")
        pg.click("#hdr button:has-text('Adjust')"); pg.locator('#modal select').nth(0).select_option(sid)
        shown_box = pg.locator('#modal select').nth(1).input_value()
        pg.fill('#modal input[max="3"]', str(max(0, before['steps'] - 1)))
        pg.click("#modal button:has-text('Apply')")
        after = pg.evaluate(f"(() => {{ const sh = G_STATE.ships['{sid}']; return {{ box: sh.box, zone: sh.zone, steps: sh.steps, force: sh.forceId }}; }})()")
        log = pg.evaluate("G_STATE.log.slice(-1)[0].text"); pg.click("#modal button:has-text('Close')")
        r = {'prompt': pg.evaluate("G_STATE.prompt.title"), 'before': before, 'adjust_box_preselected': shown_box, 'after_only_steps_changed': after, 'log': log}
        if pg.evaluate("G_STATE.prompt.kind") == 'lineup':
            r['lineup_error'] = pg.inner_text('#proc .err') if pg.query_selector('#proc .err') else ''
            r['lineup_button_disabled'] = pg.locator("#proc button.primary:has-text('Attack with these ships')").is_disabled()
            r['validate'] = pg.evaluate("validateAnswer(G_STATE, G_STATE.prompt, {attackers: UI.local.att, tows: UI.local.tows})")
            pg.screenshot(path=str(SHOTS / 'ADJ4_lineup_after_adjusting_madison_steps.png'))
        res[f'decision {at}'] = r; pg.close()
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False)); print(errors)
(OUT / 'runs' / 'adjust_lake.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
