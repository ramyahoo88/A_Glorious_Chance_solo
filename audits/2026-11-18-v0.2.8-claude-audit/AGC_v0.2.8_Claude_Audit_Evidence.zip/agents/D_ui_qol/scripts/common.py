# Shared Playwright helpers for the v0.2.8 UI audit (real Chrome, file:// dist/index.html).
import json, pathlib, re
HTML = pathlib.Path('/home/claude/a_glorious_chance_solo/dist/index.html').resolve().as_uri()
HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent
SHOTS = OUT / 'shots'; SHOTS.mkdir(exist_ok=True)
POLICY_JS = (HERE / 'policy_page.js').read_text()

def launch(p):
    return p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])

def new_page(b, w, h, errors):
    ctx = b.new_context(viewport={'width': w, 'height': h}, accept_downloads=True)
    ctx.add_init_script(POLICY_JS)
    pg = ctx.new_page()
    pg.on('pageerror', lambda e: errors.append('PAGEERROR ' + str(e)))
    pg.on('console', lambda m: errors.append('CONSOLE ' + m.text) if m.type == 'error' else None)
    return pg

def fresh_setup(pg):
    pg.goto(HTML); pg.evaluate("localStorage.clear()"); pg.reload()

def start(pg, side, seed, opts=None):
    """Start a campaign from the setup screen with the real controls."""
    if side == 'BR': pg.click("button:has-text('British Solo Campaign')")
    for k, v in (opts or {}).items():
        lab = {'cuttingOut': 'Cutting-Out', 'oa1Upgrades': 'OA1', 'confirmAiSteps': 'Pause after each', 'manualPackages': 'pick the American Force Package', 'manualLandBattle': 'Read the Land Battle Table'}[k]
        cb = pg.locator(f"label:has-text('{lab}') input[type=checkbox]")
        if cb.is_checked() != v: cb.click()
    seed_in = pg.locator("label:has-text('Random seed') input")
    seed_in.fill(str(seed)); seed_in.press('Tab')
    pg.click("text=Start campaign")

def ev(pg, js, arg=None):
    return pg.evaluate(js, arg) if arg is not None else pg.evaluate(js)

def state(pg):
    return pg.evaluate("JSON.stringify(G_STATE)")

def load_text(pg, txt):
    pg.click("#hdr button:has-text('Load')"); pg.fill("#modal textarea", txt); pg.click("text=Load pasted text")

def mark_and_click(pg, js_find):
    """js_find: JS expression returning an element; mark it and click it with a real mouse click."""
    ok = pg.evaluate(f"(() => {{ document.querySelectorAll('[data-audit-pick]').forEach(e => e.removeAttribute('data-audit-pick')); const e = ({js_find}); if (!e) return false; e.setAttribute('data-audit-pick', '1'); return true; }})()")
    if not ok: raise RuntimeError('element not found: ' + js_find)
    pg.click('[data-audit-pick]')

BODY = "(() => { const p = document.getElementById('proc'); return p.children[p.children.length - 2]; })()"

def realize(pg, ans, rec):
    """Give `ans` to the pending prompt through the page controls. rec collects counts/notes."""
    pr = pg.evaluate("G_STATE.prompt")
    k = pr['kind']
    if k == 'info':
        pg.click('#btn-ok'); return
    if k == 'choice':
        i = [o['id'] for o in pr['options']].index(ans)
        if pr.get('tactic'):
            mark_and_click(pg, f"{BODY}.querySelectorAll('.optcard')[{i}]")
        else:
            mark_and_click(pg, f"{BODY}.querySelectorAll('.opts button')[{i}]")
        return
    if k == 'select':
        ids = [it['id'] for it in pr['items']]
        want = set(ans)
        for i, iid in enumerate(ids):
            cb = pg.locator('.sel-list label input[type=checkbox]').nth(i)
            if cb.is_checked() != (iid in want):
                cb.click(); rec['clicks'] += 1
        sel = pg.evaluate("UI.local && UI.local.sel")
        if sorted(sel) != sorted(ans): rec['notes'].append(f"select mismatch UI {sel} vs wanted {ans}")
        pg.click("#proc button.primary:has-text('Confirm')"); rec['clicks'] += 1
        return
    if k == 'lineup':
        loc = pg.evaluate("UI.local")
        if sorted(loc['att']) != sorted(ans['attackers']) or loc['tows'] != ans['tows']:
            rec['notes'].append(f"lineup default differs {loc} vs {ans}")
        pg.click("#proc button.primary:has-text('Attack with these ships')"); rec['clicks'] += 1
        return
    if k == 'assign':
        ships = pr['ships']
        for fi, f in enumerate(ans['forces']):
            pg.click("#proc button:has-text('+ Add Force')"); rec['clicks'] += 1
            box = pg.locator('.asg-force').nth(fi)
            if f['mission'] != 'Patrol':
                box.locator('select').nth(0).select_option(f['mission']); rec['clicks'] += 1
            box = pg.locator('.asg-force').nth(fi)
            cur_zone = box.locator('select').nth(1).input_value()
            if cur_zone != f['zone']:
                box.locator('select').nth(1).select_option(f['zone']); rec['clicks'] += 1
            for sid in f['ships']:
                j = ships.index(sid)
                pg.locator('.asg-force').nth(fi).locator('.asg-ship').nth(j).click(); rec['clicks'] += 1
            if f['mission'] == 'ArmySupport':
                t = pg.locator('.asg-force').nth(fi).locator('input[type=number]')
                if t.input_value() != str(f['troops']):
                    t.fill(str(f['troops'])); t.press('Tab'); rec['clicks'] += 1
        loc = pg.evaluate("({flagship: UI.local.flagship, forces: UI.local.forces.map(f => ({mission: f.mission, zone: f.zone, ships: f.ships.slice().sort(), troops: f.mission === 'ArmySupport' ? f.troops : 0}))})")
        want = {'flagship': ans['flagship'], 'forces': [{'mission': f['mission'], 'zone': f['zone'], 'ships': sorted(f['ships']), 'troops': f['troops'] if f['mission'] == 'ArmySupport' else 0} for f in ans['forces']]}
        if loc != want: rec['notes'].append(f"assign mismatch UI {loc} vs wanted {want}")
        btn = pg.locator("#proc button.primary:has-text('Confirm assignments')")
        if btn.is_disabled():
            rec['notes'].append('assign confirm disabled: ' + pg.locator('#proc .err').last.inner_text())
        btn.click(); rec['clicks'] += 1
        return
    raise RuntimeError('unknown kind ' + k)
