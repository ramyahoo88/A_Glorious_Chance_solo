# Phone width: where the page is left after an action (US seed 280004, first A7 Assign → A10).
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
res = {}; errors = []
POS = """() => { const t = document.querySelector('#proc .ptitle'), b = document.querySelector('#btn-ok, #proc button.primary');
  return { scrollY: Math.round(scrollY), title: t.textContent, titleTop: Math.round(t.getBoundingClientRect().top), buttonTop: b && Math.round(b.getBoundingClientRect().top), viewportH: innerHeight }; }"""
with sync_playwright() as p:
    b = launch(p)
    for W, H in ((390, 844), (800, 1000), (1300, 900)):
        pg = new_page(b, W, H, errors); fresh_setup(pg); start(pg, 'US', 280004)
        while pg.evaluate("G_STATE.prompt.kind") != 'assign':
            realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
        ans = pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')")
        # build the Forces but stop before Confirm
        pr = pg.evaluate("G_STATE.prompt")
        for fi, f in enumerate(ans['forces']):
            pg.click("#proc button:has-text('+ Add Force')")
            if f['mission'] != 'Patrol': pg.locator('.asg-force').nth(fi).locator('select').nth(0).select_option(f['mission'])
            if pg.locator('.asg-force').nth(fi).locator('select').nth(1).input_value() != f['zone']: pg.locator('.asg-force').nth(fi).locator('select').nth(1).select_option(f['zone'])
            for sid in f['ships']: pg.locator('.asg-force').nth(fi).locator('.asg-ship').nth(pr['ships'].index(sid)).click()
        btn = pg.locator("#proc button.primary:has-text('Confirm assignments')"); btn.scroll_into_view_if_needed()
        res[f'before Confirm @{W}'] = pg.evaluate(POS)
        if W == 390: pg.screenshot(path=str(SHOTS / 'SC1_before_confirm_390.png'))
        btn.click()
        res[f'after Confirm @{W}'] = pg.evaluate(POS)
        if W == 390: pg.screenshot(path=str(SHOTS / 'SC2_after_confirm_390.png'))
        pg.close()
    b.close()
print(json.dumps(res, indent=1)); print(errors)
(OUT / 'runs' / 'scroll_repro.json').write_text(json.dumps(res, indent=1))
