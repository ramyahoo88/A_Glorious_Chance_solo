// Run the in-page policy (policy_page.js) inside the engine harness to scan seeds and count per-turn workload.
// usage: node scan_sensible.js SIDE SEED0 COUNT STYLE [opts-json]
const fs = require('fs');
const H = require('/home/claude/audit028/harness.js')();
H.X('var window = this;'); H.X(fs.readFileSync(__dirname + '/policy_page.js', 'utf8'));
const [side, seed0, count, style] = [process.argv[2], +process.argv[3], +process.argv[4], process.argv[5] || 'sensible'];
const opts = process.argv[6] || '{}';
for (let seed = seed0; seed < seed0 + count; seed++) {
  const r = H.X(`(() => { const s = newGame('${side}', ${seed}, ${opts}); run(s); const k = {}; let n = 0, info = 0;
    while (!s.over && n < 3000) { const p = s.prompt; k[p.kind] = (k[p.kind] || 0) + 1; act(s, __policy(s, p, '${style}')); n++; }
    return { seed: ${seed}, n, k, score: s.result.score, level: s.result.level, gr1: s.log.filter(l => /^Gunnery Round 1/.test(l.text)).length, lb: s.log.filter(l => /Land Battle/.test(l.text)).length }; })()`);
  console.log(side, JSON.stringify(r));
}
