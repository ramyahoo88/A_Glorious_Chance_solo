// Find a natural manual-package prompt (Package #2-#6) whose Long Gun requirement can be met, and save it.
const fs = require('fs');
const H = require('/home/claude/audit028/harness.js')();
H.X('var window = this;'); H.X(fs.readFileSync(__dirname + '/policy_page.js', 'utf8'));
const r = H.X(`(() => {
  for (let seed = 280001; seed < 280060; seed++) {
    const s = newGame('BR', seed, { manualPackages: true }); run(s); let n = 0;
    while (!s.over && n++ < 600) {
      const p = s.prompt;
      if (p.kind === 'select' && p.pkg) {
        const need = PKG_LG_NEED[p.pkg]; const pool = p.items.map(i => s.ships[i.id]);
        if (need && sumBy(pool, lg) >= need) {
          const auto = forcePackageSelect(JSON.parse(JSON.stringify(s)), p.pkg, pool);
          const counts = {}; for (let i = 0; i < 500; i++) { const k = pkgAutoFill(s, p.items.map(i => i.id), { type: 'lg', n: need }).length; counts[k] = (counts[k] || 0) + 1; }
          if (Object.keys(counts).some(k => +k !== auto.ships.length)) return { seed, n, turn: s.turn, pkg: p.pkg, need, auto: auto.ships, autoText: auto.text, counts, save: JSON.stringify({ state: s, undo: [] }) };
        }
        const pool2 = p.items.map(i => s.ships[i.id]); const a = forcePackageSelect(JSON.parse(JSON.stringify(s)), p.pkg, pool2);
        act(s, a.ok ? a.ships.concat(a.ships2 || []) : []); continue;
      }
      act(s, __policy(s, p, 'sensible'));
    }
  }
  return null; })()`);
if (!r) { console.log('none'); process.exit(); }
fs.writeFileSync(__dirname + '/../saves/PK_manual_package_prompt.json', r.save);
delete r.save; console.log(JSON.stringify(r));
