const side = process.argv[2], seed = +process.argv[3], style = process.argv[4] || 'fleet';
const repo = '/home/claude/a_glorious_chance_solo'; process.argv[2] = repo;
const { policy } = require('/home/claude/audit028/policy_campaigns.js');
const E = require(repo + '/tools/bundle_engine.js')();
const s = E.newGame(side, seed, {}); E.run(s);
let n=0; while (!s.over && n < 3000) { E.act(s, policy(s, s.prompt, style)); n++; }
const agg = {}; s.vpLog.forEach(v => { const k = v.side + ' ' + v.why.replace(/\d+/g,'#').slice(0,70); agg[k] = (agg[k]||0) + (v.side==='US'?v.n:-v.n); });
console.log(Object.entries(agg).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1])).slice(0,25).map(x=>x[1]+'\t'+x[0]).join('\n'));
