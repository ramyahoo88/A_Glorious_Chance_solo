# Lineup editor: change the attackers and tows through the controls; compare the preview line with the Gunnery Round fought.
import sys, json, re
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
run = json.loads((OUT / 'runs' / 'US280004_1300.json').read_text())
res = []; errors = []
CASES = [  # (description, ships to untick, tow changes {tower: schooner or ''})
    ('default lineup', [], {}),
    ('drop Pike and Oneida', ['pike', 'oneida'], {}),
    ('untow everything', [], {'pike': '', 'madison': '', 'sylph': ''}),
    ('drop the towing Madison (its schooner becomes untowed)', ['madison'], {}),
    ('only schooners', ['pike', 'oneida', 'madison', 'sylph', 'growler', 'julia', 'lady', 'ontario', 'pert', 'raven', 'scourge'], {}),
]
with sync_playwright() as p:
    b = launch(p)
    for desc, drop, tows in CASES:
        pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
        for a in run['answers'][:75]: realize(pg, a, {'clicks': 0, 'notes': []})
        assert pg.evaluate("G_STATE.prompt.kind") == 'lineup'
        cands = pg.evaluate("G_STATE.prompt.candidates")
        for sid in drop:
            pg.locator('.sel-list label').nth(cands.index(sid)).locator('input[type=checkbox]').click()
        for tower, sch in tows.items():
            row = pg.locator('.sel-list label').nth(cands.index(tower))
            row.locator('select').select_option(sch)
        prev = re.search(r"First-Round Gunnery strength ([\d.]+) vs ([\d.]+) → ([\d.∞]+):1 \(([^)]+)\)", pg.inner_text('#proc'))
        drm = re.search(r"(\d+) untowed Laker Schooner|No untowed Laker Schooners", pg.inner_text('#proc'))
        local = pg.evaluate("UI.local")
        n_log = pg.evaluate("G_STATE.log.length")
        pg.click("#proc button.primary:has-text('Attack with these ships')")
        for _ in range(8):
            lines = pg.evaluate(f"G_STATE.log.slice({n_log}).map(l => l.text)")
            g = next((l for l in lines if l.startswith('Gunnery Round 1')), None)
            if g: break
            realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
        gm = g and re.search(r"U\.S\. ([\d.]+) vs British ([\d.]+) = ([\d.∞]+):1 → column (\S+?)\.?( \(|\s)", g)
        un = g and re.search(r"untowed Laker Schooners \((\d+), d6", g)
        res.append({'case': desc, 'attackers': len(local['att']), 'tows': local['tows'], 'preview': prev and prev.groups(), 'preview_untowed': drm and drm.group(0),
                    'applied': gm and gm.groups()[:4], 'applied_untowed': un and int(un[1]), 'line': g,
                    'strength_match': bool(prev and gm) and float(prev[1]) == float(gm[1]) and float(prev[2]) == float(gm[2]),
                    'untowed_match': (drm and drm.group(1) and int(drm.group(1))) == (un and int(un[1])) or (drm and drm.group(1) is None and not un)})
        pg.close()
    b.close()
for r in res: print(json.dumps(r, ensure_ascii=False))
print(errors)
(OUT / 'runs' / 'lineup_checks.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
