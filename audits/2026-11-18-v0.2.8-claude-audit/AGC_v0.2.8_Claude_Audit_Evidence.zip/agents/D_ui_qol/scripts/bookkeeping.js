// Count the physical-board changes the player must mirror per turn (ship moves/flips, markers), by diffing the
// state between consecutive prompts of a recorded run, and how many ship changes are named on the next prompt.
const fs = require('fs'); const run = JSON.parse(fs.readFileSync(process.argv[2]));
const H = require('/home/claude/audit028/harness.js')();
H.X(`var RUN = ${JSON.stringify({ side: run.side, seed: run.seed, opts: run.opts || {}, answers: run.answers })};`);
const out = H.X(`(() => {
  const s = newGame(RUN.side, RUN.seed, RUN.opts); run(s);
  const snap = () => JSON.parse(JSON.stringify({ ships: s.ships, forces: Object.keys(s.forces).sort(), supply: s.supply, cd: s.cd, vp: s.vp, niagara: s.niagara,
    troops: s.troops[s.human], aiTroops: s.aiTroops.track.length + '/' + s.aiTroops.box.length, zones: ZONES.map(z => [s.zones[z].control, s.zones[z].blockade, s.zones[z].event]), pe: s.pe.length, row: s.targetRow.length, flag: s.flagship, turn: s.turn }));
  const per = {}; let prev = snap();
  for (const a of RUN.answers) {
    act(s, a); const cur = snap(); const t = prev.turn; const T = per[t] = per[t] || { shipChanges: 0, namedOnPrompt: 0, forcesPlaced: 0, forcesRemoved: 0, trackMarkers: 0, zoneMarkers: 0, peMarkers: 0, targetCards: 0 };
    const ptxt = s.prompt ? (s.prompt.title + ' ' + (s.prompt.text || '')) : '';
    for (const id in cur.ships) { const A = prev.ships[id], B = cur.ships[id];
      if (A.box !== B.box || A.zone !== B.zone || A.steps !== B.steps || A.owner !== B.owner || A.port !== B.port) { T.shipChanges++; if (ptxt.indexOf(def(s.ships[id]).name) >= 0) T.namedOnPrompt++; } }
    T.forcesPlaced += cur.forces.filter(f => prev.forces.indexOf(f) < 0).length; T.forcesRemoved += prev.forces.filter(f => cur.forces.indexOf(f) < 0).length;
    ['US', 'BR'].forEach(sd => { if (cur.supply[sd] !== prev.supply[sd]) T.trackMarkers++; if (cur.cd[sd] !== prev.cd[sd]) T.trackMarkers++; if (cur.vp[sd] !== prev.vp[sd]) T.trackMarkers++; });
    if (cur.niagara !== prev.niagara) T.trackMarkers++; if (JSON.stringify(cur.troops) !== JSON.stringify(prev.troops)) T.trackMarkers++; if (cur.aiTroops !== prev.aiTroops) T.trackMarkers++;
    cur.zones.forEach((z, i) => z.forEach((v, j) => { if (v !== prev.zones[i][j]) T.zoneMarkers++; }));
    if (cur.pe !== prev.pe) T.peMarkers += Math.abs(cur.pe - prev.pe); if (cur.row !== prev.row) T.targetCards += Math.abs(cur.row - prev.row);
    prev = cur;
  }
  return per; })()`);
const tot = {}; Object.values(out).forEach(T => Object.keys(T).forEach(k => tot[k] = (tot[k] || 0) + T[k]));
console.log(run.side, run.seed); Object.keys(out).forEach(t => console.log(' turn', t, JSON.stringify(out[t]))); console.log(' total', JSON.stringify(tot));
