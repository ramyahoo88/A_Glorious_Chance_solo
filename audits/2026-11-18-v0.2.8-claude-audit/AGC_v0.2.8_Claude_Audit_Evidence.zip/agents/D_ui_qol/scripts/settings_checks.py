# Settings dialog: switch "Pause after each A.I. move" off mid-game and count the prompts that remain.
import json, re
from playwright.sync_api import sync_playwright
import sys; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
errors = []; res = {}
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 280004)
    pg.click("#hdr button:has-text('Settings')"); res['settings_text'] = pg.inner_text('#modal')[:400]
    pg.click("#modal label:has-text('Pause after each') input"); pg.click("#modal button:has-text('Close')")
    res['option_saved'] = pg.evaluate("JSON.parse(localStorage.getItem(SAVE_KEY)).state.options.confirmAiSteps")
    n = 0; info = 0; titles = set()
    while not pg.evaluate("G_STATE.over") and n < 400:
        pr = pg.evaluate("G_STATE.prompt"); n += 1
        if pr['kind'] == 'info': info += 1; titles.add(re.sub(r'\d+', '#', pr['title']))
        realize(pg, pg.evaluate("__policy(G_STATE, G_STATE.prompt, 'sensible')"), {'clicks': 0, 'notes': []})
    res.update({'prompts_with_pauses_off': n, 'info': info, 'score': pg.evaluate("G_STATE.result.score"), 'ai_step_titles_seen': sorted(t for t in titles if re.match(r'^(A# Target|B# Possible|Encounter Check|C Enemy|AI Deployment|Encounter # – no enemy|Encounter – no enemy|Convoy found|Your Convoy is attacked|Encounter #: enemy)', t))})
    b.close()
print(json.dumps(res, indent=1, ensure_ascii=False)); print(errors)
(OUT / 'runs' / 'settings_checks.json').write_text(json.dumps(res, indent=1, ensure_ascii=False))
