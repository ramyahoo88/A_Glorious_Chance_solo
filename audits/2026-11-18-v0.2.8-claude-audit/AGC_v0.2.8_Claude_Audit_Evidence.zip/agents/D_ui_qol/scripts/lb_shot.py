# Screenshot the manual Land Battle prompt with a More Defenders shift (US seed 280003, manualLandBattle on).
from playwright.sync_api import sync_playwright
import sys, json; sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, 1300, 900, errors); fresh_setup(pg); start(pg, 'US', 1)
    load_text(pg, (OUT / 'saves' / 'LB_manual_more_defenders.json').read_text())
    print(pg.inner_text('#proc')[:900]); pg.screenshot(path=str(SHOTS / 'LB1_manual_land_battle_shift_wording.png'))
    b.close()
