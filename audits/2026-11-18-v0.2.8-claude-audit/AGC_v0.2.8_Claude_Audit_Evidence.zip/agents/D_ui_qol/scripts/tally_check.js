// Tally screens: the "This turn" summary vs the VP ledger rows of that turn and the Game Score.
const fs = require('fs'); const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
for (const f of process.argv.slice(2)) {
  const run = JSON.parse(fs.readFileSync(f)); const s = E.newGame(run.side, run.seed, run.opts || {}); E.run(s);
  let bad = 0, n = 0, noScore = 0; const ex = [];
  for (const a of run.answers) { const p = s.prompt;
    if (p.kind === 'info' && /^Tally – /.test(p.title)) { n++;
      const rows = s.vpLog.filter(v => v.turn === s.turn); const us = rows.filter(v => v.side === 'US').reduce((t, v) => t + v.n, 0), br = rows.filter(v => v.side === 'BR').reduce((t, v) => t + v.n, 0);
      const m = /This turn: (.*)$/m.exec(p.text); const txt = m ? m[1] : '(none)';
      const mu = /U\.S\. ([+−-]\d+) VP/.exec(txt), mb = /British ([+−-]\d+) VP/.exec(txt), gs = /Game Score ([+−-]?\d+)/.exec(txt);
      const num = x => x ? Number(x.replace('−', '-')) : 0;
      const ok = num(mu && mu[1]) === us && num(mb && mb[1]) === -br;
      if (!gs) noScore++; else if (num(gs[1]) !== s.vp.US - s.vp.BR) { bad++; ex.push('score ' + txt); }
      if (!ok) { bad++; ex.push(`T${s.turn} '${txt}' vs ledger US ${us} BR ${br}`); }
    }
    E.act(s, a); }
  console.log(run.side, run.seed, 'tally screens', n, 'mismatches', bad, 'without Game Score', noScore, ex.slice(0, 3));
}
