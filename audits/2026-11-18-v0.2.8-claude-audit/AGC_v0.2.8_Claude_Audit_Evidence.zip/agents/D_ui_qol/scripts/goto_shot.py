# Replay a recorded run to decision N (0-based) in the page, save the position and screenshot it.
# usage: goto_shot.py RUNTAG N NAME [WIDTH HEIGHT]
import sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__('os').path.dirname(__file__))
from common import *
tag, N, name = sys.argv[1], int(sys.argv[2]), sys.argv[3]; W = int(sys.argv[4]) if len(sys.argv) > 4 else 1300; H = int(sys.argv[5]) if len(sys.argv) > 5 else 900
run = json.loads((OUT / 'runs' / (tag + '.json')).read_text()); errors = []
with sync_playwright() as p:
    b = launch(p); pg = new_page(b, W, H, errors); fresh_setup(pg); start(pg, run['side'], run['seed'], run.get('opts') or {})
    for a in run['answers'][:N]: realize(pg, a, {'clicks': 0, 'notes': []})
    (OUT / 'saves' / f'{name}.json').write_text(pg.evaluate("saveText()"))
    pg.evaluate("document.getElementById('proc').scrollTop = 0; window.scrollTo(0, 0)")
    pg.screenshot(path=str(SHOTS / f'{name}.png'), full_page=(W < 1000))
    print(pg.inner_text('#proc')[:1500])
    b.close()
