// Replay a browser run's answers in the engine and print prompts/log lines in a window (by prompt title regex).
// usage: node inspect_run.js runs/TAG.json REGEX [context=6]
const fs = require('fs'); const run = JSON.parse(fs.readFileSync(process.argv[2]));
const re = new RegExp(process.argv[3]); const ctxN = +(process.argv[4] || 6);
const E = require('/home/claude/a_glorious_chance_solo/tools/bundle_engine.js')();
const s = E.newGame(run.side, run.seed, run.opts || {}); E.run(s);
let i = 0, show = 0;
for (const a of run.answers) {
  const p = s.prompt; const was = s.log.length;
  if (re.test(p.title) || re.test(p.text || '')) show = ctxN;
  E.act(s, a); i++;
  if (show > 0) { show--; console.log(`#${i} T${s.turn} [${p.kind}] ${p.title} -> ${JSON.stringify(a).slice(0, 80)}\n   ${(p.text || '').replace(/\n/g, '\n   ').slice(0, 600)}`); s.log.slice(was).forEach(l => console.log('   LOG ' + l.text.slice(0, 300))); }
}
