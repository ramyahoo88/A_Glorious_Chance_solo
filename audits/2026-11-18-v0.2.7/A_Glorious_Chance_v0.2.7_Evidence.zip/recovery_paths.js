// Generate downstream saves through the old shipped DOM, then reopen with the new shipped DOM.
const {fs,path,assert,repo,out,launch,st,button,loadText,start}=require('./page_helpers');
const currentBuild=JSON.parse(fs.readFileSync(path.join(repo,'package.json'),'utf8')).version;
const previous=fs.readFileSync(path.resolve(process.argv[3],'dist/index.html'),'utf8');
const older=fs.readFileSync(path.resolve(process.argv[4],'dist/index.html'),'utf8');
const fixture=name=>fs.readFileSync(path.join(out,'fixtures',name+'.json'),'utf8');
const view=t=>t.doc.querySelector('#proc');
const note=t=>view(t).querySelector('.err')?.textContent.trim()||'';
const auto=t=>t.w.localStorage.getItem('agc_solo_companion_v1');
const next=t=>button(t,'Continue',view(t));
const output=path.join(out,'positions-found');
fs.mkdirSync(output,{recursive:true});
function close(t){assert.deepEqual(t.errors,[]);t.dom.window.close();}
function save(t,name){
  button(t,'Save');
  const modal=t.doc.querySelector('#modal');
  const value=modal.querySelector('textarea').value;
  button(t,'Close',modal);
  if(name)fs.writeFileSync(path.join(output,name+'.json'),value);
  return value;
}
async function imported(bytes,source){
  const t=await launch(undefined,source);
  start(t,'BR',300149);
  loadText(t,bytes);
  return t;
}
async function restored(bytes){
  const t=await launch(bytes);
  button(t,'Continue it');
  return t;
}
function ship(s,id){
  return {owner:s.ships[id].owner,status:s.encounter?.ships[id]||null,box:s.ships[id].box,losses:s.lossesThisTurn.filter(l=>l.id===id)};
}
function troops(s){
  return {title:s.prompt.title,aiAvailable:s.aiTroops.box.filter(m=>m.revealed&&m.troops).length,queued:s.troopsReturning[s.ai],score:s.vp.US-s.vp.BR,britishSupply:s.supply.BR,rng:s.rng};
}
(async()=>{
  const result={previousRepairs:{},warnings:{},legacyUndo:null};
  for(const [name,file,id] of [
    ['Wolfe','F01_fresh_pending_withdrawal','wolfe'],
    ['Asp','F02_after_Melville_sinks','asp'],
    ['B35','E01_old_B35_at_package_picker',null],
  ]){
    const bytes=fixture(file),broken=await imported(bytes,previous);
    const exact=await imported(bytes);
    const exported=save(broken,`V026_saved_after_wrong_${name}_repair`);
    const replay=await imported(exported), returned=await restored(auto(replay));
    const take=t=>id?ship(st(t),id):troops(st(t));
    result.previousRepairs[name]={fromOriginal:take(exact),v026BeforeExport:take(broken),v026Notice:note(broken),v027AfterImport:take(replay),v027Notice:note(replay),v027AfterReload:take(returned),v027ReloadNotice:note(returned),file:`positions-found/V026_saved_after_wrong_${name}_repair.json`};
    [broken,exact,replay,returned].forEach(close);
  }
  for(const name of ['E01_old_B35_at_package_picker','E02_old_after_Kingston_Tally','L01_old_already_sailed']){
    const t=await imported(fixture(name));
    const initial=note(t);
    const exported=save(t,`V027_saved_after_${name}`);
    const resume=await restored(auto(t)), fileAgain=await imported(exported);
    assert.match(initial,/before the withdrawal/);
    assert.deepEqual(st(t),st(resume));
    assert.deepEqual(st(t),st(fileAgain));
    result.warnings[name]={initial,afterResume:note(resume),afterExportImport:note(fileAgain),state:troops(st(t))};
    [t,resume,fileAgain].forEach(close);
  }
  const old=await imported(fixture('L01_after_v024_withdrawal'),older);
  next(old); // authentic v0.2.4 Undo snapshot, exactly one decision after the old withdrawal
  const legacyAuto=auto(old);
  fs.writeFileSync(path.join(output,'V024_autosave_with_pre_F7_undo.json'),legacyAuto);
  const resumed=await restored(legacyAuto);
  assert.equal(st(resumed).build,currentBuild);
  button(resumed,'↶ Undo');
  const undoSave=JSON.parse(save(resumed,'V027_export_immediately_after_legacy_Undo'));
  assert.equal(st(resumed).troopsReturning.US,1);
  result.legacyUndo={build:undoSave.state.build??null,app:undoSave.state.app,notice:note(resumed),state:troops(st(resumed))};
  [old,resumed].forEach(close);
  fs.writeFileSync(path.join(out,'recovery-results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
  const failures=[];
  const replayed=result.previousRepairs.Wolfe;
  if(process.argv.includes('--require-damaged-notice') && replayed.v027AfterImport.owner==='US' && !/earlier|before|replay/i.test(replayed.v027Notice)) {
    failures.push('A carried-over premature Wolfe capture must be recovered or clearly identified.');
  }
  if(process.argv.includes('--require-warning') && !/before the withdrawal/.test(result.warnings.E01_old_B35_at_package_picker.afterResume)) {
    failures.push('An unresolved B35 warning should survive reload.');
  }
  if(process.argv.includes('--require-provenance') && result.legacyUndo.build!==currentBuild) {
    failures.push('A save written after legacy Undo should carry the build that wrote it.');
  }
  assert.deepEqual(failures,[]);
})().catch(error=>{console.error(error);process.exitCode=1;});
