// Exercise the actual save validator across seeded games without letting the act of testing alter play.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { isDeepStrictEqual } = require('node:util');
const { policy } = require('./campaigns');
const [repo, source, mode, firstArg, countArg] = process.argv.slice(2);
const first = Number(firstArg || 191000), count = Number(countArg || 512);
const E = require(path.resolve(source, 'tools/bundle_engine.js'))();
const { x } = require('./load')(path.resolve(repo));
x(fs.readFileSync(path.resolve(repo, 'src/ui.js'), 'utf8'));
const inspect = x('(st) => { const board = checkSaveState(st); return { board, notes: (UI.loadNotes || []).slice() }; }');
const legacy = mode === 'legacy';
const outcome = { mode, first, count, app: E.newGame('BR', 1).app, games: 0, prompts: 0, loads: 0, pursuits: 0, doublePursuits: 0, reversePursuits: 0, struckAfterPursuit: 0, comparedPrizes: 0, uncertainHistoricalPrizes: 0, eventsWithFirstSettlement: 0, missingDeployPrompts: 0, differences: 0, errors: 0, examples: [] };
const clone = value => JSON.parse(JSON.stringify(value));
const key = id => id === 'U.S.' ? 'US' : 'BR';
const other = side => side === 'US' ? 'BR' : 'US';
const struck = s => Object.keys(s.encounter?.ships || {}).filter(id => s.encounter.ships[id] === 'struck');
const marker = /^Pursuit! The withdrawal is cancelled and a new Encounter begins/;
const gunnery = /^Gunnery Round [12]: (U\.S\.|British) .* vs (U\.S\.|British) /;
const folder = path.resolve(__dirname, 'positions-found');
fs.mkdirSync(folder, { recursive: true });
function proof(s, location, detail) {
  if (outcome.examples.length >= 30) return;
  const file = `scan-${mode}-${first}-${outcome.examples.length + 1}.json`;
  fs.writeFileSync(path.join(folder, file), JSON.stringify({ state: s, undo: [] }));
  outcome.examples.push({ ...location, ...detail, file });
}
function comparable(s) {
  const data = clone(s);
  delete data.build;
  if (data.encounter && !data.encounter.flagIn) {
    const e = data.encounter;
    e.flagIn = {};
    for (const id of Object.keys(e.ships)) {
      const side = e.side[id] || data.ships[id].owner;
      if (data.flagship[side] === id) e.flagIn[side] = true;
    }
  }
  return data;
}
for (let i = 0; i < count; i++) for (const side of ['US', 'BR']) for (const style of ['fleet', 'coast']) {
  const seed = first + i;
  const state = E.newGame(side, seed, { cuttingOut: i % 2 === 0, oa1Upgrades: i % 3 === 0 });
  E.run(state);
  let encounter, history = new Map(), previousPursuit, recentPursuitTurn;
  for (let step = 0; !state.over && step < 1500; step++) {
    const prompt = state.prompt;
    const pending = struck(state);
    const inWindow = recentPursuitTurn === state.turn && pending.length > 0 && (!legacy || encounter === state.encounter && !!previousPursuit);
    const location = { seed, side, style, step, turn: state.turn, title: prompt.title, zone: state.encounter?.zone };
    outcome.prompts++;
    if (inWindow) outcome.struckAfterPursuit++;
    if (inWindow || (!legacy && step % 7 === 0)) {
      outcome.loads++;
      const before = clone(state);
      try {
        const { board, notes } = inspect(clone(before));
        if (!legacy) {
          if (!isDeepStrictEqual(comparable(before), comparable(board)) || notes.length) {
            outcome.differences++;
            proof(before, location, { notes, rawShip: pending.map(id => [id, before.ships[id].owner]), loadedShip: pending.map(id => [id, board.ships[id].owner]) });
          }
        } else {
          for (const id of pending) {
            const expected = history.get(id);
            if (!expected || expected.owner == null) continue;
            outcome.comparedPrizes++;
            const owner = board.ships[id].owner, status = board.encounter.ships[id];
            const capture = board.lossesThisTurn.some(row => row.id === id && row.how === 'captured');
            if (owner !== expected.owner || status !== 'done' || capture !== expected.captured) {
              outcome.differences++;
              proof(before, location, { id, expected, owner, status, capture, notes });
            }
          }
        }
      } catch (error) {
        outcome.errors++;
        proof(before, location, { error: String(error) });
      }
    }
    const length = state.log.length, answer = policy(state, prompt, style);
    assert(!E.validateAnswer(state, prompt, answer), JSON.stringify(location));
    E.act(state, answer);
    if (encounter !== state.encounter) {
      encounter = state.encounter;
      history = new Map();
      previousPursuit = null;
    }
    if (state.log.slice(length).some(line => marker.test(line.text))) {
      outcome.pursuits++;
      recentPursuitTurn = state.turn;
      const ended = state.log.findLastIndex(line => marker.test(line.text));
      const shot = state.log.slice(0, ended).findLast(line => line.turn === state.turn && gunnery.test(line.text));
      assert(shot, JSON.stringify(location));
      const [,attText, defText] = gunnery.exec(shot.text);
      const attacker = key(attText), defender = key(defText);
      if (previousPursuit) {
        outcome.doublePursuits++;
        if (previousPursuit.defender !== defender) outcome.reversePursuits++;
      }
      previousPursuit = { attacker, defender, ended };
      if (!legacy) continue;
      assert(encounter, JSON.stringify(location));
      const participants = Object.keys(encounter.ships);
      const attackerPresent = participants.some(id => encounter.side[id] === attacker && ['in', 'dis'].includes(encounter.ships[id]));
      const noRoll = attackerPresent && !encounter.withdrawn[attacker];
      for (const id of struck(state)) {
        if (history.has(id)) continue;  // retain the first historical end even if another Pursuit follows
        const original = encounter.side[id], captured = original === defender;
        const fate = { original, captured, owner: noRoll ? (captured ? other(original) : original) : null, attacker, defender, endStep: step + 1 };
        history.set(id, fate);
        if (noRoll) outcome.eventsWithFirstSettlement++;
        else {
          outcome.uncertainHistoricalPrizes++;
          proof(state, location, { id, why: 'both sides absent at the first Pursuit boundary', fate });
        }
      }
    }
  }
  assert(state.over, `Did not finish ${seed} ${side} ${style}`);
  outcome.games++;
}
const filename = `sweep-${mode}-${first}.json`;
fs.writeFileSync(path.join(__dirname, filename), JSON.stringify(outcome, null, 2) + '\n');
console.log(JSON.stringify(outcome, null, 2));
