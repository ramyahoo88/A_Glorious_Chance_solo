# A Glorious Chance Solo v0.2.7 re-audit evidence

The reviewed release is `497721cc4bc1d6ba90e80a082adf42841ed83c1b`. The public Pages revision was `983d43ea981a1c3bf9c0043aeb447eee3586ca7b`. All four HTML copies and the independent rebuild were 303,301 bytes with SHA-256 `766c2f02571355310d2592bf3b04be7ca054f5cb6b1add081434e3daa03d6806`. See `audit.md` for rule sections, source lines, and player impact.

## Use the shipped controls

Open the public app at https://ramyahoo88.github.io/A_Glorious_Chance_solo/. Choose **Load game** from setup or **Load** during a game. Select a JSON file or paste all of it into the load dialog. Test with a spare campaign. If the public app has advanced, use the pinned `dist/index.html` from the named Git revision.

| File | What you see in v0.2.7 |
|---|---|
| `fixtures/F01_fresh_before_Wolfe_strikes.json` | From Tactics, click Continue. Wolfe strikes during this new Encounter. Ignore the withdrawal then Undo, or reload and click Continue it. He stays pending and British. |
| `fixtures/F01_fresh_pending_withdrawal.json` | Same position one click later. It opens cleanly. |
| `positions-found/V026_saved_after_wrong_Wolfe_repair.json` | Export made by the v0.2.6 UI after its premature capture. The same choice opens with an American Wolfe and no warning. F1 at June II gives the U.S. 32 VP. |
| `fixtures/F02_just_after_Asp_pursuit.json` and `fixtures/F02_after_Melville_sinks.json` | In both original saves Asp is captured by Britain. The later save leaves Julia pending. |
| `positions-found/V026_saved_after_wrong_Asp_repair.json` | v0.2.6 had already rescued Asp incorrectly. v0.2.7 keeps him American and shows no warning. |
| `fixtures/E01_old_B35_at_package_picker.json` | Old two-Troops picker. First load warns. Refresh and Continue it. The identical unresolved position has no warning. |
| `positions-found/V027_saved_after_E01_old_B35_at_package_picker.json` | The v0.2.7 export from that same initial load. Reimport it to see the missing warning. The two-Troops picker is still active. |
| `fixtures/E01_manual_package_control.json` | Matching pre-withdrawal board. Four Continues use B35 at one Troops. The row is blank and no Kingston force sails. |
| `fixtures/E02_old_after_Kingston_Tally.json` | Original old Tally with score −7 and British supply −1. The initial recovery warning disappears after reload. |
| `fixtures/L01_after_v024_withdrawal.json` and `fixtures/L02_after_v024_pursuit.json` | The original repairs work. One Troops marker waits for F7 and B20 launches nothing. Beresford is captured once by the U.S. |
| `positions-found/Chrome_v027_pending_Growler.json` | Genuine new v0.2.7 save from September I of a British game at seed 191073. Growler is still pending with the U.S. at Transfer the flag?. Stay aboard then Undo, or reload. The position matches exactly. |

To compare Wolfe's June II tallies, start at **Withdrawal result against you**. Select **Ignore – fight on**, Continue twice, Attack, select Sir Sidney Smith and Confirm, Continue, Attack, then Continue twice. The clean state scores 0. The already-modified v0.2.6 export scores +32. Both routes are in `public-browser-results.json`.

To see the continued B35 result after the warning disappears, click **Select all**, clear Asp and Lady of the Lake, then Confirm. Continue to the July I Tally. Two Troops land at Kingston and the score is −7, British supply −1. The pre-withdrawal replay skips that attack and reaches 0, supply 1. A separate later export, `positions-found/V027_saved_after_E02_old_after_Kingston_Tally.json`, opens the already-scored board without the warning.

To examine the missing Undo stamp, use `recovery_paths.js`. It generates `positions-found/V024_autosave_with_pre_F7_undo.json` by loading the authentic L01 file in the v0.2.4 HTML and advancing one decision. Start v0.2.7 with that JSON as the same origin's autosave, click **Continue it**, then Undo and Save without another decision. Use an autosave for this case because the file dialog only restores the active board. `positions-found/V027_export_immediately_after_legacy_Undo.json` is the resulting file. The F7 queue is correct and `build` is absent.

## Reproduce the build and checks

Run from the extracted directory using Git, Python 3.12 or later, and Node. The source references below are the precise releases. The live HTTP comparison needs network access and will report a difference if the public deployment advances.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git project
git -C project checkout --detach 497721cc4bc1d6ba90e80a082adf42841ed83c1b
git -C project worktree add --detach "$PWD/v026" b7eb835
git -C project worktree add --detach "$PWD/v024" f15cdd3
python compare_release.py project
python verify_public.py project
npm --prefix project test

node next_rules.js project --require-rules
node recheck_engine.js project
node boundary_checks.js project
node edges.js project
node followup_rules.js project --require-rules
node new_boundaries.js project
node map_checks.js project
node paper_checks.js project
node export_data.js project
python verify_land_aid.py
```

The Target Card data comparison uses separately obtained VASSAL v1.0 module images, Pillow and NumPy. Run `python verify_component_grids.py /path/to/extracted/images` after the data export. The published documents and components are identified in `source-manifest.json`.

```sh
npm install --prefix audit-node jsdom@26.1.0
export NODE_PATH="$PWD/audit-node/node_modules"
node recheck_dom.js project
node legacy_dom.js project
node verify_legacy_rake.js project --require-rules
node recovery_paths.js project v026 v024
node recovery_paths.js project v026 v024 --require-damaged-notice --require-warning --require-provenance
```

The last command reports the three confirmed recovery issues and exits 1 on the audited release. The preceding command records the same behavior without enforcing the fixes. The Chrome results independently cover the first two recovery issues, the original F01–F04 witnesses and two older controls.

```sh
node scan_saves.js project project fresh 191000 512
node scan_saves.js project v026 previous 191000 512
node scan_saves.js project v024 legacy 191000 512
node scan_saves.js project v024 legacy 300000 3072
node compare_play.js project v026 520000 128
node campaign_controls.js project BR 191073 fleet
```

The current and previous scans compare the board after validation, treating the version stamp and the existing `flagIn` normalization as metadata. The v0.2.4 scans compute the expected prize from the attacker and defender at the first actual Pursuit boundary and inspect later pending snapshots. They do not use the patched loader to derive that expectation. The paired uninterrupted play check compares all prompts and finished states after removing version metadata.

`controls-191073.json` is a full Chrome replay checklist. Type the seed, tab out of the field, and start the British campaign with defaults. The signed ledger, three odds comparisons, save and reload observations, and the prior witnesses are in `public-browser-results.json`. The genuine browser download is `positions-found/Chrome_v027_game_over_191073.json`.
