// Rule-level controls for the release changes. Enter normal procedures where the selected state permits.
const fs=require('node:fs'), path=require('node:path'), assert=require('node:assert/strict');
const {x,ctx}=require('./load')(path.resolve(process.argv[2]));
x(fs.readFileSync(path.join(__dirname,'positions.js'),'utf8'));
const checks=[];
ctx.same=(id,expected,actual)=>{
  const a=JSON.parse(JSON.stringify(actual));
  const e=JSON.parse(JSON.stringify(expected));
  assert.deepEqual(a,e,id);
  checks.push({id,expected:e,actual:a});
};
x(`
for(const human of ['US','BR']){
 const s=fresh(human,185301);
 s.aiTroops.box=[];s.aiTroops.track=[];
 s.troops.BR.available=0;s.troops.BR.track=[];
 const fromEarlier=1;
 s.troopsReturning.BR=fromEarlier;
 const fr=newForce(s,'BR','NIA','ArmySupport',['wolfe','rg'],{troops:2});
 abortCoastalMission(s,fr);
 abortCoastalMission(s,fr);
 const count=q=>human==='US'?aiTroopsInBox(q):q.troops.BR.available;
 same('W01: two unlaunched markers added once ('+human+' player)',[0,3,0,true],[count(s),s.troopsReturning.BR,fr.troops,fr.aborted]);
 waitAt(s,'tally','reset');act(s,'ok');
 same('W01: all three return exactly once at F7 ('+human+' player)',[3,0],[count(s),s.troopsReturning.BR]);
}
{
 const s=pursuitBoard('dis');
 addShipToForce(s,'beres',s.encounter.aiForce);encAdd(s,'beres','struck');s.ships.beres.steps=0;
 addShipToForce(s,'tompkins',s.encounter.humanForce);encAdd(s,'tompkins','struck');s.ships.tompkins.steps=0;
 const zoneEvent=s.zones.NOR.event;
 act(s,'ok');
 const rng=s.rng, eventDeck=JSON.stringify(s.deck.event);
 act(s,'ok');
 same('W02: defender captured, attacker rescued before drawing the next Event',[ 'US','US','transit','transit','done','done',1,0 ],
   [s.ships.beres.owner,s.ships.tompkins.owner,s.ships.beres.box,s.ships.tompkins.box,s.encounter.ships.beres,s.encounter.ships.tompkins,
   s.lossesThisTurn.filter(o=>o.id==='beres').length,s.lossesThisTurn.filter(o=>o.id==='tompkins').length]);
 same('W02: one-sided fates spend no dice, no Event card drawn early',[rng,eventDeck,zoneEvent],[s.rng,JSON.stringify(s.deck.event),s.zones.NOR.event]);
 act(s,'ok');
 same('W02: different Weather Gage card and same zone Event',[9,zoneEvent],[s.prompt.eventCard,s.zones.NOR.event]);
}
for(const rng of [1,12,15,17]){
 const s=pursuitBoard('dis');
 addShipToForce(s,'beres',s.encounter.aiForce);encAdd(s,'beres','struck');s.ships.beres.steps=0;
 s.encounter.withdrawn.US=true;s.rng=rng;
 const mirror=JSON.parse(JSON.stringify(s)),r=d6(mirror);
 const lines=[];settleStruck(s,lines,'BR');
 same('W02 note 68 synthetic double withdrawal, raw RNG '+rng,
   [r<=3?'US':'BR',mirror.rng,true],[s.ships.beres.owner,s.rng,lines[0].endsWith('1d6 '+r)]);
}
`);
fs.writeFileSync(path.join(__dirname,'new-boundary-results.json'),JSON.stringify(checks,null,2)+'\n');
console.log(checks.length+' boundary comparisons pass.');
