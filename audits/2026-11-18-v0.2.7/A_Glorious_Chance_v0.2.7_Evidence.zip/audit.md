# A Glorious Chance Solo
## v0.2.7 release and save recovery re-audit
18 November 2026 · Release commit 497721c

**Pass for new campaigns. Hold sign-off on recovery of affected older games.** The four v0.2.6 audit positions behave as specified on first open in v0.2.7. An already-applied v0.2.6 error can still carry forward without a warning. A warning shown on first open can disappear while the game still needs an earlier save.

| Priority | Finding | Observed result |
|---|---|---|
| High · N01 | Saves already changed by v0.2.6 can carry the wrong result forward. | The same Wolfe game recovered from a clean save scores 0 at June II. A save produced after the old repair silently awards the Americans 32 VP. |
| Medium · N02 | The earlier-save notice is lost when an unresolved game is reopened. | The B35 picker and the already-scored Kingston attack keep their old state. The notice disappears on reload and on reopening a new export. |
| Low · N03 | An old Undo snapshot can be exported without a build stamp. | The F7 repair works. A save downloaded immediately after restoring that old snapshot still omits `build`. |
| Optional usability · O01 | Zero-defense odds use two display conventions. | The lineup shows ∞:1 and the applied round shows 99:1. Both select the correct 3:1+ column. |

### Release verification
GitHub main and release/v0.2.7 were at 497721cc4bc1d6ba90e80a082adf42841ed83c1b. The Pages branch was 983d43ea981a1c3bf9c0043aeb447eee3586ca7b. The separate rebuild, pinned GitHub release, Pages branch and public HTTP response are byte-identical at **303,301 bytes**. The public Chrome tab showed v0.2.7 after refresh. [Reviewed release](https://github.com/ramyahoo88/A_Glorious_Chance_solo/commit/497721cc4bc1d6ba90e80a082adf42841ed83c1b) · [Public app](https://ramyahoo88.github.io/A_Glorious_Chance_solo/)

`766c2f02571355310d2592bf3b04be7ca054f5cb6b1add081434e3daa03d6806`

The audit used the shipped files, the committed changelog and rules notes. The standalone response attachment named in the handoff was unavailable. The evidence archive includes importable positions, browser observations and the commands used for the build and save comparisons.

<!-- page -->
## N01 · A previous repair can silently carry the wrong prize forward
**The affected player can lose Wolfe and concede 32 VP after upgrading.** LC5.3 settles a ship at the end of its own Encounter. Pursuit card A05 starts a new Encounter, and project note 68 settles only the earlier Encounter's ships at that boundary. F1 scores confirmed captures. [Project ruling](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/497721cc4bc1d6ba90e80a082adf42841ed83c1b/RULES_NOTES.md#L95) · [Published rules and support](https://www.legionwargames.com/legion_AGC_GS.html)

### Repeat in the public app
Use `fixtures/F01_fresh_pending_withdrawal.json`. This is British seed 191347, June II, Niagara, when Wolfe's fresh Strike Check is 2 + 1. To recreate the carried-over save, open it in the pinned v0.2.6 HTML and use **Save** immediately after its erroneous recovery notice. The bundled `positions-found/V026_saved_after_wrong_Wolfe_repair.json` is that export, generated under jsdom with the shipped controls. In Chrome I reached the original withdrawal by loading `fixtures/F01_fresh_before_Wolfe_strikes.json` and clicking Continue. I then loaded the carried-over export for the second route.

| v0.2.7 import | At Withdrawal result against you | Same decisions through Tally |
|---|---|---|
| Original v0.2.6 pending save | Wolfe is British and still Struck. There is no prize entry. | Wolfe returns to Britain on d6 4. Game score 0. |
| v0.2.6 export made after its repair | Wolfe is already American and in transit with one recorded capture. No recovery notice appears. | F1 scores +32 U.S. VP for Wolfe. Game score +32. |

Choose **Ignore – fight on**, Continue twice, Attack, select Sir Sidney Smith for the Reaction Check and Confirm, Continue, Attack, then Continue twice. Both replays use those choices. The evidence also includes Asp's late v0.2.4 position after being opened and exported by v0.2.6. That export opens silently in v0.2.7 with Asp rescued for the U.S. and the British 4-VP capture absent. The direct original opens with Asp captured by Britain.

### Smallest fix
Flag an already-applied repair when the saved combat frame and chronology prove a contradiction. In the Wolfe case the current withdrawal still holds his pending Strike Check, yet the saved Encounter says `done` and there is already a capture credit. Show the earlier-save recovery message and identify the ship. The loader currently examines only ships still marked `struck`, so it skips both damaged examples. Persist the warning for later reopen. Keep later played or scored states intact when a correct rollback cannot be reconstructed. `src/engine_combat.js:609` · `src/engine_combat.js:611` · `src/engine_tally.js:11` · `src/ui.js:116`

<!-- page -->
## N02 · The earlier-save warning disappears while the position is still unresolved
**A player resuming an autosave can unknowingly keep an invalid Kingston attack.** The v0.2.7 repair policy in project note 72 tells the player to reopen a save before withdrawal once the A.I. has counted the early marker. Under LC5 and F7 (British Living Rules pp. 33–34 and 20), an unlaunched marker returns at Reset. Rule 11.1.2 and the errata use currently Available Troops for the Target Card row. [Project note 72](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/497721cc4bc1d6ba90e80a082adf42841ed83c1b/RULES_NOTES.md#L106) · [Publisher errata](https://www.legionwargames.com/docs/AGC_errata_and_clarifications_rev_13Apr2024.pdf)

### Repeat in Chrome with the B35 picker
1. Load `fixtures/E01_old_B35_at_package_picker.json`. This is the focused British seed 185301, July I, Kingston, Naval Balance ≤−70. The notice correctly asks for an earlier save. The board keeps 2 Available, 0 due at F7 and the displayed 2-Troops Force Package #7. The printed B35 card is blank with 1 Available at this balance.
2. Refresh and click **Continue it** without making a decision first. The board, dice and old picker are preserved exactly. The notice is gone. The same occurs if the initial load is immediately exported and imported again.
3. In the reopened picker click **Select all**, clear Asp and Lady of the Lake, then Confirm and Continue to Tally. The A.I. lands 2 Troops at Kingston. Land Battle rolls 45 at 17 Long Gun and succeeds. Tally is −7 with British Convoy Supply −1. In `fixtures/E01_manual_package_control.json`, four Continues use the printed 1-Troops blank. The Tally is 0 and British supply is 1.

`fixtures/E02_old_after_Kingston_Tally.json` has the same problem after scoring. The original import warns and preserves −7 and British supply −1. Reopen it through the autosave and the warning disappears with both values intact. The still earlier, already-sailed case behaves the same way through Save and reimport under jsdom. Successful repairs such as L01 rightly need no repeated warning.

### Smallest fix
Save a small unresolved-recovery record with the board, and show its instructions on every reopen until the player replaces the position or acknowledges them. The blocked case currently sets the same migration bit used for a completed repair, then emits a UI-only message. The loader stamps and autosaves the still-unresolved position. `src/engine_combat.js:576` · `src/engine_combat.js:586` · `src/engine_combat.js:595` · `src/ui.js:117` · `src/ui.js:126` · `src/ui.js:133`

<!-- page -->
## N03 · Legacy Undo can omit save provenance
**A file written by v0.2.7 can still appear unversioned to the migration code.** A build stamp is meant to say which procedure wrote the current state. The tested Undo applies the correct F7 queue and does not itself change the score. This is a save metadata defect under project note 72 and the v0.2.7 changelog. [Changelog](https://github.com/ramyahoo88/A_Glorious_Chance_solo/blob/497721cc4bc1d6ba90e80a082adf42841ed83c1b/CHANGELOG.md#L3)

The evidence contains `positions-found/V024_autosave_with_pre_F7_undo.json`, produced by advancing the genuine older L01 save once in the shipped v0.2.4 UI under jsdom. Restore it as a browser autosave, click **Continue it** in v0.2.7, then **Undo** and **Save** immediately. The queue contains one marker and the log reports the repair. The export in `positions-found/V027_export_immediately_after_legacy_Undo.json` still has `app` 0.2.4 and no `build`. The active position initially had `build` 0.2.7. `recovery_paths.js` runs the complete reproduction with real app handlers.

Apply the same version stamping to a successfully restored Undo state as to a successful import. Undo calls the migration directly. Ordinary import and subsequent play stamp the saved board on separate code paths. `src/ui.js:49` · `src/ui.js:56` · `src/ui.js:117` · `src/engine_core.js:41`

### O01 · Optional usability improvement
Use the same printed odds in the preview and result when Defense is zero. In the fresh British campaign at seed 191073, September II in Sacket's, the lineup for Royal George (B) against Lady of the Lake and Asp shows 9 vs 0 and ∞:1. The first Gunnery Round reports 99:1 and uses the same 3:1+ column. Preserve the selection logic and display ∞ in the round text. The two September I comparisons (23.5 vs 1.5 and 19.5 vs 1) matched both the preview and applied round. `src/engine_combat.js:264` · `src/engine_combat.js:303` · `src/ui.js:347`

### Original v0.2.6 findings retested
**F01.** The original Wolfe position preserves his pending British surrender through file or paste, Undo and autosave refresh. Both continuations reach score 0. A whole new v0.2.7 campaign also preserved the exact Growler flag-transfer prompt, ship and dice through Undo and refresh.

**F02.** Both original Asp saves record one British capture, even after Lord Melville sinks. Julia's newer surrender remains pending. The earlier Beresford case still gives a single American capture.

**F03 and F04.** The original B35 picker and Kingston tally each give the intended warning at first open and preserve the position. The earlier repairable L01 queues one marker, bypasses the extra B20 deployment, and reaches score 0 with British supply 1. N02 covers reopening the unresolved position.

<!-- page -->
## Coverage and release verdict
I played the shipped public app through 148 actual Chrome prompts in a new British game at seed 191073. This included 109 informational confirmations. The 26 signed ledger rows sum to **U.S. 57, Britain 31, game score +26, U.S. Victory**. A finished browser download and autosave recovery matched the exact state. Desktop Chrome was used for the live controls. Mobile hardware and offline shortcut launch were outside this browser check.

| Save cohort | Campaigns | Validator checks | Unexpected results |
|---|---|---|---|
| Stamped v0.2.7, seeds 191000–191511 | 2,048 | 42,709 | 0 |
| Clean v0.2.6, same seeds | 2,048 | 42,709 | 0 |
| v0.2.4, same seeds | 2,048 | 1,224 prompts, 1,713 prize comparisons | 0 |
| v0.2.4, seeds 300000–303071 | 12,288 | 7,130 prompts, 9,816 prize comparisons | 0 |

The cohorts used both player sides and two visible-information policies (fleet concentration and coastal missions). The fresh cohorts sampled every seventh action and all pending-strike prompts following Pursuit that turn. The older cohorts determined expected prizes at the first historical boundary and checked later saves against it. They include original, unmodified v0.2.4 saves. N01 concerns saves that already absorbed the v0.2.6 repair. The counts describe these scripted samples.

All **218 repository assertions** and **200 smoke campaigns** passed. The older save imports (v0.2.0–v0.2.3), original damaged-save refusal, Intelligence and Rake checks passed. Another **512 paired uninterrupted campaigns** matched v0.2.6 at all 72,844 prompts and in the final boards and ledgers, omitting version metadata. That sample included 108 draws. Focused checks cover exhaustion, return once at F7, interrupted combat, tied supply milestones and blockade endings.

### Published components
I checked the British Living Rules (7 August 2024), U.S. Living Rules (13 April 2024 PDF), Living Playbook (6 August 2024), and 13 April 2024 errata. I reviewed the F7 and LC5.3 page layouts, A05 Pursuit face and printed B35 rows. The comparisons covered 104 Target cards and all 2,912 matrix cells, 648 Hit Distribution cases across 18 columns, 70 Lake Combat cells, 60 Convoy Scatter cells and all 538 printed Land Battle outcomes across 15 columns. See the evidence manifest for versions and hashes. [Publisher downloads](https://www.legionwargames.com/legion_AGC_GS.html)

**Unresolved ruling.** Aid VII leaves 62 and 63 unassigned at zero Long Gun and three Troops. The app treats both as Attacker Success. The reviewed errata does not assign those outcomes.

**Pass fresh play. Hold legacy recovery sign-off.** Prioritize a visible warning for recognizable v0.2.6 damage and keep unresolved recovery notices through autosave and export. Then stamp states restored with legacy Undo. The original four fixes pass at their stated boundaries and the public release is byte-identical to the independent build.
