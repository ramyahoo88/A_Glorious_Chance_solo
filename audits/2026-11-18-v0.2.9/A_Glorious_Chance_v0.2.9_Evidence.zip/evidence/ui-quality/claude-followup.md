# Independent follow-up of Claude's UI findings

Baseline v0.2.8 (`ffd7317`), current v0.2.9 working source. No earlier-save
migration cases were needed. The supplied saves are current-play positions used
to reproduce the controls, not evidence of save-conversion defects.

## L10 — Next prompt remains above the phone viewport (confirmed, low)

Impact: after confirming a long assignment, the player can see the next Continue
button without the title or instructions that explain it. Expected behavior is
to reveal the new prompt if its title is outside the visible area and preserve
the viewport when the title is already visible.

Reproduction: U.S. seed 280004, default settings, June I convoy, proceed to A7.
Assign Forces, scroll down to Confirm assignments on a 390 px viewport and
confirm. Claude's recorded title position changes to A10 but remains at -236 px,
with the next button at -4 px. I inspected the original before/after screenshot
and source. The cause is baseline `src/ui.js:47`, which resets only the inner
panel's `scrollTop`; on narrow layouts the document is the scrolling element.

Small fix implemented: `revealPromptStart()` at current `src/ui.js:49` retains the
inner-panel reset and calls `scrollIntoView` only if the title is above the clear
viewport, below it, or hidden by a sticky header. Five deterministic geometry
controls cover all three hidden cases and two already-visible cases. These
geometry stubs test the condition and call, not browser layout. Real viewport
confirmation belongs to the main browser audit.

## L13 — Displayed Troops value differs from the held value (confirmed, low)

Impact: a Force with zero Troops shows 1 while the accompanying error correctly
refuses confirmation. Expected behavior is to display the actual entered value.

Reproduction: load `D7_US280004_A7_with_3_Troops.json`, add a Force, select Army
Support and Madison/Oneida, enter 0 Troops and leave the field. Baseline displays
1 but holds 0. The same result reproduces from a fresh game using Adjust to
provide three Available Troops before A7. Entering 1 then permits confirmation.

Cause: baseline `src/ui.js:442`, `value: f.troops || 1`. Small fix implemented at
the corresponding `renderAssign()` input (current line 469): use `f.troops`
directly. Zero stays zero and remains illegal for an Army Support assignment.
This changes no rules or stored board position before confirmation.

## L14 — Manual Auto-fill selects excess ships and is not reproducible (confirmed, low)

Impact: the opt-in manual Package helper can propose more A.I. ships than its
own “fewest ships” instruction permits. Repeated clicks on an unchanged save
produce different picks using `Math.random`, unlike the seeded game.

Expected: apply 5.3.1 and the documented project interpretation in Rules Note 35:
use Main Ships first, then the fewest Secondary Ships required. Merely examining
or editing a proposed selection must not advance dice or mutate the game.

Small independent example: full-strength Madison (2 Long Gun) and Oneida (1) are
the Main Ships; Hamilton (1), Ontario (1) and Growler (2) are available
Secondaries. Set the helper to at least 5 Long Gun. Expected is three ships,
Madison + Oneida + Growler. For a controlled equal-rank `Math.random` ordering,
baseline picks Madison + Oneida + Hamilton + Ontario, four ships.

The supplied `PK_manual_package_prompt.json` (British seed 280001, Package #4)
was also reproduced with a recorded deterministic sequence standing in for
`Math.random`. Baseline selected eight ships, 17 Long Gun. Candidate selects
seven, 16 Long Gun. The controlled sequence, names and totals are in
`claude-fixture-results.json`; this is a counterexample, not an estimated rate.

Cause: baseline `src/ui.js:374–388`, a separate greedy algorithm with unseeded
random order for Secondaries. Small fix implemented in `pkgAutoFill()` (current
line 407): use the existing minimum-subset/Main-first selector with a copied RNG
cursor. Tie choice repeats for an unchanged position; no game RNG is consumed.
The helper text states this. Exhausted/impossible pools, Main-only requirements
and exact-number mode have nearby controls. Actual Auto-fill button checks prove
game JSON, RNG, Undo and autosave remain unchanged.

## L16 — Dialog controls run together (optional usability improvement)

I inspected the original desktop Settings and Adjust screenshots. Inline labels
made adjacent checkboxes and Set buttons appear to belong to neighboring fields.
The agreed small change is `#modal label { display: block; margin: 8px 0; }` at
`src/style.css:157`. Settings choices and numeric adjustments now occupy their
own rows. Computed-style tests cover both dialogs. No rules or game state change.
Final desktop/phone visual acceptance is part of the main browser check.

## L7 — Rainy Squalls lineup describes a Gunnery Round that is skipped (confirmed, low)

The campaign-validation lane owns Command Decision text and the shared pure
`rainySquallsActive()` / `closeActionPreviewText()` helpers. This lane implemented
the lineup renderer using those helpers. Under Rainy Squalls in the Patrol
Segment, it states that play goes directly to Close Action and lists strengths
and eligible single-ship matchups. It uses the selected ships and their column /
tow order, omits Missed Signal's absent ship, and shows no irrelevant Gunnery
odds or untowed-Gunnery DRM warning. Reaction retains the Gunnery preview.

Baseline source is `src/ui.js:356–364`, updated in `renderLineup()` around current
line 376. Independent test: Wolfe's 8 Close Action against Oneida's 3 qualifies
for a matchup, displayed instead of the baseline 9 versus 5.5 Gunnery preview.
Repeated render preserves game JSON, RNG and Undo. The same state switched to a
Reaction Segment retains Gunnery odds. The engine lane tests the actual applied
matchups and original supplied Rainy fixtures.

## Verification

`tests/browser/ui_followup_v029.js` has 21 checks. All pass on the isolated source
candidate; baseline v0.2.8 passes 11. `ui_v029.js`'s existing 21 keyboard/modal/log
checks also still pass on that candidate. No script or console errors occurred.
Use the final root-built HTML for final acceptance:

```
NODE_PATH=/workspace/scratch/9f4da9405771/audit/dom-runtime/node_modules \
  node tests/browser/ui_followup_v029.js /path/to/release --require-fixed
```

Results are `claude-baseline.json`, `claude-candidate.json` and
`claude-fixture-results.json`. The standalone test is copied beside this report.
Geometry tests are explicitly mocked; source/DOM checks do not certify phone
hardware, native keyboard activation, screen readers or general accessibility.
Touch-accessible ship details and wider Adjust functionality remain optional,
unimplemented suggestions.
