# Current-play UI audit and changes

Baseline app v0.2.8, `ffd7317bf3c41b45d8ad8443073d1e5c47d17c34`.
All tests described here ran in jsdom against the delivered HTML or a separate
candidate bundle made from the updated source. Native browser key activation,
touch target geometry, screen-reader output and phone hardware are separate
checks owned by the main audit. No legacy-save migration issue was pursued.

## U01 — Keyboard shortcuts advance play behind dialogs (medium, confirmed)

**Player impact.** Trying to activate Save, Reference or a modal button with
Enter/Space can advance the campaign, roll dice and overwrite the autosave without
showing the changed prompt. Ctrl+Z can undo play while a modal covers it.

**Expected behavior.** Native buttons activate their own actions. Reading or
closing a dialog leaves the game, RNG and history unchanged. A page-level shortcut
is appropriate only outside an interactive control and a modal.

**Smallest useful setup and reproduction.** Start the U.S. campaign with seed
190901 and default options. Choose June I for the convoy. Confirm In Ordinary
without selecting a ship, then Confirm assignments with no Forces. The pending
information prompt is A10 Target Cards drawn. Open Save, focus Close and press
Enter. Alternatively focus the header Save button and press Enter/Space at A10.

**Observed v0.2.8.** The prompt advances to C Enemy Operations, a new Undo entry is
added and autosave changes. With the modal route it remains open. The global
handler prevents the normal button activation. Holding a page-level key can skip
successive information prompts as repeat events arrive.

**Source and smallest fix.** `src/main.js:3–7` in the baseline. Guard active
modals, editing controls and repeated events; let native interactive controls
handle Enter/Space. Keep game Ctrl+Z available on buttons outside modals and
native text Undo inside editors. Implemented in `src/main.js:3–13`, supported by
`modalKeydown()` in `src/ui.js`.

**Evidence.** `ui_v029.js`, `baseline.json`, `candidate.json`, and
`keyboard_A10_seed190901.json`. Nearby control verifies Enter on the document
still continues information prompts, and Ctrl+Z after closing Reference restores
the previous decision.

## U02 — Ship and Tactic choices have no keyboard controls (medium, confirmed)

**Player impact.** A keyboard-only player cannot select ships at A7 or choose a
Tactic during combat. These are essential decisions.

**Expected behavior.** Each selectable choice must be focusable and activatable
using native keyboard controls; selected and unavailable ships must be announced.

**Reproduction.** In the same seeded campaign stop at A7, add a Force and use Tab
to reach its ship choices. None are focusable. A Tactic prompt similarly renders
only clickable `div` elements, with no key handler or tab stop. The compact test
uses a rendering-only Tactic prompt to avoid requiring an unrelated whole combat.

**Observed v0.2.8.** Ship choices are `SPAN`, Tactic choices are `DIV`, both
click-only. Selecting a ship destroys/recreates its element and loses focus.

**Source and smallest fix.** Baseline `src/ui.js:292`, `452–453`. Use native
`button` elements with the same styles, `aria-pressed` on ship selection,
`disabled` for a ship assigned elsewhere, and restore focus to the recreated ship
button. Implemented at the matching renderers. Native buttons provide Enter and
Space activation without a bespoke keyboard implementation.

## Quality-of-life improvements implemented

These are presentation improvements, not game-rule findings.

- Dialogs now have a name, dialog role, initial focus, inert background controls,
  Tab/Shift+Tab containment and Escape close. Closing restores the opening
  control's focus when that control remains in the document. Visible focus
  outlines help keyboard use. Baseline modal renderer was `src/ui.js:689–695`.
- The running version is visible beside the header title, reducing the need to
  open Settings when checking a public-site update. The value comes from the
  same `APP_VERSION` used by the game.
- The Log reports how many matching entries are shown, has readable filter names
  and an accessible filter label, and offers Show full log / Show recent 400.
  Default rendering remains capped for speed. Baseline `src/ui.js:575–580`
  silently hid entries older than the most recent 400. The already completed
  U.S. seed 181118 fixture has 407 entries, so its seven oldest records could not be
  read in the app. The regression uses 405 synthetic rows to check both view
  states and a 202-row filter, and proves these controls leave game, RNG, Undo and
  the original log array unchanged.

## Validation and scope

The 21 focused checks pass on the isolated updated bundle. The baseline passes 4,
including the neighboring page-Enter and game-Undo behavior retained in the fix.
No script or console errors were observed during these checks.
The test does not treat jsdom dispatch as proof of browser-native button clicks.
Run again against the final independently rebuilt release:

```
NODE_PATH=/workspace/scratch/9f4da9405771/audit/dom-runtime/node_modules \
  node tests/browser/ui_v029.js /path/to/release --require-fixed
```

The review also checked a suspected Target Card highlight drift during Army
Support embarkation. That is not a finding. The authoritative row counts both
Available and embarked Troops, and the implementation does too, so ordinary
embarkation preserves the row.

Additional unimplemented ideas are touch-accessible ship-detail panels (currently
full details are in a hover title), better focus retention for other rerendered
checkbox/select lists, and a downloadable plain-text campaign log. These need
their own design/usability check. They are not release blockers or claims of
tested user benefit. This is not a full WCAG or physical tabletop certification.
