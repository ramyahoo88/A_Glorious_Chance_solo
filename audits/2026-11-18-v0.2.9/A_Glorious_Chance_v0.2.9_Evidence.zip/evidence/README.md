# A Glorious Chance v0.2.9 — audit evidence

Audit date: 18 November 2026 (America/Chicago). This evidence supports the accompanying comprehensive report, F01–F28. All confirmed groups were fixed. The user explicitly excluded historical-save recovery from this review; it remains unchanged.

## Versions and final results

- Baseline: `ffd7317bf3c41b45d8ad8443073d1e5c47d17c34`, v0.2.8.
- Corrected code: `6dc43ca1dc9fd195dcffed67155767514bc11582`, v0.2.9.
- Pages publication: `6a8ac8c553577a724e97b4f17103a64e5e221777`.
- Final HTML: 324,911 bytes, SHA-256 `ffa43b5dd90a5540c2757cb6701d8742e8a1eff8beba51a6ec27d4b1f7c815c4`.
- Independent rebuild: byte-identical; `cmp` exit 0. Public HTTP body: same bytes/hash.
- Final engine source sweep hash: `b17b58f81f48d80bed3228df3daabd910a5f9f74d71ec2b8eabe73969dbe0e47`.
- 423 repository engine assertions + 200 smoke games, 101 DOM checks, 768 campaign executions, 128 current-save campaigns, seven prior independent scripts.
- Two complete real Chrome campaigns: U.S. 610100/coast, score −41; British 610101/fleet, +49. Both final **entire game states** exactly equal their independent DOM-control replays, including dice/decks/logs. See `browser-vs-replay.json`.
- `browser-results.json`: 23 direct live control checks. Narrow viewport was Chrome 400% zoom, 340 CSS pixels; not physical Android hardware.

## Rebuild and run the repository tests

Use a disposable checkout. Do not run a build over a user's in-progress source changes.

```sh
git clone https://github.com/ramyahoo88/A_Glorious_Chance_solo.git agc-audit
git -C agc-audit checkout --detach 6dc43ca1dc9fd195dcffed67155767514bc11582
python /path/to/evidence/compare_release.py /path/to/agc-audit
cd /path/to/agc-audit
npm test
```

For actual DOM handlers in the shipped single-file HTML, install jsdom in a disposable tool directory; it is not required by the app:

```sh
npm install --prefix /tmp/agc-audit-tools --no-audit --no-fund jsdom@26.1.0
NODE_PATH=/tmp/agc-audit-tools/node_modules npm run test:ui
```

Node v24.22.3 and Python 3.12.14 were used. `release-tests/` mirrors the tests at the pinned code commit, including fixtures, for inspection; run the repository scripts from the checkout. Existing historical regression tests also remain in npm test, but historical recovery was not newly audited.

## Repeat independent campaign, persistence and boundary checks

Run from this evidence directory; outputs overwrite the corresponding local result JSON/logs. Preserve the delivered originals if comparing a later version.

```sh
node campaign-validation/sweep.js /path/to/agc-audit 610000 64 final-matched
node campaign-validation/sweep.js /path/to/agc-audit 610064 64 final-fresh
NODE_PATH=/tmp/agc-audit-tools/node_modules node current-saves/roundtrip_current.js /path/to/agc-audit 32
node next_rules.js /path/to/agc-audit
node followup_rules.js /path/to/agc-audit
node boundary_checks.js /path/to/agc-audit
node new_boundaries.js /path/to/agc-audit
node recheck_engine.js /path/to/agc-audit
node edges.js /path/to/agc-audit
node map_checks.js /path/to/agc-audit
```

Each campaign seed runs both sides and three deterministic policies. Manual options vary by seed. The sweep independently checks Troops conservation, steps, linked Force membership, tracks, ledger/victory thresholds, legal executable decisions, restoration and first-round arithmetic. It does not prove every rule or competitive balance. The current-save sweep normalizes only an empty `encounter.flagIn={}` insertion (495 occurrences); all other state and next dice matched.

For the exact control trace used by the real Chrome games:

```sh
NODE_PATH=/tmp/agc-audit-tools/node_modules node campaign_controls.js /path/to/agc-audit US 610100 coast
NODE_PATH=/tmp/agc-audit-tools/node_modules node campaign_controls.js /path/to/agc-audit BR 610101 fleet
```

This script runs jsdom, not Chrome. `controls-610100.json` and `controls-610101.json` enumerate the visible setup options, prompt titles and UI actions independently followed in real Chrome. Number inputs in the live browser were typed as digits and blurred; the final values were checked before confirming. The live exported finals, not intermediate harness attempts, are supplied as `Chrome_US610100_final.json` and `Chrome_BR610101_final.json`.

## Reproduce individual findings

`findings.json` is the report's structured source: impact, rule, setup/steps, expected, baseline result, baseline source line, implemented fix and adjacent regression controls. Read the report for severity and interpretations. Named source lines refer to **v0.2.8**, not changed line numbers in v0.2.9.

Open the baseline build and use Load to import the named fixture. Then follow the finding's exact steps. Use the corrected build to compare, or run the named final regression script with a baseline checkout argument to see the defect assertion fail. Fixtures are focused board states unless explicitly identified as naturally reached positions. Their seed identifies the original setup but may not reproduce edited boundary fields without the supplied file.

Important fixture details:

- F06's saved A10 prompt already contains the erroneous count. Read immediately after import; Continue moves past it. Regenerate the step with the regression to verify new wording.
- F12/F13/F14 fixtures reside in `combat-coastal/claude-followup/`.
- F16 starts with an information prompt; Continue first, then choose Possible Encounter recipients.
- F23/F24 fixtures named `tests/browser/fixtures/...` are in the pinned repo and mirrored under `release-tests/browser/fixtures/` here.
- F05 uses `AI_preview_before_command_BR_612056_fleet.json`, so the build regenerates the preview. An already-written prompt is not automatically rewritten on load.
- Malformed-save rejection and storage-write failure tests intentionally simulate corruption/denial. They are not naturally generated board positions; real Chrome did not simulate an unavailable storage device.

## Printed-source checks

The exact editions/hashes are in `source-manifest.json`. Full copyrighted PDFs and VASSAL artwork are not redistributed. Obtain them from the publisher or supplied originals. The visual inspections are recorded in the report and lane notes.

```sh
node export_data.js /path/to/agc-audit
python verify_component_grids.py /path/to/vmod/images
python verify_land_aid.py
node paper_checks.js /path/to/agc-audit
node combat-coastal/tactic_fields.js /path/to/agc-audit
```

The image-grid script needs Pillow and numpy. Visually review `weak_grid_cells.png` rather than accepting the 179 low-confidence classifications blindly. Land Aid VII's zero-LG/three-Troops rolls 62–63 are unassigned in the photo; the app retains Attacker Success as a documented interpretation. All other 538 cells match. Aid V package8 selection/lookahead remains an open ruling.

## Evidence conventions and attribution

Baseline and development-candidate outputs explain discovery and are not additional final test runs. The verdict uses `final-repo-tests.log`, `final-dom-tests.log`, `campaign-validation/final-matched.*`, `campaign-validation/final-fresh.*`, `current-saves/final-roundtrip.log`, `literal-build-results.json`, `public-release.json` and final Chrome files. Intermediate campaign `fixed`/`fixed-final` files were omitted from the ZIP to reduce confusion.

Claude's independent v0.2.8 audit was added to GitHub during this review at fc0aed0. Its focused fixtures were independently checked before acceptance. Its original report/evidence remain in `audits/2026-11-18-v0.2.8-claude-audit/` in the repository. This report does not accept its Pursuit and OA1 interpretations as confirmed defects. The user-provided rules/aid photos and publisher materials remain authoritative over either auditor's prose.

`SHA256SUMS.json` records every delivered evidence file except itself. Screenshots show the actual reviewed interface. The report's open questions and scope gaps are part of the verdict, not waived by passing tests.
