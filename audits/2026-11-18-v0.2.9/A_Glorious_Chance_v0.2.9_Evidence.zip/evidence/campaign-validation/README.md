# New-game campaign verification and A.I. odds finding

## Scope and reproduction

This is source-engine testing, not Chrome or physical tabletop play. No previous-version save migration was tested. The natural fixtures are snapshots made during ordinary new v0.2.8 games before the independently discovered defects, usable to reproduce the same legal board in the updated app.

From the audit evidence directory, with Node 24:

```sh
node campaign-validation/sweep.js /path/to/v028 610000 64 baseline
node campaign-validation/sweep.js /path/to/v029 610000 64 final-matched
node campaign-validation/sweep.js /path/to/v029 610064 64 final-fresh
node campaign-validation/preview_scan.js /path/to/v028
node /path/to/v029/tests/regression_v029_preview.js /path/to/v028
node /path/to/v029/tests/regression_v029_preview.js /path/to/v029
```

The baseline sweep and preview regression commands intentionally fail on v0.2.8. `sweep.js` uses the shared `../load.js` and `../campaigns.js`; keep their relative paths. Each output records a SHA-256 of the engine sources loaded, so a later release can be distinguished. The two final sweeps both tested source hash `b17b58f81f48d80bed3228df3daabd910a5f9f74d71ec2b8eabe73969dbe0e47`.

The fleet policy combines an Escort when available, Niagara Army Support, and a concentrated Patrol. The coast policy assigns single-ship Raids, puts Troops ashore at Niagara or the enemy homeport, and uses optional Cutting-Out when there are targets. The cautious policy uses the fleet assignments but prefers Bypass, Pass and Withdrawal when offered. These are deterministic heuristics based on the human-visible choices and ship values. They are not optimal strategies or estimates of human win rates. Diagnostics inspect hidden state only after decisions; hidden cards and RNG never guide the policies.

Options vary by seed: OA2 on alternating seeds; OA1 on every fourth; both printed A.I. attack-precondition interpretations; pause-after-A.I.-move off on every fifth. Every eighth seed uses both manual Force Packages and manual Land Battles. Manual packages follow the printed requirements with a stable choice among equally small legal groups; this tests the permitted manual-selection mode, not the automatic bot's random tie distribution. Land Battle results use an independent transcription of all 15 photographed Aid VII columns, including the documented project ruling for unassigned 62–63 in the zero-Long-Gun/three-Troops column.

## Results

| Run | Complete / attempted | Prompts | Exact JSON next-step checks | Preview purity | First-round strength checks | Failures |
|---|---:|---:|---:|---:|---:|---:|
| v0.2.8 baseline, 610000–610063 | 379 / 384 | 48,980 | 1,762 | 1,700 | 602 | 5 |
| v0.2.9 matched, 610000–610063 | 384 / 384 | 49,466 | 1,780 | 1,727 | 610 | 0 |
| v0.2.9 independent, 610064–610127 | 384 / 384 | 49,436 | 1,775 | 1,722 | 605 | 0 |

Both sides × three policies give six games per seed. The final 768 games contained 96 manual-option campaigns, 1,367 manual package selections and 372 independent manual Land Battle resolutions. The tests assert after every action:

- exactly three real Troops per side across track, Available, embarked, F7 queue and previously landed;
- whole ship steps within the correct A/B counter's capacity, linked Force and zone membership, and no ship sunk twice in one turn;
- bounded integral Convoy Supply, Construction Delay and Niagara Front tracks;
- each side's VP equals its own ledger; final score and victory tier follow the rules' thresholds;
- a pending executable decision or a completed game;
- sampled JSON-restored next actions match the uninterrupted game, including dice and all state;
- repeated preview queries leave all state and RNG untouched;
- the selected human lineup's independently calculated first-round strengths agree with the applied round (Missed Signal/Haze included; later tactic column shifts remain separate).

There were 158 Draws and two last-turn sudden-death endings under rule 5.1 in the final sample. No natural Dual Blockade ending occurred; that boundary requires focused tests outside this sweep. The two early cases were US 610000/coast and US 610047/fleet, ending before September II play because the A.I. had no ship eligible to deploy. Ordinary endings include final Construction Delay deduction in the ledger.

The five baseline failures were duplicate sinkings caused by the Rake round-memory bug, independently reproduced without editing state. Fixtures list the exact pending prompt and next action in `baseline.json`: BR610027/fleet (Attack), BR610028/cautious (Continue), US610043/fleet and cautious (Continue), BR610046/fleet (Attack). All five seeds complete without duplicate sinking after the fix. Other baseline invariants held until those failures.

The preliminary `fixed` and `fixed-final` outputs record intermediate source checks while the three combat fixes were being integrated. Use **final-matched/final-fresh** for the release verdict.

## Confirmed additional finding — command preview shows the wrong A.I. force

**Severity low, player information.** The enemy's attack is computed correctly, but the command screen can overstate the strength it will use. The new-game example shows 26 versus 18 (1.44:1) while the actual legal attack uses 23 versus 18 (1.28:1). These values occupy the same CRT column in this witness, so this finding does not change its combat result or score. The display fix changes no dice or decisions.

**Expected behavior and rule.** The companion promises first-round odds matching the force that actually attacks. LC1/project note 17 permits the A.I. Americans to omit untowed schooners to meet their attack threshold. The displayed A.I. preview should use that selected plan, then apply the first-round Missed Signal and Haze effects. If the A.I. cannot legally attack, say it would Pass.

**Smallest useful legal setup.** British seed 612056, fleet policy, August II, Niagara. U.S. full-strength Pike, Gov. Tompkins and Fair American face British full-strength Wolfe B and Royal George B. Pike tows Tompkins. All three Americans total 26 attacking strength against 18, but the untowed-schooner 1.5:1 requirement fails. Pike and Tompkins alone total 23, exceed the 1:1 requirement and meet the printed-value test. Fair American stays out.

**Exact reproduction in the app.** Load `AI_preview_before_command_BR_612056_fleet.json`, which is the natural `Encounter 1 in Niagara` information prompt, and press Continue. In v0.2.8 the A.I. preview says 26 versus 18 = 1.44:1. Choose Confront, Continue, First Shot, Continue. The Gunnery Round 1 log says U.S. 23 versus British 18 = 1.28:1. In v0.2.9 the regenerated command preview already says 23 versus 18 = 1.28:1, matching the round. The later `AI_preview_BR_612056_fleet.json` fixture retains the old already-written command text, so use the before-command file to compare the new generator.

**Source and smallest fix.** Baseline `src/engine_encounter.js:272–276` builds the preview from every full-strength enemy ship. Updated `src/engine_encounter.js:275–300` obtains the pure `aiAttackDecision` selection instead, preserving the first Breakout's precondition waiver. A denied attack is explicit. The additional independently verified coastal and preview follow-up is recorded in `claude-followup.md`.

**Regression evidence.** `tests/regression_v029_preview.js` now contains 22 checks after the follow-up audit. On v0.2.8, six fail; all 22 pass in v0.2.9. Adjacent controls preserve the full 26-strength squadron when it can legally attack, Haze, zero RNG consumption, the actual first round, and the Breakout waiver. With Missed Signal on Tompkins, the corrected first-round attack decision has Pike tow Fair American: 19 + 3 = 22 versus 18. The added Rainy Squalls checks compare pure Close Action previews with the actual first round and retain Gunnery for the Reaction Segment. The spare fixture `AI_preview_BR_612027_fleet.json` is a Haze control: omitting an untowed zero-contribution schooner does not change the displayed strength; it was not classified as a defect.

## Administration observations and coverage limits

Across the final simulated sample there were 68,725 information/Continue prompts and 30,177 choices or form submissions. Mean prompts per campaign ranged from 104.3 (U.S. cautious) to 156.5 (British coastal); mean decision/forms ranged from 32.3 to 46.7. These measure the scripted app interaction, including mixed optional/manual settings, not actual physical-play time. Board mirroring is still required, and no manual lookups are needed for default automated tables. These counts support retaining the existing option to skip A.I. confirmations when the player does not need them; they do not justify removing prompts from the default physical-board workflow.

The sweep does not prove strategic balance, human enjoyment, every tactic interaction, source-table correctness, browser persistence, keyboard behavior, touchscreen behavior or previous-version recovery. Those require the audit's separate table, focused rule and browser lanes. All tests use the engine as implemented; the independent assertions constrain particular conservation, scoring and arithmetic properties rather than establishing every rule by themselves.
