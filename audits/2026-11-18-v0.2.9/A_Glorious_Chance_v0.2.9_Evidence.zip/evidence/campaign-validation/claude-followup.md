# Independently verified coastal and preview follow-up

Reviewed baseline v0.2.8 and the final v0.2.9 source. This lane tested source procedures and save validation directly; browser tests belong to the separate UI lane. These are current-game positions, not attempts to repair historical saves.

The following originals were visually read: British Living Rulebook 7 August 2024, printed pp.20–22 (both columns and the repair timeline diagram) and p.41 (both columns, Harbor rule12); VASSAL component scans of Event19 Rainy Squalls, Event23 Haze/Heated Shot, Event26 Requisition, Event29 Missed Signal/Intelligence; the user's photographed Player Aid VII including its five Long Gun bands and all three Troops columns. Other card numbers with the same named effect were cross-checked against the game's data and the full audit's card review.

Runnable checks from the repository:

```sh
node tests/regression_v029_coastal.js
node tests/regression_v029_preview.js
# Substitute the baseline checkout to demonstrate the original failures:
node tests/regression_v029_coastal.js ../agc-v0.2.8
node tests/regression_v029_preview.js ../agc-v0.2.8
```

The coastal suite passes 36/36 on the candidate; baseline passes17 and fails19. The expanded preview suite passes22/22; baseline passes16 and fails6. Logs are the four `*-followup-{baseline,fixed}.log` files. Fixed/source line references below refer to the final candidate. Baseline locations refer to v0.2.8.

## L3 — Requisition bypasses reduced-ship repair and F7 cleanup — confirmed

**Player impact:** a Reduced ship becomes assignable and counted as Deployable without ever receiving repair; Last Step/No Steps and isolation handling can also be wrong.

**Expected independently:** F7 p.20 and6.1 p.22 discard Last Step/No Steps, return Reduced ships to In Transit, and use an isolated ship's temporary homeport. The repair diagram shows In Transit→Repairing at next A3, then full strength/Deployable at the following A3. Events26–28 remove the ship for the following turn; they grant no free repair or exemption from the Reduced-ship process.

**Reproduction:** `Requisition_Tally_BR_81.json` is Claude's supplied seed81 JulyI board: Reduced Lord Beresford A (one step), requisitioned in the Niagara Army Support Force. Load it, Continue through F7, decline optional upgrades, and advance without deploying her to AugustI. Baseline returns her to Deployable while still Reduced. The fixed app sends her to In Transit at A2 and Repairing at A3. The focused assertion additionally uses Wolfe A at one step, isolated under the U.S. Kingston Blockade: after F7 she must be a two-step Reduced ship at the temporary homeport; after the missing turn she repairs rather than sailing; the next A3 restores three steps. A full-strength Earl of Moira control returns immediately Deployable.

**Source/minimal fix:** baseline `src/engine_tally.js:136` returns before port/marker cleanup, and `src/engine_turn.js:53` unconditionally makes the returning ship Deployable. Candidate `engine_tally.js:133–141` performs normal port/marker cleanup and `engine_turn.js:52–54` chooses Deployable only for a full-strength return, otherwise In Transit. The return box is not explicitly printed on the Requisition card; this is the conservative general-rule interpretation, now made explicit rather than a new bonus repair rule.

## L7 — Rainy Squalls previews an unfought Gunnery Round — confirmed information defect

**Player impact:** the attack decision and ship-selection screen give irrelevant Gunnery odds instead of the Close Action matchups the chosen ships will fight.

**Expected:** Events19–21 specifically retain LC1/LC2, then skip Patrol combat directly to LC7 Close Action. No Gunnery Round or Tactics draw occurs. Reaction retains its ordinary sequence.

**Reproduction:** load `Rainy_before_command_BR_280009.json` and Continue to regenerate the Command Decision. It is the supplied SeptemberI Kingston board: Wolfe B/Royal George B versus Madison/Fair American/Conquest/Pike. Baseline prints Gunnery odds. Candidate says no Gunnery/straight to Close Action and displays CA strengths and selected matchups. The focused seed54 board has Wolfe B CA8 versus Oneida CA3: the preview and actual first round use that eligible2:1 pairing; repeated preview calls preserve every state field and RNG. Changing only the segment to Reaction restores the Gunnery preview.

**Source/minimal fix:** baseline `src/engine_encounter.js:263–276` unconditionally builds Gunnery odds. Candidate `engine_encounter.js:263–300` adds pure Rainy/CA preview helpers and uses the actual lineup order, missed-signal exclusion and selected A.I. plan. UI agent uses the same helpers in `renderLineup`, and combat agent suppresses its irrelevant towing/Gunnery warning. No combat outcome was changed by this preview fix.

## L8 — Manual Land Battle uses a double-negative direction — confirmed information defect

**Player impact:** “shifted -2 column(s) left” can be read as a right shift, changing which result the player enters.

**Expected:** Event36 More Defenders shifts the Long Gun band two places left, clamped to zero, while preserving the Troops subcolumn. AidVII:3 Long Guns/1 Troop becomes0 Long Guns/1 Troop; roll64 is Attacker Success, not the Major Success from the unshifted band.

**Reproduction:** load `Manual_Land_Battle_before_E_BR_47.json`, Continue. This focused JulyI board has Wolfe A, Royal George A and Moira A supporting one Troop at Niagara, Event36 next, saved RNG cursor41 producing red6/blue4. Baseline prints the negative-left phrase. Candidate names `0 Long Gun / 1 Troops` and row64 explicitly. Select Attacker Success. The regression compares manual and automatic applications, their dice consumption, and a no-shift control.

**Source/minimal fix:** baseline `src/engine_coastal.js:164`; candidate `:157–165` calculates the final printed column once and uses the same label in both modes. Manual mode still asks for the result rather than answering for the player.

## L9 — Empty Harbor defense announced for captured British A.I. schooners — confirmed information defect

**Player impact:** an unnecessary Harbor screen says the ships in port are an empty list; subsequent play already resolves without combat.

**Expected:** Rule12 engages combat-capable enemy port ships. Project note15 excludes captured Converted Laker Schooners from A.I. British combat.

**Reproduction:** the runnable seed46 board in the coastal suite gives the British A.I. only captured Julia, zero steps, In Transit at Kingston; U.S. Madison/Oneida launch one Troop there. Baseline enters a Harbor procedure whose filtered defender list is empty. Candidate goes straight to the Land Battle. Adjacent controls retain a legal Reduced non-CLS defender and the existing human-British exception.

**Source/minimal fix:** baseline `src/engine_coastal.js:116` checks a broader pool than `:198`. Candidate `:187–190` supplies one eligibility filter to both the trigger at`:116` and Harbor setup at`:196`.

## Q-B resolved in part — pending Haze/Missed Signal ignored in Harbor — confirmed rules defect

The report's proposed all-events/none-events choice is too broad. Each card's scope matters. Rule12 conducts a modified Encounter Cycle; its listed exceptions remove attack preconditions, Command Decision, Weather Gage/Tactics and rechecks, restrict combat to two Gunnery Rounds, remove the untowed-schooner DRM, and ignore Disengagement/Withdrawal. It does not cancel pending Haze or Missed Signal. Haze covers the first Lake Combat Gunnery Round1 in the zone, then burns off. Missed Signal covers the selected deployed ship's first otherwise-eligible Lake Combat round that turn. Both therefore cover a qualifying Harbor round. Rainy specifically concerns the Patrol sequence and cannot replace Rule12's explicit two-Gunnery-Round restriction with Close Action.

**Player impact:** Harbor odds, hit recipients and which side takes losses can be wrong; one-use zone effects incorrectly survive for a later Encounter.

**Reproduction:** load `Harbor_Haze_before_E_BR_71.json`, Continue to the Harbor announcement, Continue to Round1. Full Wolfe A and Royal George A attack full Madison at Sackets Harbor. Baseline uses15.5 versus11; the printed Haze adjustment gives14 versus10. Candidate applies that adjustment once, then restores Long Guns in Round2. The same minimal board in `Harbor_MissedSignal_before_E_BR_71.json` has Royal George selected by Event6 and still waiting to sit out. Baseline attacks at15.5 versus11; candidate has Wolfe alone,9 versus11. Saved RNG cursor1 gives d10=6, plus Command=7. With the shore-battery column shift, baseline's D1W hits Madison; the corrected A1 hits Wolfe. Royal George is excluded from return-hit allocation and returns for Round2.

**Source/minimal fix:** baseline `src/engine_coastal.js:209–229` always includes all ships and passes false for Haze. Candidate `:218–247` applies and consumes the pending effects only when eligible, filters both strength and hit-distribution participants for that round, and keeps the full stored column available for Round2.

**Boundary evidence:** spent Haze and Missed Signal match no-event controls; Haze uses Reduced counter values; an ineligible Reduced attacker does not consume Missed Signal; no extra Event, Weather Gage or Tactic cards are drawn. When Missed Signal removes the sole eligible attacker or defender, Round1 passes without combat dice and that ship participates in Round2: Rule12 retains Engaged ships, and the card excludes only one Round. This avoids converting the effect into immunity for the whole Harbor Encounter. A wholly unfought Round1 does not burn pending Haze; this narrow combined-event timing interpretation follows “first Gunnery Round1 to occur” and is explicitly disclosed. The normal next-turn start clears all zone effects.

## Final evidence and limitations

Final fresh-game sweep:768/768 complete, source hash `b17b58f81f48d80bed3228df3daabd910a5f9f74d71ec2b8eabe73969dbe0e47`, seeds610000–610127 × both sides × three visible-information policies. It includes98,902 prompts,3,555 exact JSON next-action comparisons,3,449 preview-purity checks,1,215 independent applied first-round strength comparisons,1,367 manual package selections and372 independent AidVII lookups. No invariant failed. See `README.md`, `final-matched.json`, `final-fresh.json` for exact options and limits.

Prioritize the return/Harbor rule corrections, then misleading previews/manual instructions. These lane results support the patched source; final shipped-byte verification and public browser sign-off remain the parent audit's responsibility. They do not establish balance, exhaustive tactics, physical-play timing, or publisher resolution of the separately documented OA1, Rainy lifetime and printed-table ambiguities.
