const fs=require('fs'),path=require('path'),assert=require('assert');
const repo=path.resolve(process.argv[2]);const {x}=require('../load')(repo);const E=x('({newGame,run,act,aiAttackDecision,encSummary,validateAnswer,encIds,isFull,sideStrength,missedSignalShip,hazeActive})');const policy=require('../campaigns').policy;
let attempts=0,found=null;
for(let seed=612000;seed<612256&&!found;seed++)for(const style of ['fleet','coast']){
 const s=E.newGame('BR',seed,{cuttingOut:true});E.run(s);attempts++;let previous=null,previousAnswer=null;
 for(let n=0;!s.over&&n<1600;n++){
  const p=s.prompt;
  if(p.title==='Command Decision – the A.I. holds the Weather Gage'){
   const plan=E.aiAttackDecision(s,false);
   const ms=E.missedSignalShip(s),all=E.encIds(s,s.ai).filter(id=>E.isFull(s.ships[id])&&id!==ms);
   const allStrength=E.sideStrength(s,all,s.ai,E.hazeActive(s)),plannedStrength=E.sideStrength(s,plan.ships.filter(id=>id!==ms),s.ai,E.hazeActive(s));
   if(plan.ships.length&&/without its untowed/.test(plan.why)&&allStrength!==plannedStrength){
    fs.writeFileSync(path.join(__dirname,'AI_preview_BR_'+seed+'_'+style+'.json'),JSON.stringify({state:s,undo:[]},null,2));
    if(previous)fs.writeFileSync(path.join(__dirname,'AI_preview_before_command_BR_'+seed+'_'+style+'.json'),previous);
    const before=E.encSummary(s),trace=[];const old=s.log.length;
    E.act(s,'confront');trace.push('Confront');
    while(!s.over&&trace.length<12&&!s.log.slice(old).some(l=>/^Gunnery Round 1:/.test(l.text))){const q=s.prompt,a=policy(s,q,style);trace.push({title:q.title,answer:a});E.act(s,a);}
    found={seed,style,step:n,previousAnswer,before,allStrength,plannedStrength,plan,trace,actual:s.log.slice(old).filter(l=>/Line of battle|^Gunnery Round 1:/.test(l.text))};break;
   }
  }
  previous=JSON.stringify({state:s,undo:[]},null,2);previousAnswer=policy(s,p,style);E.act(s,previousAnswer);
 }
 if(found)break;
}
const result={attempts,found};fs.writeFileSync(path.join(__dirname,'ai-preview-results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
