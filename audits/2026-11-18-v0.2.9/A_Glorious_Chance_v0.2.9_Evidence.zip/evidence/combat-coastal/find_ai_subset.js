const fs=require('fs'),path=require('path');const repo=path.resolve(process.argv[2]);const{x,ctx}=require('./load')(repo);const E=x('({newGame,run,act,validateAnswer})');const{policy}=require('./policy.js');let done=false;
for(let seed=293001;seed<295049&&!done;seed++)for(const style of ['fleet','coast']){
const s=E.newGame('BR',seed,{cuttingOut:true});E.run(s);let steps=0;const answers=[];
while(!s.over&&steps++<1500){const p=s.prompt;const a=policy(s,p,style);let plan=null;const before=JSON.stringify({state:s,undo:[]});
if(s.combat?.att==='US'&&s.combat.gr===1&&s.encounter?.kind==='normal'){
ctx.b=JSON.parse(before).state;plan=x(`aiPlanFor(b,'US',colShips(b.combat,'US').filter(id=>isFull(b.ships[id])&&b.encounter.ships[id]==='in'),colShips(b.combat,'BR'),false)`);
}
const logN=s.log.length;E.act(s,a);answers.push(a);
if(plan?.ships?.length&&s.log.slice(logN).some(l=>l.text.startsWith('Gunnery Round 2:'))&&s.combat?.att==='US'&&s.combat.roundAttackers.length>plan.ships.length){
const name=`R03_BR_${seed}_${style}_${steps}`;fs.writeFileSync(path.join(__dirname,name+'.json'),before);fs.writeFileSync(path.join(__dirname,name+'_after.json'),JSON.stringify({state:s,undo:[]},null,2));fs.writeFileSync(path.join(__dirname,name+'_answers.json'),JSON.stringify(answers,null,2));console.log(JSON.stringify({name,seed,style,steps,answer:a,previous:p.title,plan,actual:s.combat.roundAttackers,lines:s.log.slice(logN).map(l=>l.text)},null,2));done=true;break;
}
}if(done)break;
}
