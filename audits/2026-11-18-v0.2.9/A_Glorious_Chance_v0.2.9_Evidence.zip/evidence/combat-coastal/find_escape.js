const fs=require('fs'),path=require('path');const repo=path.resolve(process.argv[2]);const E=require(path.join(repo,'tools/bundle_engine.js'))();const{policy}=require('./policy.js');let done=false;
for(let seed=292001;seed<292513&&!done;seed++) for(const side of ['US','BR'])for(const style of ['fleet','coast']){
const s=E.newGame(side,seed,{cuttingOut:true});E.run(s);let steps=0;const answers=[];
while(!s.over&&steps++<1500){const p=s.prompt;let a=policy(s,p,style);if(p.options?.some(o=>o.id==='D_escape'&&!o.disabled))a='D_escape';const before=JSON.stringify({state:s,undo:[]});const logN=s.log.length;E.act(s,a);answers.push(a);
const f=s.calls.at(-1);if(f?.L?.res?.end&&f?.L?.res?.escape&&s.prompt?.title==='Gunnery result'){
const name=`R02_${side}_${seed}_${style}_${steps}`;fs.writeFileSync(path.join(__dirname,name+'.json'),before);fs.writeFileSync(path.join(__dirname,name+'_after.json'),JSON.stringify({state:s,undo:[]},null,2));fs.writeFileSync(path.join(__dirname,name+'_answers.json'),JSON.stringify(answers,null,2));console.log(JSON.stringify({name,seed,side,style,steps,answer:a,previous:p.title,prompt:s.prompt,combat:s.combat,lines:s.log.slice(logN).map(l=>l.text)},null,2));done=true;break;
} }if(done)break;
}
