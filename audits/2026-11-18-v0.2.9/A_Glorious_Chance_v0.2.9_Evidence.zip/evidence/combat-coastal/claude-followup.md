# Combat follow-up on Claude's v0.2.8 audit

Independent review of Claude audit commit `fc0aed0`; reviewed app baseline remains v0.2.8 (`ffd7317`). M1, L4 and L6 are confirmed for new games and fixed. M2 duplicates our earlier R03 and exposed an additional tow-pair preservation requirement, now covered. M3 is **ambiguous**, not a confirmed defect; current A05 behavior and the user's adopted Pursuit surrender-boundary ruling remain unchanged.

Only `src/engine_combat.js` and `tests/regression_v029_combat_followup.js` were changed in this lane. Other agents own Harbor-event and preview fixes.

## Sources checked directly

I viewed the original full rendered British LR printed pp.29 and36 (both columns), U.S. LR printed p.34 (both columns), the face of Event13 Missed Signal, and card A05 Pursuit. Earlier review covered both living books, Playbook, errata, all20 physical Tactic faces and agreed `RULES_NOTES.md` rulings. Relevant files: `audit/render/br-29.png`, `br-36.png`, `us-34.png`; `audit/sources/vmod/images/_0036_Event 13.jpg`, `_0005_Tactic-A05.jpg`.

The source-based expectations below were established separately from the program's decisions. Missed Signal's eligible-round wording determines when the Event is spent; LC1/LC2 determine actual combatants and odds; LC5.1 permits flag transfer during Lake Combat, including Close Action; LC6 advances existing columns and rechecks attack prerequisites before later rounds.

## Confirmed M1 — AI attack decision counts the absent Missed Signal ship

- **Impact/severity:** medium. AI can attack below its minimum odds, or decline a legal advantageous attack. The displayed first-round odds and decision disagree.
- **Smallest useful position:** U.S. campaign, North Lake, U.S. Madison against British AI Wolfe and Royal George, all full; Wolfe has the pending Missed Signal; British Weather Gage. Imported seed101 fixture: `claude-followup/F1a_AI_missed_signal_attacks_below_1to1.json`.
- **Exact steps:** load the fixture and select **Confront** on Command Decision, then Continue through the AI decision/Tactics to first Gunnery. This is a focused legal board position, not a claim that seed101 reaches it from unaltered setup.
- **Expected:** actual first round is Royal George alone, 6.5 versus11 =0.59:1; AI declines under LC1. Its separate printed weapon+Defense test still compares the selected Forces, including the Event-affected ship.
- **Observed v0.2.8:** plan uses Wolfe too, claims1.41:1, attacks, then actually fires at0.59:1.
- **Inverse witness:** `F1b_AI_declines_counting_your_missed_signal_ship.json`, seed102, U.S. Pike+Tompkins versus AI Wolfe+Moira; pending Missed Signal on Pike. AI wrongly declines at0.81:1 though actual first-round odds are6.5:1 and its printed-strength test passes.
- **Source:** baseline `src/engine_combat.js:33` (`aiPlanFor`), especially its odds/tow calculation; fixed `:33`, `:39`, `:48` and`:64`.
- **Smallest fix implemented:** omit the pending ship from actual-strength odds and from participating towers/schooners when testing the1/1.5/2:1 threshold; keep the printed Force comparison. Do not generate an attack with no participating ship even under waived prerequisites.
- **Controls:** no Event and already-spent Event retain the1.41:1 attack; a missed tower supplies no tow; lone absent attacker has no plan; reverse defender case is checked. Preview's existing call into `aiAttackDecision` now receives the same decision.

## Confirmed L6 — Voluntarily omitting a ship postpones Missed Signal

- **Impact/severity:** low. A player can omit the affected ship from an eligible attack, preserve the Event and then keep that ship out of harm in a later defending round. The Event occurs in the wrong round.
- **Rule:** Event13 applies at the first round the selected ship otherwise was eligible to join; selecting it is not an additional prerequisite.
- **Position/seed:** U.S.31, North Lake, full Madison+Oneida versus full Wolfe+Royal George; Oneida has pending Missed Signal; U.S. Weather Gage. `claude-followup/F6_missed_signal_ship_left_out_of_line.json` opens at the lineup.
- **Steps:** choose only Madison as attacker; confirm.
- **Expected:** Missed Signal is spent now because full Oneida was eligible. Oneida remains outside the chosen attacking line.
- **Observed v0.2.8:** `missedSignalUsed` remains false; Oneida can miss a later defending round instead.
- **Source:** baseline `src/engine_combat.js:132`; fixed `:176`–`:186`.
- **Smallest fix implemented:** consume on eligibility, while separately retaining the existing selected-ship sit-out/rejoin behavior. Log that the omitted but eligible ship used the Event. Do not silently add an omitted ship to the line.
- **Controls:** Reduced Oneida is ineligible to attack, so omitting her does not spend the Event. She spends it when subsequently eligible to defend. Tests also assert an omitted full ship is not automatically reintroduced.

## Confirmed L4 — No flag transfer after Close Action

- **Impact/severity:** low. A leader loses the opportunity to move to an adjacent full-strength ship; a subsequent attack can lose its Command modifier. It also removes the required choice and its casualty risk.
- **Rule:** LC5.1, U.S. printed p.34, permits transfer from a Reduced Flagship during Lake Combat, with a Leader Casualty Check. It does not restrict that opportunity to Gunnery.
- **Position/seed:** British6, North Lake, U.S. Gen.Pike attacking British SSS and flagship Lord Melville, at Close Action. `claude-followup/F4_flagship_reduced_in_close_action.json`.
- **Exact steps:** load, Continue. Pike's d10=2 hits Melville; Yeo's casualty check5+1 has no effect; Disengagement d6=5 fails; Melville stays Engaged, Reduced to1step. Pike cannot Melee. The two British ships are adjacent.
- **Expected:** offer transfer to SSS before the old column is discarded. Decline is legal; acceptance must roll the transfer casualty check.
- **Observed v0.2.8:** Close Action results proceed into Reaction with no transfer opportunity; the next British attack omits Reduced Melville and therefore loses Yeo's Command bonus. Once the new line replaces the old one, the old adjacency information is gone.
- **Source:** baseline `src/engine_combat.js:392` (Gunnery-only transfer path), `:545` (CA results skip it), `:457`/`:464` (new Sequence replaces column). Fixed `:465`/`:484` (shared round results), `:619` (CA enters transfer), `:126` (check before replacing old column).
- **Smallest fix implemented:** route CA through the existing transfer procedure, then display its own CA results and continue without advancing the round twice. At a new attacking Sequence or Reaction, preserve the old column long enough to offer a human transfer or automatically attempt a beneficial AI transfer; then assemble the new line.
- **Direct acceptance result:** in the exact seed6 fixture, the additional transfer check rolls11 and kills Yeo. The correct outcome is therefore a transfer opportunity and a failed, fatal attempt, **not** a guaranteed recovered bonus. A nearby fixed-dice control rolls5 and transfers successfully.
- **Controls:** accepted, declined, wounded leader, exact save/reload at the prompt, CA position advancement, human new Sequence, AI new Sequence with retained Command bonus. Existing Gunnery transfer tests still pass.

## M2 / our R03 refinement — Preserve established tow pairs

The earlier fix correctly uses the AI's approved subset in GR2/CA. Recalculating tows there, however, can assign a different schooner to a tower without changing its column position. Printed LC2 puts the towed ship immediately behind the tower; LC6 advances the existing column.

**Focused boundary:** start with Madison→Tompkins and Pike→Fair American. Madison then becomes Reduced/Disengaged. In a later round, Pike must retain Fair American, leaving Tompkins untowed. Re-running the initial greedy pairing would incorrectly choose Pike→Tompkins because Tompkins has higher Long Guns, while their physical positions remain unchanged.

`aiPlanFor` now takes optional `existingTows` (fixed source`:33`/`:49`); later GR/CA pass `c.tows`, retain only pairs with both participating ships, and apply the approved subset. Initial assembly/new Sequence may still choose new pairings and builds the matching column. The control asserts precisely that distinction. No persistent column/gap restructuring was added.

## M3 — Ambiguous human withdrawal/Pursuit ordering, retained

Claude's behavior report reproduces, but the rule inference is not established. Generic LC5 makes a human W optional. A05 more specifically triggers when DW is rolled and enemy ships are **eligible** to withdraw, then cancels that withdrawal and starts a new Encounter. It does not expressly require the defender to elect withdrawal first. Either precedence reading is conceivable; calling the existing card-specific interpretation a definite defect overstates the evidence.

**Current ruling preserved:** apply A05 directly when eligible defenders remain after hits/checks; if none are eligible, leave Pursuit unused. Preserve the user's separate agreed ruling settling struck ships at that Encounter boundary before the new Encounter.

`claude-followup/F3_AI_pursuit_vs_your_optional_withdrawal.json` (U.S.8): Continue yields D1W with Fair American struck; Pursuit starts, and Fair American settles to the British at the boundary. Tests keep this, the no-eligible control, and the ordinary no-Pursuit optional-W prompt. This is an unresolved publisher question, not a requested change silently made on the user's behalf.

## Verification and limits

Run from the repository:

```sh
node tests/regression_v029_combat_followup.js
node tests/regression_v029_combat.js
node tests/regression.js
```

- New follow-up suite: **28 passed** on fixed source; **12 passed /16 failed** on unchanged v0.2.8. Several baseline failures are intentionally dependent checks for the missing transfer prompt, not16 distinct defects.
- Earlier combat suite: **21 passed** after these changes.
- Existing regression suite: **153 passed** after these changes.
- `followup-baseline.log` and `followup-fixed.log` preserve the differential output. The test copy and all five original importable fixtures are in `claude-followup/`.
- This lane directly executed engine procedures/actions, parsed saves, and viewed source components. Browser controls, Undo, autosave, release build/byte comparison and full-game sweeps are parent/other-agent work; no claim here that these follow-up tests themselves exercised a browser.
- No legacy-save migration edits. Release verdict for this lane: v0.2.8 has confirmed new-game combat defects; the candidate fixes satisfy the focused independent tests, pending combined release/browser validation.
