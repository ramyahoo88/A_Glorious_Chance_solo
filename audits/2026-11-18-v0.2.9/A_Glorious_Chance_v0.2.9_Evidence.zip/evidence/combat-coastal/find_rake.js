const fs=require('fs'),path=require('path'),assert=require('assert');
const repo=path.resolve(process.argv[2]);
const E=require(path.join(repo,'tools/bundle_engine.js'))();
const {policy}=require('./policy.js');
const out=__dirname;let done=false;
for(let seed=291001;seed<292025&&!done;seed++) for(const side of ['US','BR'])for(const style of ['fleet','coast']) {
const s=E.newGame(side,seed,{cuttingOut:true}); E.run(s);let steps=0;
while(!s.over&&steps++<1500){const p=s.prompt;let a=policy(s,p,style);if(p.options?.some(o=>o.id==='A_rake'&&!o.disabled))a='A_rake';
const f=s.calls.at(-1), target=f?.L?.rakeTarget;
const before=JSON.stringify({state:s,undo:[]});const logN=s.log.length;const oldSteps=target?s.ships[target].steps:null;const oldSt=target?s.encounter?.ships[target]:null;const att=s.combat?.att;
E.act(s,a);
if(target&&s.log.slice(logN).some(l=>l.text.includes('takes ')&&l.text.startsWith(E.shipName(s,target)))&&oldSt!=='in'){
const name=`R01_${side}_${seed}_${style}_${steps}`;fs.writeFileSync(path.join(out,name+'.json'),before);fs.writeFileSync(path.join(out,name+'_after.json'),JSON.stringify({state:s,undo:[]},null,2));
console.log(JSON.stringify({name,seed,side,style,steps,prompt:p.title,answer:a,target,oldSteps,oldSt,att,lines:s.log.slice(logN).map(l=>l.text)},null,2));done=true;break;
}
}if(done)break;
}
