const fs=require('fs'),path=require('path'),vm=require('vm');
const repo=path.resolve(process.argv[2]);
const src=JSON.parse(fs.readFileSync(path.join(repo,'tools/files.json'))).engine.map(f=>fs.readFileSync(path.join(repo,'src',f),'utf8')).join('\n;\n')+'\n;installResume();';
const c=vm.createContext({console});vm.runInContext(src,c);const x=e=>vm.runInContext(e,c);
for(let seed=290101;seed<290110;seed++){
x(`var s=newGame('BR',${seed});s.turn=2;s.phase='prep';s.ships.wolfe.box='repairing';s.ships.wolfe.steps=2;s.ships.wolfe.delay=0;s.calls=[{proc:'turn',pc:'A2',A:{},L:{}}];run(s);`);
console.log(seed,x('s.prompt.title'),x('topFrame(s).L.upN'),x('s.prompt.items.map(i=>i.label)'));
}
