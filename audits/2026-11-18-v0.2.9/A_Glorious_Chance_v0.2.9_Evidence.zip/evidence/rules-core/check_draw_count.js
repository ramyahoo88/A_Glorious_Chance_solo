const fs=require('fs'),path=require('path'),vm=require('vm');const repo=path.resolve(process.argv[2]);
const ctx=vm.createContext({console});vm.runInContext(JSON.parse(fs.readFileSync(path.join(repo,'tools/files.json'))).engine.map(f=>fs.readFileSync(path.join(repo,'src',f),'utf8')).join('\n;\n')+'\n;installResume();',ctx);const x=e=>vm.runInContext(e,ctx);
for(let seed=290201;seed<290250;seed++) {
 x(`var s=newGame('BR',${seed});s.turn=2;s.phase='prep';s.zones.SAC.blockade='BR';s.nb=0;s.nbBand=3;s.calls=[{proc:'turn',pc:'A9',L:{}}];run(s);`);
 if(x('s.targetRow.length')>8){console.log(x('JSON.stringify({seed:s.seed,count:s.targetRow.length,prompt:s.prompt},null,2)'));fs.writeFileSync(path.join(__dirname,'R02_blockade_extra_card_BR_'+seed+'.json'),x('JSON.stringify({state:s},null,2)'));break;}
}
