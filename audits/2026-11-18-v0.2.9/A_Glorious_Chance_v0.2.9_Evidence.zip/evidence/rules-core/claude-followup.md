# Independent verification of Claude M4, L1 and L2

Baseline: v0.2.8, commit `ffd7317bf3c41b45d8ad8443073d1e5c47d17c34`. Fixes are in the v0.2.9 working checkout. The U.S. Living Rules (13 April 2024), British Living Rules (7 August 2024), Living Playbook (6 August 2024) and existing project rulings remain the rules baseline.

I viewed the complete rendered pages, including both columns: Playbook p.6; U.S. pp.10,12,22,25,26,27; British p.26. The text search was used to locate passages. Scope: M4's confirmed presentation defect, L1's upgrade eligibility and L2's player choices. OA1's substantive recalculation interpretation remains unresolved and unchanged.

## M4 — confirmed stale OA1 column description; recalculation ruling remains open

**Player impact:** the deployment screen and its log cite the old Naval Balance column even though the engine used a different column. A player following the companion on the printed board can consult the wrong cell.

**Expected:** after OA1 recalculates Naval Balance and rechecks the Target Card (Playbook p.6, left column), the displayed lookup must name the cell actually used.

**Exact reproduction:** load `CLAUDE_M4_US3_natural_before_OA1.json`, then press Continue. It is reached through normal controls from U.S. seed 3, OA1 enabled, all assignable ships placed on one Kingston Patrol. The complete preceding answers are in `CLAUDE_M4_US3_natural_trace.json`. Event 4 confirms the Encounter, Target A8 is revealed, and OA1 roll 7 sends Wolfe to Make Ready.

**Observed v0.2.8:** Naval Balance becomes −62, band index 1 (“≤−26”); British ships deploy using that cell, but the deployment screen/log still says the original “−15 to 15” column. The active procedure also retains the old `f.L.cell.col=3`.

**Source:** baseline `src/engine_deploy.js:168` stores the description; `:243–245` recomputes a local lookup without refreshing it. **Smallest fix applied:** shared cell-description formatter and refresh of `f.L.cell`/`f.L.cellTxt` immediately after OA1 recalculation, with a log naming the new lookup. Current locations: `engine_deploy.js:158–159,253–257`. This does not change Naval Balance, the random stream or deployment outcome.

**Paired control:** ordinary upgrades with OA1 disabled retain Naval Balance 0/band 3 and still describe that column.

**Unresolved ruling, not a confirmed arithmetic defect:** OA1 says to recalculate as in A6; U.S. p.10 A6 explicitly counts Deployable ships. Applied at this later point, that excludes U.S. ships already assigned to the lake. The existing −62 result therefore has a defensible literal reading. The alternative would preserve the A6 total and remove only the upgrading British ships: seed 3 would become +32 and A8 would not deploy. OA1's stated American advantage supports asking for clarification, but does not establish that this alternative supersedes the explicit A6 reference. No interpretation was silently changed.

## L1 — confirmed upgrades without a legal Army Support deployment

**Player impact:** a British ship can receive a permanent ordinary upgrade, or lose a turn to an OA1 refit, even though its Force is ineligible to deploy. An impossible deployment can also consume the turn's OA1 check and alter later dice.

**Expected:** U.S. 7.1 (p.22, right column) triggers when British ships are about to be placed on the lake. EN1.1 (p.12, right column) says an Army Support Force lacking the necessary carrying capacity does not deploy. OA1 (Playbook p.6) similarly requires the first Encounter that will deploy ships.

**Smallest useful position:** July I, U.S. campaign, Oneida on a Sacket's Patrol; PE1 on A26; only Beresford A is British Deployable, with 3 CA; three A.I. Troops are available; Naval Balance 0; Event 8 is next. One Troops marker requires 4 CA.

**Exact reproduction:** load `CLAUDE_L1_US182401_standard_Beresford_CA3.json` and press Continue. The constructed position has seed 182401 and saved RNG state 1; the next ordinary upgrade die is 4. For OA1 use `CLAUDE_L1_US182401_OA1_Beresford_CA3.json` (next upgrade-table roll 7). These are focused positions, not claimed as natural seed-only games.

**Observed v0.2.8:** ordinary mode makes Beresford B, then logs that the Force cannot carry Troops and does not deploy. OA1 moves Beresford to Make Ready and consumes `oa1Done`, also without a deployment. The import routes were executed through `checkSaveState` and `act`; both reach the July I Tally with those wrong ship states.

**Source:** baseline `src/engine_deploy.js:188–191` enters upgrades unconditionally; capacity is checked only later at `:269–273`. **Smallest fix applied:** reject a British Army Support Force with transport capacity below one before entering the upgrade procedure (`engine_deploy.js:195–200`). The existing later check remains necessary because a valid OA1 refit can remove ships from a previously adequate force.

**Fixed result:** Beresford remains A/Deployable in both modes, `oa1Done` remains false, no upgrade die is consumed, no Troops embark. **Paired controls:** Moira's exact 4 CA permits an ordinary upgrade and deployment carrying one marker; under OA1 the eligible Moira can correctly be selected for Make Ready. Beresford's Patrol deployment still makes its ordinary Upgrade Check despite having only 3 CA.

## L2 — confirmed missing legal Possible Encounter choices

**Player impact:** automatic rotation prevents choosing which Force faces Encounter 2. That can expose a transport Force when the player would legally send the Raid Force instead. A displaced Force's marker also silently transfers to the first remaining Force, with no choice.

**Expected:** U.S. 10.1.2 p.25, right column, and British 10.1.2 p.26, left column, permit choosing subsequent recipients while giving each Force one marker before any second and keeping placement even. Thus all six permutations of three Forces receiving three markers must be available. U.S. 11.1.3 p.27, left column, transfers a displaced Force's marker to a different friendly Force still in the original zone.

**Smallest useful position:** British seed 4401, July I, three Forces in Sacket's: F1 Patrol (Wolfe/Royal George), F2 Army Support (Beresford/Sir Sidney Smith, one Troops marker), F3 Raid (Moira). Target backs B2/B36/B37 all match Sacket's.

**Exact reproduction:** load `CLAUDE_L2_BR4401_before_B1.json`, Continue, and choose the Patrol for PE1. Then attempt to choose the Raid for PE2. **Observed v0.2.8:** no second choice; it assigns 1→F1, 2→F2, 3→F3. Starting with the other Forces only produces orders 231 and 312. Legal orders 132, 213 and 321 are unavailable.

**Transfer reproduction:** load `CLAUDE_L2_BR4401_before_transfer.json`; the Patrol is now in Niagara, while F2 and F3 remain in Sacket's, and F2 already holds PE2. Continue. **Observed v0.2.8:** PE1 is silently sent to F2 and Event31 is drawn before any choice. **Fixed:** a prompt offers either F2 or F3 before drawing an Event. Choosing F3 transfers PE1 there and then draws the same Event31.

**Source:** baseline `src/engine_turn.js:247,250–258` chooses only the first recipient and rotates; `:276` selects the first transfer recipient. **Smallest fix applied:** assign initial markers in row order, prompting only when multiple Forces tie for the lowest marker count; automatically assign the sole legal recipient. Transfer prompts offer all friendly Forces still in the original zone, or transfer automatically if only one remains. Current implementation is `engine_turn.js:240–269,280–311`.

**Interpretation of transfers:** 11.1.3 does not repeat the initial-placement minimum-load restriction. The transfer choice therefore includes an already-marked Force; no extra restriction is inferred by analogy. If no Force remains, markers are discarded as before.

**Paired controls and persistence:** all six three-Force orders pass in both campaigns; PE2 excludes the already-marked Force; after one complete cycle all three are eligible for PE4, then the twice-marked Force is excluded for PE5. A single Force gets every marker without extra prompts. One-recipient transfers are automatic; zero-recipient transfers discard without drawing. Initial placement and transfer choices consume no RNG. Both new pending choices survive checked save round trips and continue to identical states.

This supersedes the earlier core-pass characterization of the extra PE choices as optional usability. The exhaustive three-Force case establishes an unavailable rules-permitted decision, and the fix restores it without adding a full allocation editor.

## Evidence and verification

Run from the release checkout:

```sh
node tests/regression_v029_deploy.js
node tests/regression_v029_deploy.js ../agc-v0.2.8
```

- Same focused suite: v0.2.8 **33 passed / 22 failed**; corrected source **55 passed / 0 failed**. Full output is in `claude-followup-before.log` and `claude-followup-after.log`.
- Earlier turn regressions: **29/29**; existing scenario tests: **14/14**; existing regression suite: **153/153**.
- Existing simulation harness: **100 games per side, 200 total, zero failures**. This is integration coverage, not an independent rules oracle.
- All five supplied importable positions were checked and continued in both engines; observed snapshots are in `claude-fixtures-observed.json`, with no recovery notices or migration effects.
- `make_claude_followup_fixtures.js` regenerates the witnesses from baseline source; `CLAUDE_M4_US3_natural_trace.json` records the natural game answers.
- Whitespace/conflict check on changed source and the new test passed.

**Component verdict:** these confirmed items are fixed and ready for integrated release/browser verification. OA1 recalculation remains explicitly unresolved; no substantive OA1 rule change was made. This subreview did not operate the browser, so control-level and release-byte verification belong to the parent audit.
