const fs=require('fs'),path=require('path'),vm=require('vm');
const repo=path.resolve(process.argv[2]),out=path.resolve(__dirname);
const files=JSON.parse(fs.readFileSync(path.join(repo,'tools/files.json'))).engine;
const c=vm.createContext({console});vm.runInContext(files.map(f=>fs.readFileSync(path.join(repo,'src',f),'utf8')).join('\n;\n')+'\n;installResume();',c);const x=e=>vm.runInContext(e,c);
x(`var s=newGame('BR',290101);s.turn=2;s.phase='prep';s.ships.wolfe.box='repairing';s.ships.wolfe.steps=2;s.ships.wolfe.delay=0;s.calls=[{proc:'turn',pc:'A2',A:{},L:{}}];run(s);`);
fs.writeFileSync(path.join(out,'R01_finished_repairs_upgrade_BR_290101.json'),x('JSON.stringify({state:s},null,2)'));
x("act(s,['wolfe']);");
fs.writeFileSync(path.join(out,'R01_observed_v028_after_confirm.json'),x('JSON.stringify({state:s},null,2)'));
console.log(x("JSON.stringify({seed:s.seed,turn:s.turn,prompt:s.prompt.title,wolfe:s.ships.wolfe,log:s.log.slice(-4)},null,2)"));
