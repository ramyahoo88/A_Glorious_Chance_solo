// Runnable importable witnesses, generated from the unmodified v0.2.8 engine.
// The M4 fixture follows normal controls from seed3. L1/L2 are focused constructed
// board positions; their saved RNG state (not seed alone) fixes the subsequent roll.
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(process.argv[2]||path.join(__dirname,'../../../../agc-v0.2.8'));
const files=JSON.parse(fs.readFileSync(path.join(root,'tools/files.json'))).engine;
const ctx=vm.createContext({console,localStorage:{getItem(){return null;},setItem(){}}});
vm.runInContext(files.map(f=>fs.readFileSync(path.join(root,'src',f),'utf8')).join('\n;\n')+'\n;installResume();\n'+fs.readFileSync(path.join(root,'src/ui.js'),'utf8'),ctx);
const X=c=>vm.runInContext(c,ctx);
function save(name) {
  X('checkSaveState(JSON.parse(JSON.stringify(s)));');
  fs.writeFileSync(path.join(__dirname,name),X('JSON.stringify({state:s,undo:[]},null,2)'));
  console.log(name, X('s.prompt.title'));
}
X(`var s=newGame('US',3,{oa1Upgrades:true});run(s);var trace=[];
  while(s.prompt.title!=='B1 Possible Encounters'){
    var p=s.prompt,a='ok';
    if(p.kind==='choice')a=(p.options.find(o=>o.primary)||p.options[0]).id;
    else if(p.kind==='select')a=p.initial||[];
    else if(p.kind==='assign')a={forces:[{mission:'Patrol',zone:'KIN',ships:p.ships,troops:0}],flagship:p.flagship};
    trace.push({title:p.title,answer:a});act(s,a);
  }`);
save('CLAUDE_M4_US3_natural_before_OA1.json');
fs.writeFileSync(path.join(__dirname,'CLAUDE_M4_US3_natural_trace.json'),X('JSON.stringify({seed:3,options:{oa1Upgrades:true},trace},null,2)'));
for(const oa1 of [false,true]){
  X(`var s=newGame('US',182401,{oa1Upgrades:${oa1}});s.turn=2;s.phase='lake';s.lossesThisTurn=[];s.troopsReturning={US:0,BR:0};
    var hf=newForce(s,'US','SAC','Patrol',['oneida']);
    sideShips(s,'BR').forEach(sh=>{if(sh.box==='deployable'&&sh.id!=='beres'){sh.box='repairing';sh.steps=def(sh).red[4];}});
    s.flagship.BR='beres';s.nb=0;s.nbBand=3;s.aiTroops.track=[];s.aiTroops.box=[{troops:true,revealed:true},{troops:true,revealed:true},{troops:true,revealed:true}];
    s.targetRow=[{id:'A26',revealed:false,enc:false,removed:false}];s.pe=[{num:1,idx:0,zone:'SAC',forceId:hf.id,status:'possible'}];s.peNext=2;
    s.deck.event=[8].concat(s.deck.event.filter(id=>id!==8));
    s.calls=[{proc:'turn',pc:'B2',A:{},L:{}}];s.prompt=info('L1: insufficient Army Support transport','Continue: Event 8 confirms PE1; Beresford A alone has 3 CA, below the 4 CA needed for one Troops marker.');s.rng=1;`);
  save(`CLAUDE_L1_US182401_${oa1?'OA1':'standard'}_Beresford_CA3.json`);
}
X(`function threeForces(){
  var q=newGame('BR',4401);q.turn=2;q.phase='lake';q.pe=[];q.peNext=1;q.troops.BR={available:2,track:[]};q.lossesThisTurn=[];q.troopsReturning={US:0,BR:0};
  var ids=[newForce(q,'BR','SAC','Patrol',['wolfe','rg']).id,newForce(q,'BR','SAC','ArmySupport',['beres','sss'],{troops:1}).id,newForce(q,'BR','SAC','Raid',['moira']).id];
  q.targetRow=['B2','B36','B37'].map(id=>({id,revealed:false,removed:false,enc:false}));
  return {state:q,ids};
}
var p=threeForces();var s=p.state;
s.calls=[{proc:'turn',pc:'B1',A:{},L:{}}];s.prompt=info('L2: three Forces, three Possible Encounters','Continue, choose the Patrol for PE1, then choose the Raid for PE2. The Army Support Force must receive PE3.');`);
save('CLAUDE_L2_BR4401_before_B1.json');
X(`var p=threeForces();var s=p.state,ids=p.ids;
s.forces[ids[0]].zone='NIA';s.forces[ids[0]].ships.forEach(id=>s.ships[id].zone='NIA');
s.pe=[{num:1,idx:0,zone:'SAC',forceId:ids[0],status:'possible'},{num:2,idx:1,zone:'SAC',forceId:ids[1],status:'possible'}];s.peNext=3;
s.deck.event=[31,32,33].concat(s.deck.event.filter(id=>![31,32,33].includes(id)));s.eventsDrawn=[];
s.calls=[{proc:'turn',pc:'B2',A:{},L:{}}];s.prompt=info('L2: transfer a Possible Encounter',"The Patrol has left Sacket's. Continue, then choose either remaining Force for PE1. No Event should be drawn before your choice.");`);
save('CLAUDE_L2_BR4401_before_transfer.json');
