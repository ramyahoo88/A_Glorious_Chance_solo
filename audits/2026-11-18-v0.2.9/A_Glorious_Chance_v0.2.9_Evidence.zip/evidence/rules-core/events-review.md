# Event-card component pass (current games)

Reviewed against the original full card layouts in `audit/render/events_1.jpg` through `events_7.jpg`, plus `audit/sources/vmod/images/card_event_8_FRONT_2023.png` (card 8 is not in the JPG contact sheets). All 38 faces were viewed. Both the lake and coastal sections, the spyglass, initial Weather Gage, and all tactic-invalidating symbols were checked against `src/data.js:239–278` in the v0.2.9 working checkout. No mismatching card-data field was found.

This is a visual transcription and handler review, not a claim that all 38 effects were independently exercised in the browser. The separate upgrade and A10 reproductions in this directory were run directly against both the v0.2.8 release and the corrected engine.

## Visual coverage inventory

Symbols: C = club; H = heart; D = diamond; A = downward arrow; S = square; T = star; O = circle. “—” means absent. Spyglass is present on cards 1–20 and absent on 21–38. Initial Weather Gage is A on 1–19, B on 20–29 and 31–38, and absent on Gale 30.

| Card | Lake event and affected side | Invalidating symbols | Coastal event |
|---|---|---|---|
| 1 | Minor Damage, British | C H T | None |
| 2 | Construction Delay, U.S. | — | None |
| 3 | Construction Delay, British | — | None |
| 4 | Construction Delay, British | — | None |
| 5 | Convoy Delay, British | — | None |
| 6 | Missed Signal, British | H D | None |
| 7 | Sickness, U.S. | C D S O | None |
| 8 | Fair Wind, human | — | None |
| 9 | Extra Men, U.S. | — | None |
| 10 | Extra Men, British | — | None |
| 11 | Separated Ships, U.S.; clockwise, displaced force becomes Patrol | H D | None |
| 12 | Sickness, British | C D O | None |
| 13 | Missed Signal, U.S. | H D | None |
| 14 | Separated Ships, British; counterclockwise, displaced force becomes Patrol | H D | None |
| 15 | Adverse Wind, human | — | None |
| 16 | Haze | C H A S T | None |
| 17 | Haze | C H A S T | None |
| 18 | Adverse Wind, human | — | None |
| 19 | Rainy Squalls | C H D A S T | None |
| 20 | Rainy Squalls | C H D A S T | Local Militia |
| 21 | Rainy Squalls | C H D A S T | Supplies Burned |
| 22 | Adverse Wind, human | — | Supplies Moved |
| 23 | Haze | C H A S T | Heated Shot |
| 24 | Adverse Wind, human | — | Heated Shot |
| 25 | Fair Wind, human | — | Explosion |
| 26 | Sickness, U.S. | C D S O | Requisition |
| 27 | Separated Ships, U.S.; clockwise, both forces become Patrol | H D | Requisition |
| 28 | Sickness, British | C D O | Requisition |
| 29 | Missed Signal, U.S. | H D | Intelligence |
| 30 | Gale; Lake Action Phase only | — | Not a coastal event; redraw |
| 31 | Fair Wind, A.I. | — | Intelligence |
| 32 | Fair Wind, A.I. | — | Sudden Storm |
| 33 | Minor Damage, U.S. | C H T | Sudden Storm |
| 34 | Separated Ships, British; counterclockwise, displaced force becomes Patrol | H D | Sudden Storm |
| 35 | Missed Signal, British | H D | Sudden Storm |
| 36 | Convoy Delay, U.S. | — | More Defenders |
| 37 | Commanding Breeze, British attack | — | More Defenders |
| 38 | Commanding Breeze, British attack | — | More Defenders |

Source-layout anomaly: the VASSAL image named `_0029_Event 20.jpg` prints “21” at the bottom, as does the following Supplies Burned card. Its Rainy Squalls/Local Militia content and spyglass distinguish it. The module's named slot and this app consistently identify it as event 20; this is not reported as an application defect.

## Scope and timing review

Inspected `engine_core.js:83–99`, `engine_encounter.js:19–40,69–92,311–433`, `engine_combat.js:8–14,94–98,121–145,259–268,449–455,794–804`, `engine_coastal.js:68–183`, `engine_tally.js:67–91,131–176`, and `engine_turn.js:52–53`.

| Expected behavior from the faces | Implementation review |
|---|---|
| One lake event per zone per turn; a later draw still determines its Encounter's Weather Gage | `PROCS.encounter.event` applies the lake field only on the first encounter in that zone. |
| Minor Damage benefit once in the zone this turn, only a Gunnery hit, one hit prevented on roll at or below current defense | `minorDamageUsed` gates it; the owner check, d10 threshold and one-hit reduction agree. |
| Haze only the first Gunnery Round 1 in the zone | `hazeUsed` is set by the actual GR1 roll. It is not consumed merely by viewing the preview. |
| Missed Signal: random deployed ship in a multi-ship force anywhere in the zone; first eligible combat round of that force | Candidate selection uses zone forces; removal and `missedSignalUsed` occur only when that ship would be in the column. |
| Sickness affects every ship of the named side in the zone for the turn; Pike loses 2 rather than 1 CA; CD also rises by 1 | Zone flag plus owner check and Pike special case; CA floors at zero. |
| Separated 11/14/34 preserves the undisplaced force's mission; 27 changes both to Patrol | Distinct `separatedBoth` branch; half rounded down and correct direction. |
| Fair Wind human versus A.I.; Adverse Wind's printed +2 | Separate human/A.I. reaction branches. Adverse Wind follows the explicit existing player ruling, RULES_NOTES item 5. |
| Rainy Squalls only Patrol Segment, after LC1–LC2 directly to Close Action; Reaction Segment unaffected | Segment gate, no intervening tactics/gunnery, then segment end. |
| Commanding Breeze only this Encounter's Patrol Segment and British attack after GR2 | British/segment/previous-step checks; `endEncounterEffects` clears it before another Encounter including Pursuit. |
| Gale only for a new Lake Zone Event; only the opposing Encounter forces; clockwise displacement, class modifiers and Niagara odd/even coast | Gale is discarded/redrawn elsewhere. Handler iterates only participating ships, applies class/shore checks and uses non-combat losses. Troops-return handling was reviewed separately. |
| Local Militia / Supplies Burned / Supplies Moved affect only the drawing side's Raid | Stored per-raid events; F4 uses strictly greater than guns for Militia; F5 requires 6 for Burned and suppresses supply for Moved. |
| Heated Shot / Explosion / Requisition affect only Army Support; random damaged/destroyed ship, or lowest-guns requisition with random ties | Army-support handler uses these selectors. Heated Shot excludes its guns and sends it to Ordinary in F7; Requisition stays out for the next turn. Explosion credits the defender and kills the leader if the flagship explodes. |
| More Defenders affects the drawing side's Army Support against this coastal target, including multiple supporting forces | Forces in the same zone are combined for one battle; the −2 shift is attached only to that battle. Band-shift interpretation is the existing RULES_NOTES item 40. |
| Sudden Storm changes a 2-VP Raid to 1 VP, all other Raid VPs to 0; no Raid supplies; Army Support AM to AS only | These exact branches are present; Feat of Arms is not reduced. |
| Intelligence applies next turn to the first Encounter involving the enemy flagship; it then expires, even if no reaction occurs, or at turn end unused | `intelligenceApplies`, `consumeIntelligence`, normal/Harbor/Pursuit end paths and F7 expiry agree. Card is kept out of the deck while held. |

## Optional clarity improvement (not a gameplay defect)

The old text in `src/data.js:230` and `src/engine_coastal.js:182` described Intelligence as applying to “the next Encounter” through the end of next turn, without saying it starts next turn. The original faces 29/31 explicitly instruct applying it next turn. The engine correctly enforced that restriction. With the lead reviewer's authorization, both strings now say “next turn only,” identify the first applicable Encounter, and explain expiry after that Encounter even without Reaction Checks, or at turn end if unused. This helps when another Harbor Encounter occurs later in the same Coastal Action Phase. These are string changes only; no event logic changed.

Validation after the wording change: `node tests/regression.js` — 153 passed, 0 failed, including the existing Intelligence eligibility, positive/negative DRM, Encounter-consumption, Pursuit-consumption and save-reload timing checks. Output is saved as `events-timing-regression.log`.

No additional confirmed current-game defect found in this event-component pass. Full UI execution of every event in every mission/side combination remains outside this pass's direct coverage.
