# Preparation, deployment and lake-event review

Reviewed input app v0.2.8 at ffd7317bf3c41b45d8ad8443073d1e5c47d17c34, documentation head 4a630a24880ed0553b8722203590fae068f67f68. Current-game scope, with no requirement to repair historical saves. Edits are in the shared next-release checkout `agc-v0.2.9`.

## Confirmed and fixed — Concurrent repair and upgrade incorrectly loses a turn

**Player impact / priority:** high gameplay. A British ship finishing repairs misses its entire new turn if the player chooses an upgrade. The ship should be available in its stronger B version immediately. This changes available missions, Naval Balance and the A.I. Target Card draw.

**Independent expectation:** British Living Rulebook, 7 Aug 2024, printed p.23 section 7.2, left column. A ship completing its turn in Repairing may join the new turn as the upgraded version under that turn's upgrade limit. Living Playbook, 6 Aug 2024, printed p.12 left column independently demonstrates Wolfe and Earl of Moira completing repair and upgrade together and moving to Deployable. Both complete rendered pages and both columns were inspected, including the ordinary refit procedure 7.1 which requires Make Ready for a ship that was already Deployable.

**Exact focused reproduction:** Load `R01_finished_repairs_upgrade_BR_290101.json` in v0.2.8. British campaign, seed 290101, July I at A2. Wolfe A is in Repairing, 2 steps, no repair delay. The rolled limit is 3. Select Wolfe and Confirm.

**Expected:** Wolfe B, 3 steps, Deployable in this turn, present for A4 and A7.

**Observed:** Wolfe A, 3 steps, Make Ready with an upgrading flag. She cannot sail until the following turn. The old prompt explicitly says every selected ship returns next turn, so the player is also given incorrect advice before choosing.

**Natural reproduction:** `R01_natural_BR_290301.json` comes from an unmodified new British v0.2.8 campaign. Seed 290301, Cutting-Out enabled. The complete 71-prompt trace is `R01_natural_BR_290301_trace.json`. The policy used visible information only, chose the existing fleet policy, and declined upgrades until a ship was finishing repairs. At August I A2 it offers Wolfe. Selecting Wolfe reproduces the same wrong Make Ready result. `find_natural_upgrade.js` regenerates the witness. This demonstrates legal reachability without Adjust or injected combat outcomes; the smaller July I fixture isolates the defect.

**Source:** original `src/engine_turn.js` lines 62, 70–74; fixed lines 70–81. The candidate filter correctly included repairs finishing now but A2up2 unconditionally sent every selected ship to Make Ready.

**Smallest fix implemented:** distinguish a selected ship in Repairing with no delay, finish its repair and change to B/Deployable immediately. Other selected ships retain the normal Make Ready refit. The one rolled quota still covers both. The prompt, item labels and log now name the two timings explicitly.

**Regression evidence:** `regression_v029_turn.js` checks all four upgradable British ships, declining an upgrade, ordinary refit and next-turn completion, delayed repairs, isolated ships, mixed repair/refit selections and quota overflow. The first 21 checks had 12 passes and 9 failures on v0.2.8, then 21 passes after the fix.

## Confirmed and fixed — A10 tells the player the wrong row length

**Player impact / priority:** low, physical-board instruction. The prompt can tell the player to lay out eight cards while the actual row and numbered zone list have nine. The additional blockade card is correctly applied by the engine, but the printed instruction omits it from the count and does not explain the addition.

**Independent expectation:** British Living Rulebook printed p.11 A10, right column after the page's priority diagram. If the enemy Homeport is blockaded and no matching card was drawn, add one from the deck or discards at the left end. The actual resulting row therefore has one more than the ordinary draw count. Full rendered page, both columns and diagram inspected.

**Exact reproduction:** `R02_blockade_extra_card_BR_290202.json`, British campaign seed290202, July I, Naval Balance0/band3, Sacket's blockaded. The A9 draw yields no Sacket's card, so the engine adds one. At A10 the actual row has9 cards, beginning Sacket's. Old instruction begins “Lay out 8 Target Cards” but lists zones numbered1–9. `check_draw_count.js` regenerates this fixture.

**Source:** original `src/engine_turn.js` lines223–225, fixed lines232–235.

**Smallest fix implemented:** use actual `row.length` in the physical layout instruction and explicitly explain the extra blockade card in both prompt and log. The log retains the correct original draw count and explains the addition separately.

**Nearby controls:** seed290201 with a Sacket's card already drawn shifts it to the left and retains8. Seed290202 without the blockade retains8. The added card is first. The combined turn suite is29 checks, v0.2.8 has18 passes/11 failures and the fixed turn code29 passes/0 failures. See `turn-before.log`, `turn-after.log`.

## Scope and unresolved questions

- Setup, A1–A10, current Force Package dispatch, row lookup (Available plus embarked A.I. Troops), Possible Encounter placement, Reaction eligibility, regular/OA1 upgrade timing and relevant lake events reviewed in the supplied code against the cited living rules and project interpretations.
- Inspected the rendered Player Aid V photo and all11 rows including both Package8 forces, odd/even Encounter selection and the Army Support footnote. Package8's choice of its first force remains the documented RULES_NOTES57 ambiguity; no change made.
- Inspected rendered British rule pages8,11,23,26,34 and Living Playbook12 for setup, table/card ordering, repair/refit timing, PE placement and flagship eligibility; checked rule text and errata around these procedures. Inspected Event14 and27 full card images to distinguish one-force and both-force mission changes after separation, plus Event4 as a Construction Delay source. This review does not claim every card face was newly inspected by this subreview.
- **Follow-up confirmed and fixed:** 10.1.2 allows the player to choose subsequent Possible Encounter recipients while distributing them evenly. This was initially treated here as optional because every automatically generated allocation was legal. The Claude follow-up supplied a minimal three-Force case showing that half the explicitly permitted orders were unreachable. A small per-marker choice now restores those legal decisions (no full allocation editor); transfers also permit choosing a remaining Force. See `claude-followup.md` for source, rendered rules, paired tests and importable positions.
- **Ambiguous ruling / no fix:** 8.1 requires the A.I. to buy down remaining Construction Delay, while LC5.1 requires a Deployable Flagship at turn start. `aiConstructionDelayPurchase` protects its current Flagship. Both books'8.1 and LC5.1 and RULES_NOTES7–8 were checked. Exhausting the last Deployable ship would conflict with LC5.1, so retaining a flagship is defensible and is not being reported as a confirmed defect. A designer ruling could clarify whether the commander should instead move to another eligible ship to permit further buy-down.
- No browser use by this subreview; root handles real delivered app controls. Existing153 regression checks passed immediately after the concurrent-upgrade fix. A later rerun during parallel validator edits stopped at the old synthetic save fixture in regression.js218 (pending decision), which was reported to root for integration. Do not treat that transient rerun as a final release result.

## Run

```sh
node tests/regression_v029_turn.js
# independently demonstrate v0.2.8 failures from next checkout
node tests/regression_v029_turn.js /path/to/agc-v0.2.8
# optional regenerate naturally reached witness (cwd is audit workspace)
node audit/v029/evidence/rules-core/find_natural_upgrade.js agc-v0.2.8
```
