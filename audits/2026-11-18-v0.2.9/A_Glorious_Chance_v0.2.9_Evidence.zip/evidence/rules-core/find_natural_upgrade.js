const fs=require('fs'),path=require('path');
const repo=path.resolve(process.argv[2]);const E=require(path.join(repo,'tools/bundle_engine.js'))();
const {policy}=require(path.resolve('audit/v028/evidence/campaigns.js'));
for(let seed=290301;seed<290401;seed++){
 let s=E.newGame('BR',seed,{cuttingOut:true});E.run(s);const trace=[];
 while(!s.over&&trace.length<1800){
  const p=s.prompt;let a=policy(s,p,'fleet');
  if(p.title==='A2 British Ship Upgrades'){
   const repairing=p.items.filter(i=>s.ships[i.id].box==='repairing');
   if(repairing.length&&p.max>0){
    const id=repairing[0].id;fs.writeFileSync(path.join(__dirname,'R01_natural_BR_'+seed+'.json'),JSON.stringify({state:s},null,2));
    fs.writeFileSync(path.join(__dirname,'R01_natural_BR_'+seed+'_trace.json'),JSON.stringify({repo:process.argv[2],seed,human:'BR',options:{cuttingOut:true},trace,nextAnswer:[id]},null,2));
    E.act(s,[id]);console.log(JSON.stringify({seed,prompts:trace.length,turn:s.turn,selected:id,result:s.ships[id]},null,2));process.exit(0);
   }
   a=[];
  }
  trace.push({title:p.title,answer:a});E.act(s,a);
 }
}
console.log('No natural match in 100 games');
