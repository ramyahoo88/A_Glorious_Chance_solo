# Independent confirmation of Claude v0.2.8 M6, M7 and L12

Reviewed Claude's submitted report and original UI fixtures, then reproduced the problems against the unmodified v0.2.8 shipped HTML in jsdom. This is DOM-handler verification, not a claim of real Chrome execution. No previous-version recovery logic was changed.

## M6 — Setup Load could discard the retained browser game

**Player impact:** after reload, loading a different save from setup replaced the retained game and its history. With no open `G_STATE`, no Undo position was preserved. This is the Load variant of the already fixed Start campaign replacement hazard.

**Expected:** the importer promises that one Undo returns to the previous game with its history. That protection should include the retained game offered by Continue it on setup.

**Reproduction:** start U.S. seed 292001, choose June I, reload. Without pressing Continue it, Load the exported U.S. seed 292002 initial position. In v0.2.8, Undo has zero entries and the stored game is now 292002. No retained campaign remains to restore.

**Source:** v0.2.8 `src/ui.js:136–149` (`commitLoaded`, previous state only from `G_STATE`) and `:151–156` (`loadFromText`).

**Fix:** after validating the incoming save, setup import reads and validates the retained autosave without writing it. It passes that state and history as a recoverable predecessor to `commitLoaded`. Existing Continue it uses its original route and does not add a duplicate history entry. A damaged incoming file remains rejected before any retained state or storage changes. An unreadable stored game cannot provide a usable Undo predecessor; this does not block loading a valid game.

**Checks:** successful setup import, Undo after an additional reload, exact restoration of the retained game and its previous history, another Undo to its earlier decision, damaged setup import preserves stored bytes, and ordinary Continue retains its original history length. A second confirmation dialog is unnecessary because the prior game remains recoverable.

## M7 — Ship-step corrections silently moved lake ships to port

**Player impact:** changing only Madison's steps removed her from her Force and zone and put her in Deployable. A pending combat lineup could subsequently fail, since its saved participants no longer matched the board.

**Expected:** editing steps should only edit steps. Moving a ship requires an explicit box change. Changing ownership must not leave an enemy-owned ship inside the previous side's Force.

**Reproduction:** load `tests/browser/fixtures/adjust-madison-on-lake.json` (Claude's `D5_US280004_A10_Madison_on_lake.json`, U.S. seed 280004, A10 Target Cards drawn). Madison is in Kingston in Force F3 with 3 steps. Adjust → Madison → enter 2 steps → Apply. In v0.2.8, Madison becomes Deployable, `zone=null`, `forceId=null`, and F3 no longer contains her.

**Source:** v0.2.8 `src/ui.js:768–777`, especially lake-to-Deployable default at 771 and unconditional removal/zone clearing at 776–777.

**Fix:** the destination selector initially says **Keep current box (Lake)**. Position and Force membership change only when the selected destination differs from the current box. A steps-only correction preserves location and membership. If the owner of a deployed ship is changed, an explicit off-lake destination is required; otherwise a clear message is shown before any mutation. This avoids silently inventing a new Force, mission, capture result or troop transfer.

**Checks:** steps-only edit and exact save/reload/Undo; refused owner-only change preserves state, dice, history and stored bytes; explicitly changing owner and destination moves the ship out of the old Force, remains loadable, and is exactly undoable. The existing fractional-input protections remain in place.

## L12 — VP adjustments were absent from the score ledger

**Player impact:** manual VP corrections changed the headline score but not the Game Over ledger. Editing VP after Game Over also left the cached final score and victory tier stale.

**Expected:** the ledger's signed sum equals U.S. VP minus British VP and the final result. A U.S. correction of +3 contributes +3 to the score; a British correction of +2 contributes −2.

**Reproduction:** load `tests/browser/fixtures/adjust-vp-before-final-turn.json` (Claude's seed 280004, Reset – end of September I). Adjust U.S. VP from 68 to 71. v0.2.8 changes the total by 3 without adding a ledger row. Alternatively load `adjust-completed-game.json`, then add 3 U.S. VP; v0.2.8 changes the header but leaves the displayed Final Game Score unchanged.

**Source:** v0.2.8 `src/ui.js:758–759` assigns VP directly. The cached score shown at Game Over is `s.result` in `renderProc` at `:265–268`.

**Fix:** use `addVP(s, side, newTotal - oldTotal, 'Manual adjustment')`. When editing an already completed game, refresh its cached score and ordinary victory tier. Preserve a forced Dual Blockade victory. This does not call endGame again or deduct Construction Delay twice.

**Checks:** positive U.S. and British entries, signed ledger agreement, two exact Undos, final deductions and ledger consistency, finished save review, and adjusting/undoing the cached completed result. The final-deduction check calls the engine's normal endGame function from a late-game fixture; it is a focused assertion rather than a claim to have played those remaining decisions through controls. The completed-fixture adjustment uses only visible controls.

## Evidence

`tests/browser/persistence_followup_v029.js` runs 21 focused checks. All pass in a separate build of the corrected source; 13 fail against v0.2.8. These are multiple assertions covering three findings, not 13 separate defects. The original 38 persistence checks continue to pass. Outputs are `claude-baseline-checks.json` and `claude-fixed-checks.json`.

Run:

```
NODE_PATH=/path/to/jsdom/node_modules node tests/browser/persistence_followup_v029.js . --require-fixed
```

The three fixture files are copied unchanged from Claude's submitted evidence. Root owns final release build verification and real-browser checks.
