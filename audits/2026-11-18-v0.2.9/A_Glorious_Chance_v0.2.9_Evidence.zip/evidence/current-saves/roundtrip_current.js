/* Current-version games only. Shipped HTML's engine, validator, renderers.
   Reproducible fleet/coast policies inspect public position and pending decisions.
   NODE_PATH=... node roundtrip_current.js /path/to/repo [seed-count=32]
   This is jsdom coverage, not Chrome or evidence of balance/win-rate quality. */
const fs=require('fs'),path=require('path'),assert=require('assert');
const {JSDOM,VirtualConsole}=require('jsdom');
const repo=path.resolve(process.argv[2]),n=Number(process.argv[3]||32);
const html=fs.readFileSync(path.join(repo,'dist/index.html'),'utf8');
const policySource=fs.readFileSync(path.join(__dirname,'policy.js'),'utf8');
(async()=>{
 const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'https://current-roundtrip-audit.invalid/',runScripts:'dangerously',virtualConsole:vc});
 await new Promise(r=>dom.window.addEventListener('load',r));
 dom.window.eval('window.auditPolicy=(function(E){'+policySource+';return policy;})({validateAnswer,def,troopCapacity});');
 let result;try{result=dom.window.eval(`(function(){
   const rows=[];let loads=0,renders=0,emptyFlagDefaults=0;
   const comparable=x=>{const v=JSON.parse(JSON.stringify(x));if(v.encounter&&v.encounter.flagIn&&Object.keys(v.encounter.flagIn).length===0)delete v.encounter.flagIn;return JSON.stringify(v);};
   for(let i=0;i<${n};i++)for(const side of ['US','BR'])for(const style of ['fleet','coast']){
    const seed=291000+i,s=newGame(side,seed,{cuttingOut:i%2===0,oa1Upgrades:i%4===0});run(s);let prompts=0;
    while(true){
      const raw=JSON.stringify(s),loaded=checkSaveState(JSON.parse(raw));loads++;
      if(JSON.stringify(loaded)!==raw)emptyFlagDefaults++;
      if(comparable(loaded)!==comparable(s)){window.auditDiff={side,seed,style,prompts,before:JSON.parse(raw),after:loaded};throw Error('Validator changed current game '+side+' '+seed+' '+style+' '+prompts);}
      if(prompts%31===0||s.over){G_STATE=s;UI.local=null;UI.localFor=null;render();renders++;if(JSON.stringify(s)!==raw)throw Error('Rendering altered game '+seed+' '+prompts);}
      if(s.over){
        commitLoaded(loaded,[]);if(!document.getElementById('proc').textContent.includes('Game Over'))throw Error('Finished game not reviewed');break;
      }
      const answer=auditPolicy(s,s.prompt,style),err=validateAnswer(s,s.prompt,answer);if(err)throw Error(err);
      act(s,answer);act(loaded,answer);if(comparable(s)!==comparable(loaded))throw Error('Replayed load diverged '+seed+' '+prompts);
      if(++prompts>2000)throw Error('Stalled campaign');
    }
    rows.push({side,seed,style,prompts,turn:s.turn,score:s.result.score});
   }
   return {games:rows.length,loads,renders,emptyFlagDefaults,rows};
 })()`);}catch(e){if(dom.window.auditDiff)fs.writeFileSync(path.join(__dirname,'validator-diff.json'),JSON.stringify(dom.window.auditDiff,null,2));throw e;}
 assert.deepStrictEqual(errors,[]);result.jsdomErrors=errors;fs.writeFileSync(path.join(__dirname,'roundtrip-results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({games:result.games,loads:result.loads,renders:result.renders,emptyFlagDefaults:result.emptyFlagDefaults,jsdomErrors:errors},null,2));dom.window.close();
})().catch(e=>{console.error(e);process.exitCode=1});
