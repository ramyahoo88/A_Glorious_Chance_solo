// Run with NODE_PATH=../audit/dom-runtime/node_modules node probe.js /path/to/repo
// Actual shipped HTML and its DOM handlers, in jsdom (not a real browser).
const fs=require('fs'),path=require('path'),assert=require('assert');
const {JSDOM,VirtualConsole}=require('jsdom');
const repo=path.resolve(process.argv[2]),out=__dirname;
const html=fs.readFileSync(path.join(repo,'dist/index.html'),'utf8');
async function launch(storage){const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));const d=new JSDOM(html,{url:'https://current-save-audit.invalid/',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){if(storage)w.localStorage.setItem('agc_solo_companion_v1',storage)}});await new Promise(r=>d.window.addEventListener('load',r));return {d,w:d.window,doc:d.window.document,errors};}
const ev=(t,c)=>t.w.eval(c),state=t=>JSON.parse(ev(t,'JSON.stringify(G_STATE)'));
function btn(t,label,root=t.doc){const b=[...root.querySelectorAll('button')].find(b=>b.textContent===label);assert(b,'Missing button '+label);assert(!b.disabled,'Disabled '+label);b.click();return b;}
function change(t,el,value){el.value=value;el.dispatchEvent(new t.w.Event('change',{bubbles:true}));}
function start(t,seed=290001){change(t,t.doc.querySelector('input[type=number]'),String(seed));btn(t,'Start campaign');}
function advance(t){const p=state(t).prompt;if(p.kind==='choice'){const op=p.options.find(o=>!o.disabled);btn(t,op.label,t.doc.querySelector('#proc'));}else if(p.kind==='info')btn(t,'Continue',t.doc.querySelector('#proc'));else if(p.kind==='select'){let ok=t.doc.querySelector('#proc .opts button.primary');for(const cb of t.doc.querySelectorAll('#proc input[type=checkbox]')){if(!ok.disabled)break;cb.click();ok=t.doc.querySelector('#proc .opts button.primary');}assert(!ok.disabled);ok.click();}else throw Error('Unsupported '+p.kind);}
function importText(t,text){btn(t,'Load');change(t,t.doc.querySelector('#modal textarea'),text);btn(t,'Load pasted text',t.doc.querySelector('#modal'));}
(async()=>{const r={};
 // A normal control action creates a save that the app rejects after reload.
 const t=await launch();start(t);const original=state(t);btn(t,'Adjust');const step=t.doc.querySelector('#modal input[min="0"][max="3"]');assert(step);change(t,step,'1.5');btn(t,'Apply',t.doc.querySelector('#modal'));
 const broken=state(t),saved=t.w.localStorage.getItem('agc_solo_companion_v1');fs.writeFileSync(path.join(out,'S01_adjust_fractional_steps.json'),ev(t,'saveText()'));
 const reload=await launch(saved);btn(reload,'Continue it');r.fractionalAdjust={ship:'wolfe',steps:broken.ships.wolfe.steps,postReloadState:state(reload),message:reload.doc.querySelector('#app').textContent,errors:reload.errors};
 btn(t,'Close',t.doc.querySelector('#modal'));btn(t,'↶ Undo');r.fractionalAdjust.undoRestores=JSON.stringify(state(t))===JSON.stringify(original);t.d.window.close();reload.d.window.close();
 // Failed import autosave does not render the warning it just set.
 const a=await launch();start(a,290002);const incoming=ev(a,'saveText()');a.d.window.close();const b=await launch();start(b,290003);const previous=b.w.localStorage.getItem('agc_solo_companion_v1');ev(b,"Storage.prototype.setItem=function(){throw new Error('simulated storage refusal')}");importText(b,incoming);r.importStorageFailure={loadedSeed:state(b).seed,flag:ev(b,'UI.saveFailed'),headerWarns:b.doc.querySelector('#hdr').textContent.includes('Not autosaved'),diskStillPrevious:b.w.localStorage.getItem('agc_solo_companion_v1')===previous};b.d.window.close();
 // Malformed current saves remain atomic on rejection. Multiple pending choices should survive.
 const q=await launch();start(q,290004);advance(q);const good=state(q),goodSave=q.w.localStorage.getItem('agc_solo_companion_v1'),goodUndo=ev(q,'JSON.stringify(UNDO)');r.malformed={};for(const kind of ['fractionalSteps','badPc','badSupply','emptyStack']){const bad=JSON.parse(JSON.stringify(good));if(kind==='fractionalSteps')bad.ships.madison.steps=0.5;if(kind==='badPc')bad.calls.at(-1).pc='bad';if(kind==='badSupply')bad.supply.US=99;if(kind==='emptyStack'){bad.calls=[];bad.prompt=null;}importText(q,JSON.stringify({state:bad,undo:[]}));r.malformed[kind]={preserved:JSON.stringify(state(q))===JSON.stringify(good),autosavePreserved:q.w.localStorage.getItem('agc_solo_companion_v1')===goodSave,undoPreserved:ev(q,'JSON.stringify(UNDO)')===goodUndo,message:q.doc.querySelector('#modal').textContent};if(q.doc.querySelector('#modal').classList.contains('open'))btn(q,'Close',q.doc.querySelector('#modal'));else{fs.writeFileSync(path.join(out,'S04_empty_stack.json'),JSON.stringify({state:bad,undo:[]}));btn(q,'↶ Undo');}}
 q.d.window.close();fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(r,null,2));console.log(JSON.stringify(r,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
